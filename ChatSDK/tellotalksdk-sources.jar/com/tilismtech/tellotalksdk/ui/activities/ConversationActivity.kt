package com.tilismtech.tellotalksdk.ui.activities

import android.Manifest
import android.Manifest.permission.POST_NOTIFICATIONS
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Resources
import android.content.res.TypedArray
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.text.Html
import android.text.TextUtils
import android.util.Log
import android.util.TypedValue
import android.view.ActionMode
import android.view.Gravity
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.toColorInt
import androidx.core.view.GravityCompat
import androidx.core.view.isVisible
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.generic.RoundingParams
import com.facebook.drawee.view.SimpleDraweeView
import com.google.gson.GsonBuilder
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.AgentModel
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.Contact
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage.MsgType
import com.tilismtech.tellotalksdk.data.network.NetworkClient
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentDetailResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentListResponse
import com.tilismtech.tellotalksdk.data.repository.MessageReceiptRepository
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.ActivityConversationBinding
import com.tilismtech.tellotalksdk.events.DownloadFinishedEvent
import com.tilismtech.tellotalksdk.listeners.OnEmojiconClickedListener
import com.tilismtech.tellotalksdk.listeners.RecyclerItemClickListener
import com.tilismtech.tellotalksdk.managers.ChatManager.Companion.instance
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager
import com.tilismtech.tellotalksdk.packages.easypermissions.EasyPermissions
import com.tilismtech.tellotalksdk.packages.easypermissions.EasyPermissions.PermissionCallbacks
import com.tilismtech.tellotalksdk.packages.eventbus.EventBus
import com.tilismtech.tellotalksdk.packages.eventbus.Subscribe
import com.tilismtech.tellotalksdk.packages.eventbus.ThreadMode
import com.tilismtech.tellotalksdk.services.AudioService
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.ConversationMessageAdapter
import com.tilismtech.tellotalksdk.ui.customviews.EditMessage
import com.tilismtech.tellotalksdk.ui.customviews.WrapContentLinearLayoutManager
import com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.chatEndProcedure.ChatEndConfirmDialog
import com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.chatEndProcedure.RatingDialog
import com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.chatEndProcedure.RatingDialog.Companion.setYourInterface
import com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.listener.feedbackListener
import com.tilismtech.tellotalksdk.ui.emojis.utilities.Emoji
import com.tilismtech.tellotalksdk.ui.recordview.OnRecordListener
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.AndroidUtilities
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.changeStringColor
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.hideKeyboard
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isAppEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isNetworkAvailable
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL
import com.tilismtech.tellotalksdk.utils.Config
import com.tilismtech.tellotalksdk.utils.Constant
import com.tilismtech.tellotalksdk.utils.DownloadableFile
import com.tilismtech.tellotalksdk.utils.FileBackend
import com.tilismtech.tellotalksdk.utils.MessageUtils
import com.tilismtech.tellotalksdk.utils.TelloConfig
import com.tilismtech.tellotalksdk.utils.TelloMediaPlayer
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageForeGround
import com.tilismtech.tellotalksdk.utils.diffUtils.MessageDiffCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Date
import java.util.Timer
import java.util.TimerTask


class ConversationActivity : TelloActivity(), PermissionCallbacks, ActionMode.Callback,
    View.OnClickListener, feedbackListener, EditMessage.KeyboardListener,
    OnEmojiconClickedListener {

    //UI elements
    private lateinit var binding: ActivityConversationBinding
    private val viewModel = ConversationActivityViewModel.getInstance()
    lateinit var telloPrefs: TelloPreferencesManager
    private var toolbar: LinearLayout? = null
    private var ratingDialog: RatingDialog? = null
    private var actionClearHistory: MenuItem? = null
    private var actionChatEnd: MenuItem? = null
    private var actionCall: MenuItem? = null
    var actionMode: ActionMode? = null
        private set
    private var ta: TypedArray? = null

    //Keyboard
    private val keyboardButtons = ArrayList<ImageButton>()
    private var isMultiSelect = false
    private var keyboardSelectedIndex = 0
    private var selectedMesssages: HashMap<String?, TTMessage?>? = HashMap()

    //Data
    private lateinit var viewHolderUtils: ViewHolderUtils
    private var conversationAdapter: ConversationMessageAdapter? = null
    private var messages: ArrayList<TTMessage?>? = arrayListOf()
    private var agentDetailResponse: AgentDetailResponse? = null
    private var agentListResponses: AgentListResponse? = null
    private var contact: Contact? = null
    private var account: TTAccount? = null
    private var replyMessage: TTMessage? = null
    private var conversationId: String? = null
    private var conversationName: String? = null
    private var dptImage: String? = "null"
    private var currentConversation: TTConversation? = null
    private var chatID: String? = ""
    private var isCorporateChat = false
    private var departmentName: String? = ""
    private var departmentId: String? = ""
    private var isTwoWayDepartment = false
    private var isFirstMessage = true
    private var fromChatList = false
    private var customData: String? = ""
    private var isFromNotification = false
//    private var callClient: TelloVoipClient? = null
    private var enableJitsi: Boolean? = false
    private val gson = GsonBuilder().serializeNulls().create()

    private var pictureUri : Uri? = null
    private var videoUri : Uri? = null

    //Utils
    private var messageUtils: MessageUtils? = MessageUtils()

    //Listeners
    private var touchListener: RecyclerItemClickListener? = null
    private val handler = Handler()
    private val onEveryMinute: Runnable = object : Runnable {
        override fun run() {
            if (conversationAdapter != null) {
                (conversationAdapter as ConversationMessageAdapter).notifyItemRangeChanged(
                    0, (messages?.lastIndex ?: 0)
                )
                handler.postDelayed(this, TelloConfig.REFRESH_LAST_TIME.toLong())
            }
        }
    }

    private var networkChangeReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d("app", "Network connectivity change")
            val ni = intent.extras!![ConnectivityManager.EXTRA_NETWORK_INFO] as NetworkInfo?
            if (ni != null && ni.state == NetworkInfo.State.CONNECTED) {
                resendMessagesAgain(
                    TTMessageRepository.instance?.getAllUnsendMsg(conversationId) ?: listOf()
                )
            }
        }
    }

    private var pickMultipleMedia: ActivityResultLauncher<PickVisualMediaRequest> =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(5)) { uris ->
            if (uris.isNotEmpty()) {
                messageUtils?.manageMediaResult(this, uris){
                    it!!.putExtra("dptImage",dptImage)
                    it.putExtra("dptname",departmentName)
                    it.putExtra("agentObj",agentDetailResponse)
                    it.putExtra("contactJid",currentConversation?.contactJid)
                    it.putExtra("conversationMode",currentConversation?.mode)
                    attachmentActivityResult.launch(it)
                }
            }
        }

    private var takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                messageUtils?.managePhotoResult(this,pictureUri!!){
                    it!!.putExtra("dptImage",dptImage)
                    it.putExtra("dptname",departmentName)
                    it.putExtra("agentObj",agentDetailResponse)
                    it.putExtra("contactJid",currentConversation?.contactJid)
                    it.putExtra("conversationMode",currentConversation?.mode)
                    attachmentActivityResult.launch(it)
                }
            }
        }

    private val attachmentActivityResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            if(it.data!=null){
                messageUtils?.processAttachments(this,it.data!!,currentConversation?.contactJid)
            }
        }
    }

    private var recordVideo =
        registerForActivityResult(ActivityResultContracts.CaptureVideo()) { success ->
            if(success){
                messageUtils?.manageMediaResult(this,listOf(videoUri!!)){
                    it!!.putExtra("dptImage",dptImage)
                    it.putExtra("dptname",departmentName)
                    it.putExtra("agentObj",agentDetailResponse)
                    it.putExtra("contactJid",currentConversation?.contactJid)
                    it.putExtra("conversationMode",currentConversation?.mode)
                    attachmentActivityResult.launch(it)
                }
            }
        }

    private var pickFiles = registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null) {
            messageUtils?.manageFileResult(this, currentConversation?.contactJid, uri)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConversationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (intent.getBooleanExtra("notification", false)) {

        }
        setBindingAdapter()
        setAccount()
        initViews()
        initKeyboard()
        instance?.setActivity(this)
        manageIntent()
    }

    private fun initViews() {
        telloPrefs = TelloPreferencesManager.getInstance()
        toolbar = if (isAppEnglish) {
            binding.layLeft
        } else {
            binding.layRight
        }
        toolbar?.isVisible = true

        binding.tvSendMsg.setOnClickListener { //  binding.editMessage.setText(R.string.chat_start_text);
            sendMessageFromButton()
        }
        if (!EasyPermissions.hasPermissions(this, POST_NOTIFICATIONS)) {
            EasyPermissions.requestPermissions(
                this,
                "Notification permissions are required to notify you on new messages.",
                188,
                POST_NOTIFICATIONS
            )
        }
        viewModel.setTyping(false)

        if (instance?.isShowPreviousMessagesOnly() == true) {
            binding.keyboardPanel.visibility = View.GONE
            binding.sendUsAMessageView.visibility = View.GONE
        } else if (!instance!!.isShowLargeSendButton()) {
            binding.sendUsAMessageView.visibility = View.GONE
            binding.keyboardPanel.visibility = View.VISIBLE
            binding.editMessage.visibility = View.VISIBLE
        }
        binding.attachKeyboardBtn.setOnClickListener{
            keyboardSelectedIndex = if(keyboardSelectedIndex==0) 1 else 0
            onLanguageClick(keyboardSelectedIndex)
        }
        binding.attachCameraBtn.setOnClickListener {
            if (messageUtils?.checkCameraPermission(this,Config.ATTACHMENT_CHOICE_TAKE_PHOTO) == true) {
                pictureUri = FileBackend.instance?.takePhotoUri?:Uri.EMPTY
                takePicture.launch(pictureUri!!)
            }
        }
        binding.attachFileBtn.setOnClickListener {
            val mimeTypes = arrayOf(
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  // .doc & .docx
                "application/vnd.ms-powerpoint",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",  // .ppt & .pptx
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  // .xls & .xlsx
                "text/plain",
                "application/pdf",
                "application/zip"
            )

            pickFiles.launch(mimeTypes)
        }
        binding.attachImageBtn.setOnClickListener {
            if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(this)) {
                pickMultipleMedia.launch(
                    PickVisualMediaRequest.Builder()
                        .setMediaType(ActivityResultContracts.PickVisualMedia.ImageAndVideo).build()
                )
            }
        }

        binding.attachVideoBtn.setOnClickListener {
            if(messageUtils?.checkCameraPermission(this,Config.ATTACHMENT_CHOICE_RECORD_VIDEO) == true){
                videoUri = FileBackend.instance?.takeVideoUri?:Uri.EMPTY
                recordVideo.launch(videoUri!!)
            }
        }
    }


    private fun initKeyboard() {
        binding.editMessage.setOnClickListener {
            binding.attachmentButtonsContainer.isVisible = false
            binding.editMessage.isFocusableInTouchMode = true
            binding.editMessage.requestFocus()
            val inputMethodManager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager?
            inputMethodManager?.showSoftInput(binding.editMessage, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun setAccount() {
        account = TelloApiClient.getInstance()!!.getAccount()
        if (account == null) {
            finish()
            return
        }
    }

    private fun fetchAgentList() {
        instance!!.getAgentList(intent.getStringExtra("departmentId")) {
            agentListResponses = it
            if (agentListResponses?.agentList?.isNotEmpty() == true) {
                for (i in (agentListResponses?.agentList ?: listOf()).indices) {
                    val v = layoutInflater.inflate(R.layout.agents_view, null)
                    if (i == 1) {
                        setParamToView(v, 50)
                    } else if (i == 2) {
                        setParamToView(v, 100)
                    } else if (i == 3) {
                        setParamToView(v, 150)
                    }
                    val draweeView = v.findViewById<SimpleDraweeView>(R.id.im_agent)
                    setImageDetails(draweeView)
                    draweeView.setImageURI(
                        isStringContainURL(
                            agentListResponses!!.agentList[i].agentAvatar ?: ""
                        )
                    )
                    binding.layAgentsView.addView(v)
                }
                binding.layAgentlistView.visibility = View.VISIBLE
                binding.layAgentsView.visibility = View.VISIBLE
                binding.layMsg.visibility = View.VISIBLE
                binding.tvTime.text = agentListResponses?.expectedTime
            } else {
                binding.layAgentlistView.visibility = View.GONE
                binding.tvConnectingMsg.text = agentListResponses?.expectedTime
                binding.layAgentsView.visibility = View.GONE
                binding.layMsg.visibility = View.GONE
            }
        }
    }

    private fun setImageDetails(draweeView: SimpleDraweeView) {
        draweeView.hierarchy.roundingParams = RoundingParams().setRoundAsCircle(true)
        draweeView.hierarchy.setPlaceholderImage(R.drawable.image_circle)
    }

    private fun setParamToView(v: View, margin: Int) {
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(margin, 0, 0, 0)
        v.layoutParams = params
    }

    private fun setBindingAdapter() {
        invalidateOptionsMenu()
        viewHolderUtils = ViewHolderUtils.instance!!
        viewHolderUtils.setActivity(this)
        viewHolderUtils.setCurrentConversation(currentConversation)
        if (selectedMesssages == null) {
            selectedMesssages = HashMap()
            removeMultiSelect()
        }
        viewHolderUtils.selectedMessages = selectedMesssages
        viewHolderUtils.account = account
        if (conversationAdapter != null) {
            viewHolderUtils.adapter = conversationAdapter
        }
    }

    private fun updateDateTag(messageList: List<TTMessage?>) {
        var oldDateMessage: TTMessage? = null
        for (i in messageList.indices) {
            val message = messageList[i]
            if ((message?.msgType == MsgType.TYPE_DATE.value)) {
                if (oldDateMessage != null && (oldDateMessage.msgType == message.msgType)) {
                    viewModel.deleteMessage(message)
                    return
                } else {
                    oldDateMessage = message
                }
            }
        }
    }

    private fun removeDateTag(messageList: List<TTMessage?>?) {
        var oldDateMessage: TTMessage? = null
        for (i in messageList!!.indices) {
            val message = messageList[i]
            if ((message?.msgType == MsgType.TYPE_DATE.value)) {
                if (oldDateMessage != null && (oldDateMessage.msgType == message.msgType)) {
                    viewModel.deleteMessage(oldDateMessage)
                    return
                } else {
                    oldDateMessage = message
                }
            }
        }
    }

    private fun manageIntent() {
        val intentFilter = IntentFilter()
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        registerReceiver(networkChangeReceiver, intentFilter)
        var reFreshUi = false
        if (intent.extras != null) {
            if (intent.extras != null && intent.extras!!.containsKey("conversationId")) {
                val convId = intent.getStringExtra("conversationId")
                if (isEmptyString(conversationId) || (!isEmptyString(conversationId) && !convId.equals(
                        conversationId, ignoreCase = true
                    ))
                ) {
                    reFreshUi = true
                }
                if (intent.hasExtra("conversationName")) {
                    conversationName =
                        intent.getStringExtra("conversationName").toString().replace("+", "")
                    if (isEmptyString(conversationName) || (!isEmptyString(conversationName) && !convId.equals(
                            conversationName, ignoreCase = true
                        ))
                    ) {
                        reFreshUi = true
                    }
                }
                if (intent.hasExtra("isTwoWayDepartment")) {
                    isTwoWayDepartment = intent.getBooleanExtra("isTwoWayDepartment", false)
                }
                if (intent.hasExtra("isFromNotification")) {
                    isFromNotification = intent.getBooleanExtra("isFromNotification", false)
                    val broadcastFrom = intent.getStringExtra("departmentId")
                    val message_id = intent.getStringExtra("message_id")
                    val message_type = intent.getStringExtra("message_type")
                    val campaignId = intent.getStringExtra("campaignId")
                    if (isFromNotification && !isTwoWayDepartment) {
                        instance!!.onNotificationClicked(
                            message_id, broadcastFrom, message_type, campaignId
                        )
                    }
                }
                departmentId = intent.getStringExtra("departmentId")
                if (intent.hasExtra("dptImage")) {
                    dptImage = intent.getStringExtra("dptImage")
                }
                if (intent.hasExtra("isCorporateChat")) {
                    isCorporateChat = intent.extras!!.getBoolean("isCorporateChat", false)
                    departmentName = intent.extras!!.getString("departmentName", "")
                }
                if (intent.hasExtra("chatID")) {
                    chatID = intent.extras!!.getString("chatID")
                }
                conversationId = convId
                currentConversation = TTConversationRepository.getInstance()
                    .getConversationForJid(departmentId)
                if (currentConversation == null) {
                    finish()
                }
                fromChatList = intent.getBooleanExtra("fromChatList", false)
                viewHolderUtils.setCurrentConversation(currentConversation)
                updateCurrentConversation()
            }
            if (intent.extras!!.containsKey("customData")) {
                customData = intent.extras!!.getString("customData", "")
            } else if (customData == null) {
                customData = ""
            }
        }
        if (reFreshUi) {
            manageUi()
        }
        if (isTwoWayDepartment) {
            if (!fromChatList) {
                TelloApiClient.getInstance()!!.isTelloUi = true
            }
            setChatId()
        } else {
            instance?.stopEvent(NetworkClient.TYPING_EVENTS)
            annoucementPolling.schedule(object : TimerTask() {
                override fun run() {
                    instance!!.getMessageAnnouncement(isCorporateChat, conversationId)
//                        ChatManager.instance!!.sendAnnouncementReadAck(currentConversation!!.contactJid)

                    updateCurrentConversation()
                }
            }, 0, 3000)
        }
    }

    private val annoucementPolling = Timer()

    private fun setChatId() {
        val lastMessage = TTMessageRepository.instance?.getLastMessageOfConversation(conversationId)
        if (lastMessage != null && lastMessage.msgType != MsgType.TYPE_CHATEND.value) {
            chatID = lastMessage.chatId
            refreshChat()
        } else {
            chatID = ""
        }
        instance!!.listenToMessages(isCorporateChat)
        telloPrefs.putString("chatid", chatID)
    }


    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        return isTwoWayDepartment
    }

    override fun onResume() {
        super.onResume()
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this)
        }
        if (departmentName != null && departmentName != "") {
            (toolbar!!.findViewById<View>(R.id.action_bar_title) as TextView).text = departmentName
        }
        instance!!.clearNotification(currentConversation)
        handler.postDelayed(onEveryMinute, TelloConfig.REFRESH_LAST_TIME.toLong())
        if (isTwoWayDepartment) {
            onLanguageClick(keyboardSelectedIndex)
        }
        if (isTwoWayDepartment) {
            val i = if ((isAppEnglish)) 0 else 1
            onLanguageClick(i)
        }
        refreshChat()
        if (currentConversation != null) {
            TelloApiClient.getInstance()?.setmCurrentConversationOpen(currentConversation)
        }
    }

    private fun refreshChat() {
        if (currentConversation != null) {
            instance!!.clearNotification(currentConversation)
            if (TelloApiClient.getInstance()!!.isTelloUi) {
                instance!!.sendWebReadAck(agentDetailResponse?.agentId)
            }
            updateCurrentConversation()
        }
    }

    private fun updateCurrentConversation() {
        if(departmentId!=null && departmentId?.isNotEmpty()==true){
            TTMessageRepository.instance?.resetReadCountForDepartment(departmentId!!)
        }
        currentConversation?.unreadCount = 0
        TTConversationRepository.getInstance().updateConversation(currentConversation)
        TelloApiClient.getInstance()?.setmCurrentConversationOpen(currentConversation)
    }

    private fun populateMessages(messageList: List<TTMessage?>?) {
        val list = messageList?.filter { it?.contactId == conversationId } as ArrayList<TTMessage?>? ?: arrayListOf()
        runOnUiThread {
            if(list.lastOrNull()?.profileId=="chatbot"){
                hideKeyboard(this@ConversationActivity,binding.editMessage)
            }
            updateDateTag(list)
            if (list.isNotEmpty() && (list.lastOrNull()?.msgType == MsgType.TYPE_DATE.value)) {
                setLastMessage(list.findLast { it?.msgType != MsgType.TYPE_DATE.value })
                viewModel.deleteMessage(list.last())
                return@runOnUiThread
            }
            if (isTyping) {
                var typingMsg = viewModel.getTypingMessageFromDB("TYPING_MESSAGE")
                if (typingMsg == null) {
                    typingMsg = TTMessage()
                    typingMsg.systemDate = Date().apply { time = System.currentTimeMillis() + 1000 }
                    viewModel.insertMessage(typingMsg)
                }
                typingMsg.contactId = account?.userName
                typingMsg.msgType = MsgType.TYPE_TYPING.value
                typingMsg.messageId = "TYPING_MESSAGE"
                typingMsg.agentAvatar = agentDetailResponse?.avatar
                list.removeAll { it?.msgType == MsgType.TYPE_TYPING.value }
                list.add(typingMsg)
            } else {
                val typingMsg = list.find { it?.msgType == MsgType.TYPE_TYPING.value }
                viewModel.deleteMessage(typingMsg)
                list.removeAll { it?.msgType == MsgType.TYPE_TYPING.value }
            }
            val diffResult: DiffUtil.DiffResult =
                DiffUtil.calculateDiff(MessageDiffCallback(messages, list))
            diffResult.dispatchUpdatesTo((conversationAdapter)!!)
            val currentSize: Int = messages?.size ?: 0
            prepareList(list)
            if (list.size != currentSize) {
                binding.recyclerView.scrollToPosition(messages?.lastIndex ?: 0)
                binding.recyclerView.smoothScrollBy(0, binding.recyclerView.height, {
                    0f
                }, 300)
            }
            if (instance?.isShowPreviousMessagesOnly() == false) {
                togglePanelsVisibility(list)
                toggleFeedbackPanel(list)
                toggleMenuItemsVisibility(list)
                setAllMsgRead(list)
            }
        }
    }

    private var isTyping = false

    private fun manageUi() {
        initUi()
        initToolbar()
        attachmentInit()
        initMessagesList(messages)
        viewModel.getAllMessagesFromDb(
            conversationId, isTwoWayDepartment, 0
        ).observe(this@ConversationActivity) {
            Log.e("OBSERVER", "in getAllMessagesFromDb")
            val lastAgentMsg =
                it.lastOrNull { it.msgStatus == TTMessage.MsgStatus.RECEIVED && it.chatId == chatID && it.conversationId == it.receiverId && it.chatbotID == null }

            if (lastAgentMsg != null && it.size > (messages?.size
                    ?: 0) && lastAgentMsg.profileId?.lowercase() != "chatbot" && lastAgentMsg.profileId?.lowercase() != "system" && lastAgentMsg.receiverId == account?.userName
            ) {
                getAgentDetails(lastAgentMsg)
            }
            populateMessages(it)
        }
        viewModel.typingMessages().observe(this@ConversationActivity) {
            Log.e("OBSERVER", "in typingMessages")
            isTyping = it
            populateMessages(messages)
        }

        binding.layBack.setOnClickListener {
            if (binding.drawerLayout.isDrawerVisible(GravityCompat.START)) {
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                binding.drawerLayout.openDrawer(GravityCompat.START)
            }
        }
        toolbar!!.findViewById<View>(R.id.action_bar_endchat).setOnClickListener(this)
        touchListener = RecyclerItemClickListener(
            this,
            binding.recyclerView,
            actionMode,
            object : RecyclerItemClickListener.OnItemClickListener {
                override fun onItemClick(view: View, position: Int) {
                    if (position < 0) {
                        return
                    }
                    val message: TTMessage? = messages?.get(position)
                    if (isMultiSelect) {
                        if ((message?.msgType == MsgType.TYPE_DELETED.value) || (message?.msgType == MsgType.TYPE_CHATEND.value) || (message?.msgType == TTMessage.MsgStatus.RECEIVED.name) || (message?.msgType == MsgType.TYPE_DATE.value) || (message?.msgType == MsgType.TYPE_UNREAD.value)) {
                            return
                        }
                        if (actionMode == null) {
                            actionMode =
                                binding.layToolbar.findViewById<View>(R.id.conversation_toolbar)
                                    .startActionMode(this@ConversationActivity) //show ActionMode.
                            touchListener!!.setActionMode(actionMode)
                        }
                        multiSelect(position)
                        conversationAdapter!!.notifyDataSetChanged()
                    }
                }

                override fun onItemLongClick(view: View, position: Int) {
                    if (position < 0) {
                        return
                    }
                    val message: TTMessage? = messages?.get(position)
                    if (!isMultiSelect) {
                        isMultiSelect = true
                        if ((message?.msgType == MsgType.TYPE_DELETED.value) || (message?.msgType == MsgType.TYPE_CHATEND.value) || (message?.msgType == TTMessage.MsgStatus.RECEIVED.name) || (message?.msgType == MsgType.TYPE_DATE.value) || (message?.msgType == MsgType.TYPE_UNREAD.value)) {
                            isMultiSelect = false
                            return
                        }
                        if (actionMode == null) {
                            actionMode =
                                binding.layToolbar.findViewById<View>(R.id.conversation_toolbar)
                                    .startActionMode(this@ConversationActivity) //show ActionMode.
                            touchListener!!.setActionMode(actionMode)
                        }
                    }
                    multiSelect(position)
                    conversationAdapter?.notifyDataSetChanged()
                }
            })
        binding.recyclerView.addOnItemTouchListener(touchListener!!)
    }

    var offset = 0

    private fun toggleMenuItemsVisibility(messageList: List<TTMessage?>?) {
        if (actionChatEnd == null) return
        if (messageList!!.isEmpty()) {
            actionChatEnd!!.isVisible = false
            actionCall!!.isVisible = false
            return
        }
        val lastMessage = messageList[messageList.size - 1]
        val isChatEnd = (lastMessage?.msgType == MsgType.TYPE_CHATEND.value)
        actionChatEnd!!.isVisible = !isChatEnd
        if (isChatEnd) {
            actionCall?.isVisible = false
//            callClient?.onDestroy(this)
        }
    }

    private fun toggleFeedbackPanel(messageList: List<TTMessage?>) {
        if (messageList.isEmpty()) return
        val lastMessage = messageList.lastOrNull()
        val isChatEnded = (lastMessage?.msgType == MsgType.TYPE_CHATEND.value)
        val isFeedbackTaken = lastMessage?.isFeedback
        if (isChatEnded && isFeedbackTaken == false) {
            if (ratingDialog == null) openRatingDialog(lastMessage.apply {
                chatId = messageList.last { it?.chatId?.isNotEmpty() == true }?.chatId
            })
        }
    }

    private fun togglePanelsVisibility(messageList: List<TTMessage?>) {
        if (!isTwoWayDepartment) {
            binding.keyboardPanel.visibility = View.GONE
            binding.sendUsAMessageView.visibility = View.GONE
            binding.layAgents.visibility = View.GONE
            return
        }
        if (messageList.isEmpty()) {
            binding.sendUsAMessageView.isVisible = instance!!.isShowLargeSendButton() == true
            binding.keyboardPanel.isVisible = !instance!!.isShowLargeSendButton()
            binding.layAgents.visibility = View.GONE
        } else {
            val lastMessage = messageList[messageList.size - 1]
            var lastIncomingMessage: TTMessage? = null
            for (i in messageList.indices.reversed()) {
                val message = messageList[i]
                val isIncomingMessage =
                    (message?.msgStatus?.name == TTMessage.MsgStatus.RECEIVED.name)
                if (isIncomingMessage) {
                    lastIncomingMessage = message
                    break
                }
            }
            val isChatEnded =
                (messageList[messageList.size - 1]?.msgType == MsgType.TYPE_CHATEND.value)
            val isTalkToAgent = (lastMessage?.chatbotNode != null) && (gson.fromJson(
                lastMessage.chatbotNode, ChatbotNode::class.java
            )?.type == "agent")
            val isLastIncomingMessageChatBotOrChatEnd =
                lastIncomingMessage != null && ((lastIncomingMessage.msgType == MsgType.TYPE_CHATEND.value) || (lastIncomingMessage.msgType == MsgType.TYPE_CHATBOT.value))
            val hasIncomingMessage = lastIncomingMessage != null
            if (isChatEnded) {
                binding.sendUsAMessageView.isVisible = instance!!.isShowLargeSendButton()
                binding.keyboardPanel.isVisible = !instance!!.isShowLargeSendButton()
                binding.layAgents.visibility = View.GONE
            } else if (isTalkToAgent) {
                binding.sendUsAMessageView.visibility = View.GONE
                binding.keyboardPanel.visibility = View.GONE
                binding.layAgents.visibility = View.VISIBLE
                fetchAgentList()
            } else if (hasIncomingMessage && !isLastIncomingMessageChatBotOrChatEnd) {
                binding.sendUsAMessageView.visibility = View.GONE
                binding.keyboardPanel.visibility = View.VISIBLE
                binding.layAgents.visibility = View.GONE
            } else {
                binding.sendUsAMessageView.visibility = View.GONE
                binding.keyboardPanel.visibility = View.GONE
                binding.layAgents.visibility = View.GONE
            }
        }
    }

    private fun setMsg() {
        val lastMsg = TTMessageRepository.instance?.getLastMessageOfConversation(conversationId)
        if (intent.hasExtra("msg") && (lastMsg?.msgType == MsgType.TYPE_CHATEND.value || lastMsg == null)) {
            val msg = intent.getStringExtra("msg")
            if (instance?.isShowBundledText() == true) {
                binding.editMessage.setText(msg)
            } else {
                binding.editMessage.tag = msg + if(instance?.isShowLargeSendButton()==false)"\n\n" else ""
            }
        }
    }

    private fun setAllMsgRead(messageList: List<TTMessage?>) {
        for (message: TTMessage? in messageList) {
            if (message?.isRead_count == true) {
                message.isRead_count = false
                viewModel.updateMessage(message)
            }
        }
        if (messageList.isNotEmpty()) {
            val lastMsg = TTMessageRepository.instance?.getMessage(
                TTConversationRepository.getInstance()
                    .getConversationForJid(conversationId.toString())?.lastMessageId
            )
            if (lastMsg?.msgType != MsgType.TYPE_CHATEND.value && lastMsg?.msgType != MsgType.TYPE_DATE.value) {
                if (TTMessageRepository.instance?.getLastMessageOfConversation(
                        conversationId
                    )?.msgType != MsgType.TYPE_CHATEND.value
                ) {
                    chatID = TTMessageRepository.instance?.getLastMessageOfConversation(
                        conversationId
                    )?.chatId
                } else {
                    chatID = ""
                }
            }
        }
    }

    private fun setAgentDetail(agentModel: AgentModel?) {
        binding.tvAgentName.text =
            if (isAppEnglish) agentModel?.agentName else agentModel?.agentName_U
        binding.tvAgentStatus.text = agentModel?.status
        binding.agentOtherDetails.removeAllViews()
        val dp = Resources.getSystem().displayMetrics.density.toInt()
        agentModel?.otherDetails?.forEach {
            val tvLabel = TextView(this).apply {
                text = it?.label
                isSingleLine = true
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                ellipsize = TextUtils.TruncateAt.END
                setTextColor("#A9ACB6".toColorInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                val face = ResourcesCompat.getFont(this@ConversationActivity, R.font.calibri)
                setTypeface(face, Typeface.BOLD)
                setPadding(10 * dp, 15 * dp, 10 * dp, 5 * dp)
            }
            val tvValue = TextView(this).apply {
                text = it?.value
                isSingleLine = true
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                ellipsize = TextUtils.TruncateAt.END
                setTextColor("#000000".toColorInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                val face = ResourcesCompat.getFont(this@ConversationActivity, R.font.calibri)
                setTypeface(face, Typeface.BOLD)
                setPadding(10 * dp, 0, 10 * dp, 5 * dp)
            }
            val view = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    2 * dp
                ).apply {
                    marginStart = 10 * dp
                    marginEnd = 10 * dp
                }
                setBackgroundColor("#F2F2F8".toColorInt())
            }
            binding.agentOtherDetails.addView(tvLabel)
            binding.agentOtherDetails.addView(tvValue)
            binding.agentOtherDetails.addView(view)
        }

        setImageDetails(binding.imgAgent)
        toolbar?.findViewById<View>(R.id.action_bar_subtitle)?.visibility = View.VISIBLE
        (toolbar?.findViewById<View>(R.id.action_bar_subtitle) as TextView).text = departmentName
        (toolbar!!.findViewById<View>(R.id.action_bar_title) as TextView).text =
            if (isAppEnglish) agentModel?.agentName else agentModel?.agentName_U
        setImageDetails(toolbar!!.findViewById(R.id.action_bar_image))
        (toolbar!!.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView).setImageURI(
            isStringContainURL(agentModel?.agentAvatar ?: "")
        )
        binding.imgAgent.setImageURI(isStringContainURL(agentModel?.agentAvatar ?: ""))
        enableJitsi =
            telloPrefs.getString("jitsi").toBooleanStrictOrNull()

        if (enableJitsi == true) {
            actionCall?.isVisible = true
//            callClient = TelloVoipClient.Builder().setActivity(this)
//                .setReceiverId(account?.userName ?: "")
//                .setReceiverDisplayName(account?.displayName ?: "")
//                .setCallerId(agentDetailResponse?.agentId ?: "")
//                .setCallerDisplayName(agentDetailResponse?.profileName ?: "")
//                .setRingtone(R.raw.jitsi_call)
//                .setAuthParams(TelloApiClient.getInstance()?.authParams ?: "").build()
        }
    }

    private fun getAgentDetails(message: TTMessage) {
        instance!!.getAgentDetails(message.profileId) { it: AgentDetailResponse? ->
            if (it != null) {
                agentDetailResponse = it
                telloPrefs
                    .putString(message.chatId, gson.toJson(agentDetailResponse))
                getInstance()?.insertAgent(
                    AgentModel(
                        agentDetailResponse!!.agentId ?: "",
                        agentDetailResponse!!.profileName ?: "",
                        agentDetailResponse!!.profileName_U ?: "",
                        agentDetailResponse!!.avatar ?: "",
                        agentDetailResponse!!.status ?: "",
                        agentDetailResponse!!.otherDetails
                    )
                )
                setAgentDetail(getInstance()?.getAgent(it.agentId ?: ""))
            }
        }
    }

    private fun prepareList(messageList: List<TTMessage?>) {
        messages?.clear()
        if (!isTwoWayDepartment) {
            for (ttMessage: TTMessage? in messageList) {
                if (ttMessage?.msgExpTime == null) {
                    messages?.add(ttMessage)
                } else {
                    if ((ttMessage.msgExpTime?.time ?: 0L) > System.currentTimeMillis()) {
                        messages?.add(ttMessage)
                    }
                }
            }
            if (messages?.size == 1) {
                deleteDateMsg(messages)
            } else {
                removeDateTag(messages)
            }
        } else {
            messages?.addAll(messageList)
        }
        if(messages?.isEmpty()==true){
            isFirstMessage = true
        }else{
            if(messages?.lastOrNull()?.msgType== MsgType.TYPE_CHATEND.value){
                isFirstMessage = true
            }else{
                isFirstMessage = false
            }
        }
    }

    private fun deleteDateMsg(messageList: List<TTMessage?>?) {
        if (messageList!!.isNotEmpty() && (messageList.last()?.msgType == MsgType.TYPE_DATE.value)) {
            setLastMessage(if (messageList.size > 1) messageList[messageList.size - 2] else null)
            viewModel.deleteMessage(messageList[messageList.size - 1])
        }
    }

    private fun openRatingDialog(ttMessage: TTMessage?) {
        val bundle = Bundle()
        bundle.putParcelable(Constant.ttmessage, ttMessage)
        bundle.putParcelable(Constant.agentDetailResponse, agentDetailResponse)
        ratingDialog = RatingDialog.newInstance(bundle)
        setYourInterface(this)
        ratingDialog!!.show(supportFragmentManager, Constant.ConfirmDialog)
    }

    private fun resendMessagesAgain(messages: List<TTMessage>) {
        for (message: TTMessage in messages) {
            if (message.chatId != null) {
                var chatbotChild: ChatbotChild? = null
                if (message.chatbotNode != null) {
                    for (child: ChatbotChild? in gson.fromJson(
                        message.chatbotNode, ChatbotNode::class.java
                    )?.children ?: listOf()) {
                        if ((child?.name == message.message)) {
                            chatbotChild = child
                            break
                        }
                    }
                    instance!!.resendChatbotMsg(message, chatbotChild)
                    { Log.d("Resend", "" + message.message) }
                } else if (message.msgStatus != TTMessage.MsgStatus.ERROR) {
                    resendMessage(message)
                }
            }
        }
    }

    fun setLastMessage(message: TTMessage?) {
        if (currentConversation == null) {
            currentConversation = TTConversationRepository.getInstance().getConversationForJid(
                message?.departmentId ?: ""
            )
            if (currentConversation == null) {
                return
            }
        }
        currentConversation!!.lastMessage = message
        currentConversation!!.lastMessageId = message?.messageId ?: ""
        TTConversationRepository.getInstance().updateConversation(currentConversation)
    }

    private fun initMessagesList(messageList: List<TTMessage?>?) {
        messages = ArrayList(messageList ?: listOf())
        val wrapContentLinearLayoutManager = WrapContentLinearLayoutManager(this)
        wrapContentLinearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        wrapContentLinearLayoutManager.stackFromEnd = true
        binding.recyclerView.layoutManager = wrapContentLinearLayoutManager
        conversationAdapter = ConversationMessageAdapter(this, messages, viewHolderUtils)
        viewHolderUtils.adapter = conversationAdapter
//        binding.recyclerView.setItemViewCacheSize(messageList?.size ?: 10)
        binding.recyclerView.adapter = conversationAdapter
    }

    private fun initToolbar() {
        setSupportActionBar(toolbar!!.findViewById(R.id.conversation_toolbar))
        toolbar!!.findViewById<View>(R.id.back_action_button)
            .setOnClickListener { v: View? -> onBackPressed() }

        (toolbar!!.findViewById<View>(R.id.action_bar_title) as TextView).text = departmentName
        toolbar!!.findViewById<View>(R.id.action_bar_subtitle).visibility = View.GONE
        loadImage()
        invalidateOptionsMenu()
    }

    private fun openConfirmDialog() {
        if ((chatID == "")) {
            chatID =
                TTMessageRepository.instance?.getLastMessageOfConversation(conversationId)?.chatId
        }
        val bundle = Bundle()
        bundle.putString(Constant.chatID, chatID)
        bundle.putString(Constant.conversationID, conversationId)
        val myFragment = ChatEndConfirmDialog.newInstance(bundle)
        supportFragmentManager.setFragmentResultListener(
            "chat_end_request",
            this
        ) { requestKey, result ->
            if (requestKey == "chat_end_request") {
                agentDetailResponse = null
                telloPrefs
                    .putString(chatID, "")
                chatID = ""
                isFirstMessage = true
            }
        }

        myFragment.show(supportFragmentManager, Constant.ConfirmDialog)
    }

    private fun loadImage() {
        (toolbar!!.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView).hierarchy.setPlaceholderImage(
            R.drawable.image_circle
        )
        (toolbar!!.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView).hierarchy.roundingParams =
            RoundingParams().setRoundAsCircle(true)
        (toolbar!!.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView).setImageURI(
            dptImage
        )
        toolbar!!.findViewById<View>(R.id.actionbar_title_panel)
            .setOnClickListener {
                if (messages?.isNotEmpty() == true) {
                    if (messages?.last()?.msgType != MsgType.TYPE_CHATEND.value && agentDetailResponse != null) {
                        if (binding.drawerLayout.isDrawerVisible(GravityCompat.START)) {
                            binding.drawerLayout.closeDrawer(GravityCompat.START)
                        } else {
                            binding.drawerLayout.openDrawer(GravityCompat.START)
                        }
                    }
                }
            }
    }

    private fun initUi() {
        binding.sendMessageBtn.setOnClickListener(this)
        initRecordView()
        binding.editMessage.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
        binding.editMessage.inputType =
            binding.editMessage.inputType or EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES or EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE
        binding.editMessage.isSingleLine = false
        binding.editMessage.maxLines = 4
        binding.editMessage.isFocusableInTouchMode = false
        binding.editMessage.gravity = Gravity.CENTER_VERTICAL
        binding.editMessage.setHintTextColor(-0x4d4d4e)
        binding.editMessage.setKeyboardListener(this)
    }

    private fun initRecordView() {
        //IMPORTANT
        binding.recordAudioBtn.setRecordView(binding.recordAudioView)
        //Cancel Bounds is when the Slide To Cancel text gets before the timer . default is 130
        binding.recordAudioView.cancelBounds = 130f
        binding.recordAudioView.isSoundEnabled = false
        //prevent recording under one Second
        binding.recordAudioView.setLessThanSecondAllowed(false)
        binding.recordAudioView.setSlideToCancelText(getString(R.string.cancel_audio_sdk))
        binding.recordAudioView.setCustomSounds(R.raw.record_start, R.raw.record_finished, 0)
        binding.recordAudioView.setOnRecordListener(object : OnRecordListener {
            override fun onStart() {
                if (VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                    val permissions = arrayOf(Manifest.permission.RECORD_AUDIO)
                    if (!EasyPermissions.hasPermissions(this@ConversationActivity, *permissions)) {
                        var permissionText: String =
                            Html.fromHtml(getString(R.string.record_storage_permission)).toString()
                        if (EasyPermissions.hasPermissions(
                                this@ConversationActivity, Manifest.permission.RECORD_AUDIO
                            )
                        ) {
                            permissionText =
                                Html.fromHtml(getString(R.string.record_permission)).toString()
                        } else if (EasyPermissions.hasPermissions(
                                this@ConversationActivity, Manifest.permission.READ_EXTERNAL_STORAGE
                            )
                        ) {
                            permissionText =
                                Html.fromHtml(getString(R.string.storage_permission)).toString()
                        }
                        EasyPermissions.requestPermissions(
                            this@ConversationActivity,
                            (permissionText),
                            REQUEST_RECORD_AUDIO,
                            *permissions
                        )
                        return
                    }
                } else {
                    val permissions = arrayOf(Manifest.permission.RECORD_AUDIO)
                    if (!EasyPermissions.hasPermissions(this@ConversationActivity, *permissions)) {
                        var permissionText: String =
                            Html.fromHtml(getString(R.string.record_storage_permission)).toString()
                        if (EasyPermissions.hasPermissions(
                                this@ConversationActivity, Manifest.permission.RECORD_AUDIO
                            )
                        ) {
                            permissionText =
                                Html.fromHtml(getString(R.string.record_permission)).toString()
                        }
                        EasyPermissions.requestPermissions(
                            this@ConversationActivity,
                            (permissionText),
                            REQUEST_RECORD_AUDIO,
                            *permissions
                        )
                        return
                    }
                }
                startRecording()
            }

            override fun onCancel() {
                AudioService.instance?.stopRecorder()
            }

            override fun onFinish(recordTime: Long) {
                binding.recordAudioView.visibility = View.GONE
                binding.textContainer.visibility = View.VISIBLE
                //       binding.attachmentsContainer.setVisibility(VISIBLE);
                if (!isNetworkAvailable(this@ConversationActivity)) {
                    Toast.makeText(
                        this@ConversationActivity,
                        getString(R.string.no_internet_sdk),
                        Toast.LENGTH_SHORT
                    ).show()
                    return
                }
                val filePath = AudioService.instance?.stopRecorder()
                val file = File(filePath)
                if (file.exists()) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(file.absolutePath)
                        val timeInmillisec =
                            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!
                                .toLong()
                        if (timeInmillisec < 5000 && isFirstMessage) {
                            Toast.makeText(
                                this@ConversationActivity,
                                getString(R.string.audio_too_short_sdk),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            if (isFirstMessage) {
                                initiateChat {
                                    prepareMessage(null, null, MsgType.TYPE_TEXT.value)
                                    messageUtils!!.attachFileToConversation(
                                        this@ConversationActivity,
                                        currentConversation!!.contactJid,
                                        FileBackend.getUriForFile(this@ConversationActivity, file),
                                        filePath,
                                        ""
                                    )
                                }
                            } else {
                                messageUtils!!.attachFileToConversation(
                                    this@ConversationActivity,
                                    currentConversation!!.contactJid,
                                    FileBackend.getUriForFile(this@ConversationActivity, file),
                                    filePath,
                                    ""
                                )
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            override fun onLessThanSecond() {
                binding.recordAudioView.visibility = View.GONE
                binding.textContainer.visibility = View.VISIBLE
                AudioService.instance?.releaseRecorder()
            }
        })
        binding.recordAudioView.setOnBasketAnimationEndListener({
            binding.recordAudioView.visibility = View.GONE
            binding.textContainer.visibility = View.VISIBLE
        })
    }

    private fun startRecording() {
        binding.recordAudioView.visibility = View.VISIBLE
        binding.textContainer.visibility = View.GONE
        AudioService.instance?.startRecorder("AUD-" + System.currentTimeMillis() + ".m4a")
        onMoreOptionsClick()
    }

    private fun onMoreOptionsClick() {}
    fun removeMultiSelect() {
        val it: MutableIterator<MutableMap.MutableEntry<String?, TTMessage?>>? =
            selectedMesssages?.entries?.iterator()
        while (it?.hasNext() == true) {
            val pair = it.next()
            val message = pair.value
            it.remove()
            val i = messages?.indexOf(message) ?: 0
            val viewHolderForAdapterPosition =
                binding.recyclerView.findViewHolderForAdapterPosition(i)
            if (viewHolderForAdapterPosition != null) {
                viewHolderForAdapterPosition.itemView.setMessageForeGround(message)
            } else {
                if ((i ?: 0) >= 0) {
                    conversationAdapter!!.notifyItemChanged(i)
                }
            }
        }
        selectedMesssages!!.clear()
        if (actionMode != null) {
            actionMode!!.title = "" //remove item count from action mode.
            actionMode!!.finish()
            actionMode = null
        }
        if (touchListener != null) {
            touchListener!!.setActionMode(null)
        }
    }

    private fun multiSelect(position: Int) {
        val message = conversationAdapter!!.getItem(position)
        val viewHolderForAdapterPosition = binding.recyclerView.findViewHolderForAdapterPosition(position)
        if (actionMode != null) {
            if (selectedMesssages!!.containsKey(message?.messageId)) {
                selectedMesssages!!.remove(message?.messageId)
                if(selectedMesssages?.isEmpty()==true){
                    removeMultiSelect()
                    return
                }
            } else {
                selectedMesssages!!.clear()
                if ((message?.msgType == MsgType.TYPE_DELETED.value) || (message?.msgType == MsgType.TYPE_DATE.value) || (message?.msgType == MsgType.TYPE_UNREAD.value)) {
                    return
                } else {
                    selectedMesssages!![message?.messageId] = message
                }
            }
            if (viewHolderForAdapterPosition != null) {
                viewHolderForAdapterPosition.itemView.setMessageForeGround(message)
            } else {
                conversationAdapter!!.notifyItemChanged(position)
            }
            if (selectedMesssages!!.isNotEmpty()) actionMode!!.title =
                selectedMesssages!!.size.toString() + " Selected" //show selected item count on action mode.
            else {
                actionMode!!.title = "" //remove item count from action mode.
                actionMode!!.finish() //hide action mode.
                if (touchListener != null) {
                    touchListener!!.setActionMode(actionMode)
                }
            }
            if (actionMode != null) {
                actionMode!!.invalidate()
            }
        } else {
            isMultiSelect = false
        }
    }

    fun onLanguageClick(index: Int) {
        if (index == 0) {
            val typeface = ResourcesCompat.getFont(this@ConversationActivity, R.font.calibri)
            binding.editMessage.typeface = typeface
            binding.editMessage.hint = getString(R.string.message_field_eng)
        } else {
            val typeface =
                ResourcesCompat.getFont(this@ConversationActivity, R.font.calibri)
            binding.editMessage.typeface = typeface
            binding.editMessage.hint = getString(R.string.message_field_urdu)
        }
        if (index != keyboardSelectedIndex) {
            keyboardSelectedIndex = index
        }
        for (i in keyboardButtons.indices) {
            val id = ta!!.getResourceId(i, 0)
            if (index == i) {
                keyboardButtons[i].setImageResource(
                    resources.getIdentifier(
                        resources.getStringArray(
                            id
                        )[1] + "_sdk", "drawable", packageName
                    )
                )
            } else {
                keyboardButtons[i].setImageResource(
                    resources.getIdentifier(
                        resources.getStringArray(
                            id
                        )[0] + "_sdk", "drawable", packageName
                    )
                )
            }
        }
    }

    private fun attachmentInit() {
        binding.attachmentBtn.setOnClickListener(this)
        ta = resources.obtainTypedArray(R.array.keyboard_image_array)
        keyboardButtons.add(binding.englishKeyboardIcon)
        keyboardButtons.add(binding.urduKeyboardIcon)
        binding.englishKeyboardIcon.setOnClickListener {
            onLanguageClick(0)
        }
        binding.urduKeyboardIcon.setOnClickListener {
            onLanguageClick(1)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        finish()
        startActivity(getIntent())
    }

    val editText: EditMessage
        get() = binding.editMessage

    override fun onEmojiIconClicked(emojicon: String) {
        val i = if (binding.editMessage.selectionEnd < 0) 0 else binding.editMessage.selectionEnd
        val localCharSequence = Emoji.replaceEmoji(
            emojicon, binding.editMessage.paint.fontMetricsInt, AndroidUtilities.dp(23f), false
        )
        binding.editMessage.text = binding.editMessage.text!!.insert(i, localCharSequence)
        binding.editMessage.setSelection(binding.editMessage.text.toString().length)
    }

    override fun onBackSpace(): Boolean {
        if (binding.editMessage.length() == 0) {
            return false
        }
        binding.editMessage.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
        return true
    }

    val messagesView: RecyclerView
        get() = binding.recyclerView

    fun getReplyMessage(): TTMessage? {
        return replyMessage
    }

    private fun setReplyMessage(replyMessage: TTMessage?) {
        this.replyMessage = replyMessage
//        registry.notifyChange(this, BR.replyMessage)
    }

    override fun onClick(v: View) {
        if (v.id == R.id.attachment_btn) {
            hideKeyboard(this@ConversationActivity)
            if (binding.attachmentButtonsContainer.isVisible) {
                binding.attachmentButtonsContainer.visibility = View.GONE
            } else {
                binding.attachmentButtonsContainer.visibility = View.VISIBLE
            }
        }  else if (v.id == R.id.send_message_btn) {
            sendMessageFromButton()
        } else if (v.id == R.id.cancel_reply_btn) {
            setReplyMessage(null)
        } else if (v.id == R.id.action_bar_endchat) {
            //    openConfirmDialog();
        }
    }

    private fun sendMessageFromButton(isNonText: Boolean = false) {
        if ((isEmptyString(binding.editMessage.getText().toString()) && instance?.isShowLargeSendButton()==false) && !isNonText) {
            Toast.makeText(this, getString(R.string.message_error_sdk), Toast.LENGTH_LONG).show()
            return
        }
        if (isNetworkAvailable(this@ConversationActivity)) {
            if (TTConversationRepository.getInstance()
                    .getConversationForJid(conversationId.toString())?.lastMessage != null
            ) {
                chatID = if ((TTConversationRepository.getInstance()
                        .getConversationForJid(conversationId.toString())?.lastMessage?.msgType == MsgType.TYPE_CHATEND.value) || (TTMessageRepository.instance?.getLastMessageOfConversation(
                        conversationId
                    )?.msgType == MsgType.TYPE_CHATEND.value)
                ) {
                    ""
                } else {
                    TTMessageRepository.instance?.getLastMessageOfConversation(conversationId)?.chatId
                }
                telloPrefs.putString("chatid", chatID)
            }

            if (isFirstMessage && ApplicationUtils.isMessageShort(
                    binding.editMessage.getText().toString()
                ) && !instance!!.isShowLargeSendButton()
            ) {
                Toast.makeText(
                    this, getString(R.string.message_length_error_sdk), Toast.LENGTH_LONG
                ).show()
                return
            }
            if (isFirstMessage) {
                initiateChat {
                    prepareMessage(null, null, MsgType.TYPE_TEXT.value)
                }
            } else {
                prepareMessage(null, null, MsgType.TYPE_TEXT.value)
            }
        } else {
            Toast.makeText(
                this@ConversationActivity, getString(R.string.no_internet_sdk), Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun initiateChat(callback: (() -> Unit)? = {}) {
        instance!!.initiateChat(intent.getStringExtra("departmentId")) {
            if (it != null) {
                instance!!.isMsgSending = false
                chatID = it.toString()
                telloPrefs.putString("chatid", chatID)
                instance!!.listenToMessages(isCorporateChat)
                setMsg()
                isFirstMessage = false
                callback?.invoke()
            }
        }
    }

    fun prepareMessage(vcard: String?, contactName: String?, msgType: String) {
        var message: String? = binding.editMessage.text.toString().trim { it <= ' ' }
        if (contactName != null) {
            message = contactName
        }
        if (instance!!.isMsgSending) {
            return
        }
        if (!instance!!.isShowBundledText()) {
            message = (binding.editMessage.tag ?: "").toString() + message
            binding.editMessage.tag = ""
        }
        val ttMessage: TTMessage
        if (currentConversation!!.correctingMsg == null) {
            ttMessage = TTMessage(message)
            ttMessage.contactId = conversationId
            ttMessage.msgDate = Date(System.currentTimeMillis())
            ttMessage.systemDate = Date(System.currentTimeMillis())
        } else {
            ttMessage = currentConversation!!.correctingMsg
            currentConversation!!.correctingMsg = null
            ttMessage.message = message
            ttMessage.isEdited = true
            ttMessage.msgDate = (ttMessage.msgDate)
            ttMessage.systemDate = (ttMessage.msgDate)
            MessageReceiptRepository.getInstance()
                .deleteMessageReceiptForMessage(ttMessage.messageId)
        }
        if ((msgType == MsgType.TYPE_CONTACT.value) && vcard != null) {
            ttMessage.message = (vcard)
            ttMessage.caption = (contactName)
        }
        ttMessage.msgStatus = (TTMessage.MsgStatus.PENDING)
        ttMessage.msgType = (msgType)
        checkAndSetReplyMessage(ttMessage)
        runOnUiThread {
            binding.editMessage.setText("")
        }
        updateSendButton()
        sendAndSaveMessage(ttMessage)
    }

    private fun resendMessage(ttMessage: TTMessage) {
        Log.e("RESEND", "messageId: ${ttMessage.messageId}")
        ttMessage.departmentId = departmentId
        instance!!.sendMessage(ttMessage, isCorporateChat, ttMessage.chatId ?: "")
    }

    fun sendAndSaveMessage(ttMessage: TTMessage) {
        if (isTwoWayDepartment) {
            ttMessage.dptType = Constant.typeAgentChat
        } else {
            ttMessage.dptType = Constant.typeBroadcast
        }
        if (!isEmptyString(customData)) {
            ttMessage.customData = customData
            customData = ""
        }
        if (!isEmptyString(agentDetailResponse?.agentId)) {
            ttMessage.receiverId = agentDetailResponse?.agentId
        }
        telloPrefs.putString("chatid", chatID)
        ttMessage.chatId = chatID
        if(ttMessage.message?.isEmpty() == true){
            return
        }
        updateConversationForNewMessage(ttMessage)
        ttMessage.departmentId = departmentId
        instance!!.sendMessage(ttMessage, isCorporateChat, chatID ?: "0")
    }

    private fun updateConversationForNewMessage(message: TTMessage) {
        currentConversation!!.lastMessage = message
        currentConversation!!.lastMessageId = message.messageId
        currentConversation!!.created = Date()
        TTConversationRepository.getInstance().updateConversation(currentConversation)
        viewModel.insertMessage(message)
    }

    fun checkAndSetReplyMessage(ttMessage: TTMessage) {
        if (replyMessage != null) {
            ttMessage.replyMsgId = (replyMessage!!.messageId)
            setReplyMessage(null)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_conversation, menu)
        actionChatEnd = menu.findItem(R.id.action_chat_end)
        actionCall = menu.findItem(R.id.action_call)
        actionChatEnd?.title = changeStringColor()
        actionChatEnd?.isVisible = false
        actionCall?.isVisible = false
        actionClearHistory = menu.findItem(R.id.action_clear_history)
        actionClearHistory?.isVisible = true
        toggleMenuItemsVisibility(messages)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_clear_history) {
            showClearHistoryDialog()
        } else if (item.itemId == R.id.action_chat_end) {
            openConfirmDialog()
        } else if (item.itemId == R.id.action_call) {
//            callClient?.openCallDialog()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showClearHistoryDialog() {
        AlertDialog.Builder(this).setTitle("Clear History")
            .setMessage("Are you sure you want to clear this Conversation's history?")
            .setPositiveButton(android.R.string.yes) { dialog: DialogInterface?, which: Int ->
                if (chatID != null && chatID != "") {
                    viewModel.deletePrevMessages(chatID)
                } else {
                    if (messages?.isNotEmpty() == true) {
                        chatID = messages?.last()?.chatId
                        if (chatID != null && chatID != "") {
                            viewModel.deletePrevMessages(chatID)
                        }
                    }
                }
            }.setNegativeButton(android.R.string.no) { dialog: DialogInterface, _: Int ->
                // do nothing
                dialog.dismiss()
            }.show()
    }

    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
        val inflater = mode.menuInflater
        inflater.inflate(R.menu.menu_message_context, menu)
        return true
    }

    override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
        val replyMessage = menu.findItem(R.id.reply_message)
        replyMessage.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        val shareWith = menu.findItem(R.id.share_with)
        shareWith.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        val deleteMessage = menu.findItem(R.id.delete_message)
        deleteMessage.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        val correctMessage = menu.findItem(R.id.correct_message)
        correctMessage.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        val forwardMessage = menu.findItem(R.id.forward_message)
        forwardMessage.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        val copyMessage = menu.findItem(R.id.select_text)
        val sendAgain = menu.findItem(R.id.send_again)
        val messageInfo = menu.findItem(R.id.message_info)
        var selectedMessage: TTMessage? = null
        if (selectedMesssages!!.isNotEmpty()) {
            for (entry in selectedMesssages!!.entries) {
                selectedMessage = entry.value
                break
            }
            if (selectedMessage == null) {
                return false
            }
            deleteMessage.isVisible =
                selectedMessage.msgStatus != TTMessage.MsgStatus.COMPRESSING && selectedMessage.msgStatus != TTMessage.MsgStatus.PENDING
            if ((selectedMessage.msgType == MsgType.TYPE_TEXT.value)) {
                if (selectedMessage.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    // agent message
                    correctMessage.isVisible = false
                    deleteMessage.isVisible = false
                    copyMessage.isVisible = true
                } else {
                    // user message
                    copyMessage.isVisible = true
                    deleteMessage.isVisible = true
                    copyMessage.isVisible = true
                    //     correctMessage.setVisible(true);
                }
                correctMessage.isVisible = false
                shareWith.isVisible = false
                forwardMessage.isVisible = false
                messageInfo.isVisible = true
                //   copyMessage.setVisible(true);
            } else {
                if (selectedMessage.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    forwardMessage.isVisible = false
                    deleteMessage.isVisible = false
                    shareWith.isVisible = false
                    replyMessage.isVisible = false
                    correctMessage.isVisible = false
                    copyMessage.isVisible = false
                    messageInfo.isVisible = true
                } else {
                    forwardMessage.isVisible = false
                    deleteMessage.isVisible = true
                    shareWith.isVisible = false
                    replyMessage.isVisible = false
                    correctMessage.isVisible = false
                    copyMessage.isVisible = false
                    messageInfo.isVisible = true
                }
            }
            sendAgain.isVisible = selectedMessage.msgStatus == TTMessage.MsgStatus.ERROR
        }
        return true
    }

    override fun onActionItemClicked(mode: ActionMode, menuItem: MenuItem): Boolean {
        currentConversation!!.correctingMsg = null
        var selectedMessage: TTMessage? = null
        if (selectedMesssages!!.size == 1) {
            for (entry in selectedMesssages!!.entries) {
                selectedMessage = entry.value
                break
            }
            if (selectedMessage == null) {
                return false
            }
        }
        if (menuItem.itemId == R.id.reply_message) {
            setReplyMessage(selectedMessage)
            removeMultiSelect()
            return true
        } else if (menuItem.itemId == R.id.share_with) {
            messageUtils!!.shareWith(selectedMessage, this)
            removeMultiSelect()
            return true
        } else if (menuItem.itemId == R.id.delete_message) {
            messageUtils!!.showDeleteMessageDialog(selectedMesssages, this, chatID)
            return true
        } else if (menuItem.itemId == R.id.correct_message) {
            correctMessage(selectedMessage)
            removeMultiSelect()
            return true
        } else if (menuItem.itemId == R.id.select_text) {
            val finalSelectedMessage = selectedMessage
            Handler(Looper.getMainLooper()).postDelayed({
                messageUtils!!.selectText(finalSelectedMessage, this@ConversationActivity)
                removeMultiSelect()
            }, 500)
            return true
        } else if (menuItem.itemId == R.id.message_info) {
            if (selectedMessage == null) {
                return true
            }
            val intent = Intent(this, MessageInfoActivity::class.java)
            intent.putExtra("selectedMessageId", selectedMessage.messageId)
            intent.putExtra("conversationId", currentConversation!!.contactJid)
            startActivity(intent)
            removeMultiSelect()
            return true
        } else if (menuItem.itemId == R.id.send_again) {
            if (selectedMessage == null) {
                return true
            }
            resendMessage(selectedMessage)
            removeMultiSelect()
            return true
        }
        return false
    }

    private fun correctMessage(selectedMessage: TTMessage?) {
        currentConversation!!.correctingMsg = selectedMessage
        binding.editMessage.setText("")
        binding.editMessage.setText(selectedMessage!!.message)
    }

    override fun onDestroyActionMode(mode: ActionMode) {
        isMultiSelect = false
        removeMultiSelect()
    }

    override fun onStop() {
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this)
        }
        TelloMediaPlayer.getInstance().stopMediaPlayer()
        TelloMediaPlayer.removeInstance()
        if ((TelloApiClient.getInstance()
                ?.getmCurrentConversationOpen() != null) && (currentConversation != null) && (TelloApiClient.getInstance()
                ?.getmCurrentConversationOpen()?.contactJid == currentConversation!!.contactJid)
        ) {
            TelloApiClient.getInstance()?.setmCurrentConversationOpen(null)
        }
        handler.removeCallbacks(onEveryMinute)
        super.onStop()
    }

    override fun onDestroy() {
        if (actionMode != null) {
            actionMode!!.finish()
        }
        if (!fromChatList) {
            TelloApiClient.getInstance()!!.isTelloUi = false
        }
        viewHolderUtils.stopMediaPLayer()
        annoucementPolling.cancel()
        unregisterReceiver(networkChangeReceiver)
        super.onDestroy()
    }

    private fun updateSendButton() {
        val text = if (binding.editMessage.text == null) "" else binding.editMessage.text.toString()
        val empty = text.length == 0
        if (empty && currentConversation != null) {
            binding.sendMessageBtn.visibility = View.GONE
            binding.recordAudioBtn.visibility = View.VISIBLE
        } else {
            binding.sendMessageBtn.visibility = View.VISIBLE
            binding.recordAudioBtn.visibility = View.GONE
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_EXTERNAL_STORAGE_DOWNLOAD || requestCode == REQUEST_EXTERNAL_STORAGE_UPLOAD) {
            return
        }
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String?>) {
        if (requestCode == Config.ATTACHMENT_CHOICE_CONTACT) {
            try {
                startActivityForResult(
                    Intent(
                        Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                    ), Config.ATTACHMENT_CHOICE_CONTACT
                )
            } catch (e: ActivityNotFoundException) {
                //This should happen only on faulty androids because normally chooser is always available
                Toast.makeText(
                    this, R.string.no_application_found_to_open_contact, Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            messageUtils!!.onPermissionsGranted(
                requestCode,
                perms,
                this,
                currentConversation!!.mode
            )
        }
    }

    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String?>) {
        if (requestCode == REQUEST_RECORD_AUDIO) {
            val permission = ArrayList<String>()
            for (i in perms.indices) {
                if (EasyPermissions.permissionPermanentlyDenied(this, perms[i] ?:"")) {
                    permission.add(perms[i] ?:"")
                } else {
                    if (i == 0) {
                        Toast.makeText(
                            this, getString(R.string.require_audio_permission), Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            if (permission.size > 0) {
                val selectedPermissions = arrayOfNulls<String>(permission.size)
                for (i in permission.indices) {
                    selectedPermissions[i] = permission[i]
                }
                messageUtils!!.showPermissionRequestDialog(requestCode, this, selectedPermissions)
            }
        } else if (requestCode == Config.ATTACHMENT_CHOICE_CONTACT) {
            if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
                messageUtils!!.showPermissionRequestDialog(
                    requestCode, this, perms.toTypedArray<String?>()
                )
            } else {
                Toast.makeText(
                    this, getString(R.string.require_contact_permission), Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            messageUtils!!.onPermissionsDenied(requestCode, perms, this)
        }
    }

    val messageList: List<TTMessage?>?
        get() {
            if (messages == null) {
                messages = ArrayList()
            }
            return messages
        }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDownloadFinishedEvent(event: DownloadFinishedEvent) {
        val index = messages?.indexOf(event.message) ?: 0
        var file: DownloadableFile? = null
        CoroutineScope(Dispatchers.IO).launch {
            file = FileBackend.instance?.getFile(event.message)
            if (file == null || file?.exists() == false) {
                return@launch
            }
            val uri = Uri.fromFile(file)
            val imagePipeline = Fresco.getImagePipeline()
            imagePipeline.evictFromCache(uri)
            if (index > -1 && conversationAdapter != null) {
                runOnUiThread {
                    conversationAdapter!!.notifyItemChanged(index)
                }
            }

        }
    }

    override fun onBackPressed() {
        if (binding.attachmentButtonsContainer.isVisible) {
            binding.attachmentButtonsContainer.isVisible = false
            return
        }
        if (isTaskRoot) {
            try {
                instance?.setShowLargeSendButton(true)
                instance?.setShowPreviousMessagesOnly(false)
                instance?.setShowBundledText(false)
                startActivity(
                    Intent(
                        this@ConversationActivity,
                        Class.forName(
                            telloPrefs.getString("client_activity") ?: ""
                        )
                    )
                )
                finish()
            } catch (e: ClassNotFoundException) {
                e.printStackTrace()
            }
        } else {
            if (isFromNotification) {
                redirectToHomeActivity()
            }
            val returnIntent = Intent()
            returnIntent.putExtra("result", isFirstMessage)
            setResult(420, returnIntent)
            super.onBackPressed()
        }
    }

    private fun redirectToHomeActivity() {
        // startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setPackage(getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY).get(0).activityInfo.packageName));
    }

    override fun onRestart() {
        super.onRestart()
        TelloMediaPlayer.getInstance().isPlaying
        binding.recordAudioView.finish(binding.recordAudioBtn)
        TelloMediaPlayer.getInstance().updateOnComplete()
        if (isTwoWayDepartment) {
            openUrduKeyboardOnRestart()
        }
    }

    private fun openUrduKeyboardOnRestart() {
        val i = if ((isAppEnglish)) 0 else 1
        if (i == 1) {
            onLanguageClick(1)
        }
    }

    override fun onEventOccured(b: Boolean) {
        if (b) {
            ratingDialog = null
            (toolbar!!.findViewById<View>(R.id.action_bar_title) as TextView).text = departmentName
            toolbar!!.findViewById<View>(R.id.action_bar_subtitle).visibility = View.GONE
            setImageDetails(toolbar!!.findViewById(R.id.action_bar_image))
            (toolbar!!.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView).setImageURI(
                dptImage
            )
        }
    }

    override fun onEnterPressed(): Boolean {
        return false
    }

    override fun onTypingStarted() {
        Log.e("TYPING", "started/resumed")
        instance?.updateTyping(true)
        updateSendButton()
    }

    override fun onTypingStopped() {
        Log.e("TYPING", "stopped")
        instance?.updateTyping(false)
    }

    override fun onTextDeleted() {
        updateSendButton()
        instance?.updateTyping(false)
    }

    override fun onTextChanged() {
        updateSendButton()
    }

    override fun onTabPressed(repeated: Boolean): Boolean {
        return false
    }

    override val defaultViewModelCreationExtras: CreationExtras
        get() = super.defaultViewModelCreationExtras

    companion object {
        @JvmField
        val REQUEST_RECORD_AUDIO = 11156

        @JvmField
        val REQUEST_START_DOWNLOAD = 0x0210

        @JvmField
        val ACTION_VIEW_CONVERSATION = "com.tilismtech.tellotalksdk.action.VIEW"

        @JvmField
        val EXTRA_DOWNLOAD_UUID = "com.tilismtech.tellotalksdk.download_uuid"

        init {
            AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }
}
