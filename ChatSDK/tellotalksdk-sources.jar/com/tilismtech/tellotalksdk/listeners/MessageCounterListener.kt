package com.tilismtech.tellotalksdk.listeners

import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations


interface MessageCounterListener {
    /**
     * Called when there is an update in the message count for specific department-based conversations.
     *
     * @param conversations A list of [DepartmentConversations] objects containing the updated count information.
     */
    fun onConversationMessageCountUpdate(conversations: List<DepartmentConversations?>?)

    /**
     * Called when the total count of all messages is updated.
     *
     * @param count The total number of messages across all conversations.
     */
    fun onAllMessageCountUpdate(count:Int)
}
