/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.tilismtech.tellotalksdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.tilismtech.tellotalksdk";
  public static final String BUILD_TYPE = "release";
  // Field from build type: release
  public static final String APP_JID = "@im.tellotalk.com";
  // Field from build type: release
  public static final String CRYPTO_LIB_IV = "";
  // Field from build type: release
  public static final String CRYPTO_LIB_KEY = "";
  // Field from build type: release
  public static final int DEFAULT_ANIMATION_DURATION = 750;
  // Field from build type: release
  public static final String PINNING_KEY = "AIzaSyCFZyYkPsEaKxDtHsG5Kl8_OF6YSgamfcg";
  // Field from build type: release
  public static final String VERSION_NAME = "3.10.2";
}
