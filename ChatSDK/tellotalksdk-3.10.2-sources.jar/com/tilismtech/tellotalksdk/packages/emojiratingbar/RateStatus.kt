package com.tilismtech.tellotalksdk.packages.emojiratingbar

enum class RateStatus {
    EMPTY,
    AWFUL,
    BAD,
    OKAY,
    GOOD,
    GREAT
}