package com.tilismtech.tellotalksdk.packages.imageEditorLibrary.colorSeekBarView

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.annotation.ArrayRes
import com.tilismtech.tellotalksdk.R

class ColorSeekBar : View {
    private var mColorSeeds = intArrayOf(
        -0x1000000,
        -0x66ff01,
        -0xffff01,
        -0xff0100,
        -0xff0001,
        -0x10000,
        -0xff01,
        -0x9a00,
        -0x100,
        -0x1,
        -0x1000000
    )
    var alphaValue: Int = 0
        private set
    private var mOnColorChangeLister: OnColorChangeListener? = null
    private var mContext: Context? = null
    private var mIsShowAlphaBar = false

    //    public void setVertical(boolean vertical) {
    //        mIsVertical = vertical;
    //        refreshLayoutParams();
    //        invalidate();
    //    }
    var mIsVertical: Boolean = false
        //    public void setVertical(boolean vertical) {
        get() {
            return field
        }
        private set
    private var mMovingColorBar = false
    private var mMovingAlphaBar = false
    private var mTransparentBitmap: Bitmap? = null
    private var isVertical: Rect? = null
    private var mThumbHeight = 20
    private var mThumbRadius = 0f
    private var mBarHeight = 2
    private var mColorRectPaint: Paint? = null
    var thumbHeight: Int = 0
        get() = mThumbHeight
        private set
    private var realRight = 0
    var barHeight: Int = 0
        get() = mBarHeight
        private set
    private var mMaxPosition = 0
    private var mAlphaRect: Rect? = null
    private var mColorBarPosition = 0
    private var mAlphaBarPosition = 0
    var maxValue: Int = 5
        get() = mMaxPosition
        private set
    private var mAlphaMinPosition = 0
    private var mAlphaMaxPosition = 255
    val colors: MutableList<Int?> = ArrayList<Int?>()
    var barMargin: Int = -1
        get() = this.maxValue
        private set
    private var mInit = false

    /**
     * @return
     */
    @get:Deprecated("use {@link #setOnInitDoneListener(OnInitDoneListener)} instead.")
    var isFirstDraw: Boolean = true
        private set
    private var mOnInitDoneListener: OnInitDoneListener? = null

    private val colorPaint = Paint()
    private val alphaThumbGradientPaint = Paint()
    private val alphaBarPaint = Paint()
    private val thumbGradientPaint = Paint()

    constructor(context: Context) : super(context) {
        init(context, null, 0, 0)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context, attrs, 0, 0)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context, attrs, defStyleAttr, 0)
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes) {
        init(context, attrs, defStyleAttr, defStyleRes)
    }

    protected fun init(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) {
        applyStyle(context, attrs, defStyleAttr, defStyleRes)
    }

    fun applyStyle(resId: Int) {
        applyStyle(getContext(), null, 0, resId)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        var mViewWidth = widthMeasureSpec
        var mViewHeight = heightMeasureSpec

        val widthSpeMode = MeasureSpec.getMode(widthMeasureSpec)
        val heightSpeMode = MeasureSpec.getMode(heightMeasureSpec)

        val barHeight = if (mIsShowAlphaBar) mBarHeight * 2 else mBarHeight
        val thumbHeight = if (mIsShowAlphaBar) mThumbHeight * 2 else mThumbHeight


        if (this.mIsVertical) {
            if (widthSpeMode == MeasureSpec.AT_MOST || widthSpeMode == MeasureSpec.UNSPECIFIED) {
                mViewWidth = thumbHeight + barHeight + this.maxValue
                setMeasuredDimension(mViewWidth, mViewHeight)
            }
        } else {
            if (heightSpeMode == MeasureSpec.AT_MOST || heightSpeMode == MeasureSpec.UNSPECIFIED) {
                mViewHeight = thumbHeight + barHeight + this.maxValue
                setMeasuredDimension(mViewWidth, mViewHeight)
            }
        }
    }


    protected fun applyStyle(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) {
        mContext = context
        //get attributes
        val a = context.obtainStyledAttributes(
            attrs,
            R.styleable.ColorSeekBar,
            defStyleAttr,
            defStyleRes
        )
        val colorsId = a.getResourceId(R.styleable.ColorSeekBar_colorSeeds, 0)
        mMaxPosition = a.getInteger(R.styleable.ColorSeekBar_maxPosition, 100)
        mColorBarPosition = a.getInteger(R.styleable.ColorSeekBar_colorBarPosition, 0)
        mAlphaBarPosition =
            a.getInteger(R.styleable.ColorSeekBar_alphaBarPosition, mAlphaMinPosition)
        mIsVertical = a.getBoolean(R.styleable.ColorSeekBar_isVertical, false)
        mIsShowAlphaBar = a.getBoolean(R.styleable.ColorSeekBar_showAlphaBar, false)
        val backgroundColor = a.getColor(R.styleable.ColorSeekBar_bgColor, Color.TRANSPARENT)
        mBarHeight = a.getDimension(R.styleable.ColorSeekBar_barHeight, dp2px(2f).toFloat()).toInt()
        mThumbHeight =
            a.getDimension(R.styleable.ColorSeekBar_thumbHeight, dp2px(30f).toFloat()).toInt()
        this.maxValue =
            a.getDimension(R.styleable.ColorSeekBar_barMargin, dp2px(5f).toFloat()).toInt()
        a.recycle()

        if (colorsId != 0) {
            mColorSeeds = getColorsById(colorsId)
        }

        setBackgroundColor(backgroundColor)
    }

    /**
     * @param   id color array resource
     * @return
     */
    private fun getColorsById(@ArrayRes id: Int): IntArray {
        if (isInEditMode()) {
            val s = mContext!!.getResources().getStringArray(id)
            val colors = IntArray(s.size)
            for (j in s.indices) {
                colors[j] = Color.parseColor(s[j])
            }
            return colors
        } else {
            val typedArray = mContext!!.getResources().obtainTypedArray(id)
            val colors = IntArray(typedArray.length())
            for (j in 0..<typedArray.length()) {
                colors[j] = typedArray.getColor(j, Color.BLACK)
            }
            typedArray.recycle()
            return colors
        }
    }

    private fun init() {
        //init size
        mThumbRadius = (mThumbHeight / 2).toFloat()
        val mPaddingSize = mThumbRadius.toInt()
        val viewBottom = height - paddingBottom - mPaddingSize
        val viewRight: Int = width - paddingEnd - mPaddingSize
        //init left right top bottom
        this.thumbHeight = paddingStart + mPaddingSize
        realRight = if (mIsVertical) viewBottom else viewRight
        val realTop = paddingTop + mPaddingSize

        this.barHeight = realRight - this.thumbHeight

        //init rect
        this.isVertical = Rect(this.thumbHeight, realTop, realRight, realTop + mBarHeight)

        //init paint
        val mColorGradient = LinearGradient(
            0f,
            0f,
            isVertical!!.width().toFloat(),
            0f,
            mColorSeeds,
            null,
            Shader.TileMode.CLAMP
        )
        mColorRectPaint = Paint()
        mColorRectPaint!!.setShader(mColorGradient)
        mColorRectPaint!!.setAntiAlias(true)
        cacheColors()
        setAlphaValue()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (mIsVertical) {
            mTransparentBitmap = Bitmap.createBitmap(h, w, Bitmap.Config.ARGB_4444)
        } else {
            mTransparentBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_4444)
        }
        mTransparentBitmap!!.eraseColor(Color.TRANSPARENT)
        init()
        mInit = true
        if (this.barMargin != -1) {
            this.color = this.barMargin
        }
    }


    private fun cacheColors() {
        //if the view's size hasn't been initialized. do not cache.
        if (this.barHeight < 1) {
            return
        }
        colors.clear()
        for (i in 0..mMaxPosition) {
            colors.add(pickColor(i))
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (mIsVertical) {
            canvas.rotate(-90f)
            canvas.translate(-getHeight().toFloat(), 0f)
            canvas.scale(-1f, 1f, (getHeight() / 2).toFloat(), (getWidth() / 2).toFloat())
        }

        val colorPosition = mColorBarPosition.toFloat() / mMaxPosition * this.barHeight

        colorPaint.setAntiAlias(true)
        val color = getColor(false)
        val colorStartTransparent =
            Color.argb(mAlphaMaxPosition, Color.red(color), Color.green(color), Color.blue(color))
        val colorEndTransparent =
            Color.argb(mAlphaMinPosition, Color.red(color), Color.green(color), Color.blue(color))
        colorPaint.setColor(color)
        val toAlpha = intArrayOf(colorStartTransparent, colorEndTransparent)
        //clear
        canvas.drawBitmap(mTransparentBitmap!!, 0f, 0f, null)

        //draw color bar
        canvas.drawRect(this.isVertical!!, mColorRectPaint!!)
        //draw color bar thumb
        val thumbX = colorPosition + this.thumbHeight
        val thumbY = (isVertical!!.top + isVertical!!.height() / 2).toFloat()
        canvas.drawCircle(thumbX, thumbY, (mBarHeight / 2 + 5).toFloat(), colorPaint)

        //draw color bar thumb radial gradient shader
        val thumbShader =
            RadialGradient(thumbX, thumbY, mThumbRadius, toAlpha, null, Shader.TileMode.MIRROR)
        thumbGradientPaint.setAntiAlias(true)
        thumbGradientPaint.setShader(thumbShader)
        canvas.drawCircle(thumbX, thumbY, (mThumbHeight / 2).toFloat(), thumbGradientPaint)

        if (mIsShowAlphaBar) {
            //init rect
            val top = (mThumbHeight + mThumbRadius + mBarHeight + this.maxValue).toInt()
            mAlphaRect = Rect(this.thumbHeight, top, realRight, top + mBarHeight)
            //draw alpha bar
            alphaBarPaint.setAntiAlias(true)
            val alphaBarShader = LinearGradient(
                0f,
                0f,
                mAlphaRect!!.width().toFloat(),
                0f,
                toAlpha,
                null,
                Shader.TileMode.CLAMP
            )
            alphaBarPaint.setShader(alphaBarShader)
            canvas.drawRect(mAlphaRect!!, alphaBarPaint)

            //draw alpha bar thumb
            val alphaPosition =
                (mAlphaBarPosition - mAlphaMinPosition).toFloat() / (mAlphaMaxPosition - mAlphaMinPosition) * this.barHeight
            val alphaThumbX = alphaPosition + this.thumbHeight
            val alphaThumbY = (mAlphaRect!!.top + mAlphaRect!!.height() / 2).toFloat()
            canvas.drawCircle(alphaThumbX, alphaThumbY, (mBarHeight / 2 + 5).toFloat(), colorPaint)

            //draw alpha bar thumb radial gradient shader
            val alphaThumbShader = RadialGradient(
                alphaThumbX,
                alphaThumbY,
                mThumbRadius,
                toAlpha,
                null,
                Shader.TileMode.MIRROR
            )

            alphaThumbGradientPaint.setAntiAlias(true)
            alphaThumbGradientPaint.setShader(alphaThumbShader)
            canvas.drawCircle(
                alphaThumbX,
                alphaThumbY,
                (mThumbHeight / 2).toFloat(),
                alphaThumbGradientPaint
            )
        }

        if (this.isFirstDraw) {
            if (mOnColorChangeLister != null) {
                mOnColorChangeLister!!.onColorChangeListener(
                    mColorBarPosition, mAlphaBarPosition,
                    this.color
                )
            }
            this.isFirstDraw = false

            if (mOnInitDoneListener != null) {
                mOnInitDoneListener!!.done()
            }
        }
        super.onDraw(canvas)
    }


    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = if (mIsVertical) event.getY() else event.getX()
        val y = if (mIsVertical) event.getX() else event.getY()
        when (event.getAction()) {
            MotionEvent.ACTION_DOWN -> if (isOnBar(this.isVertical!!, x, y)) {
                mMovingColorBar = true
                val value = (x - this.thumbHeight) / this.barHeight * mMaxPosition
                this.colorBarPosition = value.toInt()
            } else if (mIsShowAlphaBar) {
                if (isOnBar(mAlphaRect!!, x, y)) {
                    mMovingAlphaBar = true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                getParent().requestDisallowInterceptTouchEvent(true)
                if (mMovingColorBar) {
                    val value = (x - this.thumbHeight) / this.barHeight * mMaxPosition
                    this.colorBarPosition = value.toInt()
                } else if (mIsShowAlphaBar) {
                    if (mMovingAlphaBar) {
                        val value =
                            (x - this.thumbHeight) / barHeight.toFloat() * (mAlphaMaxPosition - mAlphaMinPosition) + mAlphaMinPosition
                        mAlphaBarPosition = value.toInt()
                        if (mAlphaBarPosition < mAlphaMinPosition) {
                            mAlphaBarPosition = mAlphaMinPosition
                        } else if (mAlphaBarPosition > mAlphaMaxPosition) {
                            mAlphaBarPosition = mAlphaMaxPosition
                        }
                        setAlphaValue()
                    }
                }
                if (mOnColorChangeLister != null && (mMovingAlphaBar || mMovingColorBar)) {
                    mOnColorChangeLister!!.onColorChangeListener(
                        mColorBarPosition, mAlphaBarPosition,
                        this.color
                    )
                }
                invalidate()
            }

            MotionEvent.ACTION_UP -> {
                mMovingColorBar = false
                mMovingAlphaBar = false
            }

            else -> {}
        }
        return true
    }

    var alphaMaxPosition: Int
        get() = mAlphaMaxPosition
        /***
         *
         * @param alphaMaxPosition <= 255 && > alphaMinPosition
         */
        set(alphaMaxPosition) {
            mAlphaMaxPosition = alphaMaxPosition
            if (mAlphaMaxPosition > 255) {
                mAlphaMaxPosition = 255
            } else if (mAlphaMaxPosition <= mAlphaMinPosition) {
                mAlphaMaxPosition = mAlphaMinPosition + 1
            }

            if (mAlphaBarPosition > mAlphaMinPosition) {
                mAlphaBarPosition = mAlphaMaxPosition
            }
            invalidate()
        }

    var alphaMinPosition: Int
        get() = mAlphaMinPosition
        /***
         *
         * @param alphaMinPosition >=0 && < alphaMaxPosition
         */
        set(alphaMinPosition) {
            this.mAlphaMinPosition = alphaMinPosition
            if (mAlphaMinPosition >= mAlphaMaxPosition) {
                mAlphaMinPosition = mAlphaMaxPosition - 1
            } else if (mAlphaMinPosition < 0) {
                mAlphaMinPosition = 0
            }

            if (mAlphaBarPosition < mAlphaMinPosition) {
                mAlphaBarPosition = mAlphaMinPosition
            }
            invalidate()
        }

    /**
     * @param r
     * @param x
     * @param y
     * @return whether MotionEvent is performing on bar or not
     */
    private fun isOnBar(r: Rect, x: Float, y: Float): Boolean {
        if (r.left - mThumbRadius < x && x < r.right + mThumbRadius && r.top - mThumbRadius < y && y < r.bottom + mThumbRadius) {
            return true
        } else {
            return false
        }
    }


    /**
     * @param value
     * @return color
     */
    private fun pickColor(value: Int): Int {
        return pickColor(value.toFloat() / mMaxPosition * this.barHeight)
    }

    /**
     * @param position
     * @return color
     */
    private fun pickColor(position: Float): Int {
        val unit = position / this.barHeight
        if (unit <= 0.0) {
            return mColorSeeds[0]
        }


        if (unit >= 1) {
            return mColorSeeds[mColorSeeds.size - 1]
        }

        var colorPosition = unit * (mColorSeeds.size - 1)
        val i = colorPosition.toInt()
        colorPosition -= i.toFloat()
        val c0 = mColorSeeds[i]
        val c1 = mColorSeeds[i + 1]
        //         mAlpha = mix(Color.alpha(c0), Color.alpha(c1), colorPosition);
        val mRed = mix(Color.red(c0), Color.red(c1), colorPosition)
        val mGreen = mix(Color.green(c0), Color.green(c1), colorPosition)
        val mBlue = mix(Color.blue(c0), Color.blue(c1), colorPosition)
        return Color.rgb(mRed, mGreen, mBlue)
    }

    /**
     * @param start
     * @param end
     * @param position
     * @return
     */
    private fun mix(start: Int, end: Int, position: Float): Int {
        return start + Math.round(position * (end - start))
    }

    var color: Int
        get() = getColor(mIsShowAlphaBar)
        /**
         * Set color,the mCachedColors must contains the specified color, if not ,invoke setColorBarPosition(0);
         * @param color
         */
        set(color) {
            val withoutAlphaColor = Color.rgb(
                Color.red(color),
                Color.green(color),
                Color.blue(color)
            )

            if (mInit) {
                val value = colors.indexOf(withoutAlphaColor)
                this.colorBarPosition = value
            } else {
                this.barMargin = color
            }
        }

    /**
     * @param withAlpha
     * @return
     */
    fun getColor(withAlpha: Boolean): Int {
        //pick mode
        if (mColorBarPosition >= colors.size) {
            val color = pickColor(mColorBarPosition)
            if (withAlpha) {
                return color
            } else {
                return Color.argb(
                    this.alphaValue,
                    Color.red(color),
                    Color.green(color),
                    Color.blue(color)
                )
            }
        }

        //cache mode
        val color = colors.get(mColorBarPosition)!!

        if (withAlpha) {
            return Color.argb(
                this.alphaValue,
                Color.red(color),
                Color.green(color),
                Color.blue(color)
            )
        }
        return color
    }

    var alphaBarPosition: Int
        get() = mAlphaBarPosition
        set(value) {
            this.mAlphaBarPosition = value
            setAlphaValue()
            invalidate()
        }

    interface OnColorChangeListener {
        /**
         * @param colorBarPosition between 0-maxValue
         * @param alphaBarPosition between 0-255
         * @param color            return the color contains alpha value whether showAlphaBar is true or without alpha value
         */
        fun onColorChangeListener(colorBarPosition: Int, alphaBarPosition: Int, color: Int)
    }

    /**
     * @param onColorChangeListener
     */
    fun setOnColorChangeListener(onColorChangeListener: OnColorChangeListener?) {
        this.mOnColorChangeLister = onColorChangeListener
    }


    fun dp2px(dpValue: Float): Int {
        val scale = mContext!!.getResources().getDisplayMetrics().density
        return (dpValue * scale + 0.5f).toInt()
    }

    /**
     * Set colors by resource id. The resource's type must be ArrayRes
     *
     * @param resId
     */
    fun setColorSeeds(@ArrayRes resId: Int) {
        setColorSeeds(getColorsById(resId))
    }

    fun setColorSeeds(colors: IntArray) {
        mColorSeeds = colors
        init()
        invalidate()
        if (mOnColorChangeLister != null) {
            mOnColorChangeLister!!.onColorChangeListener(
                mColorBarPosition, mAlphaBarPosition,
                this.color
            )
        }
    }

    /**
     * @param color
     * @return the color's position in the bar, if not in the bar ,return -1;
     */
    fun getColorIndexPosition(color: Int): Int {
        return colors.indexOf(
            Color.argb(
                255,
                Color.red(color),
                Color.green(color),
                Color.blue(color)
            )
        )
    }

    var isShowAlphaBar: Boolean
        get() = mIsShowAlphaBar
        set(show) {
            mIsShowAlphaBar = show
            refreshLayoutParams()
            invalidate()
            if (mOnColorChangeLister != null) {
                mOnColorChangeLister!!.onColorChangeListener(
                    mColorBarPosition,
                    mAlphaBarPosition,
                    this.color
                )
            }
        }

    private fun refreshLayoutParams() {
        setLayoutParams(getLayoutParams())
    }

    /**
     * @param dp
     */
    fun setBarHeight(dp: Float) {
        mBarHeight = dp2px(dp)
        refreshLayoutParams()
        invalidate()
    }

    /**
     * @param px
     */
    fun setBarHeightPx(px: Int) {
        mBarHeight = px
        refreshLayoutParams()
        invalidate()
    }

    private fun setAlphaValue() {
        this.alphaValue = 255 - mAlphaBarPosition
    }

    fun setMaxPosition(value: Int) {
        this.mMaxPosition = value
        invalidate()
        cacheColors()
    }

    /**
     * set margin between bars
     *
     * @param mBarMargin
     */
    fun setBarMargin(mBarMargin: Float) {
        this.maxValue = dp2px(mBarMargin)
        refreshLayoutParams()
        invalidate()
    }

    /**
     * set margin between bars
     *
     * @param mBarMargin
     */
    fun setBarMarginPx(mBarMargin: Int) {
        this.maxValue = mBarMargin
        refreshLayoutParams()
        invalidate()
    }


    fun setOnInitDoneListener(listener: OnInitDoneListener?) {
        this.mOnInitDoneListener = listener
    }

    /**
     * set thumb's height by dpi
     *
     * @param dp
     */
    fun setThumbHeight(dp: Float) {
        this.mThumbHeight = dp2px(dp)
        mThumbRadius = (mThumbHeight / 2).toFloat()
        refreshLayoutParams()
        invalidate()
    }

    /**
     * set thumb's height by pixels
     *
     * @param px
     */
    fun setThumbHeightPx(px: Int) {
        this.mThumbHeight = px
        mThumbRadius = (mThumbHeight / 2).toFloat()
        refreshLayoutParams()
        invalidate()
    }

    val colorBarValue: Float
        get() = mColorBarPosition.toFloat()

    interface OnInitDoneListener {
        fun done()
    }

    var colorBarPosition: Int
        get() = mColorBarPosition
        /**
         * Set the value of color bar, if out of bounds , it will be 0 or maxValue;
         *
         * @param value
         */
        set(value) {
            this.mColorBarPosition = value
            mColorBarPosition =
                if (mColorBarPosition > mMaxPosition) mMaxPosition else mColorBarPosition
            mColorBarPosition = if (mColorBarPosition < 0) 0 else mColorBarPosition
            invalidate()
            if (mOnColorChangeLister != null) {
                mOnColorChangeLister!!.onColorChangeListener(
                    mColorBarPosition, mAlphaBarPosition,
                    this.color
                )
            }
        }
}
