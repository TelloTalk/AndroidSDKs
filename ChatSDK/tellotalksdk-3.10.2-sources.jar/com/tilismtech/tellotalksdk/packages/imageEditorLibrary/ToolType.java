package com.tilismtech.tellotalksdk.packages.imageEditorLibrary;

public enum  ToolType {
    BRUSH,
    TEXT,
    ERASER,
    EMOJI,
    CROP,
    DELETE
}
