package com.tilismtech.tellotalksdk.packages.imageEditorLibrary;

public enum  ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}
