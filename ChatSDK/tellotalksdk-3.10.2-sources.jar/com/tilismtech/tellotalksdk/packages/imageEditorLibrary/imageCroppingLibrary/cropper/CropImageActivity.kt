package com.tilismtech.tellotalksdk.packages.imageEditorLibrary.imageCroppingLibrary.cropper

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.tilismtech.tellotalksdk.databinding.ImageCropActivityBinding
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.imageCroppingLibrary.cropper.CropImageView.CropResult
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.imageCroppingLibrary.cropper.CropImageView.OnCropImageCompleteListener
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment.ImageEditorFragment
import java.io.File

class CropImageActivity : TelloActivity() {
    private var binding: ImageCropActivityBinding? = null
    var imageUri: Uri? = null
    var position: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ImageCropActivityBinding.inflate(getLayoutInflater())
        setContentView(binding!!.getRoot())
        ViewCompat.setOnApplyWindowInsetsListener(binding!!.getRoot()) { view, insets ->
            val navBarHeight = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.updatePadding(bottom = navBarHeight + view.paddingBottom)
            insets
        }

        val time = System.currentTimeMillis()
        this.intentData
        initalizeCropImage()
        binding!!.cancel.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                finish()
            }
        })
        binding!!.done.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                cropImage
                // finish();
            }
        })

        binding!!.rotateImage.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                binding!!.cropImageView.rotateImage(90)
            }
        })
        // subscribe to async event using cropImageView.setOnCropImageCompleteListener(listener)
        binding!!.cropImageView.setOnCropImageCompleteListener(object :
            OnCropImageCompleteListener {
            override fun onCropImageComplete(view: CropImageView?, result: CropResult) {
                val uri = result.getUri()
                if (uri == null) {
                    setResult(RESULT_CANCELED, Intent())
                } else {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                        if (ImageEditorFragment.instance != null) {
                            ImageEditorFragment.instance?.setResult(uri.toString())
                        }
                    } else {
                        val returnIntent = Intent()
                        returnIntent.putExtra("uri", uri.toString())
                        returnIntent.putExtra("position", position)
                        setResult(RESULT_OK, returnIntent)
                    }
                }
                finish()
            }
        })
    }

    private val cropImage: Unit
        get() {
            //  SAVE_PATH= TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/IMG-" + String.valueOf(time) + ".jpg";
            val myUri = Uri.fromFile(
                File(
                    getExternalCacheDir(),
                    System.currentTimeMillis().toString() + "image.jpeg"
                )
            )
            binding!!.cropImageView.saveCroppedImageAsync(myUri)
        }

    private fun initalizeCropImage() {
        if (imageUri != null) {
            binding!!.cropImageView.setImageUriAsync(imageUri)
        }
    }

    private val intentData: Unit
        get() {
            val intent = getIntent()
            imageUri = Uri.parse(intent.getStringExtra("uri"))
            position = intent.getIntExtra("position", 0)
        }

    override fun onStart() {
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        setResultCancel()
    }


    protected fun setResultCancel() {
        setResult(RESULT_CANCELED)
        finish()
    }
}
