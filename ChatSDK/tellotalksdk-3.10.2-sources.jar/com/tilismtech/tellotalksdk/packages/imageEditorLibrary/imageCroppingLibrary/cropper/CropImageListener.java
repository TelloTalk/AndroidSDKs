package com.tilismtech.tellotalksdk.packages.imageEditorLibrary.imageCroppingLibrary.cropper;

import android.net.Uri;

public interface CropImageListener {
    public void onCropComplete(int position, Uri fileUri);
}
