package com.tilismtech.tellotalksdk

import android.app.Application

/**
 * Created by lpt-034 on 10/01/2019.
 */
open class TelloApplication : Application() {

    override fun onTrimMemory(level: Int) {
        // freeMemory();
        super.onTrimMemory(level)
    }
}
