package com.tilismtech.tellotalksdk.receivers;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.provider.ContactsContract;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import android.util.Log;

import com.tilismtech.tellotalksdk.R;

public class ContactObservableService extends Service implements ContactsUpdatedReceiver.OnUpdate {
    private static final String TAG = ContactObservableService.class.getSimpleName();
    private ContactsUpdatedReceiver contactObserver ;

    public ContactObservableService() {
    }

    @Override
    public void onCreate(){
        super.onCreate();
        Log.d(TAG, "onCreate: ");
        contactObserver = new ContactsUpdatedReceiver(this);
        this.getContentResolver().registerContentObserver(ContactsContract.Contacts.CONTENT_URI,false,contactObserver);
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy: ");

        if( contactObserver !=null  )
        {
            this.getContentResolver().unregisterContentObserver(contactObserver);
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: ");
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // The service is starting, due to a call to startService()
        Log.d(TAG, "onStartCommand: ");

        return START_STICKY;
    }

    @Override
    public void onUpdate(Uri uri) {
        NotificationCompat.Builder builder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setContentTitle("Contact Update Notifier")
                .setContentText(uri.getQuery())
                .setSmallIcon(R.drawable.contacts_icon_sdk);
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        manager.notify(1,builder.build());
    }
}
