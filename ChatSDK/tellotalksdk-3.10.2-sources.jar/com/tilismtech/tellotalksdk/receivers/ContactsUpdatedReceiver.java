package com.tilismtech.tellotalksdk.receivers;

import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;

public class ContactsUpdatedReceiver extends ContentObserver {
    private OnUpdate onUpdate;
    public interface OnUpdate{
        void onUpdate(Uri uri);
    }

    public ContactsUpdatedReceiver(OnUpdate onUpdate){
        super(new Handler());
        this.onUpdate = onUpdate;
        Log.d("Contacts_Updated", "ContactsUpdatedReceiver: ");

    }
    public ContactsUpdatedReceiver(Handler handler) {
        super(handler);
        Log.d("Contacts_Updated", "ContactsUpdatedReceiver: ");
    }

    @Override
    public void onChange(boolean selfChange) {
        this.onChange(selfChange,null);
    }

    @Override
    public void onChange(boolean selfChange, Uri uri) {
        uri.getQueryParameterNames();
        Log.d("Contacts_Update", "ContactsUpdatedReceiver: "+uri);
        onUpdate.onUpdate(uri);
    }
}
