package com.tilismtech.tellotalksdk.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.tilismtech.tellotalksdk.data.db.entities.converters.ListConverter
import com.tilismtech.tellotalksdk.data.network.module.register.OtherField

@Entity(tableName = "agents")
@TypeConverters(ListConverter::class)
class AgentModel {
    @PrimaryKey
    @SerializedName("agentId")
    @Expose
    private var agentId: String = ""

    @JvmField
    @SerializedName("agentName")
    @Expose
    var agentName: String? = null

    @JvmField
    @SerializedName("agentAvatar")
    @Expose
    var agentAvatar: String? = null

    @JvmField
    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("otherDetail")
    @Expose
    var otherDetail: List<OtherField?>? = null

    constructor()

    constructor(agentId: String?, agentName: String?, agentAvatar: String?, status: String?, otherDetails: List<OtherField?>?) {
        this.agentId = agentId?:""
        this.agentName = agentName
        this.agentAvatar = agentAvatar
        this.status = status
        this.otherDetail = otherDetails
    }

    fun getAgentId(): String {
        return agentId
    }

    fun setAgentId(agentId: String) {
        this.agentId = agentId
    }
}