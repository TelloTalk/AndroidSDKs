package com.tilismtech.tellotalksdk.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.text.Html
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import com.facebook.common.executors.CallerThreadExecutor
import com.facebook.common.executors.UiThreadImmediateExecutorService
import com.facebook.common.references.CloseableReference
import com.facebook.datasource.DataSource
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.imagepipeline.common.ResizeOptions
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber
import com.facebook.imagepipeline.image.CloseableImage
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.data.repository.ContactRepository
import com.tilismtech.tellotalksdk.data.repository.TTAccountRepository
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.managers.TelloApiClient.Companion.getInstance
import com.tilismtech.tellotalksdk.ui.activities.ConversationActivity
import com.tilismtech.tellotalksdk.utils.AndroidUtilities
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.FileBackend
import com.tilismtech.tellotalksdk.utils.GeoHelper
import com.tilismtech.tellotalksdk.utils.UIHelper
import java.io.FileNotFoundException
import java.util.concurrent.atomic.AtomicInteger

/**
 * Created by Sohail on 3/20/18.
 */
class NotificationService private constructor() {
    private val silentDuration = 10000
    private val updateCount = 0
    private val notifications = LinkedHashMap<String, ArrayList<TTMessage>>()
    private var chatManager: ChatManager? = null
    private val mOpenConversation: TTConversation? = null
    private val mIsInForeground = false
    private var mLastNotification: Long = 0
    private val mBacklogMessageCounter = HashMap<TTConversation, AtomicInteger>()
    private var notificationChannel: NotificationChannel? = null

    init {
        chatManager = ChatManager.Companion.instance
    }

    private fun notify(message: TTMessage?, conversation: TTConversation?): Boolean {
        return message?.msgStatus == TTMessage.MsgStatus.RECEIVED // && notificationsEnabled();
    }

    private fun pushFromBacklog(message: TTMessage?, conversation: TTConversation?) {
        if (notify(message, conversation)) {
            synchronized(notifications) {
                getBacklogMessageCounter(conversation)?.incrementAndGet()
                pushToStack(message)
            }
        }
    }

    private fun getBacklogMessageCounter(conversation: TTConversation?): AtomicInteger? {
        synchronized(mBacklogMessageCounter) {
            if (!mBacklogMessageCounter.containsKey(conversation)) {
                conversation?.let {
                    mBacklogMessageCounter[it] = AtomicInteger(0)
                }
            }
            return mBacklogMessageCounter[conversation]
        }
    }

    private fun pushToStack(message: TTMessage?) {
        val conversationUuid = message?.contactId
        var flag = false
        if (notifications.containsKey(conversationUuid)) {
            for (i in notifications[conversationUuid]?.indices?: IntRange(0,0)) {
                if (notifications[conversationUuid]?.get(i)?.messageId == message?.messageId) {
                    notifications[conversationUuid]?.get(i)?.message = message?.message
                    notifications[conversationUuid]?.get(i)?.isDeleted = message?.isDeleted==true
                    flag = true
                    break
                }
            }
            if (!flag) {
                message?.let { notifications[conversationUuid]?.add(it) }
            }
        } else {
            val mList = ArrayList<TTMessage>()
            message?.let { mList.add(it) }
            conversationUuid?.let {
                notifications[it] = mList
            }
        }
    }

    fun push(message: TTMessage?, conversation: TTConversation?) {
        synchronized(TelloApiClient.getInstance()!!.getAccount()?:"") {
            if (chatManager != null && chatManager?.isWaitingForSmCatchup == true) {
                chatManager?.incrementSmCatchupMessageCounter()
                pushFromBacklog(message, conversation)
            } else {
                pushNow(message, conversation)
            }
        }
    }

    private fun pushNow(message: TTMessage?, conversation: TTConversation?) {
        val accou = TTAccountRepository.getInstance().account
        for (s in notifications.keys) {
            if (s != accou.userName) {
                notifications.remove(s)
            }
        }
        //   notifications.clear();
        getInstance()?.onNotifyMessageCount()
        if (!notify(message, conversation)) {
            return
        }
        val isScreenOn = TelloApiClient.getInstance()?.isInteractive?:false
        if (mIsInForeground && isScreenOn && mOpenConversation === conversation) {
            return
        }
        synchronized(notifications) {
            pushToStack(message)
            val account = TelloApiClient.getInstance()!!.getAccount()
            val doNotify = !(mIsInForeground && mOpenConversation == null) || !isScreenOn
            updateNotification(doNotify, message)
        }
    }

    //    public void clear() {
    //        synchronized (notifications) {
    //            notifications.clear();
    //            updateNotification(false, null);
    //        }
    //    }
    fun clear(conversation: TTConversation) {
        synchronized(mBacklogMessageCounter) {}
        synchronized(notifications) {
            notifications.remove(conversation.contactJid)
            val notificationManager = NotificationManagerCompat.from(getInstance()!!.telloContext)
            try {
                notificationManager.cancel(conversation.contactJid, NOTIFICATION_ID)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clearAllNotifications() {
        val notificationManager = NotificationManagerCompat.from(getInstance()!!.telloContext)
        try {
            //      notificationManager.cancelAll();
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setNotificationColor(mBuilder: NotificationCompat.Builder) {
        mBuilder.setColor(
            ContextCompat.getColor(
                getInstance()!!.telloContext,
                R.color.primary500
            )
        )
    }

    private fun updateNotification(notify: Boolean, message: TTMessage?) {
        val notificationManager = getInstance()!!.telloContext
            .getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (notifications.size == 0) {
            if (notificationManager != null) {
                try {
                    notificationManager.cancelAll()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } else {
            if (notify) {
                markLastNotification()
            }
            val mBuilder: NotificationCompat.Builder
            val largeIcon = BitmapFactory.decodeResource(
                getInstance()!!.telloContext.resources,
                TelloApiClient.Companion.getInstance()!!.notificationIcon
            ) //replace with your own image
            if (notifications.size == 1 && Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                val messages = notifications.values.iterator().next()
                if (messages.size >= 1) {
                    val conversation = TTConversationRepository.Companion.getInstance().getConversationForJid(
                        messages?.getOrNull(0)?.contactId
                    )
                    if (conversation != null && conversation.isCe) {
                        displayNotification(messages, notificationManager, null, notify)
                    } else {
                        if (conversation != null) {
                            val imageRequest =
                                ImageRequestBuilder.newBuilderWithSource(getImageUri(conversation))
                                    .setResizeOptions(
                                        ResizeOptions(
                                            AndroidUtilities.dp(50f),
                                            AndroidUtilities.dp(50f)
                                        )
                                    )
                                    .build()
                            val imagePipeline = Fresco.getImagePipeline()
                            val dataSource = imagePipeline.fetchDecodedImage(imageRequest, null)
                            dataSource.subscribe(
                                object : BaseBitmapDataSubscriber() {
                                    override fun onNewResultImpl(bitmap: Bitmap?) {
                                        displayNotification(
                                            messages,
                                            notificationManager,
                                            bitmap,
                                            notify
                                        )
                                    }

                                    override fun onFailureImpl(dataSource: DataSource<CloseableReference<CloseableImage?>>) {
                                        // In general, failing to fetch the image should not keep us from displaying the
                                        // notification. We proceed without the bitmap.
                                        displayNotification(
                                            messages,
                                            notificationManager,
                                            null,
                                            notify
                                        )
                                    }
                                },
                                UiThreadImmediateExecutorService.getInstance()
                            )
                        } else {
                            displayNotification(messages, notificationManager, largeIcon, notify)
                        }
                    }
                }
            } else {
                createNotificationChannel(notificationManager)
                mBuilder = buildMultipleConversation()
                modifyForSoundVibrationAndLight(mBuilder, notify)
                for (entry in notifications.entries) {
                    //   if(message.getDptType().equals("1")) {
                    if (entry.key == message?.conversationId) {
                        val conversation =
                            TTConversationRepository.Companion.getInstance().getConversationForJid(entry.key)
                        if (conversation != null) {
                            setImageAndCreateNotificaiton(
                                notificationManager,
                                entry,
                                getImageUri(conversation)
                            )
                        } else {
                            setImageAndCreateNotificaiton(notificationManager, entry, Uri.parse(""))
                        }
                        //       }
                    }
                }
                //                modifyForSoundVibrationAndLight(mBuilder, notify);
//                if (notificationManager != null) {
//                    notificationManager.notify(NOTIFICATION_ID, mBuilder.build());
//                }
            }
        }
    }

    private fun getImageUri(conversation: TTConversation): Uri {
        val contact = ContactRepository.getInstance().getContactFromJid(conversation.contactJid)
        return Uri.parse(if (contact != null && !ApplicationUtils.Companion.isEmptyString(contact.avatar)) NetworkConstants.BASE_URL1 + "/chatsdk" + contact.avatar else "")
    }

    private fun setImageAndCreateNotificaiton(
        notificationManager: NotificationManager?,
        entry: Map.Entry<String, ArrayList<TTMessage>>,
        uri: Uri
    ) {
        val imageRequest = ImageRequestBuilder.newBuilderWithSource(uri)
            .setResizeOptions(ResizeOptions(AndroidUtilities.dp(50f), AndroidUtilities.dp(50f)))
            .build()
        val imagePipeline = Fresco.getImagePipeline()
        val dataSource = imagePipeline.fetchDecodedImage(imageRequest, null)
        dataSource.subscribe(
            object : BaseBitmapDataSubscriber() {
                override fun onNewResultImpl(bitmap: Bitmap?) {
                    val singleBuilder =
                        buildSingleConversations(notificationManager, entry.value, bitmap)
                    singleBuilder.setGroup(CONVERSATIONS_GROUP)
                    notificationManager?.notify(entry.key, NOTIFICATION_ID, singleBuilder.build())
                }

                override fun onFailureImpl(dataSource: DataSource<CloseableReference<CloseableImage?>>) {
                    // In general, failing to fetch the image should not keep us from displaying the
                    // notification. We proceed without the bitmap.
                    if (entry.value[entry.value.size - 1].dptType == "1") {
                        //      NotificationCompat.Builder singleBuilder = buildSingleConversations(notificationManager, entry.getValue(), null);
                        sendMessage(notificationManager, entry.value, entry.key)
                    } else {
                        val singleBuilder =
                            buildSingleConversations(notificationManager, entry.value, null)
                        singleBuilder.setGroup(CONVERSATIONS_GROUP)
                        val notification = singleBuilder.build()
                        //                            ShortcutBadger.applycCount(TelloApplication.instance,getUnreadCount());
//                            singleBuilder.setNumber(getUnreadCount());
                        singleBuilder.setPriority(NotificationCompat.PRIORITY_MAX)
                        notificationManager?.notify(
                            entry.key,
                            NOTIFICATION_ID,
                            singleBuilder.build()
                        )
                        //    notifications.remove(entry.getKey());
                    }
                }
            },
            UiThreadImmediateExecutorService.getInstance()
        )
    }

    private fun sendMessage(
        notificationManager: NotificationManager?,
        messages: ArrayList<TTMessage>,
        key: String
    ) {
        val mBuilder = NotificationCompat.Builder(getInstance()!!.telloContext, "default")
        mBuilder.setPriority(NotificationCompat.PRIORITY_MAX)
        var isImageNotification = false
        if (messages.size >= 1) {
            val conversation = TTConversationRepository.Companion.getInstance().getConversationForJid(
                messages[0].contactId
            )
            if (conversation != null) {
                val convoName: String = if (conversation.isCe) {
                    conversation.conversationName
                } else {
                    conversation.conversationName
                }
                val mUnreadBuilder =
                    NotificationCompat.CarExtender.UnreadConversation.Builder(convoName)
                //// TODO: 9/13/2017 make round image notification
//                if (bitmap == null) {
//                    bitmap = BitmapFactory.decodeResource(TelloApplication.instance.getResources(), R.drawable.bykea_icon);
//                }
//                mBuilder.setLargeIcon(bitmap);
                mBuilder.setContentIntent(createContentIntent(conversation))
                if (messages[messages.size - 1].msgType == TTMessage.MsgType.TYPE_NEWS.value) {
                    isImageNotification = true
                    modifyForAnnouncment(notificationManager, mBuilder, messages)
                } else if (messages[messages.size - 1].msgType == TTMessage.MsgType.TYPE_NEWSWB.value) {
                    isImageNotification = true
                    modifyForAnnouncment(notificationManager, mBuilder, messages)
                } else if (messages[messages.size - 1].msgType == TTMessage.MsgType.TYPE_TEXT.value) {
                    isImageNotification = false
                    modifyForAnnouncmentText(
                        notificationManager,
                        mUnreadBuilder,
                        mBuilder,
                        messages
                    )
                } else if (messages[messages.size - 1].msgType == TTMessage.MsgType.TYPE_IMAGE.value) {
                    isImageNotification = true
                    modifyForAnnouncmentIm(notificationManager, mBuilder, messages)
                } else if (messages[messages.size - 1].msgType == TTMessage.MsgType.TYPE_VIDEO.value) {
                    isImageNotification = false
                    modifyForAnnouncmentVideo(
                        notificationManager,
                        mUnreadBuilder,
                        mBuilder,
                        messages
                    )
                } else {
                    isImageNotification = false
                    modifyForAnnouncmentImage(
                        notificationManager,
                        mBuilder,
                        mUnreadBuilder,
                        messages[messages.size - 1],
                        messages
                    )
                }
                if (conversation.lastMessage == null && !ApplicationUtils.Companion.isEmptyString(
                        conversation.lastMessageId
                    )
                ) {
                    val message1 =
                        TTMessageRepository.Companion.instance?.getMessage(conversation.lastMessageId)
                    if (message1 != null) {
                        conversation.lastMessage = message1
                    }
                }
                if (conversation.lastMessage != null) {
                    mBuilder.setWhen(conversation.lastMessage.msgDate?.time?:0)
                }
                if (TelloApiClient.Companion.getInstance()?.isNotificationIcon() == true) {
                    TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
                } else {
                    TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
                }
                if (notificationChannel != null) {
                    notificationChannel?.id?.let { mBuilder.setChannelId(it) }
                }
            }
        }
        mBuilder.setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY)
        if (!isImageNotification) {
            //  notifications.remove(key);
            mBuilder.setPriority(NotificationCompat.PRIORITY_DEFAULT)
            notificationManager?.notify(key, NOTIFICATION_ID, mBuilder.build())
        }
    }

    private fun modifyForAnnouncmentIm(
        notificationManager: NotificationManager?,
        mBuilder: NotificationCompat.Builder,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        var url: String? = ""
        url = if (messages.lastOrNull()?.message?.contains("http") == true) {
            messages[messages.size - 1].message
        } else {
            NetworkConstants.BASE_URL1 + messages[messages.size - 1].message
        }
        val bigPictureStyle = NotificationCompat.BigPictureStyle()
        //  bigPictureStyle.setBigContentTitle(messages.get(messages.size() - 1).getCaption());
        //       mBuilder.setContentText(messages.get(messages.size() - 1).getMsgHeading());
        mBuilder.setStyle(bigPictureStyle)
        mBuilder.setPriority(Notification.PRIORITY_MAX)
        TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
        mBuilder.setContentText(messages[messages.size - 1].caption)
        mBuilder.setContentTitle(messages[messages.size - 1].msgHeading)
        // bigPictureStyle.setSummaryText(messages.get(messages.size() - 1).getCaption());
        //   bigPictureStyle.setBigContentTitle(messages.get(messages.size() - 1).getCaption());
        //      mBuilder.setCustomContentView(notificationLayout);
        //      mBuilder.setCustomBigContentView(contentView);
        val imageRequest = ImageRequestBuilder
            .newBuilderWithSource(Uri.parse(url))
            .setProgressiveRenderingEnabled(true)
            .build()
        val imagePipeline = Fresco.getImagePipeline()
        val dataSource = imagePipeline.fetchDecodedImage(imageRequest, null)
        dataSource.subscribe(object : BaseBitmapDataSubscriber() {
            override fun onNewResultImpl(bitmap: Bitmap?) {
                // You can use the bitmap in only limited ways
                // No need to do any cleanup.
                try {
                    //    mBuilder.setLargeIcon(bitmap);
                    bigPictureStyle.bigPicture(bitmap)
                    bigPictureStyle.bigLargeIcon(bitmap)

                    //    mBuilder.setStyle(new NotificationCompat.BigTextStyle()
                    //            .bigText(messages.get(messages.size() - 1).getCaption()));
                    notificationManager?.notify(
                        messages[messages.size - 1].departmentId,
                        NOTIFICATION_ID,
                        mBuilder.build()
                    )
                } catch (e: Exception) {
                }
            }

            override fun onFailureImpl(dataSource: DataSource<CloseableReference<CloseableImage>>) {
                // No cleanup required here.
//                try {
//                    bigPictureStyle.bigPicture(null);
//                    bigPictureStyle.setSummaryText("HELLOwORL");
//                    mBuilder.setContentText("text");
//                    mBuilder.setStyle(bigPictureStyle);
//                } catch (final Exception e) {
//                    modifyForTextOnly(mBuilder, mUnreadBuilder, tempMessages);
//                }
            }
        }, CallerThreadExecutor.getInstance())
    }

    private fun modifyForAnnouncmentImage(
        notificationManager: NotificationManager?,
        mBuilder: NotificationCompat.Builder,
        mUnreadBuilder: NotificationCompat.CarExtender.UnreadConversation.Builder,
        message: TTMessage,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        try {
            val bitmap = FileBackend.Companion.instance?.getThumbnail(message, getPixel(288), false)
            val tmp = ArrayList<TTMessage>()
            for (msg in tempMessages) {
                if (msg.msgType == TTMessage.MsgType.TYPE_TEXT.value && msg.transferable == null) {
                    tmp.add(msg)
                }
            }
            val bigPictureStyle = NotificationCompat.BigPictureStyle()
            bigPictureStyle.bigPicture(bitmap)
            if (tmp.size > 0) {
                val text = getMergedBodies(tmp)
                bigPictureStyle.setSummaryText(text)
                mBuilder.setContentText(text)
            } else {
                mBuilder.setContentText(
                    getInstance()!!.telloContext.getString(
                        R.string.received_x_file,
                        UIHelper.getFileDescriptionString(getInstance()!!.telloContext, message)
                    )
                )
            }
            mBuilder.setStyle(bigPictureStyle)
        } catch (e: FileNotFoundException) {
            modifyForAnnouncmentText(notificationManager, mUnreadBuilder, mBuilder, tempMessages)
        }
    }

    private fun modifyForAnnouncmentText(
        notificationManager: NotificationManager?,
        mUnreadBuilder: NotificationCompat.CarExtender.UnreadConversation.Builder,
        mBuilder: NotificationCompat.Builder,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        val conversation = TTConversationRepository.Companion.getInstance().getConversationForJid(
            tempMessages[0].contactId
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val messagingStyle = NotificationCompat.MessagingStyle(
                getInstance()!!.telloContext.getString(R.string.me)
            )
            for (message in tempMessages) {
                if (message.msgType != TTMessage.MsgType.TYPE_NEWS.value && message.msgType != TTMessage.MsgType.TYPE_NEWSWB.value) {
                    var sender: String? = ""
                    sender = if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                        val ttConversation = TTConversationRepository.Companion.getInstance()
                            .getConversationForJid(message.contactId)
                        if (ttConversation?.isCe == true) {
                            ttConversation.conversationName
                        } else {
                            UIHelper.getMessageDisplayName(message, conversation)
                        }
                    } else {
                        null
                    }
                    sender = message.departmentName
                    var user: Person
                    if (ApplicationUtils.Companion.isAppEnglish) {
                        sender = message.departmentName
                        user = Person.Builder().setIcon(
                            IconCompat.createWithResource(
                                getInstance()!!.telloContext,
                                R.drawable.image_circle
                            )
                        )
                            .setImportant(true).setName(sender).build()
                    } else {
                        sender = message.departmentName_u
                        user = Person.Builder().setIcon(
                            IconCompat.createWithResource(
                                getInstance()!!.telloContext,
                                R.drawable.image_circle
                            )
                        )
                            .setImportant(true).setName(sender).build()
                    }
                    messagingStyle.addMessage(
                        formatBody(
                            UIHelper.getMessagePreview(
                                getInstance()!!.telloContext,
                                message
                            ).first
                        ), message.msgDate?.time?:0, user
                    )
                }
            }
            mBuilder.setStyle(messagingStyle)
        } else {
            mBuilder.setStyle(
                NotificationCompat.BigTextStyle().bigText(getMergedBodies(tempMessages))
            )
            mBuilder.setContentText(
                formatBody(
                    UIHelper.getMessagePreview(
                        getInstance()!!.telloContext,
                        tempMessages[0]
                    ).first
                )
            )
        }
        for (message in tempMessages) {
            if (message.msgType != TTMessage.MsgType.TYPE_NEWS.value && message.msgType != TTMessage.MsgType.TYPE_NEWSWB.value) {
                val preview = UIHelper.getMessagePreview(getInstance()!!.telloContext, message)
                // only show user written text
                if (preview.second != null && preview.second==false) {
                    mUnreadBuilder.addMessage(preview.first)
                    mUnreadBuilder.setLatestTimestamp(message.msgDate?.time?:0)
                }
            }
        }
    }

    private fun modifyForAnnouncmentVideo(
        notificationManager: NotificationManager?,
        mUnreadBuilder: NotificationCompat.CarExtender.UnreadConversation.Builder,
        mBuilder: NotificationCompat.Builder,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        val conversation = TTConversationRepository.Companion.getInstance().getConversationForJid(
            tempMessages[0].contactId
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val messagingStyle = NotificationCompat.MessagingStyle(
                getInstance()!!.telloContext.getString(R.string.me)
            )
            for (message in tempMessages) {
                if (message.msgType != TTMessage.MsgType.TYPE_NEWS.value && message.msgType != TTMessage.MsgType.TYPE_NEWSWB.value) {
                    var sender: String? = ""
                    sender = if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                        val ttConversation = TTConversationRepository.Companion.getInstance()
                            .getConversationForJid(message.contactId)
                        if (ttConversation?.isCe == true) {
                            ttConversation.conversationName
                        } else {
                            UIHelper.getMessageDisplayName(message, conversation)
                        }
                    } else {
                        null
                    }
                    sender = message.departmentName
                    var user: Person
                    if (ApplicationUtils.Companion.isAppEnglish) {
                        sender = message.departmentName
                        user = Person.Builder().setIcon(
                            IconCompat.createWithResource(
                                getInstance()!!.telloContext,
                                R.drawable.image_circle
                            )
                        )
                            .setImportant(true).setName(sender).build()
                    } else {
                        sender = message.departmentName_u
                        user = Person.Builder().setIcon(
                            IconCompat.createWithResource(
                                getInstance()!!.telloContext,
                                R.drawable.image_circle
                            )
                        )
                            .setImportant(true).setName(sender).build()
                    }
                    if (message.caption == "") {
                        messagingStyle.addMessage(
                            formatBody(
                                UIHelper.getMessagePreview(
                                    getInstance()!!.telloContext,
                                    message
                                ).first
                            ), message.msgDate?.time?:0, user
                        )
                    } else {
                        messagingStyle.addMessage(message.caption, message.msgDate?.time?:0, user)
                    }
                }
            }
            mBuilder.setStyle(messagingStyle)
        } else {
            mBuilder.setStyle(
                NotificationCompat.BigTextStyle().bigText(getMergedBodies(tempMessages))
            )
            mBuilder.setContentText(
                formatBody(
                    UIHelper.getMessagePreview(
                        getInstance()!!.telloContext,
                        tempMessages[0]
                    ).first
                )
            )
        }
        for (message in tempMessages) {
            if (message.msgType != TTMessage.MsgType.TYPE_NEWS.value && message.msgType != TTMessage.MsgType.TYPE_NEWSWB.value) {
                val preview = UIHelper.getMessagePreview(getInstance()!!.telloContext, message)
                // only show user written text
                if (preview.second != null && preview.second==false) {
                    mUnreadBuilder.addMessage(preview.first)
                    mUnreadBuilder.setLatestTimestamp(message.msgDate?.time?:0)
                }
            }
        }
    }

    private fun createNotificationChannel(notificationManager: NotificationManager?) {
        if (notificationChannel == null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationChannel = NotificationChannel(
                    PRIMARY_CHANNEL,
                    "Default",
                    NotificationManager.IMPORTANCE_HIGH
                )
                notificationChannel?.lightColor = Color.BLUE
                notificationChannel?.importance = NotificationManager.IMPORTANCE_HIGH
                notificationChannel?.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                notificationManager?.createNotificationChannel(notificationChannel!!)
            }
        }
    }

    private fun displayNotification(
        messages: ArrayList<TTMessage>,
        notificationManager: NotificationManager?,
        bitmap: Bitmap?,
        notify: Boolean
    ) {
        continueBuildingNotification(messages, notificationManager, bitmap, notify)
    }

    private fun continueBuildingNotification(
        messages: ArrayList<TTMessage>,
        notificationManager: NotificationManager?,
        bitmap: Bitmap?,
        notify: Boolean
    ) {
        val mBuilder: NotificationCompat.Builder
        //  if(messages.get(messages.size()-1).getDptType().equals("1")){
        //      NotificationCompat.Builder singleBuilder = buildSingleConversations(notificationManager, entry.getValue(), null);
        //      sendMessage(notificationManager,messages.get(messages.size()-1),notifications.get(notifications.size()-1)..getKey());
        //  }else {
        mBuilder = buildSingleConversations(notificationManager, messages, bitmap)
        mBuilder.setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY)
        modifyForSoundVibrationAndLight(mBuilder, notify)
        notificationManager?.notify(NOTIFICATION_ID, mBuilder.build())
        //   }
    }

    private fun modifyForSoundVibrationAndLight(
        mBuilder: NotificationCompat.Builder,
        notify: Boolean
    ) {
        if (notify) {
            val dat = 70
            val pattern = longArrayOf(0, (3 * dat).toLong(), dat.toLong(), dat.toLong())
            mBuilder.setVibrate(pattern)
            mBuilder.setOnlyAlertOnce(false)
            mBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mBuilder.setCategory(Notification.CATEGORY_MESSAGE)
        }
        mBuilder.setPriority(if (notify) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_LOW)
        setNotificationColor(mBuilder)
        mBuilder.setDefaults(0)
        mBuilder.setLights(-0xff0100, 2000, 3000)
    }

    private fun buildMultipleConversation(): NotificationCompat.Builder {
        val mBuilder = NotificationCompat.Builder(
            getInstance()!!.telloContext
        )
        val style = NotificationCompat.InboxStyle()
        style.setBigContentTitle(
            notifications.size.toString() + " " + getInstance()!!.telloContext
                .getString(R.string.unread_conversations)
        )
        val names = StringBuilder()
        var conversation: TTConversation? = null
        for (messages in notifications.values) {
            if (messages.size > 0) {
                conversation = TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(messages[0].contactId)
                if (conversation == null) {
                    continue
                }
                val name = conversation.conversationName
                var styledString: SpannableString
                styledString = SpannableString(
                    name + ": " + UIHelper.getMessagePreview(
                        getInstance()!!.telloContext,
                        messages[0]
                    ).first
                )
                styledString.setSpan(StyleSpan(Typeface.BOLD), 0, name.length, 0)
                style.addLine(formatBody(styledString))
                names.append(name)
                names.append(", ")
            }
        }
        if (names.length >= 2) {
            names.delete(names.length - 2, names.length)
        }
        mBuilder.setContentTitle(
            notifications.size.toString() + " " + getInstance()!!.telloContext
                .getString(R.string.unread_conversations)
        )
        mBuilder.setContentText(names.toString())
        mBuilder.setStyle(style)
        if (conversation != null) {
            mBuilder.setContentIntent(createContentIntent(conversation))
        }
        mBuilder.setGroupSummary(true)
        mBuilder.setGroup(CONVERSATIONS_GROUP)
        if (TelloApiClient.Companion.getInstance()?.isNotificationIcon() == true) {
            TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
        } else {
            TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
        }
        if (notificationChannel != null) {
            notificationChannel?.id?.let { mBuilder.setChannelId(it) }
        }
        return mBuilder
    }

    private fun buildSingleConversations(
        notificationManager: NotificationManager?,
        messages: ArrayList<TTMessage>,
        bitmap: Bitmap?
    ): NotificationCompat.Builder {
        var bitmap = bitmap
        val mBuilder = NotificationCompat.Builder(getInstance()!!.telloContext, "default")
        if (messages.size >= 1) {
            val conversation = TTConversationRepository.Companion.getInstance().getConversationForJid(
                messages[0].contactId
            )
            if (conversation != null) {
                val convoName: String
                convoName = if (conversation.isCe) {
                    conversation.conversationName
                } else {
                    conversation.conversationName
                }
                val mUnreadBuilder =
                    NotificationCompat.CarExtender.UnreadConversation.Builder(convoName)
                //// TODO: 9/13/2017 make round image notification
                //     if (bitmap == null) {
                bitmap = BitmapFactory.decodeResource(
                    getInstance()!!.telloContext.resources,
                    R.drawable.image_circle
                )
                //     }
                mBuilder.setLargeIcon(bitmap)
                mBuilder.setContentTitle(messages[0].departmentName)
                var message = TTMessage()
                if (getImage(messages)?.let { message = it } != null) {
                    modifyForImage(mBuilder, mUnreadBuilder, message, messages)
                } else {
                    modifyForTextOnly(mBuilder, mUnreadBuilder, messages)
                }
                //                if ((message = getFirstDownloadableMessage(messages)) != null) {
//                    mBuilder.addAction(R.drawable.download_icon_sdk,
//                            TelloApplication.instance.getResources().getString(R.string.download_x_file,
//                                    UIHelper.getFileDescriptionString(TelloApplication.instance, message)),
//                            createDownloadIntent(message, conversation)
//                    );
//                }
                if (getFirstLocationMessage(messages)?.let { message = it } != null) {
                    mBuilder.addAction(
                        R.drawable.location_icon,
                        getInstance()!!.telloContext.getString(R.string.show_location),
                        createShowLocationIntent(message)
                    )
                }
                if (conversation.lastMessage == null && !ApplicationUtils.Companion.isEmptyString(
                        conversation.lastMessageId
                    )
                ) {
                    val message1 =
                        TTMessageRepository.Companion.instance?.getMessage(conversation.lastMessageId)
                    if (message1 != null) {
                        conversation.lastMessage = message1
                    }
                }
                if (conversation.lastMessage != null) {
                    mBuilder.setWhen(conversation.lastMessage.msgDate?.time?:0)
                }
                if (TelloApiClient.Companion.getInstance()?.isNotificationIcon() == true) {
                    TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
                } else {
                    TelloApiClient.Companion.getInstance()?.notificationIcon?.let { mBuilder.setSmallIcon(it) }
                }
                if (notificationChannel != null) {
                    notificationChannel?.id?.let { mBuilder.setChannelId(it) }
                }
                mBuilder.setContentIntent(createContentIntent(conversation))
            }
        }
        // mBuilder.setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY);
        return mBuilder
    }

    private fun modifyForAnnouncment(
        notificationManager: NotificationManager?,
        mBuilder: NotificationCompat.Builder,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        var url: String? = ""
        url = if (messages.lastOrNull()?.message?.contains("http") == true) {
            messages[messages.size - 1].message
        } else {
            NetworkConstants.BASE_URL1 + messages[messages.size - 1].message
        }
        val bigPictureStyle = NotificationCompat.BigPictureStyle()
        val imageRequest = ImageRequestBuilder
            .newBuilderWithSource(Uri.parse(url))
            .setProgressiveRenderingEnabled(true)
            .build()
        val imagePipeline = Fresco.getImagePipeline()
        val dataSource = imagePipeline.fetchDecodedImage(imageRequest, null)
        dataSource.subscribe(object : BaseBitmapDataSubscriber() {
            override fun onNewResultImpl(bitmap: Bitmap?) {
                // You can use the bitmap in only limited ways
                // No need to do any cleanup.
                try {
                    mBuilder.setLargeIcon(bitmap)
                    bigPictureStyle.bigPicture(bitmap)
                    val notificationLayout = RemoteViews(
                        getInstance()!!.telloContext.packageName,
                        R.layout.notification_small
                    )
                    val contentView = RemoteViews(
                        getInstance()!!.telloContext.packageName,
                        R.layout.custom_notification_layout
                    )
                    contentView.setImageViewBitmap(R.id.image, bitmap)
                    contentView.setImageViewBitmap(R.id.img_banner, bitmap)
                    notificationLayout.setImageViewBitmap(R.id.img_banner, bitmap)
                    notificationLayout.setTextViewText(
                        R.id.title_text,
                        messages[messages.size - 1].msgHeading
                    )
                    notificationLayout.setTextViewText(
                        R.id.tv_captionn,
                        messages[messages.size - 1].caption
                    )
                    contentView.setTextViewText(R.id.title, messages[messages.size - 1].msgHeading)
                    contentView.setTextViewText(
                        R.id.tv_caption,
                        messages[messages.size - 1].caption
                    )
                    bigPictureStyle.setSummaryText(messages[messages.size - 1].caption)
                    bigPictureStyle.setBigContentTitle(messages[messages.size - 1].msgHeading)
                    mBuilder.setContentText(messages[messages.size - 1].caption)
                    mBuilder.setContentTitle(messages[messages.size - 1].msgHeading)
                    mBuilder.setStyle(bigPictureStyle)
                    mBuilder.setPriority(Notification.PRIORITY_MAX)
                    mBuilder.setCustomContentView(notificationLayout)
                    mBuilder.setCustomBigContentView(contentView)
                    mBuilder.setSmallIcon(R.drawable.notification_icon_sdk)
                    //    mBuilder.setStyle(new NotificationCompat.BigTextStyle()
                    //            .bigText(messages.get(messages.size() - 1).getCaption()));
                    notificationManager?.notify(
                        messages[messages.size - 1].departmentId,
                        NOTIFICATION_ID,
                        mBuilder.build()
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailureImpl(dataSource: DataSource<CloseableReference<CloseableImage>>) {
                // No cleanup required here.
//                try {
//                    bigPictureStyle.bigPicture(null);
//                    bigPictureStyle.setSummaryText("HELLOwORL");
//                    mBuilder.setContentText("text");
//                    mBuilder.setStyle(bigPictureStyle);
//                } catch (final Exception e) {
//                    modifyForTextOnly(mBuilder, mUnreadBuilder, tempMessages);
//                }
            }
        }, CallerThreadExecutor.getInstance())
    }

    //    public static Bitmap getScaleBitmap(Bitmap bitmap, int check) {
    //        final Bitmap toBeCropped = bitmap;
    //
    //        final BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
    //        bitmapOptions.inTargetDensity = 1;
    //        toBeCropped.setDensity(Bitmap.DENSITY_NONE);
    //        int top = 0;
    //        int bottom = 0;
    //        int targetheight = 0;
    //        if (check == 0) {// return 1st half of image
    //            top = 0;
    //            bottom = bitmap.getHeight() / 2;
    //            bottom = (bottom / 2) + 20;
    //        } else {// return 2nd half of image
    //            top = (bitmap.getHeight() / 2) - 10;
    //            bottom = (bitmap.getHeight() / 2) - 10;
    //
    //        }
    //        int fromHere = (int) (toBeCropped.getHeight() * 0.5);
    //
    //        Bitmap croppedBitmap = Bitmap.createBitmap(toBeCropped, 0, top, toBeCropped.getWidth(), bottom);
    //        return croppedBitmap;
    //
    //
    //    }
    private fun modifyForImage(
        builder: NotificationCompat.Builder,
        uBuilder: NotificationCompat.CarExtender.UnreadConversation.Builder,
        message: TTMessage,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        try {
            val bitmap = FileBackend.Companion.instance?.getThumbnail(message, getPixel(288), false)
            val tmp = ArrayList<TTMessage>()
            for (msg in tempMessages) {
                if (msg.msgType == TTMessage.MsgType.TYPE_TEXT.value && msg.transferable == null) {
                    tmp.add(msg)
                }
            }
            val bigPictureStyle = NotificationCompat.BigPictureStyle()
            bigPictureStyle.bigPicture(bitmap)
            if (tmp.size > 0) {
                val text = getMergedBodies(tmp)
                bigPictureStyle.setSummaryText(text)
                builder.setContentText(text)
            } else {
                builder.setContentText(
                    getInstance()!!.telloContext.getString(
                        R.string.received_x_file,
                        UIHelper.getFileDescriptionString(getInstance()!!.telloContext, message)
                    )
                )
            }
            builder.setStyle(bigPictureStyle)
        } catch (e: FileNotFoundException) {
            modifyForTextOnly(builder, uBuilder, tempMessages)
        }
    }

    private fun modifyForTextOnly(
        builder: NotificationCompat.Builder,
        uBuilder: NotificationCompat.CarExtender.UnreadConversation.Builder,
        messages: ArrayList<TTMessage>
    ) {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        val conversation = TTConversationRepository.Companion.getInstance().getConversationForJid(
            tempMessages[0].contactId
        )
        val messagingStyle = NotificationCompat.MessagingStyle(
            getInstance()!!.telloContext.getString(R.string.me)
        )
        for (message in tempMessages) {
            var sender: String? = ""
            sender = if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                val ttConversation = TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(message.contactId)
                if (ttConversation?.isCe == true) {
                    ttConversation.conversationName
                } else {
                    UIHelper.getMessageDisplayName(message, conversation)
                }
            } else {
                null
            }
            var user: Person
            if (ApplicationUtils.Companion.isAppEnglish) {
                sender = message.departmentName
                user = Person.Builder().setIcon(
                    IconCompat.createWithResource(
                        getInstance()!!.telloContext,
                        R.drawable.image_circle
                    )
                )
                    .setImportant(true).setName(sender).build()
            } else {
                sender = message.departmentName_u
                user = Person.Builder().setIcon(
                    IconCompat.createWithResource(
                        getInstance()!!.telloContext,
                        R.drawable.image_circle
                    )
                )
                    .setImportant(true).setName(sender).build()
            }
            // formatBody(UIHelper.getMessagePreview(TelloApplication.instance, message).first)
            messagingStyle.addMessage(
                UIHelper.getFileDescriptionString(
                    getInstance()!!.telloContext,
                    message
                ), message.msgDate?.time?:0, user
            )
        }

        // builder.setSmallIcon(R.drawable.bykea_icon);
        // builder.setLargeIcon(BitmapFactory.decodeResource(TelloApplication.instance.getResources(), R.drawable.bykea_icon));
        builder.setStyle(messagingStyle)
        for (message in tempMessages) {
            //    Pair<String, Boolean> preview = UIHelper.getMessagePreview(TelloApplication.instance, message);
            // only show user written text
            //    if (preview.second != null && !preview.second) {
            uBuilder.addMessage(message.message)
            uBuilder.setLatestTimestamp(message.msgDate?.time?:0)
            //==    }
        }
    }

    private fun getImage(messages: ArrayList<TTMessage>): TTMessage? {
        var image: TTMessage? = null
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        for (message in tempMessages) {
            if (message.msgStatus != TTMessage.MsgStatus.RECEIVED) {
                return null
            }
            if (message.msgType != TTMessage.MsgType.TYPE_TEXT.value && message.transferable == null && message.fileParams.height > 0) {
                image = message
            }
        }
        return image
    }

    private fun getFirstDownloadableMessage(messages: ArrayList<TTMessage>): TTMessage? {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        for (message in tempMessages) {
            if (message.transferable != null || message.msgType == TTMessage.MsgType.TYPE_TEXT.value && message.treatAsDownloadable()) {
                return message
            }
        }
        return null
    }

    private fun getFirstLocationMessage(messages: ArrayList<TTMessage>): TTMessage? {
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        for (message in tempMessages) {
            if (GeoHelper.isGeoUri(message.message)) {
                return message
            }
        }
        return null
    }

    private fun getMergedBodies(messages: ArrayList<TTMessage>): CharSequence {
        val text = StringBuilder()
        val tempMessages = messages.clone() as ArrayList<TTMessage>
        for (message in tempMessages) {
            if (text.length != 0) {
                text.append("\n")
            }
            text.append(
                formatBody(
                    UIHelper.getMessagePreview(
                        getInstance()!!.telloContext,
                        message
                    ).first
                )
            )
        }
        return text.toString()
    }

    private fun createShowLocationIntent(message: TTMessage): PendingIntent {
        val intents: Iterable<Intent> = GeoHelper.createGeoIntentsFromMessage(message, "")
        for (intent in intents) {
            if (intent.resolveActivity(getInstance()!!.telloContext.packageManager) != null) {
                return PendingIntent.getActivity(
                    getInstance()!!.telloContext,
                    18,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
        }
        return createOpenConversationsIntent()
    }

    private fun createContentIntent(
        conversation: TTConversation,
        downloadMessageUuid: String? = null,
        corporateEntity: Boolean = conversation.isCe
    ): PendingIntent {
        val viewConversationIntent =
            Intent(getInstance()!!.telloContext, ConversationActivity::class.java)
        viewConversationIntent.putExtra("conversationId", conversation.contactJid)
        viewConversationIntent.putExtra("isFromNotification", true)
        viewConversationIntent.putExtra("isCorporateChat", true)
        if (ApplicationUtils.Companion.isAppEnglish) {
            viewConversationIntent.putExtra(
                "departmentId",
                TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(conversation.contactJid)?.lastMessage?.departmentName
            )
        } else {
            viewConversationIntent.putExtra(
                "departmentId",
                TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(conversation.contactJid)?.lastMessage?.departmentName_u.toString()
            )
        }
        viewConversationIntent.putExtra(
            "chatID",
            TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.chatId
        )
        if (TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.dptType != null
        ) {
            if (TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(conversation.contactJid)?.lastMessage?.dptType == "2"
            ) {
                viewConversationIntent.putExtra("isTwoWayDepartment", true)
            } else {
                viewConversationIntent.putExtra("isTwoWayDepartment", false)
            }
        } else {
            val account = TTAccountRepository.getInstance().account
            if (TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(conversation.contactJid)?.contactJid == account.userName
            ) {
                viewConversationIntent.putExtra("isTwoWayDepartment", true)
            } else {
                viewConversationIntent.putExtra("isTwoWayDepartment", false)
            }
        }
        viewConversationIntent.putExtra(
            "message_id",
            TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.messageId
        )
        viewConversationIntent.putExtra(
            "message_type",
            TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.msgType
        )
        viewConversationIntent.putExtra(
            "campaignId",
            TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.campaignId
        )
        viewConversationIntent.putExtra(
            "dept_id",
            TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.departmentId
        )
        if (TTConversationRepository.Companion.getInstance().getConversationForJid(conversation.contactJid)?.lastMessage?.dptImage != null
        ) {
            viewConversationIntent.putExtra(
                "dptImage",
                TTConversationRepository.Companion.getInstance()
                    .getConversationForJid(conversation.contactJid)?.lastMessage?.dptImage
            )
        } else {
            viewConversationIntent.putExtra("dptImage", "")
        }
        viewConversationIntent.setAction(ConversationActivity.Companion.ACTION_VIEW_CONVERSATION)
        //   viewConversationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//        TaskStackBuilder stackBuilder = TaskStackBuilder.create(TelloApplication.instance);
//        stackBuilder.addNextIntentWithParentStack(viewConversationIntent);
//        if (downloadMessageUuid != null) {
//            viewConversationIntent.putExtra(ConversationActivity.EXTRA_DOWNLOAD_UUID, downloadMessageUuid);
//            return stackBuilder.getPendingIntent(conversation.getContactJid().hashCode() % 389782,
//                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
//        } else {
//            return stackBuilder.getPendingIntent(conversation.getContactJid().hashCode() % 936236,
//                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
//        }
        return if (downloadMessageUuid != null) {
            viewConversationIntent.putExtra(
                ConversationActivity.Companion.EXTRA_DOWNLOAD_UUID,
                downloadMessageUuid
            )
            PendingIntent.getActivity(
                getInstance()!!.telloContext,
                conversation.contactJid.hashCode() % 389782,
                viewConversationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            PendingIntent.getActivity(
                getInstance()!!.telloContext,
                conversation.contactJid.hashCode() % 936236,
                viewConversationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }

    private fun createDownloadIntent(
        message: TTMessage,
        conversation: TTConversation
    ): PendingIntent {
        return createContentIntent(conversation, message.messageId, conversation.isCe)
    }

    private fun getPixel(dp: Int): Int {
        val metrics = getInstance()!!.telloContext.resources
            .displayMetrics
        return (dp * metrics.density).toInt()
    }

    private fun markLastNotification() {
        mLastNotification = SystemClock.elapsedRealtime()
    }

    private fun createOpenConversationsIntent(): PendingIntent {
        return PendingIntent.getActivity(
            getInstance()!!.telloContext,
            0,
            Intent(getInstance()!!.telloContext, ConversationActivity::class.java),
            0 or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun formatBody(spannableString: SpannableString): Spanned {
        return formatBody(spannableString.toString())
    }

    private fun formatBody(body: String?): Spanned {
        var body = body
        var countBold = 0
        var countItalic = 0
        var countStrike = 0
        for (i in 0 until body?.length!!) {
            when (body[i]) {
                '*' -> countBold++
                '_' -> countItalic++
                '~' -> countStrike++
            }
        }
        body = replaceFormat(body, countBold, '*')
        body = replaceFormat(body, countItalic, '_')
        body = replaceFormat(body, countStrike, '~')
        return Html.fromHtml(body)
    }

    private fun replaceFormat(body: String?, count: Int, s: Char): String? {
        if (count == 0 || count % 2 != 0) return body
        var flag = 1
        val bodyBuilder = StringBuilder(body)
        for (i in bodyBuilder.indices) {
            if (bodyBuilder[i] == s) {
                bodyBuilder.replace(i, i + 1, getMarkerForSymbol(flag, s))
                flag++
            }
        }
        return bodyBuilder.toString()
    }

    private fun getMarkerForSymbol(flag: Int, s: Char): String {
        return if (s == '*') {
            if (flag % 2 == 0) "</b>" else "<b>"
        } else if (s == '_') {
            if (flag % 2 == 0) "</i>" else "<i>"
        } else {
            if (flag % 2 == 0) "</strike>" else "<strike>"
        }
    }

    val unreadCount: Int
        get() {
            var count = 0
            for (allConversation in TTConversationRepository.Companion.getInstance().allConversations) {
                count = count + allConversation.unreadCount
            }
            return count
        }

    companion object {
        var instance: NotificationService? = null
            get() {
                if (field == null) {
                    field = NotificationService()
                }
                return field
            }
            private set
        private const val CONVERSATIONS_GROUP = "com.udna.tellotalk"
        private const val PRIMARY_CHANNEL = "default"
        private const val NOTIFICATION_ID_MULTIPLIER = 1024 * 1024
        private const val NOTIFICATION_ID = 0x2342
    }
}