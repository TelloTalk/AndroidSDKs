package com.tilismtech.tellotalksdk.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ConversationActivityViewModel : ViewModel() {
    private var messages: List<TTMessage>? = ArrayList()
    private val messageLiveData = MutableLiveData<List<TTMessage>>()
    private val typingLiveData = MutableLiveData<Boolean>()
    fun getAllConversationMessages(
        conversationId: String?, isTwoWay: Boolean, offset: Int
    ): LiveData<List<TTMessage>> {
        return if (isTwoWay) {
            CoroutineScope(Dispatchers.IO).launch {
                messages = TTMessageRepository.instance!!.getAllMessagesByProfileId(
                    conversationId, offset
                )
                messageLiveData.postValue(messages?.takeLast(30))
            }
            messageLiveData
        } else {
            TTMessageRepository.instance!!.getAllOneWayMessages(conversationId)
        }
    }

    fun setTyping(isTyping: Boolean) {
        typingLiveData.postValue(isTyping)
    }

    fun typingMessages(): LiveData<Boolean> {
        return typingLiveData
    }

    fun getAllMessagesFromDb(
        conversationId: String?, isTwoWay: Boolean, offset: Int
    ): LiveData<List<TTMessage>> {
        return if (isTwoWay) {
            TTMessageRepository.instance!!.getAllConversationMessages(
                conversationId, offset
            )
        } else {
            TTMessageRepository.instance!!.getAllOneWayMessages(conversationId)
        }
    }

//    private val apiMessagesLiveData = TTMessageRepository.instance!!.apiMessageLiveData

//    fun getAllMessagesFromAPI(conversationId: String?,
//                              isTwoWay: Boolean
//    ): LiveData<List<TTMessage>> {
//        return if (isTwoWay) {
//            Log.e("Getter","getAllMessagesFromAPI called")
//            apiMessagesLiveData
//        } else {
//            TTMessageRepository.instance!!.getAllOneWayMessages(conversationId)
//        }
//    }

    fun insertMessage(message: TTMessage?) {
        if(message!=null){
            TTMessageRepository.instance!!.insertMessage(message)
        }
    }

    fun updateMessage(vararg message: TTMessage?) {
        TTMessageRepository.instance!!.updateMessage(*message)
    }

    fun updateMessageStatus(id: String?, status: Int) {
        TTMessageRepository.instance!!.updateMessageStatus(id, status)
    }

    fun deleteMessage(ttMessage: TTMessage?) {
        TTMessageRepository.instance!!.deleteMessage(ttMessage)
    }

    fun deleteTypingMessages() {
        TTMessageRepository.instance!!.deleteTypingMessages()
    }

    fun deletePrevMessages(chatId: String?) {
        TTMessageRepository.instance!!.deletePrevMessages(chatId)
    }

    fun getFirstUnreadMessage(conversationId: String?): TTMessage {
        return TTMessageRepository.instance!!.getFirstUnreadMessage(conversationId)
    }

    val allUnSentMessagesForP2P: ArrayList<TTMessage>
        get() = TTMessageRepository.instance!!.allUnSentMessagesForP2P

    fun getLastMessageOfConversation(conversationId: String?): TTMessage? {
        return TTMessageRepository.instance!!.getLastMessageOfConversation(conversationId)
    }

    fun getMessageFromObserver(messageId: String?): LiveData<List<TTMessage>> {
        return TTMessageRepository.instance!!.getMessageFromObserver(messageId)
    }

    fun getTypingMessageFromDB(messageId: String?): TTMessage? {
        return TTMessageRepository.instance!!.getTypingMessageFromDB(messageId)
    }

    fun updateMessageList(messageList: List<TTMessage>?) {
        if (messageList.isNullOrEmpty()) {
            // If messageList is null or empty, set messages to an empty list
            messages = emptyList()
        } else {
            // Check if the size of messageList has changed
            val sizeChanged = messageList.size != messages?.size

            // Check if any item has been changed
            val contentChanged = messages?.zip(messageList)?.any { (oldMessage, newMessage) ->
                oldMessage != newMessage
            } ?: false

            if (sizeChanged || contentChanged) {
                // If size or content has changed, update messages and post the updated list
                messages = messageList
                messageLiveData.postValue(messages ?: listOf())
            }
        }
    }

    companion object {
        private var instance: ConversationActivityViewModel? = null

        fun getInstance(): ConversationActivityViewModel {
            if (instance == null) {
                instance = ConversationActivityViewModel()
            }
            return instance!!
        }
    }
}
