package com.tilismtech.tellotalksdk.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel


class BotFormDialogViewModel() : ViewModel() {
    // Add your ViewModel code here

   // suspend fun getListFromApi(): List<MyDataModel> {
   //     return withContext(Dispatchers.IO) {
   //         apiService.getData()
   //     }
   // }

}