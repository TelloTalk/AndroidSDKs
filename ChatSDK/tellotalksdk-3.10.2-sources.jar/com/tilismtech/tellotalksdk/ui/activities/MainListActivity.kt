package com.tilismtech.tellotalksdk.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations
import com.tilismtech.tellotalksdk.databinding.ActivityMainListBinding
import com.tilismtech.tellotalksdk.listeners.MessageCounterListener
import com.tilismtech.tellotalksdk.managers.ChatManager.Companion.instance
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.DptListAdapter
import java.util.Timer

class MainListActivity : TelloActivity(), MessageCounterListener {
    private var binding: ActivityMainListBinding? = null
    private var departments: ArrayList<DepartmentConversations?>? = null
    private var adapter: DptListAdapter? = null
    private var message: String? = null
    private var timer: Timer? = null
    private var custom_data: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainListBinding.inflate(layoutInflater)
        setContentView(binding!!.getRoot())
        if (intent.hasExtra("message")) {
            message = intent.getStringExtra("message")
            custom_data = intent.getStringExtra("custom_data")
        }

        binding!!.backBtnIcon.setOnClickListener { onBackPressed() }
        setDepartment()
    }

    private fun startTimer() {
        timer = Timer()
        refreshAdapter()

        //        timer.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        refreshAdapter();
//                    }
//                });
//            }
//        }, 0, 1000);
    }

    private fun refreshAdapter() {
        //  Department[] depart = DepartmentRepository.getInstance().getAllCorporateDpt();
        departments!!.clear()
        departments!!.addAll(instance!!.departmentConversation!!)
        if (adapter != null) adapter!!.notifyDataSetChanged()
    }

    private fun setDepartment() {
        departments = ArrayList()
        val depart: ArrayList<DepartmentConversations?>? = instance!!.departmentConversation
        if (depart == null || depart.size == 0) {
            Toast.makeText(this@MainListActivity, "No service available", Toast.LENGTH_LONG).show()
            this.corporateDepartment
        } else {
            departments!!.addAll(instance!!.departmentConversation!!)
            setUpAdapter()
        }
        startTimer()
    }

    private val corporateDepartment: Unit
        get() {
            instance!!.getDepartment { it ->
                if (it.isNotEmpty()) {
                    departments!!.addAll(instance!!.departmentConversation!!)
                    setUpAdapter()
                }
            }
        }

    private fun setUpAdapter() {
        val manager =
            LinearLayoutManager(this@MainListActivity, LinearLayoutManager.VERTICAL, false)
        binding!!.chatList.addItemDecoration(
            DividerItemDecoration(
                this@MainListActivity,
                DividerItemDecoration.VERTICAL
            )
        )
        binding!!.chatList.setLayoutManager(manager)
        binding!!.chatList.setHasFixedSize(true)
        binding!!.chatList.setItemViewCacheSize(30)
        binding!!.chatList.setDrawingCacheEnabled(true)
        binding!!.chatList.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH)
        adapter = DptListAdapter(this@MainListActivity, departments, message, custom_data)
        binding!!.chatList.setAdapter(adapter)
        for (department in departments!!) {
            instance!!.getMessageAnnouncement(true, department?.getDepartment()?.dptId)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (timer != null) {
            timer!!.cancel()
            timer = null
        }
    }

    override fun onStop() {
        super.onStop()
        if (timer != null) {
            timer!!.cancel()
        }
    }

    override fun onResume() {
        super.onResume()
        setupBadge()
    }

    private fun setupBadge() {
        instance!!.setNotificationListener(this@MainListActivity)
    }

    override fun onAnnouncementCountUpdate(count: Int) {
        refreshAdapter()
    }

    override fun onMessageCountUpdate(count: Int) {
        refreshAdapter()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("TAG", "Value")
        if (requestCode == 420) {
            if (data != null) {
                if (data.hasExtra("result")) {
                    if (data.getBooleanExtra("result", false)) {
                        if (adapter != null) {
                            adapter!!.message = null
                            adapter!!.notifyDataSetChanged()
                        }
                    }
                }
            }
        }
    }
}
