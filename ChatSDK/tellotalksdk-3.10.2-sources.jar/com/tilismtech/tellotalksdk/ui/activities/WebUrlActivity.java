package com.tilismtech.tellotalksdk.ui.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.tilismtech.tellotalksdk.R;

public class WebUrlActivity extends AppCompatActivity {

    private WebView webview;
    private String Url = "";
    private LinearLayout back_action_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_url);
        Toolbar toolbar = (Toolbar) findViewById(R.id.conversation_toolbar);
        setSupportActionBar(toolbar);
        initView();
    }

    private void initView() {
        webview = findViewById(R.id.web_view);
        back_action_button = (LinearLayout)findViewById(R.id.back_action_button);
        if(getIntent().hasExtra("url")) {
            Url = getIntent().getStringExtra("url");
            if (Url.contains("youtube") || Url.contains("youtu.be")) {
//                String dataUrl =
//                        "<html>" +
//                                "<body>" +
//                                "<iframe width=\"100%\" height=\"100%\" src=\"" +"https://www.youtube.com/embed/"+ Url.split("=")[1]+"?autoplay=1" + "\" frameborder=\"0\" allowfullscreen/>" +
//                                "</body>" +
//                                "</html>";

             //   webview.setWebChromeClient(new ChromeClient());
                loadwebToURL();
                try {
                    if(Url.contains("youtube")) {
                        webview.loadUrl("https://www.youtube.com/embed/" + Url.split("=")[1]);
                    }else if(Url.contains("youtu.be")) {
                        String id[] = Url.split("/");
                        webview.loadUrl("https://www.youtube.com/embed/" + id[id.length-1]);
                    }
                }catch (Exception e){
                    webview.loadUrl(Url);
                    e.printStackTrace();
                }
              //  webview.loadData(dataUrl, "text/html", "utf-8");
            } else {
                loadwebToURL();
                webview.loadUrl(Url);
            }
         //   <iframe width="956" height="538" src="https://www.youtube.com/embed/38IEolI8f-w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        }
        back_action_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void loadwebToURL() {
        webview.setWebViewClient(new Custom_Web_Client(WebUrlActivity.this));
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setUseWideViewPort(true);
        webview.setVerticalScrollBarEnabled(false);
        webview.setHorizontalScrollBarEnabled(false);
        webview.getSettings().setJavaScriptEnabled(true);
    }

    private class Custom_Web_Client extends WebViewClient {
        //   private Dialog Loader;

        public Custom_Web_Client(Context context) {
            //  this.Loader = Methods.getLoader(context);
            //  this.Loader.setCancelable(true);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            try {
                //      Loader.show();
            } catch (Exception e) {

            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            try {
                //    if (Loader.isShowing())
                //      Loader.hide();
            } catch (Exception e) {

            }
        }
    }

    private class ChromeClient extends WebChromeClient {
        private View mCustomView;
        private CustomViewCallback mCustomViewCallback;
        protected FrameLayout mFullscreenContainer;
        private int mOriginalOrientation;
        private int mOriginalSystemUiVisibility;

        ChromeClient() {}

        public Bitmap getDefaultVideoPoster()
        {
            if (mCustomView == null) {
                return null;
            }
            return BitmapFactory.decodeResource(getApplicationContext().getResources(), 2130837573);
        }

        public void onHideCustomView()
        {
            ((FrameLayout)getWindow().getDecorView()).removeView(this.mCustomView);
            this.mCustomView = null;
            getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
            setRequestedOrientation(this.mOriginalOrientation);
            this.mCustomViewCallback.onCustomViewHidden();
            this.mCustomViewCallback = null;
        }

        public void onShowCustomView(View paramView, CustomViewCallback paramCustomViewCallback)
        {
            if (this.mCustomView != null)
            {
                onHideCustomView();
                return;
            }
            this.mCustomView = paramView;
            this.mOriginalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
            this.mOriginalOrientation = getRequestedOrientation();
            this.mCustomViewCallback = paramCustomViewCallback;
            ((FrameLayout)getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(3846 | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

}
