package com.tilismtech.tellotalksdk.ui.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.managers.ChatManager.Companion.instance
import com.tilismtech.tellotalksdk.packages.easypermissions.EasyPermissions
import com.tilismtech.tellotalksdk.packages.easypermissions.EasyPermissions.PermissionCallbacks
import com.tilismtech.tellotalksdk.ui.dialog.PermissionDialogFragment
import com.tilismtech.tellotalksdk.ui.dialog.PermissionDialogFragment.BaseDialogListener
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.openPermissionsSettings

open class TelloActivity : AppCompatActivity(), PermissionCallbacks {
    var selectedRequestCode: Int = 0
    var selectedPermissions: Array<String?>?=null
    protected var mToast: Toast? = null
    private var selectedMessage: TTMessage? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun downloadFile(message: TTMessage) {
        instance!!.downloadFile(message)
    }

    fun sendMessage(message: TTMessage) {
        instance!!.sendMessage(message)
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_EXTERNAL_STORAGE_UPLOAD || requestCode == REQUEST_EXTERNAL_STORAGE_DOWNLOAD) {
            EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
        }
    }


    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String?>) {
        if (requestCode == REQUEST_EXTERNAL_STORAGE_UPLOAD) {
            if (selectedMessage != null) {
                instance!!.sendMessage(selectedMessage!!)
            }
        } else if (requestCode == REQUEST_EXTERNAL_STORAGE_DOWNLOAD) {
            if (selectedMessage != null) {
                instance!!.downloadFile(selectedMessage!!)
            }
        }
        selectedMessage = null
    }

    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String?>) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            selectedPermissions = perms.toTypedArray<String?>()
            selectedRequestCode = requestCode
            showPermissionRequestDialog(this)
        }
        selectedMessage = null
    }

    fun showPermissionRequestDialog(activity: TelloActivity) {
        val imageResources = ArrayList<Int?>()
        val message = R.string.storage_permission
        imageResources.add(R.drawable.file_icon_sdk)
        val manager = activity.getSupportFragmentManager()
        val dialogFragment =
            PermissionDialogFragment(imageResources, message, true, object : BaseDialogListener {
                override fun onDialogPositiveClick(dialog: PermissionDialogFragment?) {
                    openPermissionsSettings(activity)

                    selectedPermissions = null
                    selectedRequestCode = 0
                }

                override fun onDialogNegativeClick(dialog: PermissionDialogFragment?) {
                    Toast.makeText(activity, R.string.no_storage_permission, Toast.LENGTH_SHORT)
                        .show()
                    selectedPermissions = null
                    selectedRequestCode = 0
                }
            })
        dialogFragment.show(manager, "PermissionDialogFragment")
    }

    fun replaceToast(msg: String?) {
        replaceToast(msg, true)
    }

    fun hideToast() {
        if (mToast != null) {
            mToast!!.cancel()
        }
    }

    protected fun replaceToast(msg: String?, showlong: Boolean) {
        hideToast()
        mToast = Toast.makeText(this, msg, if (showlong) Toast.LENGTH_LONG else Toast.LENGTH_SHORT)
        mToast!!.show()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        const val REQUEST_EXTERNAL_STORAGE_UPLOAD: Int = 10022
        const val REQUEST_EXTERNAL_STORAGE_DOWNLOAD: Int = 10033
        const val REQUEST_SYNC_CONTACTS: Int = 1112
    }
}
