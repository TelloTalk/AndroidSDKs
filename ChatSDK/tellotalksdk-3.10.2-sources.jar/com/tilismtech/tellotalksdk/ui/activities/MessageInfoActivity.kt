package com.tilismtech.tellotalksdk.ui.activities

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.tilismtech.tellotalksdk.data.db.entities.MessageReceipt
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.MessageReceiptRepository
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.databinding.ActivityMessageInfoBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.MessageInfoAdapter
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.UIHelper.readableTimeDifferenceFull
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.instance
import com.tilismtech.tellotalksdk.utils.diffUtils.MessageDiffCallback

class MessageInfoActivity : TelloActivity() {
    private var messages: ArrayList<TTMessage?>? = null
    private var binding: ActivityMessageInfoBinding? = null
    private var conversationAdapter: MessageInfoAdapter? = null
    private var viewHolderUtils: ViewHolderUtils? = null
    private var currentConversation: TTConversation? = null
    private var isInitialized = false
    private var conversationActivityViewModel: ConversationActivityViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setBindingAdapter()
        binding = ActivityMessageInfoBinding.inflate(layoutInflater)
        setContentView(binding!!.getRoot())
        //    setSupportActionBar(binding.toolbar);
        //    binding.backBtnIcon.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        binding!!.backBtnIcon.setOnClickListener(View.OnClickListener { v: View? -> onBackPressed() })
        manageIntent()
        initMessagesList(messages)
        conversationActivityViewModel = ViewModelProviders.of(this)
            .get<ConversationActivityViewModel>(ConversationActivityViewModel::class.java)
        conversationActivityViewModel!!.getMessageFromObserver(intent.getStringExtra("selectedMessageId"))
            .observe(this, Observer { ttMessages: List<TTMessage> ->
                if (messages == null) {
                    initMessagesList(ArrayList(ttMessages))
                } else {
                    val diffResult =
                        DiffUtil.calculateDiff(MessageDiffCallback(messages, ttMessages))
                    diffResult.dispatchUpdatesTo(conversationAdapter!!)
                    messages!!.clear()
                    messages!!.addAll(ttMessages)
                    if (messages!!.isNotEmpty() && !isInitialized) {
                        isInitialized = true
                        initViewModels(messages!![0])
                    }
                }
            })
    }

    private fun initViewModels(message: TTMessage?) {
        binding!!.p2pCard.setVisibility(View.VISIBLE)
        initp2pViewModel(message)
    }

    private fun initp2pViewModel(message: TTMessage?) {
        MessageReceiptRepository.getInstance().getReceiptForP2p(message?.messageId)
            .observe(this, Observer { messageReceipt: MessageReceipt? ->
                if (messageReceipt == null) {
                    val formatedTime = readableTimeDifferenceFull(
                        this@MessageInfoActivity,
                        if (message?.msgDate != null) message.msgDate!!.getTime() else System.currentTimeMillis()
                    )
                    binding!!.deliveredTime.setText(formatedTime)
                    binding!!.readTime.setText(formatedTime)
                    return@Observer
                }
                if (messageReceipt.getTimeDelivered() != null && messageReceipt.getTimeDelivered()
                        .getTime() != 0L
                ) {
                    val formatedTime = readableTimeDifferenceFull(
                        this@MessageInfoActivity,
                        if (messageReceipt.getTimeDelivered() != null) messageReceipt.getTimeDelivered()
                            .getTime() else System.currentTimeMillis()
                    )
                    binding!!.deliveredTime.setText(formatedTime)
                    message?.msgStatus = TTMessage.MsgStatus.DELIVERED
                    conversationActivityViewModel!!.updateMessageStatus(
                        message?.messageId,
                        message?.msgStatus!!.ordinal
                    )
                }
                if (messageReceipt.getTimeRead() != null && messageReceipt.getTimeRead()
                        .getTime() != 0L
                ) {
                    val formatedTime = readableTimeDifferenceFull(
                        this@MessageInfoActivity,
                        if (messageReceipt.getTimeRead() != null) messageReceipt.getTimeRead()
                            .getTime() else System.currentTimeMillis()
                    )
                    binding!!.readTime.setText(formatedTime)
                    message?.isRead = true
                    message?.msgStatus = TTMessage.MsgStatus.READ
                    conversationActivityViewModel!!.updateMessageStatus(
                        message?.messageId,
                        message?.msgStatus!!.ordinal
                    )
                }
            })
    }

    private fun manageIntent() {
        if (getIntent().getExtras() != null) {
            val conversationId = getIntent().getStringExtra("conversationId")
            currentConversation = getInstance().getConversationForJid(conversationId)
            if (currentConversation != null) {
                getInstance().insertConversation(currentConversation!!)
            } else {
                finish()
            }
            viewHolderUtils!!.setCurrentConversation(currentConversation)
        } else {
            finish()
        }
    }

    private fun setBindingAdapter() {
        viewHolderUtils = instance
        viewHolderUtils!!.setCurrentConversation(currentConversation)
        viewHolderUtils!!.setActivity(this)
    }

    private fun initMessagesList(messageList: ArrayList<TTMessage?>?) {
        this.messages = messageList ?: ArrayList()
        val messagesLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        messagesLayoutManager.setStackFromEnd(true)
        binding!!.recyclerView.setLayoutManager(messagesLayoutManager)
        conversationAdapter = MessageInfoAdapter(this, messages, viewHolderUtils!!)
        viewHolderUtils!!.adapter = conversationAdapter
        binding!!.recyclerView.setAdapter(conversationAdapter)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (viewHolderUtils != null) {
            viewHolderUtils!!.stopMediaPLayer()
        }
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
    }
}