package com.tilismtech.tellotalksdk.ui.activities

import android.R
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NavUtils
import androidx.core.net.toUri
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.interfaces.DraweeController
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.tilismtech.tellotalksdk.databinding.ActivityImageViewerBinding


class ImageViewerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityImageViewerBinding.inflate(layoutInflater)
        setContentView(binding.getRoot())
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.title = ""
        val imageUrl = intent.getStringExtra("imageUrl")
        val request = ImageRequestBuilder.newBuilderWithSource(imageUrl?.toUri())
            .setProgressiveRenderingEnabled(true)
            .disableDiskCache()
            .build()
        val controller: DraweeController? = Fresco.newDraweeControllerBuilder()
            .setImageRequest(request)
            .setAutoPlayAnimations(true)
            .setOldController(binding.fullscreenImage.controller)
            .build()
        binding.fullscreenImage.controller = controller
        binding.backBtn.setOnClickListener { finish() }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.home) {
            // This ID represents the Home or Up button.
            NavUtils.navigateUpFromSameTask(this)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}