package com.tilismtech.tellotalksdk.ui.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild;
import com.tilismtech.tellotalksdk.databinding.ActivitySlideBinding;
import com.tilismtech.tellotalksdk.ui.adapters.SliderAdapter;

import java.util.List;

public class SlideActivity extends AppCompatActivity {

    List<ChatbotChild> chatbotChildren;
    ActivitySlideBinding binding;
    int dotscount;
    ImageView[] dots;
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySlideBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getDataFromIntent();
        initView();
    }

    private void getDataFromIntent() {
        if(getIntent().hasExtra("carosalData")){
            chatbotChildren = getIntent().getParcelableArrayListExtra("carosalData");
            position  = getIntent().getIntExtra("position",0);
        }
    }

    private void initView() {


        binding.tvCarousalTitle.setText(chatbotChildren.get(position).getCarousalData().get(0).getTitle());
        binding.tvCarousalDes.setText(chatbotChildren.get(position).getCarousalData().get(0).getDescription());

        SliderAdapter sliderAdapter = new SliderAdapter(getSupportFragmentManager(), chatbotChildren);
        binding.vpCarousel.setAdapter(sliderAdapter);

        binding.vpCarousel.setOffscreenPageLimit(3);
        binding.vpCarousel.setCurrentItem(position);

        dotscount = sliderAdapter.getCount();
        dots = new ImageView[dotscount];
        binding.vpIndicator.removeAllViews();
        for (int i = 0; i < dotscount; i++) {

            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.noo_active_dot_white));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8, 0, 8, 0);
            binding.vpIndicator.addView(dots[i], params);

        }
        dots[position].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.active_dot));


        binding.vpCarousel.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                binding.tvCarousalTitle.setText(chatbotChildren.get(position).getCarousalData().get(0).getTitle());
                binding.tvCarousalDes.setText(chatbotChildren.get(position).getCarousalData().get(0).getDescription());
                for(int i = 0; i< dotscount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(SlideActivity.this, R.drawable.noo_active_dot_white));
                }

                dots[position].setImageDrawable(ContextCompat.getDrawable(SlideActivity.this, R.drawable.active_dot));

            }
            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        binding.backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }
}