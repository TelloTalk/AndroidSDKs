package com.tilismtech.tellotalksdk.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.interfaces.DraweeController
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild
import com.tilismtech.tellotalksdk.databinding.SliderViewFragmentBinding

class SliderViewFragment : Fragment() {
    var binding: SliderViewFragmentBinding? = null
    private var chatbotChild: ChatbotChild? = null
    var chatbotChildList: MutableList<ChatbotChild?>? = null
    private var position = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = SliderViewFragmentBinding.inflate(inflater, container, false)
        chatbotChild =
            arguments?.getParcelable("child") // default to car1 image resource
        chatbotChildList = arguments?.getParcelableArrayList<ChatbotChild?>("carousalList")
        position = arguments?.getInt("position")?:0

        val request = ImageRequestBuilder
            .newBuilderWithSource(chatbotChild!!.carousalData[0].image.toUri())
            .setProgressiveRenderingEnabled(true)
            .disableDiskCache()
            .build()
        val controller: DraweeController? = Fresco.newDraweeControllerBuilder()
            .setImageRequest(request)
            .setAutoPlayAnimations(true)
            .setOldController(binding!!.ivCarouselImage.controller)
            .build()
        binding!!.ivCarouselImage.controller = controller


        return binding!!.getRoot()
    }
}
