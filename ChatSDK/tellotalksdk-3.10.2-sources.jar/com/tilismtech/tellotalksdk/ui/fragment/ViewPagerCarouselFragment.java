package com.tilismtech.tellotalksdk.ui.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild;
import com.tilismtech.tellotalksdk.databinding.ViewPagerCarouselFragmentBinding;
import com.tilismtech.tellotalksdk.ui.activities.SlideActivity;

import java.util.ArrayList;
import java.util.List;

public class ViewPagerCarouselFragment extends Fragment {

    private ChatbotChild chatbotChild;
    List<ChatbotChild> chatbotChildList;
    private int position;
    ViewPagerCarouselFragmentBinding binding;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

       binding = ViewPagerCarouselFragmentBinding.inflate(getLayoutInflater());
       initData();

        binding.ivCarouselImage.setOnClickListener(v -> {

            Intent intent =  new Intent(getActivity(), SlideActivity.class);
            intent.putExtra("child",chatbotChildList.get(position));
            intent.putExtra("position",position);
            intent.putExtra("carosalData", (ArrayList<? extends Parcelable>)chatbotChildList);
            startActivity(intent);
        });

        return binding.getRoot();
    }

    private void initData() {
        chatbotChild = getArguments().getParcelable("child"); // default to car1 image resource
        chatbotChildList = getArguments().getParcelableArrayList("carousalList");
        position = getArguments().getInt("position");
        binding.ivCarouselImage.setImageURI(Uri.parse(chatbotChild.getCarousalData().get(0).getImage()));

    }
}
