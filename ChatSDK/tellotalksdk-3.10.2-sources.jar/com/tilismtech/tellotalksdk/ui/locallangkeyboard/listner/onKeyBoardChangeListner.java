package com.tilismtech.tellotalksdk.ui.locallangkeyboard.listner;

/**
 * Created by abdulmomen on 3/8/17.
 */

public interface onKeyBoardChangeListner {

    void onKeyBoarChanged();
}
