package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public class BalochiKeyboardLanguage extends KeyboardLanguage {

    public BalochiKeyboardLanguage(){
        name = "بلوچی";
        numeric = new String[]{"۱","۲","۳","۴","۵","۶","۷","۸","۹","۰"};
        specialChar = new String[]{"+", "×", "÷", "=", "%", "_", "ؓ", "ؒ", "ﷻ", "ﷺ", "@", "$", "!", "#", "/", "^", "&", "*", "(", ")", "-", "~", ":", "؛", "،", "؟"};
        alphabetLayerOne = new String[]{"ص","ث","ق","ڦ","ع","ہ","خ","ح","ج","چ","ش","س","ی","ب","ل","ا","ت","ن","م","ط","پ","ز","ر","ک","و","د"};
        alphabetLayerTwo = new String[]{"ض","ث","ڑ","ﮤ","غ","ة","خ","ح","ج","أ","ش","ي","ے","ۓ","ل","آ","ٹ","ن","م","ظ","ژ","ء","گ","ك","ؤ","ڈ"};
    }

    public String getFirstLayer(int index){
        return alphabetLayerOne[index];
    }

    public String getSecondLayer(int index){
        return alphabetLayerTwo[index];
    }

    public String getNumeric (int index) {
        return numeric[index];
    }

    public String getSpecialChar(int index) {
        return specialChar[index];
    }

    public String getName() {
        return name;
    }
}
