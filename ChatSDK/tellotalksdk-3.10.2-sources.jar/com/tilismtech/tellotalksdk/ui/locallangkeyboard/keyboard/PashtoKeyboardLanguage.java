package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public class PashtoKeyboardLanguage extends KeyboardLanguage {

    public PashtoKeyboardLanguage(){
        name = "پښتو";
        numeric = new String[]{"۱","۲","۳","۴","۵","۶","۷","۸","۹","۰"};
        specialChar = new String[]{"+", "×", "÷", "=", "%", "_", "ؓ", "ؒ", "ﷻ", "ﷺ", "@", "$", "!", "#", "/", "^", "&", "*", "(", ")", "-", "~", ":", "؛", "،", "؟"};
        alphabetLayerOne = new String[]{"ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج","چ","ش","س","ی","ب","ل","ا","ت","ن","م","ک","ګ","ظ","ط","ز"};
        alphabetLayerTwo = new String[]{"ر","ذ","د","ړ","و","ږ","ع","ه","ښ","ۍ","ي","پ","ا","آ","ټ","ڼ","ة","ے","ۂ","ې","ژ","ء","ډ","ؤ","ځ","څ"};
    }

    public String getFirstLayer(int index){
        return alphabetLayerOne[index];
    }

    public String getSecondLayer(int index){
        return alphabetLayerTwo[index];
    }

    public String getNumeric (int index) {
        return numeric[index];
    }

    public String getSpecialChar(int index) {
        return specialChar[index];
    }

    public String getName() {
        return name;
    }
}
