package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public class SindhiKeyboardLanguage extends KeyboardLanguage {

    public SindhiKeyboardLanguage(){
        name = "سنڌي";
        numeric = new String[]{"۱","۲","۳","۴","۵","۶","۷","۸","۹","۰"};
        specialChar = new String[]{"+", "×", "÷", "=", "%", "_", "ؓ", "ؒ", "ﷻ", "ﷺ", "@", "$", "!", "#", "/", "^", "&", "*", "(", ")", "-", "~", ":", "؛", "،", "؟"};
        alphabetLayerOne = new String[]{"ق","ص","ي","ر","ت","ٿ","ع","ڳ","و","پ","ڇ","چ","ا","س","د","ف","گ","ج","ڪ","ل","ک","ڱ","ڍ","ز","خ","ؤ"};
        alphabetLayerTwo = new String[]{"ط","ڀ","ب","ن","م","ض","ڙ","ٽ","ث","غ","ھ","ڦ","ڃ","ڄ","ش","ڊ","ح","ڏ","ڌ","ٺ","ذ","ظ", "ء","ٻ","ڻ","ة"};
    }

    public String getFirstLayer(int index){
        return alphabetLayerOne[index];
    }

    public String getSecondLayer(int index){
        return alphabetLayerTwo[index];
    }

    public String getNumeric (int index) {
        return numeric[index];
    }

    public String getSpecialChar(int index) {
        return specialChar[index];
    }

    public String getName() {
        return name;
    }
}
