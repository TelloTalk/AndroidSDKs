package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public class PunkabiKeyboardLanguage extends KeyboardLanguage {

    public PunkabiKeyboardLanguage() {
        name = "پنجابی";
        numeric = new String[]{"۱","۲","۳","۴","۵","۶","۷","۸","۹","۰"};
        specialChar = new String[]{"+", "×", "÷", "=", "%", "_", "ؓ", "ؒ", "ﷻ", "ﷺ", "@", "$", "!", "#", "/", "^", "&", "*", "(", ")", "-", "~", ":", "؛", "،", "؟"};
        alphabetLayerOne = new String[]{"ق","و","ع","ر","ت","ٸ","ی","ہ","پ","ا","س","د","ف","گ","ھ","ج","خ","ک","ل","ز","ص","چ","ط","ب","ن","م"};
        alphabetLayerTwo = new String[]{"ق","و","ع","ڑ", "ٹ","ے","ی","ہ","پ","آ","ش","ڈ","ف","ء","ح","ژ","خ","ک","غ","ز","ض","ث","ظ","ب","ں","م"};
    }

    public String getFirstLayer(int index){
        return alphabetLayerOne[index];
    }

    public String getSecondLayer(int index){
        return alphabetLayerTwo[index];
    }

    public String getNumeric (int index) {
        return numeric[index];
    }

    public String getSpecialChar(int index) {
        return specialChar[index];
    }

    public String getName() {
        return name;
    }
}
