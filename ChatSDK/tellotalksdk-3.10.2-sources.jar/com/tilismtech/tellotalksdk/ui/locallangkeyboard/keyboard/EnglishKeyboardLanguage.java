package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public class EnglishKeyboardLanguage extends KeyboardLanguage {

    public EnglishKeyboardLanguage() {
        name = "ENG";
        numeric = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
        specialChar = new String[]{"+", "×", "÷", "=", "%", "_", "€", "£", "¥", "₩", "@", "$", "!", "#", "/", "^", "&", "*", "(", ")", "-", "'", ":", ";", ",", "?"};
        alphabetLayerOne = new String[]{"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Z", "X", "C", "V", "B", "N", "M"};
        alphabetLayerTwo = new String[]{"q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c", "v", "b", "n", "m"};
    }

    public String getFirstLayer(int index) {
        return alphabetLayerOne[index];
    }

    public String getSecondLayer(int index) {
        return alphabetLayerTwo[index];
    }

    public String getNumeric (int index) {
        return numeric[index];
    }

    public String getSpecialChar(int index) {
        return specialChar[index];
    }

    public String getName() {
        return name;
    }
}