package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public abstract class KeyboardLanguage {

    public String name=null;
    public String[] numeric=null;
    public String[] specialChar=null;
    public String[] alphabetLayerOne=null;
    public String[] alphabetLayerTwo=null;

    public String getName() {
        return name;
    }

    public String getFirstLayer(int index) {
        return null;
    }

    public String getSecondLayer(int index) {
        return null;
    }

    public String getNumeric(int index) {
        return null;
    }

    public String getSpecialChar(int index) {
        return null;
    }
  /*  public void setName(String name) {
        this.name = name;
    }
*/
}
