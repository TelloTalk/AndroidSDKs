package com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard;

/**
 * Created by user on 6/27/2016.
 */
public class SaraikiKeyboardLanguage extends KeyboardLanguage {

    public SaraikiKeyboardLanguage(){
        name = "سرائیکی";
        numeric = new String[]{"۱","۲","۳","۴","۵","۶","۷","۸","۹","۰"};
        specialChar = new String[]{"+", "×", "÷", "=", "%", "_", "ؓ", "ؒ", "ﷻ", "ﷺ", "@", "$", "!", "#", "/", "^", "&", "*", "(", ")", "-", "~", ":", "؛", "،", "؟"};
        alphabetLayerOne = new String[]{"ق","و","ع","ر","ت","ے","ء","ی","ہ","پ","ا","س","د","ف","گ","ھ","ج","ک","ل","ز","ش","چ","ط","ب","ن","م"};
        alphabetLayerTwo = new String[]{" ڳ","ؤ","ۍ","ڑ","ٹ","ے","ء","ی","ة","پ","آ","ص","ڈ","ݙ","غ","ح","ڄ","خ","ض","ذ","ژ","ث","ظ"," ٻ","ں","ݨ"};
    }

    public String getFirstLayer(int index){
        return alphabetLayerOne[index];
    }

    public String getSecondLayer(int index){
        return alphabetLayerTwo[index];
    }

    public String getNumeric (int index) {
        return numeric[index];
    }

    public String getSpecialChar(int index) {
        return specialChar[index];
    }

    public String getName() {
        return name;
    }
}
