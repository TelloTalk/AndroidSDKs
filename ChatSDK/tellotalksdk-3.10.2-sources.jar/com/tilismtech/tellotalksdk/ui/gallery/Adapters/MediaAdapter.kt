package com.tilismtech.tellotalksdk.ui.gallery.Adapters

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.view.SimpleDraweeView
import com.facebook.imagepipeline.common.ResizeOptions
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder

class MediaAdapter(
    private val bitmapList: MutableList<String?>,
    private val selected: MutableList<Boolean?>
) : RecyclerView.Adapter<MediaAdapter.MyViewHolder?>() {
    class MyViewHolder internal constructor(view: View) : BaseViewHolder(view) {
        var thumbnail: SimpleDraweeView = view.findViewById<SimpleDraweeView>(R.id.image)
        var check: ImageView = view.findViewById<ImageView>(R.id.image2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.media_item, parent, false)
        return MediaAdapter.MyViewHolder(itemView)
    }

    override fun onViewRecycled(holder: MyViewHolder) {
        super.onViewRecycled(holder)
        holder.thumbnail.setImageURI("")
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.thumbnail.setTag("file://" + bitmapList.get(position))
        val request =
            ImageRequestBuilder.newBuilderWithSource(Uri.parse("file://" + bitmapList.get(position)))
                .setResizeOptions(ResizeOptions(153, 160))
                .build()
        holder.thumbnail.setController(
            Fresco.newDraweeControllerBuilder()
                .setOldController(holder.thumbnail.getController())
                .setImageRequest(request)
                .build()
        )
        if (selected.size > position && selected.get(position) == true) {
            holder.check.setVisibility(View.VISIBLE)
            holder.check.setAlpha(150)
        } else {
            holder.check.setVisibility(View.GONE)
        }
    }

    override fun getItemCount(): Int {
        return bitmapList.size
    }
}