package com.tilismtech.tellotalksdk.ui.gallery.Adapters

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.view.SimpleDraweeView
import com.facebook.imagepipeline.common.ResizeOptions
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder

class BucketsAdapter(
    private val bucketNames: MutableList<String?>,
    private val bitmapList: MutableList<String?>
) : RecyclerView.Adapter<BucketsAdapter.BucketViewHolder?>() {
    inner class BucketViewHolder internal constructor(view: View) : BaseViewHolder(view) {
        var title: TextView = view.findViewById<TextView>(R.id.title)
        var thumbnail: SimpleDraweeView = view.findViewById<SimpleDraweeView>(R.id.image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BucketViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.album_item, parent, false)
        return BucketViewHolder(itemView)
    }

    override fun onViewRecycled(holder: BucketViewHolder) {
        super.onViewRecycled(holder)
        holder.thumbnail.setImageURI("")
    }

    override fun onBindViewHolder(holder: BucketViewHolder, position: Int) {
        bucketNames.get(position)
        holder.title.setText(bucketNames.get(position))
        holder.thumbnail.setTag("file://" + bitmapList.get(position))
        val request =
            ImageRequestBuilder.newBuilderWithSource(Uri.parse("file://" + bitmapList.get(position)))
                .setResizeOptions(ResizeOptions(300, 300))
                .build()
        holder.thumbnail.setController(
            Fresco.newDraweeControllerBuilder()
                .setOldController(holder.thumbnail.getController())
                .setImageRequest(request)
                .build()
        )
    }

    override fun getItemCount(): Int {
        return bucketNames.size
    }
}