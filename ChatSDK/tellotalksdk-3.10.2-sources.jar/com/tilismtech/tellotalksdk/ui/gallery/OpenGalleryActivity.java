package com.tilismtech.tellotalksdk.ui.gallery;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.data.db.entities.MediaAttachment;
import com.tilismtech.tellotalksdk.databinding.ActivityOpenGalleryBinding;
import com.tilismtech.tellotalksdk.ui.gallery.Adapters.MediaAdapter;
import com.tilismtech.tellotalksdk.ui.gallery.Fragments.OneFragment;
import com.tilismtech.tellotalksdk.ui.gallery.Fragments.TwoFragment;
import com.tilismtech.tellotalksdk.utils.FileBackend;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class OpenGalleryActivity extends AppCompatActivity {

    private MediaAdapter mAdapter;
    private List<String> mediaList = new ArrayList<>();
    public static List<Boolean> selected = new ArrayList<>();
    public static ArrayList<MediaAttachment> imagesSelected = new ArrayList<>();
    public static String parent;
    ActivityOpenGalleryBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        binding = ActivityOpenGalleryBinding.inflate(getLayoutInflater());
        setSupportActionBar(binding.toolbar);
        binding.fab.setOnClickListener(view -> finish());
        binding.toolbar.setNavigationIcon(R.drawable.arrow_back_sdk);
        binding.toolbar.setTitleTextColor(getResources().getColor(R.color.colorPrimaryDarkGrey,null));
        setTitle(Gallery.title);
        if (imagesSelected.size() > 0) {
            binding.fab.setVisibility(View.VISIBLE);
            setTitle(String.valueOf(imagesSelected.size())+ " Selected");
        }else{
            setTitle(" Select media");
            binding.fab.setVisibility(View.INVISIBLE);
        }
        binding.toolbar.setNavigationOnClickListener(v -> onBackPressed());
        parent = getIntent().getStringExtra("FROM");
        mediaList.clear();
        selected.clear();
        if (parent.equals("Images")) {
            mediaList.addAll(OneFragment.imagesList);
            selected.addAll(OneFragment.selected);
        } else {
            mediaList.addAll(TwoFragment.videosList);
            selected.addAll(TwoFragment.selected);
        }
        populateRecyclerView();
    }


    private void populateRecyclerView() {
        for (int i = 0; i < selected.size(); i++) {
            if(mediaList.size() > i){
                MediaAttachment attachment = new MediaAttachment();
                attachment.setFileUri(Uri.parse("file://" + mediaList.get(i)));
                if (imagesSelected.contains(attachment)) {
                    selected.set(i, true);
                } else {
                    selected.set(i, false);
                }
            }
        }
        mAdapter = new MediaAdapter(mediaList, selected);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getApplicationContext(), 3, LinearLayoutManager.VERTICAL, false);
        binding.recyclerView.setLayoutManager(mLayoutManager);
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setItemViewCacheSize(30);
        binding.recyclerView.setDrawingCacheEnabled(true);
        binding.recyclerView.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        binding.recyclerView.getItemAnimator().setChangeDuration(0);
        binding.recyclerView.setAdapter(mAdapter);
        binding.recyclerView.addOnItemTouchListener(new RecyclerTouchListener(this, binding.recyclerView, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                MediaAttachment attachment = new MediaAttachment();
                attachment.setFileUri(Uri.parse("file://" + mediaList.get(position)));
                if ("Images".equalsIgnoreCase(parent)) {
                    ContentResolver cR = getContentResolver();
                    MimeTypeMap mime = MimeTypeMap.getSingleton();
                    String type = mime.getExtensionFromMimeType(cR.getType(FileBackend.getInstance().getImageContentUri(OpenGalleryActivity.this, new File(mediaList.get(position)))));
                    if(type !=null && type.contains("gif")){
                        attachment.setMimeType("image/gif");
                    }else{
                        attachment.setMimeType("image/*");
                    }
                } else {
                    attachment.setMimeType("video/*");
                }
                if (!selected.get(position).equals(true) && imagesSelected.size() < Gallery.maxSelection) {
                    imagesSelected.add(attachment);
                    selected.set(position, !selected.get(position));
                    mAdapter.notifyItemChanged(position);
                } else if (selected.get(position).equals(true)) {
                    if (imagesSelected.indexOf(attachment) != -1) {
                        imagesSelected.remove(imagesSelected.indexOf(attachment));
                        selected.set(position, !selected.get(position));
                        mAdapter.notifyItemChanged(position);
                    }
                }else{
                    Toast.makeText(OpenGalleryActivity.this,"Maximum 5 media files allowed",Toast.LENGTH_SHORT).show();
                }
                Gallery.selectionTitle = imagesSelected.size();
                if (imagesSelected.size() != 0) {
                    binding.fab.setVisibility(View.VISIBLE);
                    setTitle(String.valueOf(imagesSelected.size()) + " Selected");
                } else {
                    setTitle(Gallery.title);
                    binding.fab.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onLongClick(View view, int position) {
            }

        }));
    }

    public interface ClickListener {

        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        }
    }



}