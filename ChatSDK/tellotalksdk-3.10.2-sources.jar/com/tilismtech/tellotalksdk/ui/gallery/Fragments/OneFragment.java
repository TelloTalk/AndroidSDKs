package com.tilismtech.tellotalksdk.ui.gallery.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.ui.gallery.Adapters.BucketsAdapter;
import com.tilismtech.tellotalksdk.ui.gallery.OpenGalleryActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OneFragment extends Fragment {
    private RecyclerView recyclerView;
   // private final String[] projection = new String[]{MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.DATA}, projection2 = new String[]{MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATA};
   private final String[] projection = new String[]{
           MediaStore.Images.ImageColumns.DATA,
           MediaStore.Images.Media.DISPLAY_NAME,
           MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
           MediaStore.Images.Media.BUCKET_ID
   },
           projection2 = new String[]{
                   MediaStore.Images.Media.DISPLAY_NAME,
                   MediaStore.Images.Media.DATA};
    private List<String> bucketNames = new ArrayList<>(), bitmapList = new ArrayList<>();
    public static List<String> imagesList = new ArrayList<>();
    public static List<Boolean> selected = new ArrayList<>();
    private Context context;
    private ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Bucket names reloaded
        bitmapList.clear();
        imagesList.clear();
        bucketNames.clear();
      //  getPicBuckets();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_one, container, false);
        recyclerView = v.findViewById(R.id.recycler_view);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        progressDialog = ProgressDialog.show(context, "", "Please wait...");
        executor.execute(() -> {
            getPicBuckets();
            handler.post(() -> {
                progressDialog.dismiss();
                populateRecyclerView();
            });
        });

     //   populateRecyclerView();
        return v;
    }

    private void populateRecyclerView() {
        BucketsAdapter mAdapter = new BucketsAdapter(bucketNames, bitmapList);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(context, 3, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(30);
        recyclerView.setDrawingCacheEnabled(true);
        recyclerView.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        recyclerView.setAdapter(mAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(context, recyclerView, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                ExecutorService executor = Executors.newSingleThreadExecutor();
                Handler handler = new Handler(Looper.getMainLooper());
                progressDialog = ProgressDialog.show(context, "", getString(R.string.please_wait));
                executor.execute(() -> {
                    getPictures(bucketNames.get(position));
                    handler.post(() -> {
                        progressDialog.dismiss();
                        Intent intent = new Intent(context, OpenGalleryActivity.class);
                        intent.putExtra("FROM", "Images");
                        startActivity(intent);
                    });
                });
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        mAdapter.notifyDataSetChanged();
    }

    public void getPicBuckets() {
        //    Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
        //                    null, null, MediaStore.Images.Media.DATE_ADDED);
        Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = context.getContentResolver().query(
                images, projection, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC");
        ArrayList<String> bucketNamesTEMP = null;
        if(cursor != null){
         //   Log.i("ListingImages"," query count=" + cursor.getCount());
            bucketNamesTEMP = new ArrayList<>(cursor.getCount());
            ArrayList<String> bitmapListTEMP = new ArrayList<>(cursor.getCount());
            HashSet<String> albumSet = new HashSet<>();
            ArrayList<String> picPaths = new ArrayList<>();
            File file;
            try {
                if (cursor.moveToFirst()) {
                    String bucket;
                    String data;
                    int bucketColumn = cursor.getColumnIndex(
                            MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
                    int dataColumn = cursor.getColumnIndex(
                            MediaStore.Images.Media.DATA);

                    do {
                        // Get the field values
                        bucket = cursor.getString(bucketColumn);
                        data = cursor.getString(dataColumn);

                        // Do something with the values.
//                        Log.i("ListingImages", " bucket=" + bucket
//                                + "  _data=" + data);
                        if (Thread.interrupted()) {
                            return;
                        }
                        String album = bucket;
                        String image = data;
                        String folderpaths = data.substring(0, data.lastIndexOf(bucket + "/"));
                        folderpaths = folderpaths + bucket + "/";
                        file = new File(image);
                        if (!picPaths.contains(folderpaths)) {
                            picPaths.add(folderpaths);
                            if (file.exists() && !albumSet.contains(album)) {
                                bucketNamesTEMP.add(album);
                                bitmapListTEMP.add(image);
                                albumSet.add(album);
                            }
                        }
                    } while (cursor.moveToNext());
                }
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
            finally {
                cursor.close();
            }
            bucketNames.clear();
            bitmapList.clear();
            bucketNames.addAll(bucketNamesTEMP);
            bitmapList.addAll(bitmapListTEMP);
        }
    }


    public void getPictures(String bucket) {
        selected.clear();
        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection2,
                        MediaStore.Images.Media.BUCKET_DISPLAY_NAME + " =?", new String[]{bucket}, MediaStore.Images.Media.DATE_ADDED);
        ArrayList<String> imagesTEMP = null;
        if (cursor != null) {
            imagesTEMP = new ArrayList<>(cursor.getCount());
            HashSet<String> albumSet = new HashSet<>();
            File file;
            if (cursor.moveToLast()) {
                do {
                    if (Thread.interrupted()) {
                        return;
                    }
                    String path = cursor.getString(cursor.getColumnIndex(projection2[1]));
                    file = new File(path);
                    if (file.exists() && !albumSet.contains(path)) {
                        imagesTEMP.add(path);
                        albumSet.add(path);
                        selected.add(false);
                    }
                } while (cursor.moveToPrevious());
            }
            cursor.close();
            imagesList.clear();
            imagesList.addAll(imagesTEMP);
        }
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {
        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        }
    }
}