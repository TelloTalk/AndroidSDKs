package com.tilismtech.tellotalksdk.ui.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.tilismtech.tellotalksdk.listeners.OnEmojiconClickedListener;
import com.tilismtech.tellotalksdk.ui.customviews.ImageViewEmoji;
import com.tilismtech.tellotalksdk.ui.emojis.utilities.Emoji;
import com.tilismtech.tellotalksdk.ui.emojis.utilities.EmojiData;
import com.tilismtech.tellotalksdk.utils.AndroidUtilities;

public class EmojiGridAdapter extends BaseAdapter {

    private int emojiPage;
    private Context context;
    private OnEmojiconClickedListener mOnEmojiconClickedListener;

    public EmojiGridAdapter(int page, Context context, OnEmojiconClickedListener mOnEmojiconClickedListener) {
        emojiPage = page;
        this.context = context;
        this.mOnEmojiconClickedListener = mOnEmojiconClickedListener;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public int getCount() {
        return EmojiData.dataColored[emojiPage].length;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View view, ViewGroup paramViewGroup) {
        final ImageView imageView = new ImageViewEmoji(context);
        AbsListView.LayoutParams params = new AbsListView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        imageView.setLayoutParams(params);
        imageView.setPadding(AndroidUtilities.dp(2), AndroidUtilities.dp(2), AndroidUtilities.dp(2), AndroidUtilities.dp(2));
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        final String code;
        final String coloredCode;
        coloredCode = code = EmojiData.dataColored[emojiPage][position];
        final Drawable d = Emoji.getEmojiBigDrawable(coloredCode);
        imageView.setImageDrawable(d);
        imageView.setOnClickListener(v -> {
            if (mOnEmojiconClickedListener != null) {
                mOnEmojiconClickedListener.onEmojiIconClicked(code);
            }
        });
        imageView.setTag(code);
        return imageView;
    }
}