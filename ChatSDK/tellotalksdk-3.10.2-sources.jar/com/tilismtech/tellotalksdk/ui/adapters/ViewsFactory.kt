package com.tilismtech.tellotalksdk.ui.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.AudioMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.AudioMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.BroadcastAudioMessageBubbleBinding
import com.tilismtech.tellotalksdk.databinding.BroadcastFileMessageBubbleBinding
import com.tilismtech.tellotalksdk.databinding.BroadcastImageMessageBubbleBinding
import com.tilismtech.tellotalksdk.databinding.BroadcastTextMessageBubbleBinding
import com.tilismtech.tellotalksdk.databinding.BroadcastVideoMessageBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatbotFormviewBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatbotMessageOptionchildBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatbotMessageRecievedBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatbotMessageVoteBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatbotTextBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatbotUnsupportedBubbleBinding
import com.tilismtech.tellotalksdk.databinding.ChatendMessageLayoutBinding
import com.tilismtech.tellotalksdk.databinding.ContactMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.ContactMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.DeletedMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.DeletedMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.FileMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.FileMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.ImageMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.ImageMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.IntimationMessageLayoutBinding
import com.tilismtech.tellotalksdk.databinding.LocationMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.LocationMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.MessageNewsBtnLayoutBinding
import com.tilismtech.tellotalksdk.databinding.MessageNewsItemLayoutBinding
import com.tilismtech.tellotalksdk.databinding.TextMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.TextMessageSentItemBinding
import com.tilismtech.tellotalksdk.databinding.TypingDotsLayoutBinding
import com.tilismtech.tellotalksdk.databinding.UnreadCountMessageLayoutBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.AudioViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BroadCastAudioViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BroadCastFileViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BroadCastImageViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BroadCastTextViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BroadCastVideoViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatBotBubbleViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatBotFormViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatBotOptionChildViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatBotTextViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatBotUnSupportedHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatBotVoteViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ChatEndViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ContactMsgViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.DeleteViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.FileViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.ImageViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.IntimationViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.LocationViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.NewsMsgViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.NewsWBTNViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.TextViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.TypingDotsViewHolder
import com.tilismtech.tellotalksdk.utils.ApplicationUtils

/**
 * Created by lpt-034 on 13/04/2018.
 */
class ViewsFactory internal constructor() {
    var gson = Gson().newBuilder().serializeNulls().create()
    fun getItemViewType(message: TTMessage?): Int {
        val type = message?.msgType
        if (message?.isDeleted == true || type == TTMessage.MsgType.TYPE_DELETED.value) {
            return if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                TYPE_DELETED_RECEIVED
            } else TYPE_DELETED_SENT
        }
        if (type == TTMessage.MsgType.TYPE_IMAGE.value) {
            return if (message.dptType == "1") {
                TYPE_IMAGE_BROADCAST
            } else {
                if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    TYPE_IMAGE_RECEIVED
                } else TYPE_IMAGE_SENT
            }
        } else if (type == TTMessage.MsgType.TYPE_VIDEO.value) {
            return if (message.dptType == "1") {
                TYPE_VIDEO_BROADCAST
            } else {
                if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    TYPE_VIDEO_RECEIVED
                } else TYPE_VIDEO_SENT
            }
        } else if (type == TTMessage.MsgType.TYPE_TEXT.value) {
            return if (message.dptType == "1") {
                TYPE_TEXT_BROADCAST
            } else {
                if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    TYPE_TEXT_RECEIVED
                } else TYPE_TEXT_SENT
            }
        } else if (type == TTMessage.MsgType.TYPE_AUDIO.value) {
            return if (message.dptType == "1") {
                TYPE_AUDIO_BROADCAST
            } else {
                if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    TYPE_AUDIO_RECEIVED
                } else TYPE_AUDIO_SENT
            }
        } else if (type == TTMessage.MsgType.TYPE_FILE.value) {
            return if (message.dptType == "1") {
                TYPE_FILE_BROADCAST
            } else {
                if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    TYPE_FILE_RECEIVED
                } else TYPE_FILE_SENT
            }
        } else if (type == TTMessage.MsgType.TYPE_LOCATION.value) {
            return if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                TYPE_LOCATION_RECEIVED
            } else TYPE_LOCATION_SENT
        } else if (type == TTMessage.MsgType.TYPE_CONTACT.value) {
            return if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                TYPE_CONTACT_RECEIVED
            } else TYPE_CONTACT_SENT
        } else if (type == TTMessage.MsgType.TYPE_DATE.value) {
            return TYPE_INTIMATION
        } else if (type == TTMessage.MsgType.TYPE_UNREAD.value) {
            return TYPE_UNREAD
        } else if (type == TTMessage.MsgType.TYPE_CHOICES.value) {
            return TYPE_CHOICE
        } else if (type == TTMessage.MsgType.TYPE_CARDVIEWS.value) {
            return TYPE_CARDVIEW
        } else if (type == TTMessage.MsgType.TYPE_INVITE.value) {
            return TYPE_INVITE
        } else if (type == TTMessage.MsgType.TYPE_CHATEND.value) {
            return TYPE_CHATEND
        } else if (type == TTMessage.MsgType.TYPE_NEWS.value) {
            return TYPE_NEWS_RECEIVED
        } else if (type == TTMessage.MsgType.TYPE_NEWSWB.value) {
            return TYPE_NEWSW_BUTTON
        } else if (type == TTMessage.MsgType.TYPE_TYPING.value) {
            return TYPE_TYPING_DOTS
        } else if (type == TTMessage.MsgType.TYPE_CHATBOT.value) {
            return if (!ApplicationUtils.isEmptyString(message.chatbotNode)) {
                val children = gson.fromJson(message.chatbotNode, ChatbotNode::class.java)?.children
                val type = gson.fromJson(message.chatbotNode, ChatbotNode::class.java)?.type
                if (children?.getOrNull(0)?.type?.equals(ChatbotNode.BotType.TYPE_OPTIONCHILD.getName(), ignoreCase = true) == true || type.equals(ChatbotNode.BotType.TYPE_OPTIONCHILD.getName(), ignoreCase = true)) {
                    TYPE_CHATBOT_OPTIONCHILD
                } else if (children?.getOrNull(0)?.type?.equals(ChatbotNode.BotType.TYPE_VOTE.getName(), ignoreCase = true) == true || type.equals(ChatbotNode.BotType.TYPE_VOTE.getName(), ignoreCase = true)) {
                    TYPE_CHATBOT_VOTE
                } else if ((children?.getOrNull(0)?.type?.equals(ChatbotNode.BotType.TYPE_TEXT.getName(), ignoreCase = true) == true || children?.getOrNull(0)?.type?.equals(ChatbotNode.BotType.TYPE_PDMESSAGE.getName(), ignoreCase = true) == true || type.equals(ChatbotNode.BotType.TYPE_TEXT.getName(), ignoreCase = true) || type.equals(ChatbotNode.BotType.TYPE_PDMESSAGE.getName(), ignoreCase = true)) || (children?.getOrNull(0)?.type?.equals(ChatbotNode.BotType.TYPE_AGENT.getName(), ignoreCase = true)?: type.equals(ChatbotNode.BotType.TYPE_AGENT.getName(), ignoreCase = true))) {
                    TYPE_CHATBOT_TEXT
                } else if (children?.getOrNull(0)?.type?.equals(ChatbotNode.BotType.TYPE_FORM.getName(), ignoreCase = true) == true || type.equals(ChatbotNode.BotType.TYPE_FORM.getName(), ignoreCase = true)) {
                    TYPE_CHATBOT_FORMS
                } else {
                    TYPE_CHATBOT
                }
            } else {
                TYPE_CHATBOT_UNSUPPORTED
            }
        }
        return -1
    }

    fun getView(
        viewType: Int,
        layoutInflater: LayoutInflater?,
        parent: ViewGroup?,
        context: Context?
    ): BaseViewHolder {
        return when (viewType) {
            TYPE_TEXT_RECEIVED -> TextViewHolder(
                TextMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_TEXT_SENT -> TextViewHolder(
                TextMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_AUDIO_SENT -> AudioViewHolder(
                AudioMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_AUDIO_RECEIVED -> AudioViewHolder(
                AudioMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_IMAGE_SENT, TYPE_VIDEO_SENT -> ImageViewHolder(
                ImageMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_IMAGE_RECEIVED, TYPE_VIDEO_RECEIVED -> ImageViewHolder(
                ImageMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_FILE_SENT -> FileViewHolder(
                FileMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_FILE_RECEIVED -> FileViewHolder(
                FileMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_DELETED_SENT -> DeleteViewHolder(
                DeletedMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_DELETED_RECEIVED -> DeleteViewHolder(
                DeletedMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_CONTACT_SENT -> ContactMsgViewHolder(
                ContactMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_CONTACT_RECEIVED -> ContactMsgViewHolder(
                ContactMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_LOCATION_SENT -> LocationViewHolder(
                LocationMessageSentItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_LOCATION_RECEIVED -> LocationViewHolder(
                LocationMessageReceivedItemBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_DATE -> IntimationViewHolder(
                IntimationMessageLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_UNREAD -> IntimationViewHolder(
                UnreadCountMessageLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_CHATEND -> ChatEndViewHolder(
                ChatendMessageLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_NEWS_RECEIVED -> NewsMsgViewHolder(
                MessageNewsItemLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_NEWSW_BUTTON -> NewsWBTNViewHolder(
                MessageNewsBtnLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_TYPING_DOTS -> TypingDotsViewHolder(
                TypingDotsLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                ), context
            )

            TYPE_CHATBOT -> ChatBotBubbleViewHolder(
                ChatbotMessageRecievedBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_CHATBOT_OPTIONCHILD -> ChatBotOptionChildViewHolder(
                ChatbotMessageOptionchildBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_CHATBOT_VOTE -> ChatBotVoteViewHolder(
                ChatbotMessageVoteBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_CHATBOT_TEXT -> ChatBotTextViewHolder(
                ChatbotTextBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                ),
            )

            TYPE_CHATBOT_UNSUPPORTED -> ChatBotUnSupportedHolder(
                ChatbotUnsupportedBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_CHATBOT_FORMS -> ChatBotFormViewHolder(
                ChatbotFormviewBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_TEXT_BROADCAST -> BroadCastTextViewHolder(
                BroadcastTextMessageBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_IMAGE_BROADCAST -> BroadCastImageViewHolder(
                BroadcastImageMessageBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_VIDEO_BROADCAST -> BroadCastVideoViewHolder(
                BroadcastVideoMessageBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            TYPE_AUDIO_BROADCAST -> BroadCastAudioViewHolder(
                BroadcastAudioMessageBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                ), context!!
            )

            TYPE_FILE_BROADCAST -> BroadCastFileViewHolder(
                BroadcastFileMessageBubbleBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )

            else -> IntimationViewHolder(
                IntimationMessageLayoutBinding.inflate(
                    layoutInflater!!, parent, false
                )
            )
        }
    }

    fun onBindViewHolder(
        holder: BaseViewHolder?,
        message: TTMessage?,
        messageAdapter: BaseMessageAdapter?,
        messageRepository: TTMessageRepository?,
        position: Int
    ) {
        if (holder is TextViewHolder) {
            holder.bind(message, messageAdapter, messageRepository!!, position, null)
        } else if (holder is ImageViewHolder) {
            holder.bind(message, messageAdapter, messageRepository, null)
        } else if (holder is FileViewHolder) {
            holder.bind(message, messageAdapter, messageRepository!!, null)
        } else if (holder is AudioViewHolder) {
            holder.bind(message, messageAdapter, messageRepository, null)
            message?.setAssets()
        } else if (holder is DeleteViewHolder) {
            holder.bind(message)
        } else if (holder is ContactMsgViewHolder) {
            holder.bind(message, messageAdapter!!,messageRepository!!)
        } else if (holder is LocationViewHolder) {
            holder.bind(message, messageAdapter, messageRepository!!, null)
            holder.recycle()
        } else if (holder is IntimationViewHolder) {
            holder.bind(message)
        } else if (holder is NewsMsgViewHolder) {
            holder.bind(message, messageAdapter, null)
        } else if (holder is NewsWBTNViewHolder) {
            holder.bind(message, messageAdapter, null)
        } else if (holder is ChatBotBubbleViewHolder) {
            holder.bind(message, messageAdapter)
        } else if (holder is ChatEndViewHolder) {
            holder.bind(message)
        } else if (holder is ChatBotOptionChildViewHolder) {
            holder.bind(message, messageAdapter!!)
        } else if (holder is ChatBotVoteViewHolder) {
            holder.bind(message, messageAdapter!!)
        } else if (holder is ChatBotTextViewHolder) {
            holder.bind(message)
        } else if (holder is ChatBotUnSupportedHolder) {
            holder.bind(message, messageAdapter!!)
        } else if (holder is ChatBotFormViewHolder) {
            holder.bind(message, messageAdapter)
        } else if (holder is BroadCastTextViewHolder) {
            holder.bind(message, messageAdapter!!)
        } else if (holder is BroadCastImageViewHolder) {
            holder.bind(message, messageAdapter!!)
        } else if (holder is BroadCastVideoViewHolder) {
            holder.bind(message, messageAdapter!!)
        } else if (holder is BroadCastAudioViewHolder) {
            holder.bind(message, messageAdapter!!, messageRepository!!, null)
        } else if (holder is BroadCastFileViewHolder) {
            holder.bind(message, messageAdapter!!)
        } else if(holder is TypingDotsViewHolder){
            holder.bind(message,messageAdapter!!)
        }
    }

    fun onViewRecycled(holder: BaseViewHolder?) {
        if (holder is TextViewHolder) {
            holder.recycle()
        } else if (holder is ImageViewHolder) {
            holder.recycle()
        } else if (holder is FileViewHolder) {
            holder.recycle()
        } else if (holder is AudioViewHolder) {
            holder.recycle()
        } else if (holder is ContactMsgViewHolder) {
            holder.recycle()
        } else if (holder is LocationViewHolder) {
            holder.recycle()
        } else if (holder is IntimationViewHolder) {
            holder.recycle()
        } else if (holder is ChatEndViewHolder) {
            holder.recycle()
        } else if (holder is NewsMsgViewHolder) {
            holder.recycle()
        } else if (holder is NewsWBTNViewHolder) {
            holder.recycle()
        } else if (holder is ChatBotBubbleViewHolder) {
            holder.recycle()
        } else if (holder is ChatBotOptionChildViewHolder) {
            holder.recycle()
        } else if (holder is ChatBotVoteViewHolder) {
            holder.recycle()
        } else if (holder is ChatBotTextViewHolder) {
            holder.recycle()
        } else if (holder is ChatBotUnSupportedHolder) {
            holder.recycle()
        } else if (holder is ChatBotFormViewHolder) {
            holder.recycle()
        } else if (holder is BroadCastTextViewHolder) {
            holder.recycle()
        } else if (holder is BroadCastImageViewHolder) {
            holder.recycle()
        } else if (holder is BroadCastVideoViewHolder) {
            holder.recycle()
        } else if (holder is BroadCastAudioViewHolder) {
            holder.recycle()
        } else if (holder is BroadCastFileViewHolder) {
            holder.recycle()
        }
        else if (holder is TypingDotsViewHolder) {
            holder.recycle()
        }
    }

    companion object {
        private const val TYPE_TEXT_RECEIVED = 1
        private const val TYPE_TEXT_SENT = 2
        private const val TYPE_AUDIO_SENT = 3
        private const val TYPE_AUDIO_RECEIVED = 4
        private const val TYPE_IMAGE_SENT = 5
        private const val TYPE_IMAGE_RECEIVED = 6
        private const val TYPE_VIDEO_SENT = 7
        private const val TYPE_VIDEO_RECEIVED = 8
        private const val TYPE_FILE_SENT = 9
        private const val TYPE_FILE_RECEIVED = 10
        private const val TYPE_STICKER_SENT = 11
        private const val TYPE_STICKER_RECEIVED = 12
        private const val TYPE_DELETED_SENT = 13
        private const val TYPE_DELETED_RECEIVED = 14
        private const val TYPE_CONTACT_SENT = 15
        private const val TYPE_CONTACT_RECEIVED = 16
        private const val TYPE_NEWS_SENT = 17
        private const val TYPE_NEWS_RECEIVED = 18
        private const val TYPE_LOCATION_SENT = 19
        private const val TYPE_LOCATION_RECEIVED = 20
        private const val TYPE_INTIMATION = 21
        private const val TYPE_DATE = 22
        private const val TYPE_UNREAD = 23
        private const val TYPE_CHOICE = 24
        private const val TYPE_CARDVIEW = 25
        private const val TYPE_INVITE = 26
        private const val TYPE_CHATEND = 27
        private const val TYPE_NEWSW_BUTTON = 28
        private const val TYPE_CHATBOT = 29
        private const val TYPE_CHATBOT_OPTIONCHILD = 30
        private const val TYPE_CHATBOT_VOTE = 31
        private const val TYPE_CHATBOT_TEXT = 32
        private const val TYPE_CHATBOT_UNSUPPORTED = 33
        private const val TYPE_CHATBOT_FORMS = 34
        private const val TYPE_TEXT_BROADCAST = 35
        private const val TYPE_IMAGE_BROADCAST = 36
        private const val TYPE_VIDEO_BROADCAST = 37
        private const val TYPE_AUDIO_BROADCAST = 38
        private const val TYPE_FILE_BROADCAST = 39
        private const val TYPE_TYPING_DOTS = 40
        @JvmStatic
        val instance = ViewsFactory()
    }
}