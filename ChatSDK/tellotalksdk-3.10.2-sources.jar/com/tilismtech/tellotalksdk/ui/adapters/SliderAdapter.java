package com.tilismtech.tellotalksdk.ui.adapters;

import android.os.Bundle;
import android.os.Parcelable;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild;
import com.tilismtech.tellotalksdk.ui.fragment.SliderViewFragment;

import java.util.ArrayList;
import java.util.List;

public class SliderAdapter extends FragmentStatePagerAdapter {
   // private int[] imageResourceIds;
    List<ChatbotChild> chatbotChildList;

    public SliderAdapter(FragmentManager fm, List<ChatbotChild> chatbotChildList) {
        super(fm);
        this.chatbotChildList = chatbotChildList;
    }

    @Override
    public Fragment getItem(int position) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("child",chatbotChildList.get(position));
        bundle.putInt("position",position);
        bundle.putParcelableArrayList("carousalList", (ArrayList<? extends Parcelable>) chatbotChildList);
        SliderViewFragment frag = new SliderViewFragment();
        frag.setArguments(bundle);

        return frag;
    }

    @Override
    public int getCount() {
        return chatbotChildList.size();
    }

}
