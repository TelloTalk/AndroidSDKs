package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import androidx.viewbinding.ViewBinding
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.AudioMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.AudioMessageSentItemBinding
import com.tilismtech.tellotalksdk.managers.http.TransferableManager
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.changeAudioStatus
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setAudioLength
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setAudioProgress
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.updateBtnSrc


/**
 * Created by sohailahmed on 12/04/2017.
 */
class AudioViewHolder(var binding: ViewBinding) : BaseViewHolder(binding.root) {

    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter?,
        repository: TTMessageRepository?,
        payloads: List<Any?>?
    ) {
        val audioSentBinding: AudioMessageSentItemBinding
        val audioReceivedBinding: AudioMessageReceivedItemBinding
        val transferable = TransferableManager.getInstance().getTransferable(message?.messageId)
        if (transferable != null) {
            message?.transferable = transferable
        }
        if (!isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage = repository?.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        if (binding is AudioMessageSentItemBinding) {
            audioSentBinding = binding as AudioMessageSentItemBinding
            audioSentBinding.playBtn.changeAudioStatus(audioSentBinding.audioSeekBar, message)
            audioSentBinding.playBtn.updateBtnSrc(message,audioSentBinding.audioSeekBar)
            audioSentBinding.audioSeekBar.setAudioProgress(message)
            audioSentBinding.audioLengthTxt.setAudioLength(message)
            audioSentBinding.downloadProgressBar.setUpProgress(message)
        } else {
            audioReceivedBinding = binding as AudioMessageReceivedItemBinding
            audioReceivedBinding.playBtn.changeAudioStatus(audioReceivedBinding.audioSeekBar, message)
            audioReceivedBinding.playBtn.updateBtnSrc(message,audioReceivedBinding.audioSeekBar)
            audioReceivedBinding.audioSeekBar.setAudioProgress(message)
            audioReceivedBinding.audioLengthTxt.setAudioLength(message)

            audioReceivedBinding.newsImage.hierarchy.roundingParams =
                RoundingParams().setRoundAsCircle(true)
            audioReceivedBinding.newsImage.hierarchy.setPlaceholderImage(R.drawable.image_circle)
            val agentModel = getInstance()?.getAgent(message?.profileId)
            if (agentModel != null) {
                audioReceivedBinding.newsImage.setImageURI(isStringContainURL(agentModel.agentAvatar).ifEmpty { message?.dptImage })
            }
        }
    }


    fun recycle() {
        val audioSentBinding: AudioMessageSentItemBinding
        val audioReceivedItemBinding: AudioMessageReceivedItemBinding
        if (binding is AudioMessageSentItemBinding) {
            audioSentBinding = binding as AudioMessageSentItemBinding
            audioSentBinding.audioLengthTxt.text = ""
            audioSentBinding.playBtn.setImageResource(R.drawable.play_icon_sdk)
            audioSentBinding.audioSeekBar.setProgress(0,false)
        } else {
            audioReceivedItemBinding = binding as AudioMessageReceivedItemBinding
            audioReceivedItemBinding.audioLengthTxt.text = ""
            audioReceivedItemBinding.playBtn.setImageResource(R.drawable.play_icon_sdk)
            audioReceivedItemBinding.audioSeekBar.setProgress(0,false)
        }
    }
}