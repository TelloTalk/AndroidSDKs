package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.content.Context
import android.view.ContextMenu
import android.view.View
import androidx.core.content.res.ResourcesCompat
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.databinding.ChatbotMessageOptionchildBubbleBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppTextView
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setChatbubbleOption
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMinWidthText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setOptionChildTitle

class ChatBotOptionChildViewHolder(
    private val binding: ChatbotMessageOptionchildBubbleBinding,
    private val mContext: Context
) :
    BaseViewHolder(binding.root), View.OnCreateContextMenuListener {

    private var message: TTMessage? = null

    fun bind(message: TTMessage?, adapter: BaseMessageAdapter) {
        this.message = message

        binding.mainContainer.tag = this

        if (message?.message != null && message?.message?.isNotEmpty() == true) {
            if (!ApplicationUtils.isEnglish(message?.message)) {
                val whatsAppTextView =
                    binding.root.findViewById<WhatsAppTextView>(R.id.message_body)
                val face = ResourcesCompat.getFont(mContext, R.font.calibri)
                whatsAppTextView.typeface = face
            } else {
                val face = ResourcesCompat.getFont(mContext, R.font.calibri);
                val whatsAppTextView =
                    binding.root.findViewById<WhatsAppTextView>(R.id.message_body)
                whatsAppTextView.typeface = face
            }
        }

        binding.newsImage.hierarchy.roundingParams =
            RoundingParams().setRoundAsCircle(true)


        val agentModel = getInstance()?.getAgent(message?.profileId)

        if (agentModel != null) {
            binding.newsImage.setImageURI(ApplicationUtils.isStringContainURL(agentModel.agentAvatar?:"").ifEmpty { message?.dptImage })
        }
        binding.messageBody.setOptionChildTitle(message)
        binding.messageBody.setMinWidthText(message)
        binding.questions.setChatbubbleOption(message)

    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo
    ) {

    }

    fun recycle() {

    }
}