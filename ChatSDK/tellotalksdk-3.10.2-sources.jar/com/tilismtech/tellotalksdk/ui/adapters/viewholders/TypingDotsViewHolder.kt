package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.content.Context
import android.view.ContextMenu
import android.view.ContextMenu.ContextMenuInfo
import android.view.View
import android.view.View.OnCreateContextMenuListener
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.TypingDotsLayoutBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL


class TypingDotsViewHolder(var binding: TypingDotsLayoutBinding, context: Context?) :
    BaseViewHolder(binding.root), OnCreateContextMenuListener {


    fun bind(message: TTMessage?, adapter: BaseMessageAdapter?) {
        binding.newsImage.hierarchy.roundingParams = RoundingParams().setRoundAsCircle(true)
        binding.newsImage.hierarchy.setPlaceholderImage(R.drawable.image_circle)
        binding.newsImage.setImageURI(isStringContainURL(message?.agentAvatar))

    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenuInfo) {
    }

    fun recycle() {

    }
}