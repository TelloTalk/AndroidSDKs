package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import androidx.viewbinding.ViewBinding
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.ChatendMessageLayoutBinding
import com.tilismtech.tellotalksdk.databinding.UnreadCountMessageLayoutBinding

class ChatEndViewHolder(val binding: ViewBinding) : BaseViewHolder(binding.root) {
    fun bind(message: TTMessage?) {
        val chatendMessageLayoutBinding: ChatendMessageLayoutBinding?
        val unreadCountMessageLayoutBinding: UnreadCountMessageLayoutBinding
        if (binding is ChatendMessageLayoutBinding) {
            chatendMessageLayoutBinding = binding
            chatendMessageLayoutBinding.messageBody.text = message?.message

        } else {
            unreadCountMessageLayoutBinding = binding as UnreadCountMessageLayoutBinding
            unreadCountMessageLayoutBinding.messageBody.text = message?.message
        }
    }

    fun recycle() {
        val chatendMessageLayoutBinding: ChatendMessageLayoutBinding?
        val unreadCountMessageLayoutBinding: UnreadCountMessageLayoutBinding
        if (binding is ChatendMessageLayoutBinding) {
            chatendMessageLayoutBinding = binding
            chatendMessageLayoutBinding.messageBody.setCompoundDrawablesWithIntrinsicBounds(
                null,
                null,
                null,
                null
            )
        } else {
            unreadCountMessageLayoutBinding = binding as UnreadCountMessageLayoutBinding
            unreadCountMessageLayoutBinding.messageBody.setCompoundDrawablesWithIntrinsicBounds(
                null,
                null,
                null,
                null
            )
        }
    }
}