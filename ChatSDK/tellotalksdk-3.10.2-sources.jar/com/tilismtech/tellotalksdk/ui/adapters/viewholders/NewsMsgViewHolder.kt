package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.ContextMenu
import android.view.View
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.MessageNewsItemLayoutBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastHeading
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastImage
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setExpandableText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFaqOptions
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setHeadingArrow
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageTime
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setReadmoreURL

class NewsMsgViewHolder(var binding: MessageNewsItemLayoutBinding) :
    BaseViewHolder(
        binding.getRoot()
    ), View.OnCreateContextMenuListener {
    fun bind(message: TTMessage?, adapter: BaseMessageAdapter?, payloads: MutableList<Any?>?) {
        binding.parentLayout.setOnClickListener {
            adapter?.onLinkClicked(message?.msgURL?:"")
        }
        binding.layHeading.setHeadingArrow(message)
        binding.newsHeading.setBroadcastHeading(message)
        binding.layReadMore.setReadmoreURL(message)
        binding.layReadMore.setOnClickListener {
            adapter?.onLinkClicked(message?.msgURL?:"")
        }
        binding.newsImage.setBroadcastImage(message)
        binding.expandableParent.setExpandableText(message)
        binding.questions.setFaqOptions(message)
        binding.messageTime.setMessageTime(message)


    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun recycle() {
//        binding.newsImage.setImageURI("");
//        binding.senderName.setText("");
//        binding.newsDetail.setText("");
//        binding.newsHeading.setText("");
    }
}