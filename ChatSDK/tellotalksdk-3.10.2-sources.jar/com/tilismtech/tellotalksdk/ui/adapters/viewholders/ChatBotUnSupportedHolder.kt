package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.graphics.Typeface
import android.view.ContextMenu
import android.view.View
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository
import com.tilismtech.tellotalksdk.databinding.ChatbotUnsupportedBubbleBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMinWidthText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUnsupportedTextMessage

class ChatBotUnSupportedHolder(
    private val binding: ChatbotUnsupportedBubbleBinding,
) :
    BaseViewHolder(binding.root), View.OnCreateContextMenuListener {

    private var face: Typeface? = null
    private var message: TTMessage? = null

    fun bind(message: TTMessage?, adapter: BaseMessageAdapter) {
        this.message = message
        binding.mainContainer.tag = this

        binding.newsImage.hierarchy.roundingParams =
            RoundingParams().setRoundAsCircle(true)

        val agentModel = TTAgentRepository.getInstance()?.getAgent(message?.profileId)
        if (agentModel != null) {
            binding.newsImage.setImageURI(ApplicationUtils.isStringContainURL(agentModel.agentAvatar?:"").ifEmpty { message?.dptImage })
        }
        binding.messageBody.setUnsupportedTextMessage(message)
        binding.messageBody.setMinWidthText(message)
        binding.messageDescription.setUnsupportedTextMessage(message)
        binding.messageDescription.setMinWidthText(message)

    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo
    ) {

    }

    fun recycle() {

    }
}