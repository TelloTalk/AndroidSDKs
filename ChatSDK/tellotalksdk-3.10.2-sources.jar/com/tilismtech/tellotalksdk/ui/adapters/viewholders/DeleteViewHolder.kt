package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import androidx.core.graphics.toColorInt
import androidx.viewbinding.ViewBinding
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.databinding.DeletedMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.DeletedMessageSentItemBinding
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL

class DeleteViewHolder(var binding: ViewBinding) : BaseViewHolder(
    binding.root
) {
    fun bind(message: TTMessage?) {
        val deletedMessageReceivedItemBinding: DeletedMessageReceivedItemBinding
        val deletedMessageSentItemBinding: DeletedMessageSentItemBinding
        if (binding is DeletedMessageReceivedItemBinding) {
            deletedMessageReceivedItemBinding = binding as DeletedMessageReceivedItemBinding

            deletedMessageReceivedItemBinding.newsImage.hierarchy.roundingParams =
                RoundingParams().setRoundAsCircle(true)
            deletedMessageReceivedItemBinding.newsImage.hierarchy.setPlaceholderImage(R.drawable.image_circle)
            val agentModel = getInstance()?.getAgent(message?.profileId)
            if (agentModel != null) {
                deletedMessageReceivedItemBinding.newsImage.setImageURI(
                    isStringContainURL(
                        agentModel.agentAvatar
                    )
                )
            }
        } else {
            deletedMessageSentItemBinding = binding as DeletedMessageSentItemBinding
            deletedMessageSentItemBinding.msgSentFooter.messageTime.setTextColor("#000000".toColorInt())

        }

    }
}
