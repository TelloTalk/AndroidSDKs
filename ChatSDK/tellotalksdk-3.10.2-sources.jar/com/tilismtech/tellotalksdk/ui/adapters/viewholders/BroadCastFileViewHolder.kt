package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.graphics.Typeface
import android.view.ContextMenu
import android.view.View
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.BroadcastFileMessageBubbleBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastHeading
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setExpandableText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFaqOptions
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFileIcons
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFileName
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFileSize
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setHeadingArrow
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageTime
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setReadmoreURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress

class BroadCastFileViewHolder(
    private val binding: BroadcastFileMessageBubbleBinding
) :
    BaseViewHolder(binding.root), View.OnCreateContextMenuListener {

    private var face: Typeface? = null
    private var message: TTMessage? = null


    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun bind(message: TTMessage?, adapter: BaseMessageAdapter) {
        this.message = message

        binding.mainContainer.tag = this
        binding.layParent.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layHeading.setHeadingArrow(message)
        binding.newsHeading.setBroadcastHeading(message)
        binding.layReadMore.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layReadMore.setReadmoreURL(message)
        binding.newsImage.setOnClickListener{
            adapter.openDownloadable(message)
        }
        binding.imgIcon.setFileIcons(message)
        binding.downloadProgressBar.setUpProgress(message)
        binding.fileSizeText.setFileSize(message)
        binding.tvFilename.setFileName(message)
        binding.layText.setExpandableText(message)
        binding.questions.setFaqOptions(message)
        binding.messageTime.setMessageTime(message)
    }

    fun recycle() {
    }

}