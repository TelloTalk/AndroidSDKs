package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.content.Context
import android.view.ContextMenu
import android.view.ContextMenu.ContextMenuInfo
import android.view.View
import android.view.View.OnCreateContextMenuListener
import androidx.core.content.res.ResourcesCompat
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.databinding.ChatbotFormviewBubbleBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppTextView
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setChatbotTitle
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFormview
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMinWidthText

class ChatBotFormViewHolder(var binding: ChatbotFormviewBubbleBinding, private val mContext: Context) :
    BaseViewHolder(
        binding.root
    ), OnCreateContextMenuListener {
    var message: TTMessage? = null
    fun bind(message: TTMessage?, adapter: BaseMessageAdapter?) {
        this.message = message

        binding.mainContainer.tag = this
        if (message?.message != null && (message.message?.length?:0) > 0) {
            if (!isEnglish(message.message)) {
                val whatsAppTextView =
                    binding.root.findViewById<View>(R.id.message_body) as WhatsAppTextView
                val face = ResourcesCompat.getFont(mContext, R.font.calibri)
                whatsAppTextView.typeface = face
            } else {
                val face = ResourcesCompat.getFont(mContext, R.font.calibri)
                val whatsAppTextView =
                    binding.root.findViewById<View>(R.id.message_body) as WhatsAppTextView
                whatsAppTextView.typeface = face
            }
        }
        binding.newsImage.hierarchy.roundingParams =
            RoundingParams().setRoundAsCircle(true)
        val agentModel = getInstance()?.getAgent(message?.profileId)
        if (agentModel != null) {
            binding.newsImage.setImageURI(isStringContainURL(agentModel.agentAvatar?:"").ifEmpty { message?.dptImage })
        }
        binding.messageBody.setChatbotTitle(message)
        binding.messageBody.setMinWidthText(message)
        binding.layFormParent.setFormview(message)

    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenuInfo) {}
    fun recycle() {

    }
}
