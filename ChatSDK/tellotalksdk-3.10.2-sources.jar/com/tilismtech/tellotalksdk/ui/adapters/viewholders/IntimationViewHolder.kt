package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import androidx.viewbinding.ViewBinding
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.IntimationMessageLayoutBinding
import com.tilismtech.tellotalksdk.databinding.UnreadCountMessageLayoutBinding

class IntimationViewHolder(val binding: ViewBinding) : BaseViewHolder(binding.root) {
    fun bind(message: TTMessage?) {
        val intimationMessageLayoutBinding: IntimationMessageLayoutBinding?
        val unreadCountMessageLayoutBinding: UnreadCountMessageLayoutBinding?
        if (binding is IntimationMessageLayoutBinding) {
            intimationMessageLayoutBinding = binding
            intimationMessageLayoutBinding.messageBody.text = message?.message
        } else {
            unreadCountMessageLayoutBinding = binding as UnreadCountMessageLayoutBinding?
            unreadCountMessageLayoutBinding?.messageBody?.text = message?.message
        }
    }

    fun recycle() {
        val intimationMessageLayoutBinding: IntimationMessageLayoutBinding?
        val unreadCountMessageLayoutBinding: UnreadCountMessageLayoutBinding
        if (binding is IntimationMessageLayoutBinding) {
            intimationMessageLayoutBinding = binding
            intimationMessageLayoutBinding.messageBody.setCompoundDrawablesWithIntrinsicBounds(
                null,
                null,
                null,
                null
            )
        } else {
            unreadCountMessageLayoutBinding = binding as UnreadCountMessageLayoutBinding
            unreadCountMessageLayoutBinding.messageBody.setCompoundDrawablesWithIntrinsicBounds(
                null,
                null,
                null,
                null
            )
        }
    }
}