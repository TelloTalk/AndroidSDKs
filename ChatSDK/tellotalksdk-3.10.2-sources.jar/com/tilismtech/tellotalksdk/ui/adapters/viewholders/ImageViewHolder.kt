package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.content.Context
import android.view.ContextMenu
import android.view.ContextMenu.ContextMenuInfo
import android.view.View
import android.view.View.OnCreateContextMenuListener
import androidx.core.content.res.ResourcesCompat
import androidx.viewbinding.ViewBinding
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.ImageMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.ImageMessageSentItemBinding
import com.tilismtech.tellotalksdk.managers.http.TransferableManager
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppTextView
import com.tilismtech.tellotalksdk.utils.AndroidUtilities
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.avatarImage
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpFileTag
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress


class ImageViewHolder(var binding: ViewBinding, private val mContext: Context) :
    BaseViewHolder(
        binding.root
    ), OnCreateContextMenuListener {
    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter?,
        repository: TTMessageRepository?,
        payloads: List<Any?>?
    ) {
        val imageSentBinding: ImageMessageSentItemBinding
        val imageReceivedBinding: ImageMessageReceivedItemBinding
        val transferable = TransferableManager.getInstance().getTransferable(message?.messageId)
        if (transferable != null) {
            message?.transferable = transferable
        }
        if (!isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage = repository?.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        if (binding is ImageMessageSentItemBinding) {
            imageSentBinding = binding as ImageMessageSentItemBinding

            imageSentBinding.messageImage.setOnClickListener {
                adapter?.openDownloadable(message)
            }
            imageSentBinding.messageImage.avatarImage(message)
            imageSentBinding.messageProgressBar.setUpProgress(message)
            imageSentBinding.msgFileTag.setUpFileTag(message?.caption)
        } else {
            imageReceivedBinding = binding as ImageMessageReceivedItemBinding
            imageReceivedBinding.messageImage.setOnClickListener {
                adapter?.openDownloadable(message)
            }
            imageReceivedBinding.messageImage.avatarImage(message)
            imageReceivedBinding.messageProgressBar.setUpProgress(message)
            imageReceivedBinding.msgFileTag.setUpFileTag(message?.caption)
            if (message?.agentAvatar == null) {
                return
            }
            imageReceivedBinding.newsImage.hierarchy.roundingParams =
                RoundingParams().setRoundAsCircle(true)
            imageReceivedBinding.newsImage.hierarchy.setPlaceholderImage(R.drawable.image_circle)
            val agentModel = getInstance()?.getAgent(message.profileId?.ifEmpty { message.dptImage })
            if (agentModel != null) {
                imageReceivedBinding.newsImage.setImageURI(isStringContainURL(agentModel.agentAvatar))
            }
        }
        if (message?.caption != null && (message.caption?.length?:0) > 0) {
            if (!isEnglish(message.caption)) {
                val whatsAppTextView =
                    binding.root.findViewById<View>(R.id.msg_file_tag) as WhatsAppTextView
                val face = ResourcesCompat.getFont(mContext, R.font.calibri)
                whatsAppTextView.typeface = face
            } else {
                val face = ResourcesCompat.getFont(mContext, R.font.calibri)
                val whatsAppTextView =
                    binding.root.findViewById<View>(R.id.msg_file_tag) as WhatsAppTextView
                whatsAppTextView.typeface = face
            }
        }
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenuInfo) {}
    fun recycle() {
        val imageSentBinding: ImageMessageSentItemBinding
        val imageReceivedBinding: ImageMessageReceivedItemBinding
        if (binding is ImageMessageSentItemBinding) {
            imageSentBinding = binding as ImageMessageSentItemBinding
            imageSentBinding.msgFileTag.text = ""
            imageSentBinding.messageImage.layoutParams.height =
                AndroidUtilities.displayMetrics.widthPixels * 2 / 3
            imageSentBinding.messageImage.layoutParams.width =
                AndroidUtilities.displayMetrics.widthPixels * 2 / 3
            imageSentBinding.messageProgressBar.visibility = View.GONE
        } else {
            imageReceivedBinding = binding as ImageMessageReceivedItemBinding
            imageReceivedBinding.messageImage.setImageURI("")
            imageReceivedBinding.messageImage.layoutParams.height =
                AndroidUtilities.displayMetrics.widthPixels * 2 / 3
            imageReceivedBinding.messageImage.layoutParams.width =
                AndroidUtilities.displayMetrics.widthPixels * 2 / 3
            imageReceivedBinding.msgFileTag.text = ""
            imageReceivedBinding.messageProgressBar.visibility = View.GONE
        }
    }
}
