package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.facebook.drawee.view.SimpleDraweeView
import com.tilismtech.tellotalksdk.R

class AllMemberHolder(itemView: View) : BaseViewHolder(itemView) {
    @JvmField
    var containerLayout: ConstraintLayout?
    @JvmField
    var memberImage: SimpleDraweeView
    @JvmField
    var memberName: TextView
    @JvmField
    var memberNumber: TextView
    @JvmField
    var memberSelected: ImageView?

    init {
        containerLayout = itemView.findViewById<ConstraintLayout?>(R.id.upper_layout)
        memberSelected = itemView.findViewById<ImageView?>(R.id.member_selected_img)
        memberNumber = itemView.findViewById<TextView>(R.id.contact_number)
        memberImage = itemView.findViewById<SimpleDraweeView>(R.id.contact_image)
        memberName = itemView.findViewById<TextView>(R.id.contact_name)
    }

    fun recycle() {
        memberName.setText("")
        memberImage.setImageURI("")
        memberNumber.setText("")
    }
}