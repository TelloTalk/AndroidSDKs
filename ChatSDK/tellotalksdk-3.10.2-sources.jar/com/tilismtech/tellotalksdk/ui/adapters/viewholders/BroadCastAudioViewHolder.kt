package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.content.Context
import android.graphics.Typeface
import android.view.ContextMenu
import android.view.View
import com.facebook.drawee.generic.GenericDraweeHierarchyBuilder
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.BroadcastAudioMessageBubbleBinding
import com.tilismtech.tellotalksdk.managers.http.TransferableManager
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.TelloMediaPlayer
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.changeAudioStatus
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setAudioLength
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setAudioProgress
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastHeading
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setExpandableText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFaqOptions
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setHeadingArrow
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageTime
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setReadmoreURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.updateBtnSrc

class BroadCastAudioViewHolder(
    private val binding: BroadcastAudioMessageBubbleBinding, private val mContext: Context) :
    BaseViewHolder(binding.root), View.OnCreateContextMenuListener {

    private var face: Typeface? = null
    private var message: TTMessage? = null


    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter,
        messageRepository: TTMessageRepository,
        o: Any?
    ) {
        this.message = message
        binding.mainContainer.tag = this

        val transferable = TransferableManager.getInstance().getTransferable(message?.messageId)
        if (transferable != null) {
            message?.transferable = transferable
        }
        if (!ApplicationUtils.isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage: TTMessage? = messageRepository.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        val mediaPlayer = TelloMediaPlayer.getInstance()
        if (mediaPlayer.messgeId.equals(message?.messageId, ignoreCase = true)) {
            try {
                mediaPlayer.setListenerBack(message)
                message?.updateProgress(mediaPlayer.doneProgress)
                message?.maxProgress = mediaPlayer.duration
                message?.isPlaying = mediaPlayer.isPlaying
            } catch (e: Exception) {
                mediaPlayer.stopMediaPlayer()
                e.printStackTrace()
            }
        }

        val roundingParams: RoundingParams = RoundingParams.fromCornersRadius(7f)
        binding.newsImage.hierarchy = GenericDraweeHierarchyBuilder(mContext.resources)
            .setRoundingParams(roundingParams)
            .build()

        binding.layParent.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layHeading.setHeadingArrow(message)
        binding.newsHeading.setBroadcastHeading(message)
        binding.layReadMore.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layReadMore.setReadmoreURL(message)
        binding.newsImage.setOnClickListener{
            adapter.openDownloadable(message)
        }
        binding.playBtn.updateBtnSrc(message,binding.audioSeekBar)
        binding.playBtn.changeAudioStatus(binding.audioSeekBar, message)
        binding.audioSeekBar.setAudioProgress(message)
        binding.audioLengthTxt.setAudioLength(message)
        binding.downloadProgressBar.setUpProgress(message)
        binding.layText.setExpandableText(message)
        binding.questions.setFaqOptions(message)
        binding.messageTime.setMessageTime(message)

    }

    fun recycle() {
    }

}