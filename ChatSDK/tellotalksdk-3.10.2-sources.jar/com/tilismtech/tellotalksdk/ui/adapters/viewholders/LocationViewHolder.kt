package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.View
import androidx.viewbinding.ViewBinding
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.LocationMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.LocationMessageSentItemBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.avatarImage
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress


class LocationViewHolder(var binding: ViewBinding) : BaseViewHolder(binding.root) {
    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter?,
        repository: TTMessageRepository,
        payloads: MutableList<Any?>?
    ) {
        val imageSentBinding: LocationMessageSentItemBinding?
        val imageReceivedBinding: LocationMessageReceivedItemBinding
        if (!isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage = repository.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        if (binding is LocationMessageSentItemBinding) {
            imageSentBinding = binding as LocationMessageSentItemBinding
            imageSentBinding.messageImage.setOnClickListener{
                adapter?.openDownloadable(message)
            }
            imageSentBinding.messageImage.avatarImage(message)
            imageSentBinding.messageProgressBar.setUpProgress(message)
            imageSentBinding.msgFileTag.text = message?.caption
            imageSentBinding.msgFileTag.visibility = if (!isEmptyString(message?.caption)) View.VISIBLE else View.GONE

        } else {
            imageReceivedBinding = binding as LocationMessageReceivedItemBinding
            imageReceivedBinding.messageImage.setOnClickListener{
                adapter?.openDownloadable(message)
            }
            imageReceivedBinding.messageImage.avatarImage(message)
            imageReceivedBinding.messageProgressBar.setUpProgress(message)
            imageReceivedBinding.msgFileTag.text = message?.caption
            imageReceivedBinding.msgFileTag.visibility = if (!isEmptyString(message?.caption)) View.VISIBLE else View.GONE
        }
    }

    fun recycle() {
        val imageSentBinding: LocationMessageSentItemBinding?
        val imageReceivedBinding: LocationMessageReceivedItemBinding
        if (binding is LocationMessageSentItemBinding) {
            imageSentBinding = binding as LocationMessageSentItemBinding
            imageSentBinding.messageImage.setImageURI("")
            imageSentBinding.msgFileTag.setText("")
        } else {
            imageReceivedBinding = binding as LocationMessageReceivedItemBinding
            imageReceivedBinding.messageImage.setImageURI("")
            imageReceivedBinding.msgFileTag.setText("")
        }
    }
}

