package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.View
import android.widget.LinearLayout
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageForeGround
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpFooter
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setupLinkPreview
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setupReplyContainer

open class BaseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val replyContainer: ConstraintLayout? = itemView.findViewById(R.id.reply_container)
    val footer: LinearLayout? = itemView.findViewById(R.id.msg_sent_footer)
    val linkPreview: ConstraintLayout? = itemView.findViewById(R.id.link_preview_container)


    open fun bindCommon(message: TTMessage?){
        itemView.setMessageForeGround(message)
        replyContainer?.setupReplyContainer(message)
        footer?.setUpFooter(message)
        linkPreview?.setupLinkPreview(message)
    }
}