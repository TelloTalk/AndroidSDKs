package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.ContextMenu
import android.view.View
import androidx.viewbinding.ViewBinding
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.FileMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.FileMessageSentItemBinding
import com.tilismtech.tellotalksdk.managers.http.TransferableManager
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFileIcons
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFileName
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress

class FileViewHolder(var binding: ViewBinding) : BaseViewHolder(binding.root), View.OnCreateContextMenuListener {


    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter?,
        repository: TTMessageRepository,
        payloads: MutableList<Any?>?
    ) {
        val fileSentBinding: FileMessageSentItemBinding?
        val fileReceivedBinding: FileMessageReceivedItemBinding
        val transferable = TransferableManager.getInstance().getTransferable(message?.messageId)
        if (transferable != null) {
            message?.transferable = transferable
        }
        if (!isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage = repository.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        if (binding is FileMessageSentItemBinding) {
            fileSentBinding = binding as FileMessageSentItemBinding
            fileSentBinding.innerContainer.setOnClickListener {
                adapter?.openDownloadable(message)
            }
            fileSentBinding.fileIcon.setFileIcons(message)
            fileSentBinding.audioLengthTxt.setFileName(message)
            fileSentBinding.downloadProgressBar.setUpProgress(message)

        } else {
            fileReceivedBinding = binding as FileMessageReceivedItemBinding
            fileReceivedBinding.innerContainer.setOnClickListener {
                adapter?.openDownloadable(message)
            }
            fileReceivedBinding.fileIcon.setFileIcons(message)
            fileReceivedBinding.audioLengthTxt.setFileName(message)
            fileReceivedBinding.downloadProgressBar.setUpProgress(message)


            fileReceivedBinding.newsImage.hierarchy
                .setRoundingParams(RoundingParams().setRoundAsCircle(true))
            fileReceivedBinding.newsImage.hierarchy
                .setPlaceholderImage(R.drawable.image_circle)

            val agentModel = TTAgentRepository.getInstance()
                ?.getAgent(message?.profileId)

            if (agentModel != null) {
                fileReceivedBinding.newsImage.setImageURI(isStringContainURL(agentModel.agentAvatar))
            }
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun recycle() {
        val fileSentBinding: FileMessageSentItemBinding?
        val fileReceivedBinding: FileMessageReceivedItemBinding
        if (binding is FileMessageSentItemBinding) {
            fileSentBinding = binding as FileMessageSentItemBinding
            fileSentBinding.downloadProgressBar.setVisibility(View.GONE)
            fileSentBinding.fileIcon.setImageResource(R.drawable.simple_file_icon)
            fileSentBinding.audioLengthTxt.setText("")
        } else {
            fileReceivedBinding = binding as FileMessageReceivedItemBinding
            fileReceivedBinding.downloadProgressBar.setVisibility(View.GONE)
            fileReceivedBinding.fileIcon.setImageResource(R.drawable.simple_file_icon)
            fileReceivedBinding.audioLengthTxt.setText("")
        }
    }
}

