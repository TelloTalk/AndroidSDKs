package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.ContextMenu
import android.view.View
import androidx.viewbinding.ViewBinding
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.ContactMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.ContactMessageSentItemBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.checkContactExists

class ContactMsgViewHolder(var binding: ViewBinding) : BaseViewHolder(binding.root),
    View.OnCreateContextMenuListener {


    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter,
        repository: TTMessageRepository
    ) {
        val contactReceivedBinding: ContactMessageReceivedItemBinding?
        val contactSentBinding: ContactMessageSentItemBinding
        if (!isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage = repository.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        if (binding is ContactMessageReceivedItemBinding) {
            contactReceivedBinding = binding as ContactMessageReceivedItemBinding
            contactReceivedBinding.audioLengthTxt.text = message?.caption
            contactReceivedBinding.addContactBtn.setOnClickListener {
                adapter.addContactIntoAddressBook(message?.message)
            }
            contactReceivedBinding.addContactBtn.checkContactExists(message?.message)

            contactReceivedBinding.mainContainer.tag = this
        } else {
            contactSentBinding = binding as ContactMessageSentItemBinding
            contactSentBinding.audioLengthTxt.text = message?.caption

            contactSentBinding.mainContainer.tag = this
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun recycle() {
        val contactReceivedBinding: ContactMessageReceivedItemBinding?
        val contactSentBinding: ContactMessageSentItemBinding
        if (binding is ContactMessageReceivedItemBinding) {
            contactReceivedBinding = binding as ContactMessageReceivedItemBinding
            contactReceivedBinding.audioLengthTxt.setText("")
            contactReceivedBinding.contactImg.setImageResource(R.drawable.contact_default_pic)
        } else {
            contactSentBinding = binding as ContactMessageSentItemBinding
            contactSentBinding.audioLengthTxt.setText("")
            contactSentBinding.contactImg.setImageResource(R.drawable.contact_default_pic)
        }
    }
}
