package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.graphics.Typeface
import android.view.ContextMenu
import android.view.View
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.BroadcastVideoMessageBubbleBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastHeading
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastImage
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setExpandableText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFaqOptions
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setHeadingArrow
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageTime
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setReadmoreURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setUpProgress

class BroadCastVideoViewHolder(
    private val binding: BroadcastVideoMessageBubbleBinding
) : BaseViewHolder(binding.root), View.OnCreateContextMenuListener {

    private var face: Typeface? = null
    private var message: TTMessage? = null


    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun bind(message: TTMessage?, adapter: BaseMessageAdapter) {
        this.message = message
        binding.mainContainer.tag = this
        binding.layParent.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layHeading.setHeadingArrow(message)
        binding.newsHeading.setBroadcastHeading(message)
        binding.layReadMore.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layReadMore.setReadmoreURL(message)
        binding.newsImage.setOnClickListener{
            adapter.openDownloadable(message)
        }
        binding.newsImage.setBroadcastImage(message)
        binding.messageProgressBar.setUpProgress(message)
        binding.layText.setExpandableText(message)
        binding.questions.setFaqOptions(message)
        binding.messageTime.setMessageTime(message)
    }

    fun recycle() {

    }

}