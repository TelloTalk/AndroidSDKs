package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.view.ContextMenu
import android.view.View
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.BroadcastTextMessageBubbleBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setBroadcastHeading
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setExpandableText
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setFaqOptions
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setHeadingArrow
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMessageTime


class BroadCastTextViewHolder(
    private val binding: BroadcastTextMessageBubbleBinding
) :
    BaseViewHolder(binding.root), View.OnCreateContextMenuListener {

    private var message: TTMessage? = null


    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
    }

    fun bind(message: TTMessage?, adapter: BaseMessageAdapter) {
        this.message = message
        binding.mainContainer.tag = this

        binding.layParent.setOnClickListener {
            adapter.onLinkClicked(message?.msgURL?:"")
        }
        binding.layHeading.setHeadingArrow(message)
        binding.newsHeading.setBroadcastHeading(message)
        binding.layText.setExpandableText(message)
        binding.questions.setFaqOptions(message)
        binding.messageTime.setMessageTime(message)
    }

    fun recycle() {

    }

}