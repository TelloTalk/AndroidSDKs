package com.tilismtech.tellotalksdk.ui.adapters.viewholders

import android.content.Context
import android.view.ContextMenu
import android.view.ContextMenu.ContextMenuInfo
import android.view.View
import android.view.View.OnCreateContextMenuListener
import androidx.core.content.res.ResourcesCompat
import androidx.viewbinding.ViewBinding
import com.facebook.drawee.generic.RoundingParams
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository.Companion.getInstance
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.TextMessageReceivedItemBinding
import com.tilismtech.tellotalksdk.databinding.TextMessageSentItemBinding
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppTextView
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isStringContainURL
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils.Companion.setMinWidthText

/**
 * Created by sohailahmed on 12/04/2017.
 */
class TextViewHolder(var binding: ViewBinding, private val mContext: Context) :
    BaseViewHolder(
        binding.root
    ), OnCreateContextMenuListener {
    var selectedMessages: HashMap<String?, TTMessage>? = null
    var message: TTMessage? = null
    fun bind(
        message: TTMessage?,
        adapter: BaseMessageAdapter?,
        repository: TTMessageRepository,
        position: Int,
        payloads: List<Any?>?
    ) {
        this.message = message
        val textReceivedBinding: TextMessageReceivedItemBinding
        val textSentBinding: TextMessageSentItemBinding
        if (!isEmptyString(message?.replyMsgId) && message?.replyMessage == null) {
            val replyMessage = repository.getReplyMessageFromUid(message?.replyMsgId)
            message?.replyMessage = replyMessage
        }
        message?.getLinkPreview(repository)
        if (binding is TextMessageReceivedItemBinding) {
            textReceivedBinding = binding as TextMessageReceivedItemBinding
            textReceivedBinding.mainContainer.tag = this
            textReceivedBinding.newsImage.hierarchy.roundingParams = RoundingParams().setRoundAsCircle(true)
            textReceivedBinding.newsImage.hierarchy.setPlaceholderImage(R.drawable.image_circle)
            val agentModel = getInstance()?.getAgent(message?.profileId)
            if (agentModel != null) {
                textReceivedBinding.newsImage.setImageURI(isStringContainURL(agentModel.agentAvatar).ifEmpty { message?.dptImage })
            }

            textReceivedBinding.messageBody.text = message?.message
        } else {
            textSentBinding = binding as TextMessageSentItemBinding
            textSentBinding.mainContainer.tag = this
            textSentBinding.messageBody.text = message?.message
            textSentBinding.messageBody.setMinWidthText(message)

        }

        if (message?.message != null && message.message?.isNotEmpty() == true) {
            if (!isEnglish(message.message)) {
                val whatsAppTextView = binding.root.findViewById<View>(R.id.message_body) as WhatsAppTextView
                val face = ResourcesCompat.getFont(mContext, R.font.calibri)
                whatsAppTextView.typeface = face
            } else {
                val face = ResourcesCompat.getFont(mContext, R.font.calibri);
                val whatsAppTextView = binding.root.findViewById<View>(R.id.message_body) as WhatsAppTextView
                whatsAppTextView.typeface = face
            }
        }
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenuInfo) {}
    fun recycle() {
        val textReceivedBinding: TextMessageReceivedItemBinding
        val textSentBinding: TextMessageSentItemBinding
        if (binding is TextMessageReceivedItemBinding) {
            textReceivedBinding = binding as TextMessageReceivedItemBinding
            textReceivedBinding.messageBody.text = ""
        } else {
            textSentBinding = binding as TextMessageSentItemBinding
            textSentBinding.messageBody.text = ""
        }
    }
}
