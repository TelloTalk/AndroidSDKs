package com.tilismtech.tellotalksdk.ui.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.tilismtech.tellotalksdk.data.db.entities.MediaAttachment;
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment.AttachVideoFragment;
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment.ImageEditorFragment;

import java.util.ArrayList;
import java.util.List;

public class AttachmentPagerAdapter extends FragmentStatePagerAdapter {
    private final int mNumOfTabs;
    private final List<Fragment> fragments = new ArrayList<>();

    public AttachmentPagerAdapter(FragmentManager fm, List<MediaAttachment> mediaAttachments) {
        super(fm);
        int index = 0;
        for (MediaAttachment mediaAttachment : mediaAttachments) {
            String mimeType = mediaAttachment.getMimeType();
            if (mimeType.contains("video")){
                AttachVideoFragment attachVideoFragment = AttachVideoFragment.getInstance(mediaAttachment);
                fragments.add(attachVideoFragment);
            } else {
                ImageEditorFragment imageEditorFragment=ImageEditorFragment.getInstance(mediaAttachment, index);
                fragments.add(imageEditorFragment);
            }
            index++;
        }
        this.mNumOfTabs = fragments.size();
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }

    public Fragment getFragmentAtPosition(int position) {
        return fragments.get(position);

    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }
}
