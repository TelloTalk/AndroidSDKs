package com.tilismtech.tellotalksdk.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.data.network.module.responses.FormFieldOptionResponse;

import java.util.ArrayList;

public class ChatFormDropDownAdapter extends BaseAdapter {

    private ArrayList<FormFieldOptionResponse> formFieldOptionResponses;
    private Context mContext;
    private LayoutInflater layoutInflater;

    public ChatFormDropDownAdapter(ArrayList<FormFieldOptionResponse>
                                           formFieldOptionResponses,
                                   Context mContext) {
        this.formFieldOptionResponses = formFieldOptionResponses;
        this.mContext = mContext;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return formFieldOptionResponses.size();
    }

    @Override
    public Object getItem(int position) {
        return formFieldOptionResponses.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = layoutInflater.inflate(R.layout.spin_text,null);
        TextView tv_dropdown = (TextView) view.findViewById(R.id.tv_dropdown);
        tv_dropdown.setText(formFieldOptionResponses.get(position).getFieldOptionValue());
        return view;
    }
}
