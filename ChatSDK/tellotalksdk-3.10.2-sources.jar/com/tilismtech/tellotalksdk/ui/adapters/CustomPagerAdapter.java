package com.tilismtech.tellotalksdk.ui.adapters;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class CustomPagerAdapter extends PagerAdapter {

    private ArrayList<View> views;

    public CustomPagerAdapter(ArrayList<View> views) {
        this.views = views;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull final ViewGroup collection, final int position) {
        collection.addView(views.get(position));
        return views.get(position);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup collection, int position, @NonNull Object view) {
        collection.removeView((View) view);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return "";
    }
}