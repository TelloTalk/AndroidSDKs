package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.view.ViewGroup
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.ui.activities.MessageInfoActivity
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils

/**
 * Created by sohail on 1/12/18.
 */
class MessageInfoAdapter(
    context: MessageInfoActivity,
    messages: ArrayList<TTMessage?>?,
    viewHolderUtils: ViewHolderUtils
) : BaseMessageAdapter(context, messages) {
    private val viewHolderUtils: ViewHolderUtils

    init {
        this.context = context
        this.viewHolderUtils = viewHolderUtils
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        return super.onCreateViewHolder(parent, viewType)
    }
}