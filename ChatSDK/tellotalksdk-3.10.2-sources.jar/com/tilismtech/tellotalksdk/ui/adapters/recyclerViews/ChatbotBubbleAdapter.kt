package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.ChatbotBubbleViewBinding
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.Constant

class ChatbotBubbleAdapter(private val activity: TelloActivity?, private val message: TTMessage?) :
    RecyclerView.Adapter<ChatbotBubbleAdapter.AnswersViewHolder>() {
    val gson = Gson()
    private val chatbotChildList: List<ChatbotChild> = gson.fromJson(message?.chatbotNode, ChatbotNode::class.java)?.children?: listOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnswersViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemBinding = ChatbotBubbleViewBinding.inflate(layoutInflater, parent, false)
        return AnswersViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: AnswersViewHolder, position: Int) {
        val chatbotChild = chatbotChildList[position]
        if (!ApplicationUtils.Companion.isEnglish(chatbotChild.name)) {
            val face = ResourcesCompat.getFont(holder.binding.root.context, R.font.calibri)
            holder.binding.optionsText.setTypeface(face)
        } else {
            val face = ResourcesCompat.getFont(holder.binding.root.context, R.font.calibri)
            holder.binding.optionsText.setTypeface(face)
        }
        holder.binding.optionsText.text = chatbotChild.name

        holder.binding.optionsText.setOnClickListener(View.OnClickListener {
            if(chatbotChildList.any{it.isSelected}){
                return@OnClickListener
            }

            val s1 = TelloPreferencesManager.getInstance().getString("chatid")
            if (message?.chatId != s1) {
                return@OnClickListener
            }
            if (s1 != "" && message.chatId == s1 /*&& !s2*/) {
                chatbotChild.isSelected = true
                if (chatbotChild.childType == "agent" || gson.fromJson(message.chatbotNode, ChatbotNode::class.java)?.type?.equals(
                        "agent",
                        ignoreCase = true
                    )==true
                ) {

                    TelloPreferencesManager.getInstance().putBoolean(Constant.Companion.isAgentMsg, true)
                    ConversationActivityViewModel.Companion.getInstance().updateMessage(message)
                }
                val msgChatbotNode = gson.fromJson(message.chatbotNode, ChatbotNode::class.java)
                msgChatbotNode.children[position] = chatbotChild
                message.chatbotNode = gson.toJson(msgChatbotNode)

                ChatManager.Companion.instance!!.sendMessageToChatbot(
                    message, chatbotChild
                ) { `object`: Boolean? ->
                    ConversationActivityViewModel.Companion.getInstance().updateMessage(message)
                    activity?.runOnUiThread {
                        notifyItemChanged(position)
                    }
                }
            }
        })
        if (chatbotChild.isSelected) {
            holder.binding.layVote.background = ContextCompat.getDrawable(
                holder.binding.root.context,
                R.drawable.rounded_selected_bg
            )
            holder.binding.optionsText.setTextColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.white
                )
            )
        } else {
            holder.binding.layVote.background = ContextCompat.getDrawable(
                holder.binding.root.context,
                R.drawable.rounded_progress_bg
            )
            holder.binding.optionsText.setTextColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.black87
                )
            )
            //  shapeDrawable.setColor(Color.parseColor("#f5f6f9"));
            //  shapeDrawable.setStroke(AndroidUtilities.dp(1), ContextCompat.getColor(activity, R.color.black12));
        }

    }

    override fun getItemCount(): Int {
        return chatbotChildList.size
    }

    class AnswersViewHolder(itemView: ChatbotBubbleViewBinding) :
        BaseViewHolder(itemView.root) {
            var binding: ChatbotBubbleViewBinding = itemView
    }
}