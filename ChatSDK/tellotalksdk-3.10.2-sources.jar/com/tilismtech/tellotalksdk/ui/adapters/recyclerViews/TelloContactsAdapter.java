package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.drawable.ScalingUtils;
import com.facebook.drawee.generic.RoundingParams;
import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.data.db.entities.Contact;
import com.tilismtech.tellotalksdk.data.network.NetworkConstants;
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.AllMemberHolder;
import com.tilismtech.tellotalksdk.utils.ApplicationUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sohail on 1/12/18.
 */

public class TelloContactsAdapter extends RecyclerView.Adapter<AllMemberHolder> {

    private static final int TYPE_LIGHT = 1, TYPE_DARK = 2;
    Context context;
    private ArrayList<Contact> allMembers = new ArrayList<>(), selectedMembers = new ArrayList<>();
    private ArrayList<String> existingContacts = new ArrayList<>();

    public TelloContactsAdapter(Context context, ArrayList<Contact> allMembers, ArrayList<Contact> selectedMembers, ArrayList<String> existingContacts){
        this.context = context;
        this.allMembers = allMembers;
        this.selectedMembers = selectedMembers;
        this.existingContacts = existingContacts;

        if(this.existingContacts == null){
            this.existingContacts = new ArrayList<>();
        }
    }

    @NonNull
    @Override
    public AllMemberHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.member_list_item, parent, false);
        return new AllMemberHolder(view);
    }

    @Override
    public int getItemViewType(int position) {
        if(position%2 == 0){
            return TYPE_DARK;
        }else{
            return TYPE_LIGHT;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final AllMemberHolder holder, final int position) {
        Contact ttContact = allMembers.get(position);
        holder.memberImage.setImageURI(NetworkConstants.BASE_URL1 + "/chatsdk" + ttContact.getAvatar());
//        holder.memberImage.getHierarchy().setPlaceholderImage(avatarRepository.getPlaceHolderImage(ttContact.getContactJid()));
        holder.memberImage.getHierarchy().setRoundingParams(new RoundingParams().setRoundAsCircle(true));
        holder.memberImage.getHierarchy().setActualImageScaleType(ScalingUtils.ScaleType.FIT_XY);
        String localPart = "+" + ttContact.getContactJid().split("@")[0];
        holder.memberName.setText(ApplicationUtils.isEmptyString(ttContact.getName()) ? localPart : ttContact.getName());
        holder.memberNumber.setText("+"+ttContact.getContactJid().split("@")[0]);
        if(selectedMembers.contains(ttContact) || existingContacts.contains(ttContact.getContactJid())){
            holder.memberSelected.setVisibility(View.VISIBLE);
        }else{
            holder.memberSelected.setVisibility(View.GONE);
        }
      //  holder.containerLayout.setOnClickListener(v -> ((SelectParticipantsActivity)context).addSelectedMemeber(allMembers.indexOf(ttContact))); //
    }

    @Override
    public void onBindViewHolder(@NonNull AllMemberHolder holder, int position, @NonNull List<Object> payloads) {
        onBindViewHolder(holder, position);
    }

    @Override
    public void onViewRecycled(@NonNull AllMemberHolder holder) {
        super.onViewRecycled(holder);
        holder.containerLayout.setOnClickListener(null);
        holder.recycle();
    }

    @Override
    public int getItemCount() {
        return allMembers.size();
    }
}