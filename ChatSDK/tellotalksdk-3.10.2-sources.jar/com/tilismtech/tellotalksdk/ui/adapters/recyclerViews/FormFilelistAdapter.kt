package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.facebook.drawee.generic.RoundingParams
import com.facebook.drawee.view.SimpleDraweeView
import com.tilismtech.tellotalksdk.databinding.FilenameListItemBinding
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder

class FormFilelistAdapter(imgList: ArrayList<String?>) :
    RecyclerView.Adapter<FormFilelistAdapter.AnswersViewHolder?>() {
    val list: ArrayList<String?> = imgList

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnswersViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemBinding = FilenameListItemBinding.inflate(layoutInflater, parent, false)
        return AnswersViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: AnswersViewHolder, position: Int) {
        val choice = list[holder.bindingAdapterPosition]

        val roundingParams = RoundingParams.fromCornersRadius(50f)
        holder.im_attach.hierarchy.setRoundingParams(roundingParams)
        holder.im_attach.setImageURI(choice)

        holder.selected_icon.setOnClickListener {
            list.removeAt(holder.bindingAdapterPosition)
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    class AnswersViewHolder(itemView: FilenameListItemBinding) :
        BaseViewHolder(
            itemView.getRoot()
        ) {
        val im_attach: SimpleDraweeView = itemView.imAttach
        val selected_icon: ImageView = itemView.selectedIcon
    }

    fun addItem(imgURL: String?) {
        list.clear()
        list.add(imgURL)
        notifyDataSetChanged()
    }
}
