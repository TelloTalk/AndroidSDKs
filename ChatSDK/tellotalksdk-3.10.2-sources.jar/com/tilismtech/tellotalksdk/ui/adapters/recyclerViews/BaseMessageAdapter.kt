package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode.BotType
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.ui.activities.ImageViewerActivity
import com.tilismtech.tellotalksdk.ui.activities.WebUrlActivity
import com.tilismtech.tellotalksdk.ui.adapters.ViewsFactory
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.DownloadableFile
import com.tilismtech.tellotalksdk.utils.FileBackend
import com.tilismtech.tellotalksdk.utils.GeoHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Created by sohail on 1/12/18.
 */
abstract class BaseMessageAdapter(
    protected open var context: Context,
    messages: ArrayList<TTMessage?>?
) : RecyclerView.Adapter<BaseViewHolder>() {
    private var lastPosition = -1
    var gson = Gson()
    var messages: ArrayList<TTMessage?>? = ArrayList()
        protected set
    private val messageRepository: TTMessageRepository?
    var adapter: BaseMessageAdapter? = null

    init {
        this.messages = messages
        messageRepository = TTMessageRepository.instance
    }

    override fun getItemViewType(position: Int): Int {
        val message = messages?.getOrNull(position)
        return ViewsFactory.Companion.instance.getItemViewType(message)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ViewsFactory.Companion.instance.getView(viewType, layoutInflater, parent, context)
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        val pos = holder.bindingAdapterPosition
        ViewsFactory.Companion.instance.onBindViewHolder(
            holder.apply {
                bindCommon(messages?.getOrNull(pos))
            }, messages?.getOrNull(pos), this@BaseMessageAdapter, messageRepository, pos
        )
    }

    override fun onViewRecycled(holder: BaseViewHolder) {
        super.onViewRecycled(holder)
        ViewsFactory.Companion.instance.onViewRecycled(holder)
    }

    override fun getItemCount(): Int {
        return messages?.size?:0
    }

    fun getItem(position: Int): TTMessage? {

        val msg = messages?.get(position)
        if (position + 1 < (messages?.size?:0) && gson.fromJson(msg?.chatbotNode, ChatbotNode::class.java)?.type == BotType.TYPE_OPTIONCHILD.name) {
            val replyMsg = messages?.get(position + 1)
            var chatbotNodeChildren = gson.fromJson(msg?.chatbotNode, ChatbotNode::class.java)?.children
            val nodeChildren = chatbotNodeChildren
            nodeChildren?.forEach {
                if (replyMsg?.message == it?.name) {
                    it?.isSelected = true
                    gson.fromJson(msg?.chatbotNode, ChatbotNode::class.java)?.children = nodeChildren
                    return@forEach
                }
            }
        }
        return msg
    }

    open fun showLocation(message: TTMessage?) {
        for (intent in GeoHelper.createGeoIntentsFromMessage(message, "")) {
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                return
            }
        }
        Toast.makeText(context, "No application found to display location", Toast.LENGTH_SHORT)
            .show()
    }

    open fun openDownloadable(message: TTMessage?) {
        if (message?.msgType == TTMessage.MsgType.TYPE_LOCATION.value) {
            showLocation(message)
            return
        }
        if (message?.msgStatus == TTMessage.MsgStatus.RECEIVED && ((message.dptType=="2" && message.transmissionCancelled) || !message.isDownloaded)) {
            return
        }


        var file: DownloadableFile? = null
        CoroutineScope(Dispatchers.IO).launch {
            file = FileBackend.instance?.getFile(message)

            if (file?.exists() == false) {
                if (message?.msgStatus == TTMessage.MsgStatus.SENT || message?.msgStatus == TTMessage.MsgStatus.READ) {
                    val uri = Uri.parse(message.message)
                    if (message.msgType == TTMessage.MsgType.TYPE_IMAGE.value) {
                        openImagePreview(uri)
                    } else if (message.msgType == TTMessage.MsgType.TYPE_FILE.value || message.msgType == TTMessage.MsgType.TYPE_VIDEO.value) {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW)
                            intent.setData(uri)
                            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            if (openIntent(intent)) return@launch
                        } catch (e: SecurityException) {
                            launch(Dispatchers.Main){
                                Toast.makeText(
                                    context, context.getString(
                                        R.string.no_permission_to_access_x, file?.absolutePath
                                    ), Toast.LENGTH_SHORT
                                ).show()
                            }
                            return@launch
                        }
                    }
                }
            } else {
                var mime = file?.mimeType
                if (isEmptyString(mime)) {
                    mime = "*/*"
                }
                if (mime?.contains("image") == true) {
                    val uri = Uri.fromFile(file)
                    openImagePreview(uri)
                    return@launch
                }
                try {
                    val apkUri = FileBackend.getUriForFile(context, file)
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(apkUri)
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    if (openIntent(intent)) return@launch
                } catch (e: SecurityException) {
                    launch(Dispatchers.Main){
                        Toast.makeText(
                            context, context.getString(
                                R.string.no_permission_to_access_x, file?.absolutePath
                            ), Toast.LENGTH_SHORT
                        ).show()
                    }
                    return@launch
                }
                launch(Dispatchers.Main){
                    Toast.makeText(
                        context, R.string.no_application_found_to_open_file, Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun openImagePreview(uri: Uri) {
        val intent = Intent(context, ImageViewerActivity::class.java)
        //   Uri uri = Uri.parse(file);
        intent.putExtra("imageUrl", uri.toString())
        CoroutineScope(Dispatchers.Main).launch {
            context.startActivity(intent)
        }
    }

    private fun openIntent(intent: Intent): Boolean {
        try {
            CoroutineScope(Dispatchers.Main).launch {
                context.startActivity(intent)
            }
            return true
        } catch (e: ActivityNotFoundException) {
            e.message
        }
        return false
    }

    fun onLinkClicked(finalUrl: String) {
        var finalUrl = finalUrl
        if (isEmptyString(finalUrl)) {
            return
        }
        if (!finalUrl.startsWith("http") && !finalUrl.startsWith("https")) {
            finalUrl = "http://$finalUrl"
        }
        try {
            if (finalUrl.contains("youtube") || finalUrl.contains("youtu.be")) {
                val intent = Intent(context, WebUrlActivity::class.java)
                intent.putExtra("url", finalUrl)
                context.startActivity(intent)
            } else {
                val builder = CustomTabsIntent.Builder()
                val customTabsIntent = builder.build()
                customTabsIntent.launchUrl(context, Uri.parse(finalUrl))
            }
        } catch (e: ActivityNotFoundException) {
            val intent = Intent(context, WebUrlActivity::class.java)
            intent.putExtra("url", finalUrl)
            context.startActivity(intent)
            e.message
        }
    }
    open fun addContactIntoAddressBook(vCard: String?) {}
    fun sendMessageToContact(vCard: String?) {}
    open fun scrollToReplyMessage(message: TTMessage?) {}

    companion object {
        private const val FADE_DURATION = 1000 //FADE_DURATION in milliseconds
    }
}