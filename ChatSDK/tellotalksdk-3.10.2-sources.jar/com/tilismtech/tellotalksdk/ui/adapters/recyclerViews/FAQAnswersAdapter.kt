package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ButtonDet
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.databinding.AnswerListItemBinding
import com.tilismtech.tellotalksdk.managers.ChatManager.Companion.instance
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.utils.AndroidUtilities
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.openChromeTab
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.openURLActivity
import java.io.Serializable

class FAQAnswersAdapter(private val activity: TelloActivity?, private val message: TTMessage?) :
    RecyclerView.Adapter<FAQAnswersAdapter.AnswersViewHolder>() {
    private val choices: List<ButtonDet>?
    private val gson = Gson()


    init {
        choices = gson.fromJson(message?.button_det, object : TypeToken<List<ButtonDet>?>(){})
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnswersViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemBinding = AnswerListItemBinding.inflate(layoutInflater, parent, false)
        return AnswersViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: AnswersViewHolder, position: Int) {
        val choice = choices?.get(position)
        if (!isEnglish(choice?.bLabel)) {
            val face = ResourcesCompat.getFont(holder.binding.root.context, R.font.calibri)
            holder.binding.optionsText.setTypeface(face)
        } else {
            val face = ResourcesCompat.getFont(holder.binding.root.context, R.font.calibri)
            holder.binding.optionsText.setTypeface(face)
        }
        holder.binding.optionsText.text = choice?.bLabel?.trim { it <= ' ' }
        //      if (!faqChoices.isSelected()) {
        //   holder.itemView.selectedIcon.setVisibility(View.GONE);
        holder.binding.optionsText.setOnClickListener(View.OnClickListener {
            instance!!.onAnnouncementClicked(
                message?.messageId,
                message?.departmentName,
                message?.msgType,
                message?.campaignId
            )
            choice?.isSelected = true
            if (choice?.bType == "LBC") {
                sendMessage(choice)
            } else if (choice?.bType == "URL") {
                var finalUrl = choice.bValue
                if (isEmptyString(finalUrl)) {
                    return@OnClickListener
                }
                if (finalUrl?.startsWith("http")==false && !finalUrl.startsWith("https")) {
                    finalUrl = "http://$finalUrl"
                }
                try {
                    if (finalUrl?.contains("youtube")==true || finalUrl?.contains("youtu.be")==true) {
                        openURLActivity(activity, finalUrl)
                    } else {
                        openChromeTab(activity, finalUrl)
                    }
                } catch (e: ActivityNotFoundException) {
                    openURLActivity(activity, finalUrl)
                    e.message
                }
            } else if (choice?.bType == "LBK") {
                sendMessageWithHashmap(choice)
            }
            notifyDataSetChanged()
        })

        val shapeDrawable = holder.binding.optionsText.background as GradientDrawable
        if (choice?.isSelected == true) {
            holder.binding.optionsText.setTextColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.white
                )
            )
            holder.binding.selectedIcon.visibility = View.VISIBLE
            shapeDrawable.setColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.selected_text_color_newswb
                )
            )
            shapeDrawable.setStroke(
                AndroidUtilities.dp(1f),
                ContextCompat.getColor(holder.binding.root.context, R.color.selected_text_color_newswb)
            )
        } else {
            holder.binding.optionsText.setTextColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.black87
                )
            )
            holder.binding.selectedIcon.visibility = View.GONE
            shapeDrawable.setColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.unselected_text_color_newswb
                )
            )
            shapeDrawable.setStroke(
                AndroidUtilities.dp(1f),
                ContextCompat.getColor(holder.binding.root.context, R.color.unselected_text_color_newswb)
            )
        }

    }


    private fun sendMessage(choice: ButtonDet) {
        Log.d("sender", "Broadcasting message")
        val intent = Intent("custom-event-name")
        // You can also include some extra data.
        intent.putExtra("message", choice.bValue)
        activity?.sendBroadcast(intent)
    }

    private fun sendMessageWithHashmap(choice: ButtonDet) {
        Log.d("sender", "Broadcasting message")
        val intent = Intent("custom-event-name")

        val stringStringHashMap = HashMap<String, String>()
        if (choice.keyValueModels != null) {
            if (choice.keyValueModels.isNotEmpty()) {
                for (keyValueModel in choice.keyValueModels) {
                    stringStringHashMap[keyValueModel.key] = keyValueModel.value
                }
            }
        }

        // You can also include some extra data.
        intent.putExtra("key_value_map", stringStringHashMap as Serializable)
        activity?.sendBroadcast(intent)
    }

    override fun getItemCount(): Int {
        return choices?.size?:0
    }

    inner class AnswersViewHolder(itemView: AnswerListItemBinding) :
        BaseViewHolder(itemView.root) {
            var binding: AnswerListItemBinding = itemView
    }
}