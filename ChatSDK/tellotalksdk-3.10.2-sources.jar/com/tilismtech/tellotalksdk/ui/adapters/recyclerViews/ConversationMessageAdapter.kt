package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.view.ViewGroup
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.ui.activities.ConversationActivity
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.utils.ViewHolderUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Created by sohail on 1/12/18.
 */
class ConversationMessageAdapter(val activity: ConversationActivity, messages: ArrayList<TTMessage?>?, private val replyViewHolderUtils: ViewHolderUtils) : BaseMessageAdapter(activity, messages) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        return super.onCreateViewHolder(parent, viewType)
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        super.onBindViewHolder(holder, position)
    }

    override fun showLocation(message: TTMessage?) {
        if (activity.actionMode != null) {
            return
        }
        super.showLocation(message)
    }

    override fun openDownloadable(message: TTMessage?) {
        if (activity.actionMode != null) {
            return
        }
        super.openDownloadable(message)
    }

    override fun scrollToReplyMessage(message: TTMessage?) {
        if (activity.actionMode != null) {
            return
        }
        val position = messages?.indexOf(message)?:messages?.lastIndex?:0
        try {
            activity.messagesView.smoothScrollToPosition(position)
            replyViewHolderUtils.selectedMessages?.set(message!!.messageId, message)
            CoroutineScope(Dispatchers.Main).launch {
                delay(500)
                replyViewHolderUtils.selectedMessages?.remove(message?.messageId)
                notifyItemChanged(position)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun addContactIntoAddressBook(vCard: String?) {
//        if (context.getActionMode() != null) {
//            return;
//        }
//        String displayName;
//        VCard first = Ezvcard.parse(vCard).first();
//        if (first != null && first.getFormattedName() != null) {
//            displayName = first.getFormattedName().getValue();
//            ArrayList<String> phonenumbers = new ArrayList<>();
//            for (Telephone telephone : first.getTelephoneNumbers()) {
//                phonenumbers.add(telephone.getText());
//            }
//            ArrayList<String> emails = new ArrayList<>();
//            for (Email email : first.getEmails()) {
//                emails.add(email.getValue());
//            }
//            new AlertDialog.Builder(context)
//                    .setMessage("Create new contact or edit existing contact?")
//                    .setPositiveButton("Edit", (dialog, which) -> {
//                        final Intent intent = new Intent(Intent.ACTION_INSERT_OR_EDIT);
//                        intent.putExtra(ContactsContract.Intents.Insert.PHONE, phonenumbers.get(0));
//                        if (phonenumbers.size() > 1) {
//                            intent.putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, phonenumbers.get(1));
//                        }
//                        if (emails.size() > 0) {
//                            intent.putExtra(ContactsContract.Intents.Insert.EMAIL, emails.get(0));
//                        }
//                        intent.setType(Contacts.People.CONTENT_ITEM_TYPE);
//                        context.startActivity(intent);
//                    })
//                    .setNegativeButton("ADD", (dialog, which) -> {
//                        Intent intent = new Intent(Intent.ACTION_INSERT);
//                        intent.setType(ContactsContract.Contacts.CONTENT_TYPE);
//                        intent.putExtra(ContactsContract.Intents.Insert.NAME, displayName);
//                        intent.putExtra(ContactsContract.Intents.Insert.PHONE, phonenumbers.get(0));
//                        if (phonenumbers.size() > 1) {
//                            intent.putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, phonenumbers.get(1));
//                        }
//                        if (emails.size() > 0) {
//                            intent.putExtra(ContactsContract.Intents.Insert.EMAIL, emails.get(0));
//                        }
//                        int PICK_CONTACT = 100;
//                        context.startActivityForResult(intent, PICK_CONTACT);
//                    })
//                    .setIcon(android.R.drawable.ic_dialog_alert)
//                    .show();
//        }
    }
}