package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations
import com.tilismtech.tellotalksdk.databinding.DepartmentlistViewBinding
import com.tilismtech.tellotalksdk.managers.ChatManager.Companion.instance
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.DptListAdapter.DepartmentViewHolder
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder

class DptListAdapter(
    private val mContext: Activity,
    private val departments: ArrayList<DepartmentConversations?>?,
    @JvmField var message: String?,
    private val custom_data: String?
) : RecyclerView.Adapter<DepartmentViewHolder?>() {
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): DepartmentViewHolder {
        val layoutInflater = LayoutInflater.from(viewGroup.getContext())
        val itemBinding = DepartmentlistViewBinding.inflate(layoutInflater, viewGroup, false)
        return DepartmentViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: DepartmentViewHolder, position: Int) {
        val pos = holder.bindingAdapterPosition
        holder.binding.tvDptName.text = departments?.get(pos)!!.getDepartment().dptName
        holder.binding.conversationImage.setImageURI(
            departments[pos]!!.getDepartment().dptImage
        )
        if (departments[pos]!!.getConversation() != null) {
            val conversation = departments[pos]!!.getConversation()

            if (conversation.unreadCount == 0) {
                holder.binding.msgsUnreadCount.visibility = View.INVISIBLE
            } else {
                holder.binding.msgsUnreadCount.visibility = View.VISIBLE
                holder.binding.msgsUnreadCount.text = "" + conversation.getUnreadCount()
            }
            //            String formatedTime = UIHelper.readableTimeDifferenceFull(mContext,
//                    conversation.getLastMessage() != null ? conversation.getLastMessage().getMsgDate().getTime() : System.currentTimeMillis());
//            if (conversation.getLastMessage() == null) {
//                TTMessage message = TTMessageRepository.instance?.getLastMessageOfConversation(conversation.getContactJid());
//                if (message != null) {
//                    formatedTime = UIHelper.readableTimeDifferenceFull(mContext,
//                            message != null ? message.getMsgDate().getTime() : System.currentTimeMillis());
//                    holder.binding.tvChatAccTime.setText(formatedTime);
//                    holder.binding.tvChatAccTime.setVisibility(View.VISIBLE);
//                } else {
//                    holder.binding.tvChatAccTime.setText(formatedTime);
//                    holder.binding.tvChatAccTime.setVisibility(View.INVISIBLE);
//                }
//
//            } else {
//                holder.binding.tvChatAccTime.setText(formatedTime);
//                holder.binding.tvChatAccTime.setVisibility(View.VISIBLE);
//            }
        }
        holder.itemView.setOnClickListener {
            val department = departments[pos]!!.getDepartment()

            if (department.dptType == "2") {
                //    ChatManager.getInstance().getChatId((Activity) mContext, department, message, true, custom_data);
                instance!!.openConversationActivity(
                    mContext,
                    "",
                    department.dptName,
                    department.getDptId(),
                    department.getDptType(),
                    false,
                    message,
                    true,
                    custom_data,
                    department.getDptImage(),
                    department.getName_u()
                )
            } else {
                instance!!.openConversationActivity(
                    mContext,
                    "",
                    department.getDptName(),
                    department.getDptId(),
                    department.getDptType(),
                    false,
                    message,
                    false,
                    custom_data,
                    department.getDptImage(),
                    department.getName_u()
                )
            }
            // setMessage(null);
        }
    }

    override fun getItemCount(): Int {
        return departments?.size?:0
    }

    inner class DepartmentViewHolder(val binding: DepartmentlistViewBinding) :
        BaseViewHolder(
            binding.getRoot()
        )
}
