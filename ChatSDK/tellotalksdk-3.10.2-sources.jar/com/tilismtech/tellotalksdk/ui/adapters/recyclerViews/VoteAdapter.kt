package com.tilismtech.tellotalksdk.ui.adapters.recyclerViews

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.db.entities.VoteData
import com.tilismtech.tellotalksdk.databinding.ChatbotBubbleViewBinding
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.utils.ApplicationUtils

class VoteAdapter(
    val message: TTMessage?,
    private val alreadySelected: Boolean
) :
    RecyclerView.Adapter<VoteAdapter.AnswersViewHolder>() {
    private val choices: ArrayList<VoteData>
    private val gson = Gson()
    var chatbotNode: ChatbotNode? = null


    init {
        choices = gson.fromJson(message?.chatbotNode,
            ChatbotNode::class.java).voteData as ArrayList<VoteData>
        chatbotNode = gson.fromJson(message?.chatbotNode, ChatbotNode::class.java)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnswersViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemBinding = ChatbotBubbleViewBinding.inflate(layoutInflater, parent, false)
        return AnswersViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: AnswersViewHolder, position: Int) {
        val choice = choices[position]
        if (!ApplicationUtils.Companion.isEnglish(choice.voteName)) {
            val face = ResourcesCompat.getFont(holder.binding.root.context, R.font.calibri)
            holder.binding.optionsText.setTypeface(face)
        } else {
            val face = ResourcesCompat.getFont(holder.binding.root.context, R.font.calibri)
            holder.binding.optionsText.setTypeface(face)
        }
        holder.binding.optionsText.text = choice.voteName.trim { it <= ' ' }

        //  if(isEnable){
        holder.binding.optionsText.isEnabled = !alreadySelected


        //   }else{
        //      holder.itemView.optionsText.setEnabled(true);
        //  }
        holder.binding.optionsText.setOnClickListener(View.OnClickListener {
            for (voteData in choices) {
                voteData.voteChecked = "false"
            }
            choice.voteChecked = "true"
            choices[position] = choice
            chatbotNode?.voteData = choices
            message?.chatbotNode = gson.toJson(chatbotNode)
            notifyDataSetChanged()
        })
        //  GradientDrawable shapeDrawable = (GradientDrawable) holder.itemView.layVote.getBackground();
        if (choice.voteChecked == "true") {
            holder.binding.layVote.background = ContextCompat.getDrawable(
                holder.binding.root.context,
                R.drawable.rounded_selected_bg
            )
            holder.binding.optionsText.setTextColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.white
                )
            )
        } else {
            holder.binding.layVote.background = ContextCompat.getDrawable(
                holder.binding.root.context,
                R.drawable.rounded_progress_bg
            )
            holder.binding.optionsText.setTextColor(
                ContextCompat.getColor(
                    holder.binding.root.context,
                    R.color.black87
                )
            )
            //  shapeDrawable.setColor(Color.parseColor("#f5f6f9"));
            //  shapeDrawable.setStroke(AndroidUtilities.dp(1), ContextCompat.getColor(activity, R.color.black12));
        }

    }

    override fun getItemCount(): Int {
        return choices.size
    }

    inner class AnswersViewHolder(itemView: ChatbotBubbleViewBinding) : BaseViewHolder(itemView.root) {
            val binding: ChatbotBubbleViewBinding = itemView
    }
}