package com.tilismtech.tellotalksdk.ui.linkpreview;

public interface LinkPreviewCallback {

	void onPre();
	void onPos(SourceContent sourceContent, boolean isNull);
}
