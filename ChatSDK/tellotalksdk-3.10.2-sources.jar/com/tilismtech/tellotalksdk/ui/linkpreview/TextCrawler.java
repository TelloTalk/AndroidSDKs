package com.tilismtech.tellotalksdk.ui.linkpreview;

import android.os.AsyncTask;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TextCrawler {

    private static final int ALL = -1;
    public static final int NONE = -2;
    private final String HTTP_PROTOCOL = "http://";
    private final String HTTPS_PROTOCOL = "https://";
    private LinkPreviewCallback callback;
    private AsyncTask getCodeTask;

    public TextCrawler() {
    }

    public void makePreview(LinkPreviewCallback callback, String url) {
        makePreview(callback, url, ALL);
    }

    private void makePreview(LinkPreviewCallback callback, String url, int imageQuantity) {
        this.callback = callback;
        cancel();
        getCodeTask = createPreviewGenerator(imageQuantity).execute(url);
    }

    private GetCode createPreviewGenerator(int imageQuantity) {
        return new GetCode(imageQuantity);
    }

    public void cancel() {
        if (getCodeTask != null) {
            getCodeTask.cancel(true);
        }
    }

    public class GetCode extends AsyncTask<String, Void, Void> {

        private SourceContent sourceContent = new SourceContent();
        private int imageQuantity;
        private ArrayList<String> urls;

        GetCode(int imageQuantity) {
            this.imageQuantity = imageQuantity;
        }

        @Override
        protected void onPreExecute() {
            if (callback != null) {
                callback.onPre();
            }
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void result) {
            if (callback != null) {
                sourceContent.setHtmlCode("");
                callback.onPos(sourceContent, isNull());
            }
            super.onPostExecute(result);
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override
        protected Void doInBackground(String... params) {
            // Don't forget the http:// or https://
            urls = SearchUrls.matches(params[0]);
            if (urls.size() == 0) {
                sourceContent.setFinalUrl("");
            }
            for (String url : urls) {
                String finalUrl = unshortenUrl(extendedTrim(url));
                if (finalUrl == null) {
                    sourceContent.setSuccess(false);
                    continue;
                }
                sourceContent.setFinalUrl(finalUrl);
                if (!sourceContent.getFinalUrl().equals("")) {
                    if (isImage(sourceContent.getFinalUrl()) && !sourceContent.getFinalUrl().contains("dropbox")) {
                        sourceContent.setSuccess(true);
                        sourceContent.getImages().add(sourceContent.getFinalUrl());
                        sourceContent.setTitle("");
                        sourceContent.setDescription("");
                    } else {
                        try {
                            Document doc = getDocument();
                            sourceContent.setHtmlCode(extendedTrim(doc.toString()));
                            HashMap<String, String> metaTags = getMetaTags(sourceContent.getHtmlCode());
                            sourceContent.setMetaTags(metaTags);
                            sourceContent.setTitle(metaTags.get("title"));
                            sourceContent.setDescription(metaTags.get("description"));
                            if (sourceContent.getTitle().equals("")) {
                                String matchTitle = Regex.pregMatch(sourceContent.getHtmlCode(), Regex.TITLE_PATTERN, 2);
                                if (!matchTitle.equals(""))
                                    sourceContent.setTitle(htmlDecode(matchTitle));
                            }
                            if (sourceContent.getDescription().equals(""))
                                sourceContent.setDescription(crawlCode(sourceContent.getHtmlCode()));
                            sourceContent.setDescription(sourceContent.getDescription().replaceAll(Regex.SCRIPT_PATTERN, ""));
                            if (imageQuantity != NONE) {
                                if (!metaTags.get("image").equals(""))
                                    sourceContent.getImages().add(metaTags.get("image"));
                                else {
                                    sourceContent.setImages(getImages(doc));
                                }
                            }
                            sourceContent.setSuccess(true);
                            break;
                        } catch (Throwable t) {
                            sourceContent.setSuccess(false);
                        }
                    }
                }
            }
            String[] finalLinkSet = sourceContent.getFinalUrl().split("&");
            sourceContent.setUrl(finalLinkSet[0]);
            sourceContent.setCannonicalUrl(cannonicalPage(sourceContent.getFinalUrl()));
            sourceContent.setDescription(stripTags(sourceContent.getDescription()));
            return null;
        }

        Document getDocument() throws IOException {
            return Jsoup.connect(sourceContent.getFinalUrl()).timeout(30000).userAgent("Chrome").get();
        }

        public boolean isNull() {
            return !sourceContent.isSuccess() && extendedTrim(sourceContent.getHtmlCode()).equals("") && !isImage(sourceContent.getFinalUrl());
        }
    }

    private String getTagContent(String tag, String content) {
        String pattern = "<" + tag + "(.*?)>(.*?)</" + tag + ">";
        String result = "", currentMatch = "";
        List<String> matches = Regex.pregMatchAll(content, pattern, 2);
        int matchesSize = matches.size();
        for (int i = 0; i < matchesSize; i++) {
            if (getCodeTask.isCancelled()) {
                break;
            }
            currentMatch = stripTags(matches.get(i));
            if (currentMatch.length() >= 120) {
                result = extendedTrim(currentMatch);
                break;
            }
        }
        if (result.equals("")) {
            String matchFinal = Regex.pregMatch(content, pattern, 2);
            result = extendedTrim(matchFinal);
        }
        result = result.replaceAll("&nbsp;", "");
        return htmlDecode(result);
    }

    private List<String> getImages(Document document) {
        List<String> matches = new ArrayList<String>();
        Elements media = document.select("[src]");
        for (Element srcElement : media) {
            if (getCodeTask.isCancelled()) {
                break;
            }
            if (srcElement.tagName().equals("img")) {
                matches.add(srcElement.attr("abs:src"));
            }
        }
        if(matches.size()>0){
            matches = matches.subList(0, 1);
        }
        return matches;
    }

    private String htmlDecode(String content) {
        return Jsoup.parse(content).text();
    }

    private String crawlCode(String content) {
        String result = "";
        String resultSpan = "";
        String resultParagraph = "";
        String resultDiv = "";
        resultSpan = getTagContent("span", content);
        resultParagraph = getTagContent("p", content);
        resultDiv = getTagContent("div", content);
        result = resultSpan;
        if (resultParagraph.length() > resultSpan.length() && resultParagraph.length() >= resultDiv.length())
            result = resultParagraph;
        else if (resultParagraph.length() > resultSpan.length() && resultParagraph.length() < resultDiv.length())
            result = resultDiv;
        else
            result = resultParagraph;
        return htmlDecode(result);
    }

    private String cannonicalPage(String url) {
        String cannonical = "";
        if (url.startsWith(HTTP_PROTOCOL)) {
            url = url.substring(HTTP_PROTOCOL.length());
        } else if (url.startsWith(HTTPS_PROTOCOL)) {
            url = url.substring(HTTPS_PROTOCOL.length());
        }
        int urlLength = url.length();
        for (int i = 0; i < urlLength; i++) {
            if (getCodeTask.isCancelled()) {
                break;
            }
            if (url.charAt(i) != '/')
                cannonical += url.charAt(i);
            else
                break;
        }
        return cannonical;
    }

    private String stripTags(String content) {
        return Jsoup.parse(content).text();
    }

    private boolean isImage(String url) {
        return url.matches(Regex.IMAGE_PATTERN);
    }

    private HashMap<String, String> getMetaTags(String content) {
        HashMap<String, String> metaTags = new HashMap<String, String>();
        metaTags.put("url", "");
        metaTags.put("title", "");
        metaTags.put("description", "");
        metaTags.put("image", "");
        List<String> matches = Regex.pregMatchAll(content, Regex.METATAG_PATTERN, 1);
        for (String match : matches) {
            if (getCodeTask.isCancelled()) {
                break;
            }
            final String lowerCase = match.toLowerCase();
            if (lowerCase.contains("property=\"og:url\"") || lowerCase.contains("property='og:url'")
                    || lowerCase.contains("name=\"url\"") || lowerCase.contains("name='url'"))
                updateMetaTag(metaTags, "url", separeMetaTagsContent(match));
            else if (lowerCase.contains("property=\"og:title\"") || lowerCase.contains("property='og:title'")
                    || lowerCase.contains("name=\"title\"") || lowerCase.contains("name='title'"))
                updateMetaTag(metaTags, "title", separeMetaTagsContent(match));
            else if (lowerCase.contains("property=\"og:description\"") || lowerCase.contains("property='og:description'")
                    || lowerCase.contains("name=\"description\"") || lowerCase.contains("name='description'"))
                updateMetaTag(metaTags, "description", separeMetaTagsContent(match));
            else if (lowerCase.contains("property=\"og:image\"") || lowerCase.contains("property='og:image'")
                    || lowerCase.contains("name=\"image\"") || lowerCase.contains("name='image'"))
                updateMetaTag(metaTags, "image", separeMetaTagsContent(match));
        }
        return metaTags;
    }

    private void updateMetaTag(HashMap<String, String> metaTags, String url, String value) {
        if (value != null && (value.length() > 0)) {
            metaTags.put(url, value);
        }
    }

    private String separeMetaTagsContent(String content) {
        String result = Regex.pregMatch(content, Regex.METATAG_CONTENT_PATTERN,
                1);
        return htmlDecode(result);
    }

    private String unshortenUrl(String shortURL) {
        if (!shortURL.startsWith(HTTP_PROTOCOL)
                && !shortURL.startsWith(HTTPS_PROTOCOL))
            return "";
        String finalResult = null;
        try {
            URLConnection urlConn = connectURL(shortURL);
            urlConn.getHeaderFields();
            finalResult = urlConn.getURL().toString();
            urlConn = connectURL(finalResult);
            urlConn.getHeaderFields();
            shortURL = urlConn.getURL().toString();
            while (!shortURL.equals(finalResult)) {
                finalResult = unshortenUrl(finalResult);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalResult;
    }

    private URLConnection connectURL(String strURL) {
        URLConnection conn = null;
        try {
            URL inputURL = new URL(strURL);
            conn = inputURL.openConnection();
        } catch (MalformedURLException e) {
            System.out.println("Please input a valid URL");
        } catch (IOException ioe) {
            System.out.println("Can not connect to the URL");
        }
        return conn;
    }

    static String extendedTrim(String content) {
        return content.replaceAll("\\s+", " ").replace("\n", " ")
                .replace("\r", " ").trim();
    }
}