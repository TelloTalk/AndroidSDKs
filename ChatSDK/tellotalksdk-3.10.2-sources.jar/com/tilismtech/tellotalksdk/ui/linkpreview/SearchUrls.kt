package com.tilismtech.tellotalksdk.ui.linkpreview

import android.util.Patterns
import java.net.URL

internal object SearchUrls {
    @JvmStatic
    fun matches(text: String?): ArrayList<String> {
        val urls = ArrayList<String>()
        val splitString = (text?.split(" ".toRegex())?.dropLastWhile { it.isEmpty() }?.toTypedArray())
        for (string in splitString?: arrayOf()) {
            var string = string
            var string1 = ""
            try {
                if (!string.startsWith("http") && !string.startsWith("Http")) {
                    string1 = "https://$string"
                    string = "http://$string"
                }
                var item = URL(string)
                if (Patterns.WEB_URL.matcher(item.toString()).matches()) {
                    urls.add(item.toString())
                }
                item = URL(string1)
                if (Patterns.WEB_URL.matcher(item.toString()).matches()) {
                    urls.add(item.toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (urls.size > 0) break
        }
        return urls
    }
}
