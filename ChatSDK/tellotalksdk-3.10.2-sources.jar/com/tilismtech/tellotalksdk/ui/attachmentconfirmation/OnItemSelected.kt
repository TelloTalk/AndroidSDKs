package com.tilismtech.tellotalksdk.ui.attachmentconfirmation

import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.ToolType

interface OnItemSelected {
        fun onToolSelected(toolType: ToolType?, showView: Boolean)
    }