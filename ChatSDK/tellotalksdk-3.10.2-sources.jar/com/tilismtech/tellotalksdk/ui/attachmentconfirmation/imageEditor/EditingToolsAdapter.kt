package com.tilismtech.tellotalksdk.ui.attachmentconfirmation.imageEditor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.databinding.RowEditingToolsBinding
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.ToolType
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.OnItemSelected

private class EditingToolsAdapter(
    private val mOnItemSelected: OnItemSelected,
    isDeleteIconVisible: Boolean
) : RecyclerView.Adapter<EditingToolsAdapter.ToolsViewHolder?>() {
    private val mToolList: MutableList<ToolModel> = ArrayList<ToolModel>()
    private lateinit var view: RowEditingToolsBinding
    private val isSelected = false
    private var row_index = -1

    init {
        mToolList.add(ToolModel("Brush", R.drawable.brush_icon_editor_sdk, ToolType.BRUSH))
        mToolList.add(ToolModel("Eraser", R.drawable.eraser_icon_editor_sdk, ToolType.ERASER))
        mToolList.add(ToolModel("Text", R.drawable.edit_icon_editor_sdk, ToolType.TEXT))
        mToolList.add(ToolModel("Emoji", R.drawable.emoji_icon_editor, ToolType.EMOJI))
        mToolList.add(ToolModel("Crop", R.drawable.crop_icon_editor_sdk, ToolType.CROP))
        if (isDeleteIconVisible) {
            mToolList.add(ToolModel("delete", R.drawable.delete_icon_editor, ToolType.DELETE))
        }
    }

    inner class ToolModel(
        private val mToolName: String?,
        val mToolIcon: Int,
        val mToolType: ToolType?
    ) {
        var isSelected: Boolean = false
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToolsViewHolder {
        view = RowEditingToolsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ToolsViewHolder(view.root)
    }

    override fun onBindViewHolder(holder: ToolsViewHolder, position: Int) {
        val item = mToolList[holder.bindingAdapterPosition]
        holder.imgToolIcon.setImageResource(item.mToolIcon)
        holder.imgToolIcon.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                row_index = holder.getBindingAdapterPosition()
                mOnItemSelected.onToolSelected(
                    mToolList[holder.bindingAdapterPosition].mToolType,
                    true
                )
                notifyItemChanged(holder.bindingAdapterPosition)
            }
        })
        if (row_index == holder.getBindingAdapterPosition()) {
            holder.imgToolIcon.setBackgroundResource(R.drawable.rounded_row_editor_tool)
        } else {
            holder.imgToolIcon.setBackgroundResource(0)
        }
    }


    override fun getItemCount(): Int {
        return mToolList.size
    }

    internal inner class ToolsViewHolder(itemView: View) : BaseViewHolder(itemView) {
        var imgToolIcon: ImageView = itemView.findViewById<View?>(R.id.imgToolIcon) as ImageView
        var txtTool: TextView? = null
    }
}
