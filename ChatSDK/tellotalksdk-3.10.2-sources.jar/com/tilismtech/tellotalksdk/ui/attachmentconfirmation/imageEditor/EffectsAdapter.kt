package com.tilismtech.tellotalksdk.ui.attachmentconfirmation.imageEditor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment.ImageEditorFragment
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.imageEditor.EffectsAdapter.StyleViewHolder

class EffectsAdapter(
    private val frag: ImageEditorFragment
) : RecyclerView.Adapter<StyleViewHolder?>() {
    override fun onCreateViewHolder(container: ViewGroup, position: Int): StyleViewHolder {
        val inflater = LayoutInflater.from(container.context)
        val cell = inflater.inflate(R.layout.effect_list_item, container, false)

        return StyleViewHolder(cell)
    }

    override fun onBindViewHolder(viewHolder: StyleViewHolder, position: Int) {
        //  UIHelper.applyFilters(position, viewHolder.image, bitmap, context);


        viewHolder.image.setOnClickListener { frag.applyFilters(viewHolder.adapterPosition) }
    }

    override fun getItemCount(): Int {
        return 20
    }

    inner class StyleViewHolder(itemView: View) : BaseViewHolder(itemView) {
        var image: ImageView = itemView.findViewById<View?>(R.id.item_img) as ImageView
    }
}
