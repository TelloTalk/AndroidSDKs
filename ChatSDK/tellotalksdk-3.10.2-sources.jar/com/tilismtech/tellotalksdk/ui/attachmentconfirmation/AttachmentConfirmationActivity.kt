package com.tilismtech.tellotalksdk.ui.attachmentconfirmation

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.res.TypedArray
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.facebook.drawee.generic.RoundingParams
import com.facebook.drawee.view.SimpleDraweeView
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.MediaAttachment
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentDetailResponse
import com.tilismtech.tellotalksdk.databinding.ActivityAttacmentConfirmationBinding
import com.tilismtech.tellotalksdk.listeners.OnEmojiconClickedListener
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.PhotoEditor
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.PhotoEditor.OnSaveListener
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.SaveSettings
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.adapters.AttachmentPagerAdapter
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.ui.customviews.EditMessage
import com.tilismtech.tellotalksdk.ui.emojis.utilities.Emoji
import com.tilismtech.tellotalksdk.utils.AndroidUtilities
import com.tilismtech.tellotalksdk.utils.TelloConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.net.URISyntaxException

class AttachmentConfirmationActivity : TelloActivity(), EditMessage.KeyboardListener,
    OnEmojiconClickedListener {
    private lateinit var binding: ActivityAttacmentConfirmationBinding
    private var contactJid: String? = null
    private var conversationMode = 0
    private var attachments: ArrayList<MediaAttachment?>? = null
    private var selectedAttachment: MediaAttachment? = null
    var attachmentPagerAdapter: AttachmentPagerAdapter? = null
    private var imagesAdapter: ImagesAdapter? = null
    private val keyboardButtons = ArrayList<ImageButton>()
    private val photoEditorObjectList = HashMap<Int, PhotoEditor>()
    private var keyboardSelectedIndex = 0
    private var ta: TypedArray? = null
    var dialog: ProgressDialog? = null
    private var agentObj: AgentDetailResponse? = null
    private var dptname: String? = null
    private var dptImage: String? = null

    //    static {
    //        System.loadLibrary("NativeImageProcessor");
    //    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAttacmentConfirmationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.attachmentToolbar)
        createDialog()
        binding.backActionButton.setOnClickListener { v: View? ->
            onBackPressed()
        }
        binding.addCaption.setKeyboardListener(this)
        attachments = intent.getParcelableArrayListExtra("uris")
        if (attachments == null || attachments!!.isEmpty()) {
            finish()
            return
        }
        selectedAttachment = attachments!![0]
        setUpList()
        setUpPager()

        dptImage = intent.getStringExtra("dptImage")

        dptname = intent.getStringExtra("dptname")
        agentObj = intent.getParcelableExtra("agentObj")
        this.contactJid = intent.getStringExtra("contactJid")
        this.conversationMode = intent.getIntExtra("conversationMode", 0)
        loadImage()
        binding.confirmSendAttachment.setOnClickListener { v: View? ->
            saveImage()
        }
        binding.mainLayout.viewTreeObserver.addOnGlobalLayoutListener {
            val heightView = binding.mainLayout.height
            val widthView = binding.mainLayout.width
            if (1.0 * widthView / heightView > 1) {
                binding.attachmentsListContainer.visibility = View.GONE
            } else {
                binding.attachmentsListContainer.visibility = View.VISIBLE
            }
        }
        binding.addCaption.setOnClickListener {
            val inputMethodManager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager?
            inputMethodManager?.showSoftInput(binding.addCaption, InputMethodManager.SHOW_IMPLICIT)
        }
        onLanguageClick(keyboardSelectedIndex)
        ta = resources.obtainTypedArray(R.array.keyboard_image_array)
        keyboardButtons.add(binding.englishKeyboardIcon)
        keyboardButtons.add(binding.urduKeyboardIcon)
        binding.englishKeyboardIcon.setOnClickListener {
            onLanguageClick(0)
        }
        binding.urduKeyboardIcon.setOnClickListener {
            onLanguageClick(1)
        }
    }

    private fun setUpPager() {
        attachmentPagerAdapter = AttachmentPagerAdapter(supportFragmentManager, attachments)
        binding!!.attachmentPager.adapter = attachmentPagerAdapter
        binding!!.attachmentPager.offscreenPageLimit = attachments!!.size - 1
        binding!!.attachmentPager.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                saveFileTag()
                selectedAttachment = attachments!![position]
                if (imagesAdapter != null) {
                    imagesAdapter!!.notifyItemChanged(position)
                }
            }

            override fun onPageScrollStateChanged(state: Int) {
            }
        })
    }

    override fun onPause() {
        hideKeyboard()
        super.onPause()
    }

    fun hideKeyboard() {
        binding!!.addCaption.clearFocus()
        val view = currentFocus
        if (view != null) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm?.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }

    private fun setUpList() {
        binding!!.attachmentsListContainer.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        imagesAdapter = ImagesAdapter(this, attachments)
        binding!!.attachmentsListContainer.adapter = imagesAdapter
    }


    fun closeAttachmentFragment() {
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun sendAttachments(uris: ArrayList<MediaAttachment?>?) {
        val intent = Intent()
        val bundle = Bundle()
        bundle.putParcelableArrayList("uris", uris)
        intent.putExtras(bundle)
        setResult(RESULT_OK, intent)
        finish()
    }

    override fun onBackPressed() {
        if (binding!!.emojiStickersContainer.visibility == View.VISIBLE) {
            binding!!.emojiStickersContainer.visibility = View.GONE
            return
        } else {
            closeAttachmentFragment()
            super.onBackPressed()
        }
    }

    private fun loadImage() {
        // if (contactJid == null) {
        //     binding.actionBarImage.setImageResource(R.drawable.image_circle);
        //      return;
        //   }
//        Contact contact = ContactRepository.getInstance().getContactFromJid(contactJid);
//        if (contact != null && !ApplicationUtils.isEmptyString(contact.getAvatar())) {
//            binding.actionBarImage.setImageURI(NetworkConstants.BASE_URL1 + "/chatsdk" + contact.getAvatar());
//        } else {
//            binding.actionBarImage.setImageURI("");
//        }

        binding.actionBarImage.hierarchy.setPlaceholderImage(R.drawable.image_circle)
        binding.actionBarImage.hierarchy.roundingParams = RoundingParams().setRoundAsCircle(true)
        if (agentObj != null) {
            binding.tvActionTitle.text = agentObj!!.profileName
            if (agentObj!!.avatar?.contains("http") == true) {
                binding.actionBarImage.setImageURI(agentObj!!.avatar)
            } else {
                binding.actionBarImage.setImageURI(NetworkConstants.BASE_IMAGE + agentObj!!.avatar)
            }
        }

        if (dptname != null) {
            binding.tvActionTitle.text = dptname
        }
        if (dptImage != null || dptImage != "") {
            binding.actionBarImage.setImageURI(dptImage)
        }
    }

    override fun onEmojiIconClicked(emojicon: String) {
        val i = if (binding.addCaption.selectionEnd < 0) 0 else binding.addCaption.selectionEnd
        val localCharSequence = Emoji.replaceEmoji(
            emojicon,
            binding.addCaption.paint.fontMetricsInt,
            AndroidUtilities.dp(23f),
            false
        )
        binding.addCaption.text = binding.addCaption.text!!.insert(i, localCharSequence)
        binding.addCaption.setSelection(binding.addCaption.text.toString().length)
    }

    override fun onBackSpace(): Boolean {
        if (binding.addCaption.length() == 0) {
            return false
        }
        binding.addCaption.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
        return true
    }

    inner class ImagesAdapter internal constructor(
        var context: Context,
        images: List<MediaAttachment?>?
    ) :
        RecyclerView.Adapter<ImagesAdapter.ImagesHolder?>() {
        var images: List<MediaAttachment?>? = ArrayList()

        init {
            this.images = images
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImagesHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.gallery_images_item, parent, false)
            return ImagesHolder(view)
        }

        override fun onBindViewHolder(holder: ImagesHolder, position: Int) {
            val mediaAttachment = images!![position]
            val mimeType = mediaAttachment!!.mimeType
            holder.image.hierarchy.setPlaceholderImage(R.drawable.placeholder_icon_sdk)
            if (mimeType.startsWith("video")) {
                try {
                    val thumbnail = ThumbnailUtils.createVideoThumbnail(
                        mediaAttachment.fileUri.path.toString(),
                        MediaStore.Images.Thumbnails.MINI_KIND
                    )
                    val bitmapDrawable = BitmapDrawable(thumbnail)
                    holder.image.setImageDrawable(bitmapDrawable)
                } catch (e: URISyntaxException) {
                    holder.image.setImageDrawable(null)
                    e.printStackTrace()
                }
            } else {
                holder.image.setImageURI(mediaAttachment.fileUri)
            }
            if (selectedAttachment!!.fileUri === mediaAttachment.fileUri) {
                holder.parent.setBackgroundResource(R.drawable.attachment_selected_bg_sdk)
            } else {
                holder.parent.setBackgroundColor(Color.TRANSPARENT)
            }
            holder.image.setOnClickListener { view: View? ->
                selectedAttachment = mediaAttachment
                binding.addCaption.setText(selectedAttachment!!.fileTag)
                notifyItemChanged(position)
                binding.attachmentPager.currentItem = attachments!!.indexOf(selectedAttachment)
            }
        }

        override fun getItemCount(): Int {
            return images!!.size
        }

        inner class ImagesHolder(view: View) : BaseViewHolder(view) {
            var image: SimpleDraweeView = view.findViewById(R.id.gallery_image)
            var parent: ConstraintLayout = view.findViewById(R.id.image_container)
        }
    }


    override fun onEnterPressed(): Boolean {
        return false
    }

    override fun onTypingStarted() {
        saveFileTag()
    }

    override fun onTypingStopped() {
        saveFileTag()
    }

    override fun onTextDeleted() {
        saveFileTag()
    }

    override fun onTextChanged() {
        saveFileTag()
    }

    override fun onTabPressed(repeated: Boolean): Boolean {
        return false
    }

    private fun saveFileTag() {
        val tag = binding.addCaption.text.toString().trim { it <= ' ' }
        selectedAttachment!!.fileTag = tag
    }

    fun addPhotoEditor(photoEditor: PhotoEditor, position: Int) {
        photoEditorObjectList[position] = photoEditor
    }

    var count: Int = 0

    @SuppressLint("MissingPermission")
    fun saveImage() {
        showDialog()
        CoroutineScope(Dispatchers.IO).launch {
            val saveSettings = SaveSettings.Builder()
                .setClearViewsEnabled(true)
                .setTransparencyEnabled(true)
                .build()
            val list: List<Int> = ArrayList(photoEditorObjectList.keys)
            count = list.size
            for (i in list) {
                val photoEditor = photoEditorObjectList[i]
                val sentDirectory = File(TelloConfig.TELLO_IMAGE_DIRECTORY + "/Sent")
                if (!sentDirectory.exists()) {
                    sentDirectory.mkdirs()
                }
                val time = System.currentTimeMillis()
                val file =
                    File(TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/IMG-" + time.toString() + ".jpg")
                try {
                    if (!file.exists()) file.createNewFile()
                    photoEditor!!.saveAsFile(
                        file.absolutePath,
                        saveSettings,
                        object : OnSaveListener {
                            override fun onSuccess(imagePath: String) {
                                count -= 1
                                attachments!![i]!!.fileUri = Uri.fromFile(file)
                                attachments!![i]!!.isEdited = true
                            }

                            override fun onFailure(exception: Exception) {
                                count -= 1
                                exception.stackTrace
                            }
                        })
                } catch (e: IOException) {
                    count -= 1
                    e.printStackTrace()
                }
            }
            while (count > 0) {
                try {
                    delay(10)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
        }.invokeOnCompletion {
            dismissDialog()
            sendAttachments(ArrayList(attachments?: arrayListOf()))
        }
    }

    val editText: EditMessage
        get() = binding.addCaption

    fun performEditMessageClick() {
        if (binding.languagesContainer.visibility == View.GONE) {
            binding.languagesContainer.visibility = View.VISIBLE
        }
    }

    fun onLanguageClick(index: Int) {
        if (index == 0) {
            val typeface =
                ResourcesCompat.getFont(this@AttachmentConfirmationActivity, R.font.calibri)
            binding.addCaption.typeface = typeface
            binding.addCaption.hint = "Write Message Here"
        } else {
            val typeface = ResourcesCompat.getFont(
                this@AttachmentConfirmationActivity,
                R.font.calibri
            )
            binding.addCaption.typeface = typeface
            binding.addCaption.hint = "یہاں ٹائپ کریں"
        }
        if (index != keyboardSelectedIndex) {
            keyboardSelectedIndex = index
        }
        for (i in keyboardButtons.indices) {
            val id = ta!!.getResourceId(i, 0)
            if (index == i) {
                keyboardButtons[i].setColorFilter(resources.getColor(R.color.black))
            } else {
                keyboardButtons[i].setColorFilter(resources.getColor(R.color.white))
            }
        }
    }

    private fun createDialog() {
        dialog = ProgressDialog(this@AttachmentConfirmationActivity)
        dialog!!.setMessage("Please wait...")
    }

    private fun showDialog() {
        if (dialog != null) {
            dialog!!.show()
        }
    }

    private fun dismissDialog() {
        if (dialog != null) {
            dialog!!.dismiss()
        }
    }
}