package com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.facebook.common.executors.UiThreadImmediateExecutorService
import com.facebook.common.references.CloseableReference
import com.facebook.datasource.DataSource
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber
import com.facebook.imagepipeline.image.CloseableImage
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.MediaAttachment
import com.tilismtech.tellotalksdk.databinding.ImageEditorFragmentBinding
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.OnPhotoEditorListener
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.PhotoEditor
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.ToolType
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.ViewType
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.colorSeekBarView.ColorSeekBar.OnColorChangeListener
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.imageCroppingLibrary.cropper.CropImageActivity
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.AttachmentConfirmationActivity
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.OnItemSelected
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.imageEditor.EffectsAdapter
import com.tilismtech.tellotalksdk.ui.customviews.EditMessage
import com.tilismtech.tellotalksdk.utils.AndroidUtilities

class ImageEditorFragment : Fragment(), OnPhotoEditorListener, EditMessage.KeyboardListener,
    OnItemSelected {
    var binding: ImageEditorFragmentBinding? = null
    private var mPhotoEditor: PhotoEditor? = null
    private var sp: SharedPreferences? = null
    private var spe: SharedPreferences.Editor? = null
    var uri: Uri? = null
    var selectedAttachment: MediaAttachment? = null
    private var activity: AttachmentConfirmationActivity? = null
    private var position = 0
    var bitmap: Bitmap? = null
    private var isFilterVisible = false

    fun applyFilters(adapterPosition: Int) {
        if (bitmap != null) {
            //    UIHelper.applyFilters(adapterPosition, binding.editingImageView.getSource(), bitmap, getContext());
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val bundle = getArguments()
        if (bundle != null) {
            selectedAttachment = bundle.getParcelable<MediaAttachment?>("uri")
            position = bundle.getInt("position", 0)
            setEditorView()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        activity = context as AttachmentConfirmationActivity
    }

    private fun getResizedBitmap(image: Bitmap, maxSize: Int): Bitmap {
        var width = image.getWidth()
        var height = image.getHeight()

        val bitmapRatio = width.toFloat() / height.toFloat()
        if (bitmapRatio > 1 && width > maxSize) {
            width = maxSize
            height = (width / bitmapRatio).toInt()
        } else if (height > maxSize) {
            height = maxSize
            width = (height * bitmapRatio).toInt()
        }
        return Bitmap.createScaledBitmap(image, width, height, true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = ImageEditorFragmentBinding.inflate(inflater,container,false)
        instance = this
        setListeners()
        return binding!!.getRoot()
    }

    private fun setListeners() {
        binding!!.brush.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                binding!!.filtersContainer.setVisibility(View.GONE)
                binding!!.colorSlider.setVisibility(View.VISIBLE)
                binding!!.colorSlider.setVisibility(View.VISIBLE)
                setColorSeekBar()
                mPhotoEditor!!.onStartDrawing()
                mPhotoEditor!!.setBrushSize(7f)
                mPhotoEditor!!.setOpacity(98)
            }
        })

        binding!!.eraser.setOnClickListener(View.OnClickListener { view: View? ->
            binding!!.filtersContainer.setVisibility(View.GONE)
            mPhotoEditor!!.setBrushDrawingMode(false)
            binding!!.colorSlider.setVisibility(View.GONE)
            mPhotoEditor!!.brushEraser()
        })
        binding!!.edit.setOnClickListener(View.OnClickListener { view: View? ->
            binding!!.filtersContainer.visibility = View.GONE
            mPhotoEditor!!.setBrushDrawingMode(false)
            mPhotoEditor!!.onStopDrawing()
            binding!!.colorSlider.visibility = View.GONE
            val textEditorDialogFragment = TextEditorDialogFragment.show(requireActivity() as TelloActivity, "")
            textEditorDialogFragment.setOnTextEditorListener { inputText, colorCode ->
                mPhotoEditor!!.addText(
                    inputText,
                    colorCode,
                    context
                )
            }
        })
        binding!!.crop.setOnClickListener(View.OnClickListener { view: View? ->
            binding!!.filtersContainer.setVisibility(View.GONE)
            mPhotoEditor!!.setBrushDrawingMode(false)
            mPhotoEditor!!.onStopDrawing()
            val cropActivityIntent = Intent(getContext(), CropImageActivity::class.java)
            cropActivityIntent.putExtra("uri", selectedAttachment!!.getFileUri().toString())
            cropActivityIntent.putExtra("position", 0)
            startActivityForResult(cropActivityIntent, 1)
        })
        binding!!.filter.setOnClickListener(View.OnClickListener { view: View? ->
            mPhotoEditor!!.setBrushDrawingMode(false)
            binding!!.colorSlider.setVisibility(View.GONE)
            if (!isFilterVisible) {
                binding!!.filtersContainer.setVisibility(View.VISIBLE)
                isFilterVisible = true
            } else {
                binding!!.filtersContainer.setVisibility(View.GONE)
                isFilterVisible = false
            }
        })
        binding!!.undoIcon.setOnClickListener(View.OnClickListener { view: View? ->
            if (mPhotoEditor != null) {
                mPhotoEditor!!.undo()
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                val uri = data?.getStringExtra("uri")?.toUri()
                try {
                    binding!!.editingImageView.source.setImageURI(uri)
                    bitmap = binding!!.editingImageView.source.getBitmap()
                    setFilterAdapter(bitmap)
                } catch (e: IndexOutOfBoundsException) {
                    e.stackTrace
                }
            }
        }
    }

    private fun setEditorView() {
        //        binding.editingImageView.getSource().setImageURI(selectedAttachment.getFileUri());

        mPhotoEditor = PhotoEditor.Builder(getContext(), binding!!.editingImageView)
            .setPinchTextScalable(true)
            .deleteView(binding!!.delete)
            .build()

        //        bitmap = binding.editingImageView.getSource().getBitmap();
        val imageRequest =
            ImageRequestBuilder.newBuilderWithSource(selectedAttachment!!.getFileUri())
                .build()
        val imagePipeline = Fresco.getImagePipeline()
        //        showDialog();
        val dataSource: DataSource<CloseableReference<CloseableImage>> =
            imagePipeline.fetchDecodedImage(imageRequest, null)
        val finalFileUri = selectedAttachment!!.getFileUri()
        dataSource.subscribe(
            object : BaseBitmapDataSubscriber() {
                override fun onNewResultImpl(bitmap: Bitmap?) {
//                        orignalImage = bitmap;
                    this@ImageEditorFragment.bitmap = bitmap?.copy(bitmap.config!!, true)
                    //                        dismissDialog();
                    if (bitmap != null) proceedSettingImage()
                }

                override fun onFailureImpl(dataSource: DataSource<CloseableReference<CloseableImage?>?>) {
                    binding!!.editingImageView.source.setImageURI(finalFileUri)
                    bitmap = binding!!.editingImageView.source.getBitmap()
                    //                        orignalImage = binding.editingImageView.getSource().getBitmap();
//                        try {
                    if (bitmap != null) {
                        bitmap = getResizedBitmap(bitmap!!, AndroidUtilities.dp(200f))
                        //                                ImageEditorFragment.this.bitmap = rotateBitmap(activity, finalFileUri, ImageEditorFragment.this.bitmap);
                    }
                    //                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                        dismissDialog();
                    if (bitmap != null) proceedSettingImage()
                }
            },
            UiThreadImmediateExecutorService.getInstance()
        )

        if (bitmap != null) {
            binding!!.filter.setVisibility(View.GONE)
            setFilterAdapter(bitmap)
        }
        mPhotoEditor!!.setOnPhotoEditorListener(this)
        (requireActivity() as AttachmentConfirmationActivity).addPhotoEditor(mPhotoEditor!!, position)
    }

    private fun proceedSettingImage() {
        if (bitmap != null) {
            binding!!.editingImageView.getSource().setImageBitmap(bitmap)
            //            imageType = ApplicationUtils.getImageType(bitmap);
            bitmap = getResizedBitmap(bitmap!!, AndroidUtilities.dp(200f))
            binding!!.filter.setVisibility(View.GONE)
            setFilterAdapter(bitmap)
        }
    }

    private fun setFilterAdapter(bitmap: Bitmap?) {
        val llmTools = LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false)
        binding!!.filtersContainer.setLayoutManager(llmTools)
        val effectsAdapter = EffectsAdapter(this)
        binding!!.filtersContainer.setAdapter(effectsAdapter)
        effectsAdapter.notifyDataSetChanged()
    }

    private fun setColorSeekBar() {
        sp = requireActivity().getPreferences(Context.MODE_PRIVATE)
        spe = sp!!.edit()
        binding!!.colorSlider.setColorSeeds(R.array.text_colors)
        binding!!.colorSlider.setBarHeight(10f)
        binding!!.colorSlider.setThumbHeight(16f)
        binding!!.colorSlider.setOnColorChangeListener(object : OnColorChangeListener{
            override fun onColorChangeListener(
                colorBarPosition: Int,
                alphaBarPosition: Int,
                color: Int
            ) {
                mPhotoEditor!!.brushColor = binding!!.colorSlider.color
            }
        })
        binding!!.colorSlider.color = (sp!!.getInt("color", 0))
    }

    override fun onEditTextChangeListener(text: String?, colorCode: Int) {
    }

    override fun onAddViewListener(viewType: ViewType?, numberOfAddedViews: Int) {
    }

    override fun onRemoveViewListener(numberOfAddedViews: Int) {
    }

    override fun onRemoveViewListener(viewType: ViewType?, numberOfAddedViews: Int) {
    }

    override fun onStartViewChangeListener(viewType: ViewType?) {
    }

    override fun onStopViewChangeListener(viewType: ViewType?) {
    }

    override fun onToolSelected(toolType: ToolType?, showView: Boolean) {
    }

    override fun onEnterPressed(): Boolean {
        return false
    }

    override fun onTypingStarted() {
    }

    override fun onTypingStopped() {
    }

    override fun onTextDeleted() {
    }

    override fun onTextChanged() {
    }

    override fun onTabPressed(repeated: Boolean): Boolean {
        return false
    }

    fun setResult(image: String?) {
        val uri = Uri.parse(image)
        binding!!.editingImageView.getSource().setImageURI(uri)
        bitmap = binding!!.editingImageView.getSource().getBitmap()
        setFilterAdapter(bitmap)
    }

    companion object {
        val TAG: String = ImageEditorFragment::class.java.getName()
        var instance: ImageEditorFragment? = null

        @JvmStatic
        fun getInstance(mediaAttachment: MediaAttachment?, position: Int): ImageEditorFragment {
            val args = Bundle()
            args.putParcelable("uri", mediaAttachment)
            args.putInt("position", position)
            val fragment = ImageEditorFragment()
            fragment.setArguments(args)
            return fragment
        }
    }
}
