package com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.text.InputType;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.colorSeekBarView.ColorSeekBar;
import com.tilismtech.tellotalksdk.packages.imageEditorLibrary.views.PhotoEditorEditText;
import com.tilismtech.tellotalksdk.utils.ApplicationUtils;

import static android.content.Context.MODE_PRIVATE;

public class TextEditorDialogFragment extends DialogFragment {
    public static final String TAG = TextEditorDialogFragment.class.getSimpleName();
    public static final String EXTRA_INPUT_TEXT = "extra_input_text";
    public static final String EXTRA_COLOR_CODE = "extra_color_code";
    private PhotoEditorEditText mAddTextEditText;
    private InputMethodManager mInputMethodManager;
    private int mColorCode;
    private TextEditor mTextEditor;
    public ColorSeekBar colorSeekBar;
    private SharedPreferences sp;
    private SharedPreferences.Editor spe;
    private static String mText;
    String inputText;

    public interface TextEditor {
        void onDone(String inputText, int colorCode);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new Dialog(getActivity(), getTheme()) {
            @Override
            public void onBackPressed() {
                hideKeyboard();
                dismiss();
                super.onBackPressed();
                //do your stuff
            }
        };
    }

    public void hideKeyboard() {
        // Check if no view has focus:
        View view = getActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager inputManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    //Show dialog with provide text and text color
    public static TextEditorDialogFragment show(@NonNull AppCompatActivity appCompatActivity,
                                                @NonNull String inputText,
                                                @ColorInt int colorCode) {
        Bundle args = new Bundle();
        args.putString(EXTRA_INPUT_TEXT, inputText);
        args.putInt(EXTRA_COLOR_CODE, colorCode);
        TextEditorDialogFragment fragment = new TextEditorDialogFragment();
        fragment.setArguments(args);
        fragment.show(appCompatActivity.getSupportFragmentManager(), TAG);
        return fragment;
    }

    //Show dialog with default text input as empty and text color white
    public static TextEditorDialogFragment show(@NonNull AppCompatActivity appCompatActivity, String text) {
        if (!ApplicationUtils.isEmptyString(text)) {
            mText = text;
        }
        return show(appCompatActivity,
                "", ContextCompat.getColor(appCompatActivity, R.color.white));
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (!ApplicationUtils.isEmptyString(mText)) {
            mAddTextEditText.setText(mText, TextView.BufferType.EDITABLE);
            mText = null;
        } else {
            mAddTextEditText.setText("");
        }
        //Make dialog full screen with transparent background
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.text_editor_dialog_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAddTextEditText = (PhotoEditorEditText) view.findViewById(R.id.add_text_edit_text);
        mAddTextEditText.requestFocus();
        // LoseFocusEditText loseFocusEditText=new LoseFocusEditText(getContext());
        mAddTextEditText.setSelection(mAddTextEditText.getText().length());

        mAddTextEditText.setInputType(InputType.TYPE_NULL);
        mAddTextEditText.setRawInputType(InputType.TYPE_CLASS_TEXT);
        mAddTextEditText.setTextIsSelectable(true);

        mInputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        colorSeekBar = view.findViewById(R.id.colorSlider);
        setColorSeekBar();
        mAddTextEditText.setText(getArguments().getString(EXTRA_INPUT_TEXT));
        mColorCode = getArguments().getInt(EXTRA_COLOR_CODE);
        mAddTextEditText.setTextColor(mColorCode);
        mInputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        InputMethodManager imm =
                (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,
                InputMethodManager.HIDE_IMPLICIT_ONLY);

        //Make a callback on activity when user is done with text editing
        mAddTextEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.add_text_edit_text || id == EditorInfo.IME_ACTION_DONE) {
                    mInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    dismiss();
                    inputText = mAddTextEditText.getText().toString();
                    if (!TextUtils.isEmpty(inputText) && mTextEditor != null) {
                        mTextEditor.onDone(inputText, mColorCode);
                    }
                    return true;
                }
                return false;
            }
        });
        mAddTextEditText.setKeyImeChangeListener(new PhotoEditorEditText.KeyImeChange() {
            @Override
            public void onKeyIme(int keyCode, KeyEvent event) {
                if (KeyEvent.KEYCODE_BACK == event.getKeyCode()) {
                    hideKeyboard();
                    dismiss();
                    if (!TextUtils.isEmpty(inputText) && mTextEditor != null) {
                        mTextEditor.onDone(inputText, mColorCode);
                    }
                    // do something
                }
            }
        });

    }

    private void setColorSeekBar() {
        sp = getActivity().getPreferences(MODE_PRIVATE);
        spe = sp.edit();
        colorSeekBar.setColorSeeds(R.array.text_colors);
        colorSeekBar.setBarHeight(10);
        colorSeekBar.setThumbHeight(12);
        colorSeekBar.setOnColorChangeListener((colorBarPosition, alphaBarPosition, color) -> {
            mColorCode = colorSeekBar.getColor();
            mAddTextEditText.setTextColor(colorSeekBar.getColor());
        });
        colorSeekBar.setColor(sp.getInt("color", 0));
    }

    //Callback to listener if user is done with text editing
    public void setOnTextEditorListener(TextEditor textEditor) {
        mTextEditor = textEditor;
    }


}
