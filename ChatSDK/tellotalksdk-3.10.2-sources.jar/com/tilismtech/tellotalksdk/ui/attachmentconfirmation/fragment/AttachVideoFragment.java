package com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.data.db.entities.MediaAttachment;
import com.tilismtech.tellotalksdk.databinding.FragmentAttachVideoBinding;
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.AttachmentConfirmationActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class AttachVideoFragment extends Fragment {
    public static final String TAG = AttachVideoFragment.class.getSimpleName();

    float videoDuration;
    private String duration = null;
    private MediaAttachment uri;
    private int rotationValue, resultWidth, resultHeight, bitrate;
    private long audioFramesSize, videoFramesSize;
    private AttachmentConfirmationActivity activity;
    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
    Bitmap bmp = null;
    float ratio = 0;
    private int videoHeight, videoWidth;

    public AttachVideoFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (AttachmentConfirmationActivity) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(false);

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!isVisibleToUser) {
            try {
                if (binding.videoview.isPlaying()) {
                    binding.videoview.pause();
                    binding.play.setImageResource(R.drawable.play_big_icon_sdk);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    FragmentAttachVideoBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAttachVideoBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            uri = bundle.getParcelable("uri");
        }
        try {
            retriever.setDataSource(activity, uri.getFileUri());
            bmp = retriever.getFrameAtTime();
            videoHeight = bmp.getHeight();
            videoWidth = bmp.getWidth();
        } catch (Exception e) {
            e.printStackTrace();
        }
     //   processOpenVideo();
        binding.videoContainer.addOnLayoutChangeListener((v, left, top, right, bottom, leftWas, topWas, rightWas, bottomWas) -> {
            int heightWas = bottomWas - topWas; // bottom exclusive, top inclusive
            if (v.getHeight() != heightWas) {
                binding.play.setVisibility(View.VISIBLE);
                binding.videoview.pause();
                binding.videoview.seekTo(0);
                binding.videoSeek.setProgress(0);
                playVideo(uri);
            }
        });
        playVideo(uri);
    }

    private void playVideo(MediaAttachment uri) {
        binding.videoview.setVideoURI(uri.getFileUri());
        binding.videoview.seekTo(10);
        binding.videoview.setOnPreparedListener(mp -> {
            // TODO Auto-generated method stub
            int duration1 = mp.getDuration() / 1000;
            int hours = duration1 / 3600;
            int minutes = (duration1 / 60) - (hours * 60);
            int seconds = duration1 - (hours * 3600) - (minutes * 60);
            duration = String.format("%d:%02d:%02d", hours, minutes, seconds);
            binding.duration.setText("Duration : " + duration);
            binding.play.setOnClickListener(v -> {
                if (binding.videoview.isPlaying()) {
                    binding.videoview.pause();
                    binding.play.setImageResource(R.drawable.play_big_icon_sdk);
                } else {
                    binding.play.setImageResource(R.drawable.pause_icon_sdk);
                    binding.videoSeek.setMax((int) (binding.videoview.getDuration()));
                    binding.videoSeek.postDelayed(onEverySecond, 20);
                    binding.videoview.start();
                }
            });
        });

        if (videoWidth >= videoHeight) {
            ratio = (float) videoHeight / (float) videoWidth;
            binding.videoContainer.post(() -> {
                videoWidth = binding.videoContainer.getWidth();
                videoHeight = (int) (videoWidth * ratio);
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(videoWidth, videoHeight);
                layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
                binding.videoview.setLayoutParams(layoutParams);
            });
        } else if (videoHeight > videoWidth) {
            ratio = (float) videoWidth / (float) videoHeight;
            binding.videoContainer.post(() -> {
                videoHeight = binding.videoContainer.getHeight();
                videoWidth = (int) (videoHeight * ratio);
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(videoWidth, videoHeight);
                layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
                binding.videoview.setLayoutParams(layoutParams);
            });
        }
        binding.videoSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser) {
                    binding.videoview.seekTo(progress);
                }
                if (progress == 100) {
                    binding.play.setVisibility(View.VISIBLE);
                    binding.videoSeek.setProgress(0);
                }
            }
        });
        binding.videoview.setOnCompletionListener(vmp -> {
            binding.play.setImageResource(R.drawable.play_big_icon_sdk);
            binding.videoSeek.setProgress(0);
        });
    }

    private Runnable onEverySecond = new Runnable() {

        @Override
        public void run() {
            if (binding.videoview.isPlaying()) {
                if (binding.videoSeek != null) {
                    binding.videoSeek.setProgress(binding.videoview.getCurrentPosition());
                }
                if (binding.videoSeek != null) {
                    binding.videoSeek.postDelayed(onEverySecond, 200);
                }
            }
        }
    };

//    private void processOpenVideo() {
//        try {
//            IsoFile isoFile = new IsoFile(videoPath);
//            List<Box> boxes = Path.getPaths(isoFile, "/moov/trak/");
//            TrackHeaderBox trackHeaderBox = null;
//            boolean isAvc = true;
//            boolean isMp4A = true;
//            Box boxTest = Path.getPath(isoFile, "/moov/trak/mdia/minf/stbl/stsd/mp4a/");
//            if (boxTest == null) {
//                isMp4A = false;
//            }
//            if (!isMp4A) {
//                return;
//            }
//            boxTest = Path.getPath(isoFile, "/moov/trak/mdia/minf/stbl/stsd/avc1/");
//            if (boxTest == null) {
//                isAvc = false;
//            }
//            for (Box box : boxes) {
//                TrackBox trackBox = (TrackBox) box;
//                long sampleSizes = 0;
//                try {
//                    MediaBox mediaBox = trackBox.getMediaBox();
//                    MediaHeaderBox mediaHeaderBox = mediaBox.getMediaHeaderBox();
//                    SampleSizeBox sampleSizeBox = mediaBox.getMediaInformationBox().getSampleTableBox().getSampleSizeBox();
//                    for (long size : sampleSizeBox.getSampleSizes()) {
//                        sampleSizes += size;
//                    }
//                    videoDuration = (float) mediaHeaderBox.getDuration() / (float) mediaHeaderBox.getTimescale();
//                } catch (Exception e) {
//                }
//                TrackHeaderBox headerBox = trackBox.getTrackHeaderBox();
//                if (headerBox.getWidth() != 0 && headerBox.getHeight() != 0) {
//                    trackHeaderBox = headerBox;
//                    if (bitrate > 450000) {
//                        bitrate = 450000;
//                    }
//                    videoFramesSize = sampleSizes;
//                }
//                audioFramesSize = sampleSizes;
//            }
//            if (trackHeaderBox == null) {
//                return;
//            }
//            Matrix matrix = trackHeaderBox.getMatrix();
//            if (matrix.equals(Matrix.ROTATE_90)) {
//                rotationValue = 90;
//            } else if (matrix.equals(Matrix.ROTATE_180)) {
//                rotationValue = 180;
//            } else if (matrix.equals(Matrix.ROTATE_270)) {
//                rotationValue = 270;
//            }
//            int originalWidth;
//            resultWidth = originalWidth = (int) trackHeaderBox.getWidth();
//            int originalHeight;
//            resultHeight = originalHeight = (int) trackHeaderBox.getHeight();
//            if (resultWidth > 640 || resultHeight > 640) {
//                float scale = resultWidth > resultHeight ? 640.0f / resultWidth : 640.0f / resultHeight;
//                resultWidth *= scale;
//                resultHeight *= scale;
//                if (bitrate != 0) {
//                    bitrate *= Math.max(0.5f, scale);
//                    videoFramesSize = (long) (bitrate / 8 * videoDuration);
//                }
//            }
//            if (!isAvc && (resultWidth == originalWidth || resultHeight == originalHeight)) {
//                return;
//            }
//        } catch (Exception e) {
//            return;
//        }
//        videoDuration *= 1000;
//        updateVideoInfo();
//    }

    private void updateVideoInfo() {
        long esimatedDuration = (long) videoDuration;
        int width;
        int height;
        width = rotationValue == 90 || rotationValue == 270 ? resultHeight : resultWidth;
        height = rotationValue == 90 || rotationValue == 270 ? resultWidth : resultHeight;
        int estimatedSize = (int) ((audioFramesSize + videoFramesSize) * ((float) esimatedDuration / videoDuration));
        estimatedSize += estimatedSize / (32 * 1024) * 16;
        String videoDimension = String.format("%dx%d", width, height);
        int minutes = (int) (esimatedDuration / 1000 / 60);
        int seconds = (int) Math.ceil(esimatedDuration / 1000) - minutes * 60;
        String videoTimeSize = String.format("%02d:%02d", minutes, seconds);
        String fileSize = String.format("~%s", formatFileSize(estimatedSize));
        binding.dimens.setText(videoDimension);
        binding.size.setText(fileSize);
        binding.duration.setText(videoTimeSize);
    }

    public static String formatFileSize(long size) {
        if (size < 1024) {
            return String.format("%d B", size);
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0f);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / 1024.0f / 1024.0f);
        } else {
            return String.format("%.1f GB", size / 1024.0f / 1024.0f / 1024.0f);
        }
    }

    public static AttachVideoFragment getInstance(MediaAttachment mediaAttachment) {
        Bundle args = new Bundle();
        args.putParcelable("uri", mediaAttachment);
        AttachVideoFragment fragment = new AttachVideoFragment();
        fragment.setArguments(args);
        return fragment;
    }
}
