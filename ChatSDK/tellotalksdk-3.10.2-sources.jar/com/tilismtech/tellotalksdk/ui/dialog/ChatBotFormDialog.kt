package com.tilismtech.tellotalksdk.ui.dialog

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProviders
import com.facebook.drawee.view.SimpleDraweeView
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.FormFilledview
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.module.requests.SubmitChatFormRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.SubmitFieldRequest
import com.tilismtech.tellotalksdk.data.network.module.responses.ChatFormResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.FormFieldOptionResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.FormFieldResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.SubmitFieldOption
import com.tilismtech.tellotalksdk.data.network.module.responses.SubmittedFormResponse
import com.tilismtech.tellotalksdk.databinding.LayFormBinding
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppEditText
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppTextView
import com.tilismtech.tellotalksdk.ui.viewmodels.BotFormDialogViewModel
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.MessageUtils

class ChatBotFormDialog : DialogFragment() {

    private lateinit var binding: LayFormBinding
    private var ttMessage: TTMessage? = null
    private lateinit var chatFormRes: ChatFormResponse
    private lateinit var viewModel: BotFormDialogViewModel
    private lateinit var account: TTAccount
    private lateinit var onSuccess: (it:TTMessage?)->Unit
    private var isFormSubmitted: Boolean = false
    private val gson = Gson()


    //  companion object {
    private val ARG_MY_PARCELABLE_OBJECT = "messageParcel"
    private val ARG_MY_BOOLEAN_FLAG = "isFormSubmitted"


    fun newInstance(
        message: TTMessage?,
        isFormSubmitted: Boolean,
        onSuccess: (it: TTMessage?) -> Unit
    ): ChatBotFormDialog {
        val args = Bundle()
        this.onSuccess = onSuccess
        ttMessage = message
        this.isFormSubmitted = isFormSubmitted

        args.putParcelable(ARG_MY_PARCELABLE_OBJECT, message)
        args.putBoolean(ARG_MY_BOOLEAN_FLAG, isFormSubmitted)
        val fragment = ChatBotFormDialog()
        fragment.arguments = args
        return fragment
    }
    //  }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            //   ttMessage = it.getParcelable(ARG_MY_PARCELABLE_OBJECT)!!
            //   isFormSubmitted = it.getBoolean(ARG_MY_BOOLEAN_FLAG)
        }
        viewModel = ViewModelProviders.of(this).get(BotFormDialogViewModel::class.java)
        account = TelloApiClient.getInstance()!!.getAccount() ?: return
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = LayFormBinding.inflate(inflater, container, false)
        if (!isFormSubmitted) {
            setupView()
        } else {
            binding.tvSubmitForm.visibility = View.GONE
            ChatManager.instance?.getSubmitForm(
                ttMessage?.viewId
            ) {
                if (it != null) {
                    openViewSubmittedForm(it)
                }
            }
        }

        return binding.root
    }

    private fun openViewSubmittedForm(submittedFormResponse: SubmittedFormResponse?) {
        binding.tvGoBack.visibility = View.GONE
        binding.scFillForm.visibility = View.VISIBLE
        binding.scForm.visibility = View.GONE
        binding.tvSubmitForm.visibility = View.GONE
        binding.layFormsFillData.visibility = View.VISIBLE
        binding.tvDes.visibility = View.GONE


        binding.tvTitle.text = submittedFormResponse?.formTitle

        val formFilledviews = java.util.ArrayList<FormFilledview>()


        submittedFormResponse?.formData?.forEach {
            when (it.fieldType) {
                FormFieldResponse.NodeType.SHORTTEXT.name, FormFieldResponse.NodeType.LONGTEXT.name, FormFieldResponse.NodeType.NUMERIC.name, FormFieldResponse.NodeType.EMAIL.name,
                FormFieldResponse.NodeType.DATESELECTOR.name, FormFieldResponse.NodeType.TIMESELECTOR.name, FormFieldResponse.NodeType.DROPDOWNLIST.name, FormFieldResponse.NodeType.OPTIONLIST.name -> if (it.fieldValue != null) {
                    formFilledviews.add(
                        FormFilledview(
                            it.fieldId,
                            it.fieldValue.toString(),
                            it.fieldType,
                            it.fieldName,
                            null
                        )
                    )
                } else {
                    formFilledviews.add(
                        FormFilledview(
                            it.fieldId,
                            "",
                            it.fieldType,
                            it.fieldName,
                            null
                        )
                    )
                }
                FormFieldResponse.NodeType.CHECKBOX.name -> if (it.fieldOptions != null) {
                    val s = java.util.ArrayList<String>()
                    for (fieldOption in it.fieldOptions) {
                        s.add(fieldOption.fieldOptionsDetValue)
                    }
                    formFilledviews.add(
                        FormFilledview(
                            it.fieldId,
                            "",
                            it.fieldType,
                            it.fieldName,
                            s
                        )
                    )
                }
                FormFieldResponse.NodeType.FILEUPLOAD.name -> if (it.fieldOptions.size > 0) formFilledviews.add(
                    FormFilledview(
                        it.fieldId,
                        it.fieldOptions[0].getaFile(),
                        it.fieldType,
                        it.fieldName,
                        null
                    )
                )
            }
        }
        drawEditForm(formFilledviews)

    }

    private fun disableEnableControls(enable: Boolean, vg: ViewGroup) {
        for (i in 0 until vg.childCount) {
            val child = vg.getChildAt(i)
            child.isEnabled = enable
            if (child is ViewGroup) {
                disableEnableControls(enable, child)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val window: Window = dialog!!.window!!
        window.setGravity(Gravity.BOTTOM)

        // Set the dialog window's width and height to match_parent
        val params: WindowManager.LayoutParams = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        window.attributes = params

        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun setupView() {
        val chatbotNode = gson.fromJson(ttMessage?.chatbotNode, ChatbotNode::class.java)
        if (ttMessage!=null) {
            ChatManager.instance?.getChatRequestForm(
                chatbotNode?.children?.getOrNull(0)?.formData?.getOrNull(0)?.fieldName?:chatbotNode?.formData?.getOrNull(0)?.fieldName
            ) { chatFormResponse: ChatFormResponse? ->
                if(chatFormResponse!=null){
                    chatFormRes = chatFormResponse
                    binding.tvTitle.text = chatFormResponse.formTitle
                    binding.tvDes.text = chatFormResponse.formDescription
                    binding.layFormsData.visibility = View.VISIBLE
                    for (formFieldResponse in chatFormResponse.fieldList) {
                        when (formFieldResponse.fieldType) {
                            FormFieldResponse.NodeType.SHORTTEXT.name, FormFieldResponse.NodeType.LONGTEXT.name, FormFieldResponse.NodeType.NUMERIC.name, FormFieldResponse.NodeType.EMAIL.name, FormFieldResponse.NodeType.URL.name -> {
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createEditText(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                            }
                            FormFieldResponse.NodeType.DATESELECTOR.name -> {
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createDateEdittext(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                            }
                            FormFieldResponse.NodeType.TIMESELECTOR.name -> {
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createTimeEdittext(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                            }
                            FormFieldResponse.NodeType.CHECKBOX.name -> if (formFieldResponse.fieldOptionList.size > 0) {
                                MessageUtils.createSeperator(
                                    requireContext(), binding.layFormsData
                                )
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createCheckBox(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                            }
                            FormFieldResponse.NodeType.FILEUPLOAD.name -> {
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createButton(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createFilesizeTextview(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                            }
                            FormFieldResponse.NodeType.OPTIONLIST.name -> {
                                MessageUtils.createSeperator(
                                    context, binding.layFormsData
                                )
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createRadioButton(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createSeperator(requireContext(), binding.layFormsData)
                            }
                            FormFieldResponse.NodeType.DROPDOWNLIST.name -> {
                                MessageUtils.createTextView(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                                MessageUtils.createDropDown(
                                    formFieldResponse, requireContext(), binding.layFormsData
                                )
                            }
                        }
                    }
                }
            }

            binding.tvSubmitForm.setOnClickListener { v ->
                if (::chatFormRes.isInitialized) {
                    getAllFieldValues(chatFormRes)
                }
            }
            binding.tvGoBack.visibility = View.GONE
            binding.imEditform.setOnClickListener { v ->
                binding.tvSubmit.text = "Confirm"
                binding.imEditform.visibility = View.GONE
                disableEnableControls(true, binding.layFormsData)
            }

        }

    }

    private fun getAllFieldValues(
        chatFormResponse: ChatFormResponse,
    ) {
        val chatbotNode = gson.fromJson(ttMessage?.chatbotNode, ChatbotNode::class.java)
        val childCount = binding.layFormsData.childCount
        val submitChatFormRequest = SubmitChatFormRequest()
        submitChatFormRequest.profileId = account.userName
        submitChatFormRequest.formId = chatFormResponse.formId.toInt()
        submitChatFormRequest.messageId = ttMessage?.messageId
        submitChatFormRequest.masterId = ttMessage?.chatbotID
        submitChatFormRequest.chatId = ttMessage?.chatId
        submitChatFormRequest.nodeId = chatbotNode?.id.toString()
        val submitFieldRequests = ArrayList<SubmitFieldRequest>()
        val formFilledviews = ArrayList<FormFilledview>()
        for (i in 0 until childCount) {
            val v = binding.layFormsData.getChildAt(i)

            val formFieldResponse = if (v.tag != null && v.tag is FormFieldResponse) {
                v.tag as FormFieldResponse
            } else {
                // handle the case where v.tag is null or not of type FormFieldResponse
                null
            }

            //    val formFieldResponse = v.tag as FormFieldResponse
            if (formFieldResponse != null) {
                if (formFieldResponse.fieldType == FormFieldResponse.NodeType.SHORTTEXT.getName()
                    || formFieldResponse.fieldType == FormFieldResponse.NodeType.LONGTEXT.getName()
                    || formFieldResponse.fieldType == FormFieldResponse.NodeType.URL.getName()
                ) {
                    if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                        if ((v as WhatsAppEditText).text.toString().length < formFieldResponse.fieldMinValue.toInt()) {
                            ApplicationUtils.errorMessage(
                                context,
                                formFieldResponse.fieldLabel + " required minimum Length is " + formFieldResponse.fieldMinValue + " character"
                            )
                            return
                        } else {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    v.text.toString(),
                                    null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    v.text.toString(),
                                    FormFieldResponse.NodeType.SHORTTEXT.getName(),
                                    formFieldResponse.fieldLabel,
                                    null
                                )
                            )
                        }
                    } else {
                        if ((v as WhatsAppEditText).text.toString().isNotEmpty()) {
                            if (v.text.toString().length < formFieldResponse.fieldMinValue.toInt()) {
                                ApplicationUtils.errorMessage(
                                    context,
                                    formFieldResponse.fieldLabel + " required minimum Length is " +
                                            formFieldResponse.fieldMinValue + " character"
                                )
                                return
                            } else {
                                submitFieldRequests.add(
                                    SubmitFieldRequest(
                                        formFieldResponse.fieldId,
                                        v.text.toString(), null
                                    )
                                )
                                formFilledviews.add(
                                    FormFilledview(
                                        formFieldResponse.fieldId,
                                        v.text.toString(),
                                        FormFieldResponse.NodeType.SHORTTEXT.getName(),
                                        formFieldResponse.fieldLabel,
                                        null
                                    )
                                )
                            }
                        } else {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    v.text.toString(), null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    v.text.toString(),
                                    FormFieldResponse.NodeType.SHORTTEXT.getName(),
                                    formFieldResponse.fieldLabel,
                                    null
                                )
                            )
                        }
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.NUMERIC.getName()) {
                    if ((v as WhatsAppEditText).text.toString().isNotEmpty()) {
                        if (formFieldResponse.fieldValidationType == "Range") {
                            if (v.text.toString()
                                    .toInt() >= formFieldResponse.fieldMinValue.toInt() &&
                                v.text.toString().toInt() <= formFieldResponse.fieldMaxValue.toInt()
                            ) {
                                submitFieldRequests.add(
                                    SubmitFieldRequest(
                                        formFieldResponse.fieldId,
                                        v.text.toString(), null
                                    )
                                )
                                formFilledviews.add(
                                    FormFilledview(
                                        formFieldResponse.fieldId,
                                        v.text.toString(),
                                        FormFieldResponse.NodeType.NUMERIC.getName(),
                                        formFieldResponse.fieldLabel,
                                        null
                                    )
                                )
                            } else {
                                ApplicationUtils.errorMessage(
                                    context,
                                    formFieldResponse.fieldLabel + " range is " + formFieldResponse.fieldMinValue + " - " + formFieldResponse.fieldMaxValue
                                )
                                return
                            }
                        }
                    } else {
                        if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                            ApplicationUtils.errorMessage(
                                context,
                                formFieldResponse.fieldLabel + " range is " + formFieldResponse.fieldMinValue + " - " + formFieldResponse.fieldMaxValue
                            )
                            return
                        } else {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    v.text.toString(), null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    v.text.toString(), FormFieldResponse.NodeType.NUMERIC.getName(),
                                    formFieldResponse.fieldLabel, null
                                )
                            )
                        }
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.EMAIL.getName()) {
                    if ((v as WhatsAppEditText).text.toString().isNotEmpty()) {
                        if (formFieldResponse.fieldRegExp != "") {
                            val emailPattern = Regex(formFieldResponse.fieldRegExp)
                            if (v.text.toString().matches(emailPattern)) {
                                //  Toast.makeText(getApplicationContext(), "valid email address", Toast.LENGTH_SHORT).show();
                                submitFieldRequests.add(
                                    SubmitFieldRequest(
                                        formFieldResponse.fieldId,
                                        v.text.toString(), null
                                    )
                                )
                                formFilledviews.add(
                                    FormFilledview(
                                        formFieldResponse.fieldId,
                                        v.text.toString(),
                                        FormFieldResponse.NodeType.EMAIL.getName(),
                                        formFieldResponse.fieldLabel,
                                        null
                                    )
                                )
                            } else {
                                ApplicationUtils.errorMessage(context, "Invalid email address")
                                return
                            }
                        } else if (MessageUtils.isValidEmail(v.text.toString())) {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    v.text.toString(), null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    v.text.toString(), FormFieldResponse.NodeType.EMAIL.getName(),
                                    formFieldResponse.fieldLabel, null
                                )
                            )
                        } else {
                            ApplicationUtils.errorMessage(context, "Invalid email address")
                            return
                        }
                    } else {
                        if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                            ApplicationUtils.errorMessage(
                                context,
                                formFieldResponse.fieldLabel + " is required"
                            )
                            return
                        }
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.DATESELECTOR.getName()) {
                    val rl = v as RelativeLayout
                    if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                        if ((rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString()
                                .isEmpty()
                        ) {
                            ApplicationUtils.errorMessage(
                                context,
                                formFieldResponse.fieldLabel + " is invalid Date"
                            )
                            return
                        } else {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                    null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                    FormFieldResponse.NodeType.DATESELECTOR.getName(),
                                    formFieldResponse.fieldLabel,
                                    null
                                )
                            )
                        }
                    } else {
                        submitFieldRequests.add(
                            SubmitFieldRequest(
                                formFieldResponse.fieldId,
                                (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                null
                            )
                        )
                        formFilledviews.add(
                            FormFilledview(
                                formFieldResponse.fieldId,
                                (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                FormFieldResponse.NodeType.DATESELECTOR.getName(),
                                formFieldResponse.fieldLabel,
                                null
                            )
                        )
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.TIMESELECTOR.getName()) {
                    val rl = v as RelativeLayout
                    if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                        if ((v as WhatsAppEditText).text.toString().length == 0) {
                            Toast.makeText(
                                context,
                                formFieldResponse.fieldLabel + " is invalid Time",
                                Toast.LENGTH_SHORT
                            ).show()
                            return
                        } else {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                    null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                    FormFieldResponse.NodeType.TIMESELECTOR.getName(),
                                    formFieldResponse.fieldLabel,
                                    null
                                )
                            )
                        }
                    } else {
                        submitFieldRequests.add(
                            SubmitFieldRequest(
                                formFieldResponse.fieldId,
                                (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                null
                            )
                        )
                        formFilledviews.add(
                            FormFilledview(
                                formFieldResponse.fieldId,
                                (rl.findViewById<View>(R.id.edt_formdate) as WhatsAppEditText).text.toString(),
                                FormFieldResponse.NodeType.TIMESELECTOR.getName(),
                                formFieldResponse.fieldLabel,
                                null
                            )
                        )
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.DROPDOWNLIST.getName()) {
                    var formOptionResponse: FormFieldOptionResponse? = null
                    for (formFieldOptionResponse in formFieldResponse.fieldOptionList) {
                        if (formFieldOptionResponse.isOptionSelected) {
                            formOptionResponse = formFieldOptionResponse
                            break
                        }
                    }
                    if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                        if (formOptionResponse == null) {
                            ApplicationUtils.errorMessage(
                                context,
                                formFieldResponse.fieldLabel + " is required"
                            )
                            return
                        }
                    }
                    submitFieldRequests.add(
                        SubmitFieldRequest(
                            formFieldResponse.fieldId,
                            formOptionResponse!!.fieldOptionId, null
                        )
                    )
                    formFilledviews.add(
                        FormFilledview(
                            formFieldResponse.fieldId,
                            formOptionResponse.fieldOptionValue,
                            FormFieldResponse.NodeType.DROPDOWNLIST.getName(),
                            formFieldResponse.fieldLabel,
                            null
                        )
                    )
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.FILEUPLOAD.getName()) {
                    val submitFieldOptions = ArrayList<SubmitFieldOption>()
                    if (MessageUtils.hashMap != null) {
                        if (MessageUtils.hashMap[formFieldResponse.fieldId] != null) {
                            for (imageURL in MessageUtils.hashMap[formFieldResponse.fieldId]!!) {
                                submitFieldOptions.add(
                                    SubmitFieldOption(
                                        imageURL, "image",
                                        null
                                    )
                                )
                            }
                        } else {
                            if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                                ApplicationUtils.errorMessage(context, "Upload Attachments")
                                return
                            }
                        }
                    }
                    submitFieldRequests.add(
                        SubmitFieldRequest(
                            formFieldResponse.fieldId,
                            null, submitFieldOptions
                        )
                    )
                    if (submitFieldOptions.size > 0) {
                        formFilledviews.add(
                            FormFilledview(
                                formFieldResponse.fieldId,
                                submitFieldOptions[0].getaFile(),
                                FormFieldResponse.NodeType.FILEUPLOAD.getName(),
                                formFieldResponse.fieldLabel,
                                null
                            )
                        )
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.OPTIONLIST.getName()) {
                    val submitFieldOptions = ArrayList<SubmitFieldOption>()
                    for (formFieldOptionResponse in formFieldResponse.fieldOptionList) {
                        if (formFieldOptionResponse.isOptionSelected) {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    formFieldOptionResponse.fieldOptionId, null
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    formFieldOptionResponse.fieldOptionValue,
                                    FormFieldResponse.NodeType.OPTIONLIST.getName(),
                                    formFieldResponse.fieldLabel,
                                    null
                                )
                            )
                        }
                    }
                } else if (formFieldResponse.fieldType == FormFieldResponse.NodeType.CHECKBOX.getName()) {
                    var isAdded = false
                    val strings = ArrayList<String>()
                    for (submitFieldRequest in submitFieldRequests) {
                        if (submitFieldRequest.fieldId == formFieldResponse.fieldId) {
                            isAdded = true
                            break
                        }
                    }
                    val submitFieldOptions = ArrayList<SubmitFieldOption>()
                    for (formFieldOptionResponse in formFieldResponse.fieldOptionList) {
                        if (formFieldOptionResponse.isOptionSelected) {
                            submitFieldOptions.add(
                                SubmitFieldOption(
                                    null, null,
                                    formFieldOptionResponse.fieldOptionId
                                )
                            )
                            strings.add(formFieldOptionResponse.fieldOptionValue)
                        }
                    }
                    if (submitFieldOptions.size > 0) {
                        if (!isAdded) {
                            submitFieldRequests.add(
                                SubmitFieldRequest(
                                    formFieldResponse.fieldId,
                                    null, submitFieldOptions
                                )
                            )
                            formFilledviews.add(
                                FormFilledview(
                                    formFieldResponse.fieldId,
                                    "",
                                    FormFieldResponse.NodeType.CHECKBOX.getName(),
                                    formFieldResponse.fieldLabel,
                                    strings
                                )
                            )
                        }
                    } else {
                        if (formFieldResponse.isRequired == FormFieldResponse.FIELDREQUIRED.Y.name) {
                            ApplicationUtils.errorMessage(
                                context,
                                formFieldResponse.fieldLabel + " is required"
                            )
                            return
                        }
                    }
                }
            }
        }
        submitChatFormRequest.submitFieldRequests = submitFieldRequests
        if (binding.tvGoBack.isVisible) {
            ChatManager.instance?.submitForm(submitChatFormRequest) {
                    if (it != null) {
                        chatbotNode?.children?.apply {
                            add(ChatbotChild().apply {
                                isFormSubmitted = true
                            })
                        }
                        ttMessage?.viewId = it.replace("\"", "")
                        ConversationActivityViewModel.getInstance().updateMessage(ttMessage)
                        onSuccess(ttMessage)
                        dismiss()
                        ApplicationUtils.errorMessage(context, "Form is Submitted")
                    }
                }
        }
        binding.scForm.visibility = View.GONE
        binding.scFillForm.visibility = View.VISIBLE
        binding.layFormsFillData.removeAllViews()
        binding.layFormsFillData.visibility = View.VISIBLE
        binding.imEditform.visibility = View.GONE
        binding.tvSubmitForm.visibility = View.VISIBLE
        binding.tvSubmit.text = "Verify & Submit"
        binding.tvTitle.text = "Verify Form Details"
        binding.tvDes.visibility = View.INVISIBLE
        binding.tvGoBack.visibility = View.VISIBLE
        drawEditForm(formFilledviews)
        binding.tvGoBack.setOnClickListener {
            binding.scForm.visibility = View.VISIBLE
            binding.scFillForm.visibility = View.GONE
            binding.tvGoBack.visibility = View.GONE
            binding.tvTitle.text = chatFormResponse.formTitle
            binding.tvDes.visibility = View.VISIBLE
            binding.tvDes.text = chatFormResponse.formDescription
        }
    }

    private fun drawEditForm(
        formFilledviews: java.util.ArrayList<FormFilledview>,
    ) {

        //  binding.layFormsFillData.removeAllViews();
        for (formFilledview in formFilledviews) {
            when (formFilledview.fieldType) {
                FormFieldResponse.NodeType.SHORTTEXT.name, FormFieldResponse.NodeType.LONGTEXT.name, FormFieldResponse.NodeType.NUMERIC.name, FormFieldResponse.NodeType.EMAIL.name,
                FormFieldResponse.NodeType.DATESELECTOR.name, FormFieldResponse.NodeType.TIMESELECTOR.name, FormFieldResponse.NodeType.DROPDOWNLIST.name -> if (formFilledview.fieldValue != "") {
                    val v = layoutInflater.inflate(R.layout.lay_text, null)
                    val tv_title = v.findViewById<WhatsAppTextView>(R.id.edt_title)

                    val edit_value = v.findViewById<WhatsAppTextView>(R.id.edit_value)
                    tv_title.text = formFilledview.fieldLabel
                    edit_value.text = formFilledview.fieldValue
                    val params = RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(10, 20, 10, 20)
                    // v.setPadding(30, 30, 20, 30);
                    v.layoutParams = params
                    binding.layFormsFillData.addView(v)
                }
                FormFieldResponse.NodeType.CHECKBOX.name -> if (formFilledview.fieldOptions.size > 0) {
                    val v = layoutInflater.inflate(R.layout.custom_checkbox_submit, null)
                    val tv_title = v.findViewById<WhatsAppTextView>(R.id.edt_title)
                    tv_title.text = formFilledview.fieldLabel
                    val lay_checkbox = v.findViewById<LinearLayout>(R.id.lay_checkbox)
                    for (fieldOption in formFilledview.fieldOptions) {
                        val checkbox = layoutInflater.inflate(R.layout.custom_checkbox, null)
                        val cb = checkbox.findViewById<CheckBox>(R.id.cb_options)
                        cb.text = fieldOption
                        cb.isChecked = true
                        cb.isEnabled = false
                        lay_checkbox.addView(checkbox)
                    }
                    binding.layFormsFillData.addView(v)
                }
                FormFieldResponse.NodeType.FILEUPLOAD.name -> if (formFilledview.fieldValue != "") {
                    val v = layoutInflater.inflate(R.layout.custom_file_upload, null)
                    val tv_title = v.findViewById<WhatsAppTextView>(R.id.tv_title)
                    tv_title.text = formFilledview.fieldLabel
                    val attachment = v.findViewById<SimpleDraweeView>(R.id.im_attach)
                    attachment.setImageURI(formFilledview.fieldValue)
                    binding.layFormsFillData.addView(v)
                }
                FormFieldResponse.NodeType.OPTIONLIST.name -> if (formFilledview.fieldValue != "") {
                    val v = layoutInflater.inflate(R.layout.custom_radiobutton_submit, null)
                    val rb = v.findViewById<RadioButton>(R.id.rb_options)
                    val tv_title = v.findViewById<WhatsAppTextView>(R.id.edt_title)
                    rb.text = formFilledview.fieldValue
                    rb.isChecked = true
                    rb.isEnabled = false
                    tv_title.text = formFilledview.fieldLabel
                    binding.layFormsFillData.addView(v)
                }
            }
        }
    }


}