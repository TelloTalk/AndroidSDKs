package com.tilismtech.tellotalksdk.ui.dialog

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.ui.adapters.viewholders.BaseViewHolder
import com.tilismtech.tellotalksdk.ui.dialog.PermissionDialogFragment.PermissionImagesAdapter.PermissionImageHolder
import com.tilismtech.tellotalksdk.utils.AndroidUtilities

class PermissionDialogFragment : DialogFragment {
    interface BaseDialogListener {
        fun onDialogPositiveClick(dialog: PermissionDialogFragment?)
        fun onDialogNegativeClick(dialog: PermissionDialogFragment?)
    }

    var dialogListener: BaseDialogListener? = null
    private var imageResources: ArrayList<Int?>? = null
    private var message = 0
    var isNavigate: Boolean = false
        private set
    private var mIsStateAlreadySaved = false
    private var mPendingShowDialog = false
    var requestCode: Int = -1

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag).addToBackStack(null)
            ft.commitAllowingStateLoss()
        } catch (e: IllegalStateException) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        onResumeFragments()
        super.onResume()
        if (getDialog()!!.getWindow() != null) {
            getDialog()!!.getWindow()!!
                .setLayout(AndroidUtilities.dp(290f), WindowManager.LayoutParams.WRAP_CONTENT)
        }
    }

    fun onResumeFragments() {
        mIsStateAlreadySaved = false
        if (mPendingShowDialog) {
            mPendingShowDialog = false
            showSnoozeDialog()
        }
    }

    override fun onPause() {
        super.onPause()
        mIsStateAlreadySaved = true
    }

    fun showSnoozeDialog() {
        if (mIsStateAlreadySaved) {
            mPendingShowDialog = true
        } else {
            val fm = getFragmentManager()
            val snoozeDialog = PermissionDialogFragment()
            snoozeDialog.show(fm!!, "BaseDialogFragment")
        }
    }

    constructor()

    @SuppressLint("ValidFragment")
    constructor(
        imageResources: ArrayList<Int?>,
        message: Int,
        navigate: Boolean,
        listener: BaseDialogListener
    ) { //
        this.imageResources = imageResources
        this.message = message
        this.isNavigate = navigate
        dialogListener = listener
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireActivity())
        val view =
            LayoutInflater.from(requireActivity()).inflate(R.layout.permission_dialog_layout, null)
        val permissionImages = view.findViewById<RecyclerView>(R.id.permission_images)
        val manager = LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false)
        permissionImages.setLayoutManager(manager)
        val permissionMessage = view.findViewById<AppCompatTextView>(R.id.permission_text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            permissionMessage.setText(
                Html.fromHtml(
                    if (message == 0) "" else getString(message),
                    Html.FROM_HTML_MODE_LEGACY
                )
            )
        } else {
            permissionMessage.setText(Html.fromHtml(if (message == 0) "" else getString(message)))
        }
        val permissionImagesAdapter = PermissionImagesAdapter()
        permissionImages.setAdapter(permissionImagesAdapter)
        builder.setView(view)
        builder.setPositiveButton(
            android.R.string.ok,
            DialogInterface.OnClickListener { dialog: DialogInterface?, id: Int ->
                dialogListener!!.onDialogPositiveClick(this@PermissionDialogFragment)
                try {
                    dismiss()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }).setNegativeButton(
            android.R.string.cancel,
            DialogInterface.OnClickListener { dialog: DialogInterface?, id: Int ->
                dialogListener!!.onDialogNegativeClick(this@PermissionDialogFragment)
                try {
                    dismiss()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            })
        val dialog: Dialog = builder.create()
        dialog.window?.setBackgroundDrawable(
            ContextCompat.getDrawable(
                requireActivity(),
                R.drawable.dialog_bg_sdk
            )
        )
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        return dialog
    }

    private inner class PermissionImagesAdapter : RecyclerView.Adapter<PermissionImageHolder?>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PermissionImageHolder {
            val view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.permission_image_item_layout, parent, false)
            return PermissionImageHolder(view)
        }

        override fun onBindViewHolder(holder: PermissionImageHolder, position: Int) {
            holder.permissionImage.setImageResource(imageResources!!.get(position)!!)
        }

        override fun getItemCount(): Int {
            return imageResources!!.size
        }

        inner class PermissionImageHolder(itemView: View) : BaseViewHolder(itemView) {
            var permissionImage: ImageView

            init {
                permissionImage = itemView.findViewById<ImageView>(R.id.permission_image)
            }
        }
    }
}