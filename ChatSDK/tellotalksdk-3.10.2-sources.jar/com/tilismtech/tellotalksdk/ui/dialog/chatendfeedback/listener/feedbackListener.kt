package com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.listener

interface feedbackListener {
    fun onEventOccured(boolean: Boolean)
}