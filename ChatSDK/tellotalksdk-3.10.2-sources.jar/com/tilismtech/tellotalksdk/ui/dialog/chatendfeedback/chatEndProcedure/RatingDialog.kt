package com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.chatEndProcedure

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentDetailResponse
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.databinding.ChatEndFeedabackPopupBinding
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager
import com.tilismtech.tellotalksdk.packages.emojiratingbar.EmojiRatingBar.OnRateChangeListener
import com.tilismtech.tellotalksdk.packages.emojiratingbar.RateStatus
import com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.listener.feedbackListener
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.Constant

class RatingDialog : DialogFragment() {


    private lateinit var ttMessage: TTMessage
    private  var agentDetailResponse: AgentDetailResponse? = null
    private lateinit var binding: ChatEndFeedabackPopupBinding
    private lateinit var account: TTAccount


    companion object {

        const val TAG = "ChatBotFormDialog"
        private var listener: feedbackListener? = null



        @JvmStatic
        fun newInstance(
            bundle: Bundle,
        ): RatingDialog {
            val args = Bundle()
            args.putBundle(Constant.bundle, bundle)
            val fragment = RatingDialog()
            fragment.arguments = args
            return fragment
        }

        @JvmStatic
        fun setYourInterface(listener: feedbackListener) {
            this.listener = listener
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let { it ->
            ttMessage = it.getBundle(Constant.bundle)
                ?.getParcelable(Constant.ttmessage)!!
            it.getBundle(Constant.bundle)
                ?.getParcelable<AgentDetailResponse>(Constant.agentDetailResponse)
                .also {
                    if (it != null) {
                        agentDetailResponse = it
                    }
                }
            TelloApiClient.getInstance()!!.getAccount()?.let {
                account = it
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = ChatEndFeedabackPopupBinding.inflate(inflater, container, false)
        isCancelable = false
        setViews()
        return binding.root
    }

    private fun setViews() {
        TelloPreferencesManager.getInstance().putBoolean(Constant.isAgentMsg, false)
        val s: String = if (agentDetailResponse != null) (getString(R.string.help) +" "+ agentDetailResponse?.profileName
                + getString(R.string.Understand_how_they_are_doing)) else (getString(R.string.help)+" "+ getString(R.string.chatbot)+" "
                        + getString(R.string.Understand_how_they_are_doing))
        binding.tvPopupTitle.text = s

        var rating_selected = ""

        binding.emojiRatingBar.setRateChangeListener(object : OnRateChangeListener {
            override fun onRateChanged(rateStatus: RateStatus) {
                when (rateStatus) {
                    RateStatus.AWFUL -> rating_selected = "101"
                    RateStatus.BAD -> rating_selected = "102"
                    RateStatus.OKAY -> rating_selected = "103"
                    RateStatus.GOOD -> rating_selected = "104"
                    RateStatus.GREAT -> rating_selected = "105"
                    RateStatus.EMPTY -> rating_selected = ""
                }
            }
        })


        binding.btnShareFeed.setOnClickListener(View.OnClickListener {
            if (!ApplicationUtils.isNetworkAvailable(requireContext())) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.no_internet_sdk),
                    Toast.LENGTH_SHORT
                ).show()
                return@OnClickListener
            } else if (rating_selected == "") {
                Toast.makeText(
                    requireContext(),
                    "Please rate your conversation",
                    Toast.LENGTH_SHORT
                ).show()
                return@OnClickListener
            }
            ChatManager.instance?.sendRating(
                requireActivity(),
                ttMessage.chatId,
                rating_selected.toInt(),
                binding.edtFeedback.text.toString()
            ) {
                if (it==true) {
                    ttMessage.isFeedback = true
                    ConversationActivityViewModel.getInstance().updateMessage(ttMessage)
                    val conversation = TTConversationRepository.getInstance()
                        .getConversationForJid(ttMessage.contactId)
                    conversation?.lastMessage = ttMessage
                    if (conversation != null) {
                        TTConversationRepository.getInstance()
                            .updateConversation(conversation)
                    }
                    binding.tvUserName.visibility = View.VISIBLE
                    binding.tvUserFeedbacl.visibility = View.VISIBLE
                    binding.btnShareFeed.visibility = View.GONE
                    binding.layFeedback.visibility = View.GONE
                    binding.tvUserName.text = buildString {
                        append(account.userName)
                        append(getString(R.string.feedback_username))
                    }
                    binding.tvUserFeedbacl.text = binding.edtFeedback.text.toString()
                    listener?.onEventOccured(true).apply {
                        dismiss()

                        //     binding.footerView.setVisibility(VISIBLE);
                        //   builderRating = null
                        //   binding.include.setVisibility(View.GONE)
                        //    binding.feedbackView.setVisibility(View.VISIBLE)
                        //     binding.tvSendMsg.setVisibility(View.VISIBLE)
                        //     lay_toolbar.findViewById<View>(R.id.lay_endchat)
                        //         .setVisibility(View.GONE)
                        //    (lay_toolbar.findViewById<View>(R.id.action_bar_title) as TextView).setText(
                        //        departmentID
                        //    )
                        //   ((TextView) lay_toolbar.findViewById(R.id.action_bar_title)).setText("TelloBot");
                        //    (lay_toolbar.findViewById<View>(R.id.action_bar_subtitle) as TextView).visibility =
                        //       View.GONE
                        //.setText(departmentID);
                        //    setImageDetails(lay_toolbar.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView)
                        //    (lay_toolbar.findViewById<View>(R.id.action_bar_image) as SimpleDraweeView).setImageURI(
                        //         dptImage
                        //      )
                        TelloPreferencesManager.getInstance().putString(ttMessage.chatId, null)

                    }
                    //   optionDialog.dismiss()
                }
            }
        })
    }


    override fun onStart() {
        super.onStart()

        val window: Window = dialog!!.window!!
        window.setGravity(Gravity.BOTTOM)
        // Set the dialog window's width and height to match_parent
        val params: WindowManager.LayoutParams = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        window.attributes = params

        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }


}