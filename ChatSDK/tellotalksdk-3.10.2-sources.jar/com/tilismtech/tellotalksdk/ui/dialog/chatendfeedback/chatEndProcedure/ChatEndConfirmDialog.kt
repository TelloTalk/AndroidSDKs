package com.tilismtech.tellotalksdk.ui.dialog.chatendfeedback.chatEndProcedure

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.viewModels
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.databinding.WcChatendBinding
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils
import com.tilismtech.tellotalksdk.utils.Constant
import java.util.Date

class ChatEndConfirmDialog : DialogFragment() {


    private lateinit var binding: WcChatendBinding
    private var chatID: String = ""
    private var conversationId: String = ""
    private val conversationViewModel: ConversationActivityViewModel by viewModels()


    companion object{
        @JvmStatic
        fun newInstance(bundle: Bundle): ChatEndConfirmDialog {
            val args = Bundle()
            args.putBundle(Constant.bundle, bundle)
            val fragment = ChatEndConfirmDialog()
            fragment.arguments = args
            return fragment
        }
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            chatID = it.getBundle(Constant.bundle)?.getString(Constant.chatID).toString()
            conversationId = it.getBundle(Constant.bundle)?.getString(Constant.conversationID).toString()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = WcChatendBinding.inflate(inflater, container, false)
        isCancelable = false
        setupView()
        return binding.root
    }

    private fun setupView() {
        if (ApplicationUtils.isAppEnglish) {
            binding.tvTitle.text = getString(R.string.chat_end_confirm_eng)
            binding.tvSubYes.setText(R.string.chat_end_confirm_yes_eng)
            binding.tvSubNo.setText(R.string.chat_end_confirm_no_eng)
        } else {
            binding.tvTitle.setText(R.string.chat_end_confirm_urdu)
            binding.tvSubYes.setText(R.string.chat_end_confirm_yes_urdu)
            binding.tvSubNo.setText(R.string.chat_end_confirm_no_urdu)
            val typeface =
                ResourcesCompat.getFont(requireContext(), R.font.calibri)
            binding.tvTitle.typeface = typeface
            binding.tvSubYes.typeface = typeface
            binding.tvSubNo.typeface = typeface
        }

        binding.tvSubYes.setOnClickListener {
            endAgentChat()
        }

        binding.tvSubNo.setOnClickListener {
            dismiss()
        }
    }

    private fun endAgentChat() {
        if (ApplicationUtils.isNetworkAvailable(requireContext())) {
            if (chatID == "") {
                chatID = TTMessageRepository.instance?.getMessage(
                    TTConversationRepository.getInstance()
                        .getConversationForJid(conversationId)?.lastMessageId
                )?.chatId?:""
            }
            ChatManager.instance?.endWebChat(
                chatID
            ) {
                if (it==true) {
                    createUserEndMessage()
                }
                setFragmentResult("chat_end_request", Bundle())
            }
        } else {
            if (ApplicationUtils.isAppEnglish) {
                Toast.makeText(
                    activity,
                    getString(R.string.chatend_internet_popup_eng),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    activity,
                    getString(R.string.chatend_internet_popup_urdu),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun createUserEndMessage() {
        val lastMsg = TTMessageRepository.instance?.getLastMessageOfConversation(conversationId)
        if(lastMsg?.msgType == TTMessage.MsgType.TYPE_CHATEND.value){
            return
        }
        val ttMessage = TTMessage()
        ttMessage.contactId = conversationId
        ttMessage.message = getString(R.string.chatend_user)
        ttMessage.isEdited = false
        if (chatID == "") {
            chatID = TTMessageRepository.instance?.getLastMessageOfConversation(conversationId)?.chatId?:""
        }
        ttMessage.chatId = chatID
        ttMessage.departmentId = conversationId
        ttMessage.conversationId = conversationId
        ttMessage.msgStatus = TTMessage.MsgStatus.DELIVERED
        ttMessage.msgDate = Date()
        ttMessage.systemDate = Date()
        ttMessage.msgType = TTMessage.MsgType.TYPE_CHATEND.value
        val conversation =
            TTConversationRepository.getInstance().getConversationForJid(ttMessage.contactId)
        if (conversation != null) {
            conversation.isHasMessage = true
            conversation.lastMessageId = ttMessage.messageId
            conversation.lastMessage = ttMessage
            TTConversationRepository.getInstance().updateConversation(conversation)
        }
        conversationViewModel.insertMessage(ttMessage.apply { this.chatId="" }).apply {
            chatID = ""
            TelloPreferencesManager.getInstance().putBoolean(Constant.isAgentMsg, false)
            TelloPreferencesManager.getInstance().putString("chatid", chatID)
            dismiss()
        }
    }

    override fun onStart() {
        super.onStart()
        val window: Window = dialog!!.window!!
        window.setGravity(Gravity.BOTTOM)
        // Set the dialog window's width and height to match_parent
        val params: WindowManager.LayoutParams = window.attributes
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        window.attributes = params
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }


}

