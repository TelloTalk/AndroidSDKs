package com.tilismtech.tellotalksdk.ui.recordview;

/**
 * Created by Devlomi on 13/01/2018.
 */

public interface OnBasketAnimationEnd {
    void onAnimationEnd();
}
