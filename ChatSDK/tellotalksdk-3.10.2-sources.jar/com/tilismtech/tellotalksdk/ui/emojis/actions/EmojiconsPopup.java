package com.tilismtech.tellotalksdk.ui.emojis.actions;

import static com.tilismtech.tellotalksdk.managers.TelloPreferencesManager.LANGUAGE_PRESERVED;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.listeners.OnEmojiconClickedListener;
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager;
import com.tilismtech.tellotalksdk.ui.activities.ConversationActivity;
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity;
import com.tilismtech.tellotalksdk.ui.adapters.CustomPagerAdapter;
import com.tilismtech.tellotalksdk.ui.adapters.EmojiGridAdapter;
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.AttachmentConfirmationActivity;
import com.tilismtech.tellotalksdk.ui.customviews.EditMessage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.OnSwipeTouchListener;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.BalochiKeyboardLanguage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.KeyboardLanguage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.PashtoKeyboardLanguage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.PunkabiKeyboardLanguage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.SaraikiKeyboardLanguage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.SindhiKeyboardLanguage;
import com.tilismtech.tellotalksdk.ui.locallangkeyboard.keyboard.UrduKeyboardLanguage;
import com.tilismtech.tellotalksdk.utils.AndroidUtilities;
import com.tilismtech.tellotalksdk.utils.ApplicationUtils;

import java.util.ArrayList;

public class EmojiconsPopup extends PopupWindow {
    private int keyBoardHeight = 0;
    private Boolean pendingOpen = false, isOpened = false, isCapsOn;
    private OnSoftKeyboardOpenCloseListener onSoftKeyboardOpenCloseListener;
    private View rootView;
    private TelloActivity mContext;
    private ViewPager emojisPager;
    private String inputStr = "";
    private EditMessage myText;
    private TextView[] myButton;
    private TextView langKey, symbolKey;
    private ImageButton shiftKey;
    private int check = 0, numCheck = 0, currentLanguageIndex = 0, isFirstLayer = 1, number = 1, editTextBoxLength;
    private static Typeface urduFont = null, engFont = null;
    private KeyboardLanguage[] Languages = {new UrduKeyboardLanguage(), new PunkabiKeyboardLanguage(), new SindhiKeyboardLanguage(), new PashtoKeyboardLanguage(), new SaraikiKeyboardLanguage(), new BalochiKeyboardLanguage()};
    private int cLang[] = {0, 1};//, 2, 3, 4, 5  //0 for urdu, 1 for sindhi, 2 for pashto, 3 for siraiki, 4 for balochi
    private CharSequence csq[] = {"English", "Urdu"};//"Punjabi", "Sindhi", "Pashto", "Saraiki", "Balochi"
    private TelloPreferencesManager appPreference;
    private String URDU_SYMBOL = "اب", ENGLISH_SYMBOL = "SYM";
    private ImageView backSpaceButton;
    private boolean backspacePressed, backspaceOnce, isKeyboard = false;
    private OnEmojiconClickedListener mOnEmojiconClickedListener;
    private ArrayList<View> views = new ArrayList<>();
    private RelativeLayout emojiContainer;
    private TableLayout keyboardContainer;

    public enum ELanguages {
        URDU,
        PUNJABI,
        SINDHI,
        PASHTO,
        SARAIKI,
        BALOCHI
    }

    EmojiconsPopup(View rootView, TelloActivity mContext, OnEmojiconClickedListener listener) {
        super(mContext);
        mOnEmojiconClickedListener = listener;
        this.mContext = mContext;
        this.rootView = rootView;
        View customView = createCustomView();
        setContentView(customView);
        setSoftInputMode(LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        setSize(LayoutParams.MATCH_PARENT, AndroidUtilities.dp(260));
        setBackgroundDrawable(null);
    }

    void setOnSoftKeyboardOpenCloseListener(OnSoftKeyboardOpenCloseListener listener) {
        this.onSoftKeyboardOpenCloseListener = listener;
    }

    void showAtBottom() {
        showAtLocation(rootView, Gravity.BOTTOM, 0, 0);
    }

    void showAtBottomPending() {
        if (isKeyBoardOpen())
            showAtBottom();
        else
            pendingOpen = true;
    }

    Boolean isKeyBoardOpen() {
        return isOpened;
    }

    @Override
    public void dismiss() {
        super.dismiss();
    }

    void setSizeForSoftKeyboard() {
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime());
            boolean isKeyboardVisible = insets.isVisible(WindowInsetsCompat.Type.ime());

            if (isKeyboardVisible) {
                int keyboardHeight = imeInsets.bottom;
                if (!isOpened) {
                    if (onSoftKeyboardOpenCloseListener != null) {
                        onSoftKeyboardOpenCloseListener.onKeyboardOpen(keyboardHeight);
                    }
                }
                isOpened = true;
                if (pendingOpen) {
                    showAtBottom();
                    pendingOpen = false;
                }
            } else {
                isOpened = false;
                if (onSoftKeyboardOpenCloseListener != null)
                    onSoftKeyboardOpenCloseListener.onKeyboardClose();
            }

            return insets;

        });
    }

    private int getUsableScreenHeight() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                DisplayMetrics metrics = new DisplayMetrics();
                Point screenSize = new Point();
                WindowManager windowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
                if (windowManager != null) {
//                windowManager.getDefaultDisplay().getMetrics(metrics);
                    windowManager.getDefaultDisplay().getSize(screenSize);
                }
                return screenSize.y;
            } else {
                return rootView.getRootView().getHeight();
            }
        }catch (Exception e){
            e.printStackTrace();
            return rootView.getRootView().getHeight();
        }
    }

    private void setSize(int width, int height) {
        setWidth(width);
        setHeight(height);
    }

    private void postBackspaceRunnable(final int time, final View v) {
        new Handler().postDelayed(() -> {
            if (!backspacePressed) {
                return;
            }
            if (mOnEmojiconClickedListener != null) {
                mOnEmojiconClickedListener.onBackSpace();
            }
            backspaceOnce = true;
            postBackspaceRunnable(Math.max(50, time - 100), v);
        }, time);
    }

    public boolean isKeyboard() {
        return isKeyboard;
    }

    void showEmojis(boolean showEmoji) {
        if (showEmoji) {
            isKeyboard = false;
            emojiContainer.setVisibility(View.VISIBLE);
            keyboardContainer.setVisibility(View.GONE);
        } else {
            isKeyboard = true;
            emojiContainer.setVisibility(View.GONE);
            keyboardContainer.setVisibility(View.VISIBLE);
            myText.requestFocus();
        }
    }

    private View createCustomView() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.fragment_main_pager, null, false);
        emojiContainer = view.findViewById(R.id.emoji_container);
        keyboardContainer = view.findViewById(R.id.keyboard_layout);
        emojisPager = view.findViewById(R.id.pager);
        TabLayout tabLayout = view.findViewById(R.id.tab_layout);
        backSpaceButton = view.findViewById(R.id.emoji_back_spc);
        backSpaceButton.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                backSpaceButton.setBackgroundColor(0x59d1d6d9);
                backspacePressed = true;
                backspaceOnce = false;
                postBackspaceRunnable(350, backSpaceButton);
            } else if (event.getAction() == MotionEvent.ACTION_CANCEL || event.getAction() == MotionEvent.ACTION_UP) {
                backSpaceButton.setBackgroundColor(Color.TRANSPARENT);
                backspacePressed = false;
                if (!backspaceOnce) {
                    if (mOnEmojiconClickedListener != null) {
                        mOnEmojiconClickedListener.onBackSpace();
                    }
                }
            }
            return true;
        });
        for (int i = 0; i < 5; i++) {
            GridView gridView = new GridView(view.getContext());
            if (AndroidUtilities.isTablet()) {
                gridView.setColumnWidth(AndroidUtilities.dp(44));
            } else {
                gridView.setColumnWidth(AndroidUtilities.dp(40));
            }
            gridView.setNumColumns(8);
            gridView.setBackgroundColor(0xfff5f6f7);
            final EmojiGridAdapter emojiGridAdapter = new EmojiGridAdapter(i, view.getContext(), mOnEmojiconClickedListener);
//            AndroidUtilities.setListViewEdgeEffectColor(gridView, 0xfff5f6f7);
            gridView.setAdapter(emojiGridAdapter);
            views.add(gridView);
            emojiGridAdapter.notifyDataSetChanged();
            final View view1 = inflater.inflate(R.layout.tab_icon, null);
            try {
                if (i == 0) {
                    ((ImageView) view1.findViewById(R.id.icon)).setImageDrawable(ResourcesCompat.getDrawable(view.getContext().getResources(), R.drawable.ic_emoji_smile, null));//getResources().getDrawable(R.drawable.ic_emoji_smile)
                } else if (i == 1) {
                    ((ImageView) view1.findViewById(R.id.icon)).setImageDrawable(ResourcesCompat.getDrawable(view.getContext().getResources(), R.drawable.ic_emoji_flower, null));//getResources().getDrawable(R.drawable.ic_emoji_flower)
                } else if (i == 2) {
                    ((ImageView) view1.findViewById(R.id.icon)).setImageDrawable(ResourcesCompat.getDrawable(view.getContext().getResources(), R.drawable.ic_emoji_bell, null));//getResources().getDrawable(R.drawable.ic_emoji_bell)
                } else if (i == 3) {
                    ((ImageView) view1.findViewById(R.id.icon)).setImageDrawable(ResourcesCompat.getDrawable(view.getContext().getResources(), R.drawable.ic_emoji_car, null));//getResources().getDrawable(R.drawable.ic_emoji_car)
                } else if (i == 4) {
                    ((ImageView) view1.findViewById(R.id.icon)).setImageDrawable(ResourcesCompat.getDrawable(view.getContext().getResources(), R.drawable.ic_emoji_symbol, null));//getResources().getDrawable(R.drawable.ic_emoji_symbol)
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            tabLayout.addTab(tabLayout.newTab().setCustomView(view1));
            emojisPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
            tabLayout.setClickable(false);
            int a;
            tabLayout.addOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    emojisPager.setCurrentItem(tab.getPosition());
                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {

                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {

                }
            });


//            tabLayout.setOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener<>().OnTabSelectedListener() {
//                @Override
//                public void onTabSelected(TabLayout.Tab tab) {
//
//                }
//
//                @Override
//                public void onTabUnselected(TabLayout.Tab tab) {
//                }
//
//                @Override
//                public void onTabReselected(TabLayout.Tab tab) {
//                }
//            });
        }
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setSelectedTabIndicatorColor(ContextCompat.getColor(view.getContext(), R.color.indicator));
        CustomPagerAdapter customPagerAdapter = new CustomPagerAdapter(views);
        emojisPager.setAdapter(customPagerAdapter);
        customPagerAdapter.notifyDataSetChanged();
        setUpKeyboardView(view);
        return view;
    }

    private void setUpKeyboardView(View view) {
        try {
            appPreference = TelloPreferencesManager.getInstance();
            myButton = new TextView[37];
            int[] buttonIds = {R.id.row2_btn1, R.id.row2_btn2, R.id.row2_btn3, R.id.row2_btn4, R.id.row2_btn5, R.id.row2_btn6, R.id.row2_btn7, R.id.row2_btn8, R.id.row2_btn9, R.id.row2_btn10,
                    R.id.row3_btn1, R.id.row3_btn2, R.id.row3_btn3, R.id.row3_btn4, R.id.row3_btn5, R.id.row3_btn6, R.id.row3_btn7, R.id.row3_btn8, R.id.row3_btn9,
                    R.id.row4_btn2, R.id.row4_btn3, R.id.row4_btn4, R.id.row4_btn5, R.id.row4_btn6, R.id.row4_btn7, R.id.row4_btn8, R.id.row5_btn4,
                    R.id.row1_btn1, R.id.row1_btn2, R.id.row1_btn3, R.id.row1_btn4, R.id.row1_btn5, R.id.row1_btn6, R.id.row1_btn7, R.id.row1_btn8, R.id.row1_btn9, R.id.row1_btn10};
            for (int i = 0; i < 37; ++i) {
                myButton[i] = view.findViewById(buttonIds[i]);
                myButton[i].setTypeface(engFont);
                myButton[i].setOnClickListener(v -> {
                    inputStr = (String) v.getTag();
                    if (myText != null) {
                        if (editTextBoxLength == 0 && currentLanguageIndex == 0 && !isCapsOn && isFirstLayer == 1) {
                            myText.append(inputStr);
                            number = 1;
                            currentLanguageIndex = 0;
                            setLayer(cLang[currentLanguageIndex], number);
                        } else {
                            int start = Math.max(myText.getSelectionStart(), 0);
                            int end = Math.max(myText.getSelectionEnd(), 0);
                            myText.getText().replace(Math.min(start, end), Math.max(start, end), inputStr, 0, inputStr.length());
                        }
                    }
                });
            }
            isCapsOn = false;
            if (mContext instanceof ConversationActivity) {
                myText = ((ConversationActivity) mContext).getEditText();
            } else if (mContext instanceof AttachmentConfirmationActivity) {
                myText = ((AttachmentConfirmationActivity) mContext).getEditText();
            }
            if (myText != null) {
                editTextBoxLength = myText.length();
            } else {
                editTextBoxLength = 0;
            }
            ImageButton backspace = view.findViewById(R.id.row4_btn9);
            ImageButton spacebar = view.findViewById(R.id.row5_btn3);
            shiftKey = view.findViewById(R.id.row4_btn1);
            ImageButton enterKey = view.findViewById(R.id.row5_btn5);
            langKey = view.findViewById(R.id.row5_btn1);
            langKey.setTypeface(urduFont);
            symbolKey = view.findViewById(R.id.row5_btn2);
            langKey.setOnClickListener(v -> showLanguageDialog());
            isFirstLayer = 1;
            spacebar.setOnTouchListener(new OnSwipeTouchListener(view.getContext()) {

                @Override
                public void onSwipeLeft() {
                    try {
                        currentLanguageIndex = currentLanguageIndex - 1;
                        if (currentLanguageIndex <= -1) {
                            currentLanguageIndex = 0;
                        }
                        changeLanguage(currentLanguageIndex, true);
                        numCheck = 0;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onSwipeRight() {
                    try {
                        currentLanguageIndex = currentLanguageIndex + 1;
                        if (currentLanguageIndex >= 1) {
                            currentLanguageIndex = 0;
                        }
                        changeLanguage(currentLanguageIndex, true);
                        numCheck = 0;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            });
            spacebar.setOnClickListener(v -> {
                try {
                    inputStr = (String) v.getTag();
                    if (myText != null) {
                        int start = Math.max(myText.getSelectionStart(), 0);
                        int end = Math.max(myText.getSelectionEnd(), 0);
                        myText.getText().replace(Math.min(start, end), Math.max(start, end), inputStr, 0, inputStr.length());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            enterKey.setOnClickListener(v -> {
                try {
                    inputStr = (String) v.getTag();
                    if (myText != null) {
                        int start = Math.max(myText.getSelectionStart(), 0);
                        int end = Math.max(myText.getSelectionEnd(), 0);
                        myText.getText().replace(Math.min(start, end), Math.max(start, end), inputStr, 0, inputStr.length());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            backspace.setOnClickListener(v -> {
                if (myText != null) {
                    myText.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL));
                }
            });
            backspace.setOnLongClickListener(v -> {
                if (myText != null) {
                    CharSequence chseq = myText.getText();
                    if (chseq != null && chseq.length() > 0) {
                        int start = Math.max(myText.getSelectionStart(), 0);
                        int end = Math.max(myText.getSelectionEnd(), 0);
                        myText.getText().delete(0, Math.min(start, end));
                        editTextBoxLength = myText.length();
                        englishLetterCap();
                    }
                }
                return true;
            });
            shiftKey.setOnClickListener(v -> {
                try {
                    isFirstLayer = 1;
                    symbolKey.setTypeface(engFont);
                    symbolKey.setTextSize(15);
                    symbolKey.setText("SYM");
                    if (currentLanguageIndex < 0 || currentLanguageIndex > cLang.length) {
                        return;
                    }
                    if (cLang[currentLanguageIndex] == ELanguages.URDU.ordinal() ||
                            cLang[currentLanguageIndex] == ELanguages.PUNJABI.ordinal()
                            || cLang[currentLanguageIndex] == ELanguages.SINDHI.ordinal()
                            || cLang[currentLanguageIndex] == ELanguages.PASHTO.ordinal()
                            || cLang[currentLanguageIndex] == ELanguages.SARAIKI.ordinal()
                            || cLang[currentLanguageIndex] == ELanguages.BALOCHI.ordinal()) {
                        ChnageKeyBoardLayerOnShiftKey(urduFont);
                        setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            symbolKey.setOnClickListener(v -> {
                try {
                    if (numCheck == 0) {
                        for (int i = 27, j = 0; i < 37 && j < 10; ++i, ++j) {
                            setPropertiesForButton(myButton[i], urduFont, Languages[1].getNumeric(j));
                        }
                        for (int i = 0, j = 1; i < 26; ++i) {
                            if (i == 6 || i == 7 || i == 8 || i == 9) {
                                myButton[i].setTypeface(urduFont);
                            } else {
                                myButton[i].setTypeface(engFont);
                            }
                            myButton[i].setText(Languages[j].getSpecialChar(i));
                            myButton[i].setTag(Languages[j].getSpecialChar(i));
                        }
                        setPropertiesForButton(symbolKey, urduFont, Typeface.NORMAL, URDU_SYMBOL, 19);
                        isFirstLayer = 2;
                        numCheck = 1;
                    } else {
                        if (myText != null) {
                            editTextBoxLength = myText.length();
                        } else {
                            editTextBoxLength = 0;
                        }
                        if (cLang[currentLanguageIndex] == ELanguages.URDU.ordinal() || cLang[currentLanguageIndex] == ELanguages.SINDHI.ordinal()
                                || cLang[currentLanguageIndex] == ELanguages.PASHTO.ordinal() || cLang[currentLanguageIndex] == ELanguages.SARAIKI.ordinal()
                                || cLang[currentLanguageIndex] == ELanguages.BALOCHI.ordinal()) {
                            setLayer(cLang[currentLanguageIndex], number);
                        }
                        setPropertiesForButton(symbolKey, engFont, Typeface.NORMAL, ENGLISH_SYMBOL, 15);
                        isFirstLayer = 1;
                        numCheck = 0;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            currentLanguageIndex = appPreference.getInt(LANGUAGE_PRESERVED);
            changeLanguage(currentLanguageIndex, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ChnageKeyBoardLayerOnShiftKey(Typeface typeface) {
        try {
            numCheck = 0;
            if (check == 0) {
                number = 2;
                setLayer(cLang[currentLanguageIndex], number);
                check = 1;
                isCapsOn = true;
                shiftKey.setImageResource(R.drawable.shift_caps_on_sdk);
            } else {
                number = 1;
                setLayer(cLang[currentLanguageIndex], number);
                langKey.setTypeface(typeface);
                check = 0;
                isCapsOn = false;
                shiftKey.setImageResource(R.drawable.shift_caps_off_sdk);
            }
            langKey.setTypeface(engFont);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void setKeyboardLanguage(int i) {
        changeLanguage(i, false);
        showEmojis(false);
    }

    private void changeLanguage(int index, boolean notify) {
        try {
            if (index < 0) {
                appPreference.setIntValue(LANGUAGE_PRESERVED, index);
                if (notify) {
                    notifyLanguageChange(currentLanguageIndex);
                }
                return;
            }
            currentLanguageIndex = index;
            if (myText != null) {
                editTextBoxLength = myText.length();
            } else {
                editTextBoxLength = 0;
            }

            if (index > 1) {
                if (ApplicationUtils.isAppEnglish()) {
                    index = 0;
                } else {
                    index = 1;
                }
            }
            appPreference.setIntValue(LANGUAGE_PRESERVED, index);
            if (cLang[index] == ELanguages.URDU.ordinal()) {        //CHECK FOR URDU
                number = 1;
                setLayer(cLang[index], number);
                setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                langKey.setTypeface(urduFont);
            } else if (cLang[index] == ELanguages.PUNJABI.ordinal()) {          //CHECK FOR SINDHI
                number = 1;
                setLayer(cLang[index], number);
                setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                langKey.setTypeface(urduFont);
            } else if (cLang[index] == ELanguages.SINDHI.ordinal()) {          //CHECK FOR SINDHI
                number = 1;
                setLayer(cLang[index], number);
                setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                langKey.setTypeface(urduFont);
            } else if (cLang[index] == ELanguages.PASHTO.ordinal()) {          //CHECK FOR PASHTO
                number = 1;
                setLayer(cLang[index], number);
                setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                langKey.setTypeface(urduFont);
            } else if (cLang[index] == ELanguages.SARAIKI.ordinal()) {         //CHECK FOR SARAIKI
                number = 1;
                setLayer(cLang[index], number);
                setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                langKey.setTypeface(urduFont);
            } else if (cLang[index] == ELanguages.BALOCHI.ordinal()) {
                number = 1;
                setLayer(cLang[index], number);
                setPropertiesForButton(myButton[26], urduFont, Typeface.BOLD, "۔", 0);
                langKey.setTypeface(urduFont);
            }
            langKey.setText(Languages[index].getName());
            isFirstLayer = 1;
            for (int i = 27, j = 0; i < 37 && j < 10; ++i, ++j) {
                setPropertiesForButton(myButton[i], urduFont, Languages[1].getNumeric(j));
            }
            if (isFirstLayer == 1) {
                setPropertiesForButton(symbolKey, engFont, Typeface.NORMAL, ENGLISH_SYMBOL, 15);
            } else {
                setPropertiesForButton(symbolKey, urduFont, Typeface.NORMAL, URDU_SYMBOL, 19);
            }
            if (myText != null) {
                editTextBoxLength = myText.length();
            } else {
                editTextBoxLength = 0;
            }
            if (notify) {
                notifyLanguageChange(currentLanguageIndex);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void notifyLanguageChange(int currentLanguageIndex) {
        if (onSoftKeyboardOpenCloseListener != null)
            onSoftKeyboardOpenCloseListener.onKeyboardLanguageChangeListener(currentLanguageIndex);
    }

    private void showLanguageDialog() {
        AlertDialog.Builder alt_bld = new AlertDialog.Builder(mContext);
        alt_bld.setTitle("Select Language");
        int selection;
        selection = currentLanguageIndex + 1;
        alt_bld.setSingleChoiceItems(csq, selection, (dialog, item) -> {
            try {
                if (item == 0) {
                    notifyLanguageChange(-1);
                    currentLanguageIndex = -1;
                } else {
                    changeLanguage(item - 1, true);
                }
                dialog.dismiss();// dismiss the alertbox after chose option
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        AlertDialog alert = alt_bld.create();
        alert.show();
    }

    int getCurrentLanguageIndex() {
        return currentLanguageIndex;
    }

    private void englishLetterCap() {
        if (editTextBoxLength == 0 && currentLanguageIndex == 0) {
            number = 2;
            currentLanguageIndex = 0;
            setLayer(cLang[currentLanguageIndex], number);
        }
    }

    private void setLayer(int indexOfLang, int layerNumber) {
        if (indexOfLang >= 0 && indexOfLang < 6 && layerNumber == 1) {
            for (int i = 0; i < 26; ++i) {
                setPropertiesForButton(myButton[i], urduFont, Languages[indexOfLang].getFirstLayer(i));
            }
        } else if (indexOfLang >= 0 && indexOfLang < 6 && layerNumber == 2) {
            for (int i = 0; i < 26; ++i) {
                setPropertiesForButton(myButton[i], urduFont, Languages[indexOfLang].getSecondLayer(i));
            }
        }
    }

    private void setPropertiesForButton(TextView button, Typeface typeface, String text) {
        setPropertiesForButton(button, typeface, Typeface.NORMAL, text, 0);
    }

    private void setPropertiesForButton(TextView button, Typeface typeface, int style, String text, int size) {
        button.setTypeface(typeface, style);
        button.setText(text);
        button.setTag(text);
        if (size != 0) {
            button.setTextSize(15);
        }
    }

    public interface OnSoftKeyboardOpenCloseListener {
        void onKeyboardOpen(int keyBoardHeight);

        void onKeyboardClose();

        void onKeyboardLanguageChangeListener(int index);
    }
}