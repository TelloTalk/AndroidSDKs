package com.tilismtech.tellotalksdk.ui.emojis.actions;

import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.tilismtech.tellotalksdk.R;
import com.tilismtech.tellotalksdk.listeners.OnEmojiconClickedListener;
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity;
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.AttachmentConfirmationActivity;
import com.tilismtech.tellotalksdk.ui.customviews.EditMessage;

public class EmojIconActions implements View.OnFocusChangeListener {

    private EmojiconsPopup popup;
    private TelloActivity context;
    private View rootView;
    private ImageView emojiButton;
    private int SmileyIcons = R.drawable.emoji_icon_sdk;
    private KeyboardListener keyboardListener;
    private EditMessage emojiconEditText;
    private OnEmojiconClickedListener listener;
    private boolean isTelloKeyboard;

    public EmojIconActions(TelloActivity ctx, View rootView, EditMessage emojiconEditText,
                           ImageButton emojiButton, OnEmojiconClickedListener listener, boolean isTelloKeyboard) {
        this.rootView = rootView;
        this.emojiButton = emojiButton;
        this.context = ctx;
        this.emojiconEditText = emojiconEditText;
        this.listener = listener;
        this.isTelloKeyboard = isTelloKeyboard;
        this.emojiButton.setOnClickListener(v -> changeUiForKeyboard(true));
        this.emojiconEditText.setOnClickListener(v -> showTelloKeyboard());

    }

    public void ShowEmojIcon() {
        if(popup == null){
            this.popup = new EmojiconsPopup(rootView, context, listener);
            ShowEmojIcon();
        }
        //Will automatically set size according to the soft keyboard size
        popup.setSizeForSoftKeyboard();
        //If the emoji popup is dismissed, change emojiButton to smiley icon
        popup.setOnDismissListener(() -> changeEmojiKeyboardIcon(emojiButton, SmileyIcons));

        //If the text keyboard closes, also dismiss the emoji popup
        popup.setOnSoftKeyboardOpenCloseListener(new EmojiconsPopup.OnSoftKeyboardOpenCloseListener() {

            @Override
            public void onKeyboardOpen(int keyBoardHeight) {
                if (keyboardListener != null)
                    keyboardListener.onKeyboardOpen();
                emojiconEditText.setFocusableInTouchMode(true);
            }

            @Override
            public void onKeyboardClose() {
                if (keyboardListener != null)
                    keyboardListener.onKeyboardClose();
                if (popup.isShowing())
                    popup.dismiss();
                emojiconEditText.setFocusableInTouchMode(false);
            }

            @Override
            public void onKeyboardLanguageChangeListener(int index) {
                if (keyboardListener != null) {
                    keyboardListener.onKeyboardLanguageChange(index + 1);
                }
            }
        });
        popup.notifyLanguageChange(popup.getCurrentLanguageIndex());
        // To toggle between text keyboard and emoji keyboard keyboard(Popup)
//        showForEditText();
    }

    public void setPopupDismiss(){
        if(popup!=null){
            if (popup.isShowing()) {
                popup.dismiss();
                popup = null;
            }
        }
    }

//    private void showForEditText() {
//        emojiButton.setOnClickListener(v -> changeUiForKeyboard(true));
//        emojiconEditText.setOnClickListener(v -> showTelloKeyboard());
//    }

    private void changeUiForKeyboard(boolean showEmoji) {
        if(popup == null){
            this.popup = new EmojiconsPopup(rootView, context, listener);
            ShowEmojIcon();
        }
        //If popup is not showing => emoji keyboard is not visible, we need to show it
        int keyBoardIcon = R.drawable.keyboard_icon_sdk;
        if (!popup.isShowing()) {
            //If keyboard is visible, simply show the emoji popup
            if (popup.isKeyBoardOpen()) {
                popup.showEmojis(showEmoji);
                popup.showAtBottom();
                if (showEmoji) {
                    changeEmojiKeyboardIcon(emojiButton, keyBoardIcon);
                } else {
                    changeEmojiKeyboardIcon(emojiButton, SmileyIcons);
                }
            }
            //else, open the text keyboard first and immediately after that show the
            // emoji popup
            else {
                if (showEmoji) {
                    popup.showEmojis(true);
                    openKeyboard();
                    popup.showAtBottomPending();
                    changeEmojiKeyboardIcon(emojiButton, keyBoardIcon);
                }
            }
        }
        //If popup is showing, simply dismiss it to show the undelying text keyboard
        else {
            if (isTelloKeyboard()) {
                if (!showEmoji) {
                    changeEmojiKeyboardIcon(emojiButton, SmileyIcons);
                    popup.showEmojis(false);
                    popup.showAtBottomPending();
                    return;
                }
                if (popup.isKeyboard()) {
                    popup.showEmojis(true);
                    changeEmojiKeyboardIcon(emojiButton, keyBoardIcon);
                } else {
                    changeEmojiKeyboardIcon(emojiButton, SmileyIcons);
                    popup.showEmojis(false);
                }
            } else {
                changeEmojiKeyboardIcon(emojiButton, keyBoardIcon);
                popup.dismiss();
            }
        }
    }

    private void openKeyboard() {
        emojiconEditText.setFocusableInTouchMode(true);
        emojiconEditText.requestFocus();
//        if (isTelloKeyboard()) {
//            popup.showAtBottomPending();
//        }
        final InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.showSoftInput(emojiconEditText, InputMethodManager.SHOW_IMPLICIT);
        }
//        emojiconEditText.setFocusableInTouchMode(false);
    }

    public void showTelloKeyboard() {
//        if(popup == null){
//            this.popup = new EmojiconsPopup(rootView, context, listener);
//            ShowEmojIcon();
//        }

        if (context instanceof AttachmentConfirmationActivity){
            ((AttachmentConfirmationActivity)context).performEditMessageClick();
        }
        if (!popup.isShowing()) {
            openKeyboard();
            popup.showEmojis(false);
            changeEmojiKeyboardIcon(emojiButton, SmileyIcons);
        }
        //If popup is showing, simply dismiss it to show the undelying text keyboard
        else {
            if (isTelloKeyboard()) {
                popup.showEmojis(false);
                changeEmojiKeyboardIcon(emojiButton, SmileyIcons);
            } else {
                popup.dismiss();
            }
        }
    }

    public void closeEmojIcon() {
        if (popup != null && popup.isShowing())
            popup.dismiss();
    }

    private void changeEmojiKeyboardIcon(ImageView iconToBeChanged, int drawableResourceId) {
        iconToBeChanged.setImageResource(drawableResourceId);
    }

    @Override
    public void onFocusChange(View view, boolean hasFocus) {
        if (hasFocus) {
            if (view instanceof EditMessage) {
                emojiconEditText = (EditMessage) view;
            }
        }
    }

    public void setKeyboardIndex(int keyboardSelectedIndex) {
        popup.setKeyboardLanguage(keyboardSelectedIndex - 1);
    }

    public interface KeyboardListener {
        void onKeyboardOpen();
        void onKeyboardClose();
        void onKeyboardLanguageChange(int index);
    }

    public void setKeyboardListener(KeyboardListener listener) {
        this.keyboardListener = listener;
    }

    private boolean isTelloKeyboard() {
        return isTelloKeyboard;
    }

    public void setTelloKeyboard(boolean telloKeyboard) {
        isTelloKeyboard = telloKeyboard;
        changeUiForKeyboard(false);
    }
}