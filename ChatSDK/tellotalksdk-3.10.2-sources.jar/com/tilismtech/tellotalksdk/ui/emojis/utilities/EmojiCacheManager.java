package com.tilismtech.tellotalksdk.ui.emojis.utilities;

import android.util.LruCache;

/**
 * Created by sohailahmed on 07/03/2017.
 */

public class EmojiCacheManager {

    private static LruCache<CharSequence , Emoji.EmojiDrawable> emojiCache = new LruCache(500);

    public static Emoji.EmojiDrawable get(CharSequence cs){
        return emojiCache.get(cs);
    }

    public static void put(CharSequence cs, Emoji.EmojiDrawable d){
        emojiCache.put(cs,d);
    }




}
