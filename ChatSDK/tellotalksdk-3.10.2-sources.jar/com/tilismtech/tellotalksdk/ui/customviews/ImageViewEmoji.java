package com.tilismtech.tellotalksdk.ui.customviews;

import android.content.Context;
import android.view.MotionEvent;

public class ImageViewEmoji extends androidx.appcompat.widget.AppCompatImageView {

        public ImageViewEmoji(Context context) {
            super(context);

            setScaleType(ScaleType.CENTER);
        }

        @Override
        public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(widthMeasureSpec));
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            return super.onTouchEvent(event);
        }
    }