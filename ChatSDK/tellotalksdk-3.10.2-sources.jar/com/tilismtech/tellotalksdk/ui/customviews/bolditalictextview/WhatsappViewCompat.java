package com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview;

import android.graphics.Color;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;

import java.util.ArrayList;

import static com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsappUtil.BOLD_FLAG;
import static com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsappUtil.INVALID_INDEX;
import static com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsappUtil.ITALIC_FLAG;
import static com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsappUtil.STRIKE_FLAG;


public class WhatsappViewCompat {
    
    /**
     * Performs formatting on the given text.
     *
     * @param text - input sequence.
     * @return formatted sequence.
     */
    public static CharSequence extractFlagsForTextView(CharSequence text) {

        char[] textChars = text.toString().toCharArray();
        ArrayList<Character> characters = new ArrayList<>();
        ArrayList<WhatsappUtil.Flag> flags = new ArrayList<>();

        WhatsappUtil.Flag boldFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, BOLD_FLAG);
        WhatsappUtil.Flag strikeFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, STRIKE_FLAG);
        WhatsappUtil.Flag italicFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, ITALIC_FLAG);


        for (int i = 0, j = 0; i < textChars.length; i++) {
            char c = textChars[i];

            if (c == BOLD_FLAG) {
                if (boldFlag.start == INVALID_INDEX) {
                    if (WhatsappUtil.hasFlagSameLine(text, BOLD_FLAG, i + 1)) {
                        boldFlag.start = j;
                        continue;
                    }
                } else {
                    boldFlag.end = j;
                    flags.add(boldFlag);
                    boldFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, BOLD_FLAG);
                    continue;
                }
            }
            if (c == STRIKE_FLAG) {
                if (strikeFlag.start == INVALID_INDEX) {
                    if (WhatsappUtil.hasFlagSameLine(text, STRIKE_FLAG, i + 1)) {
                        strikeFlag.start = j;
                        continue;
                    }
                } else {
                    strikeFlag.end = j;
                    flags.add(strikeFlag);
                    strikeFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, STRIKE_FLAG);
                    continue;
                }
            }
            if (c == ITALIC_FLAG) {
                if (italicFlag.start == INVALID_INDEX) {
                    if (WhatsappUtil.hasFlagSameLine(text, ITALIC_FLAG, i + 1)) {
                        italicFlag.start = j;
                        continue;
                    }
                } else {
                    italicFlag.end = j;
                    flags.add(italicFlag);
                    italicFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, ITALIC_FLAG);
                    continue;
                }
            }
            characters.add(c);
            j++;
        }

        String formatted = WhatsappUtil.getText(characters);
        SpannableStringBuilder builder = new SpannableStringBuilder(formatted);


        for (int i = 0; i < flags.size(); i++) {

            WhatsappUtil.Flag flag = flags.get(i);

            if (flag.flag == BOLD_FLAG) {
                StyleSpan bss = new StyleSpan(Typeface.BOLD);
                builder.setSpan(bss, flag.start, flag.end, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            } else if (flag.flag == STRIKE_FLAG) {
                builder.setSpan(new StrikethroughSpan(), flag.start, flag.end, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            } else if (flag.flag == ITALIC_FLAG) {
                StyleSpan iss = new StyleSpan(Typeface.ITALIC);
                builder.setSpan(iss, flag.start, flag.end, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            }
        }

        return builder;
    }


    /**
     * Performs formatting on the given text.
     *
     * @param text - input sequence.
     * @return formatted sequence.
     */
    public static CharSequence extractFlagsForEditText(CharSequence text) {

        char[] textChars = text.toString().toCharArray();
        ArrayList<Character> characters = new ArrayList<>();
        ArrayList<WhatsappUtil.Flag> flags = new ArrayList<>();

        WhatsappUtil.Flag boldFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, BOLD_FLAG);
        WhatsappUtil.Flag strikeFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, STRIKE_FLAG);
        WhatsappUtil.Flag italicFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, ITALIC_FLAG);


        for (int i = 0, j = 0; i < textChars.length; i++) {
            char c = textChars[i];

            if (c == BOLD_FLAG) {
                if (boldFlag.start == INVALID_INDEX) {
                    if (WhatsappUtil.hasFlagSameLine(text, BOLD_FLAG, i + 1)) {
                        boldFlag.start = j + 1;
                    }
                } else {
                    boldFlag.end = j;
                    flags.add(boldFlag);
                    boldFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, BOLD_FLAG);
                }
            } else if (c == STRIKE_FLAG) {
                if (strikeFlag.start == INVALID_INDEX) {
                    if (WhatsappUtil.hasFlagSameLine(text, STRIKE_FLAG, i + 1)) {
                        strikeFlag.start = j + 1;
                    }
                } else {
                    strikeFlag.end = j;
                    flags.add(strikeFlag);
                    strikeFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, STRIKE_FLAG);
                }
            } else if (c == ITALIC_FLAG) {
                if (italicFlag.start == INVALID_INDEX) {
                    if (WhatsappUtil.hasFlagSameLine(text, ITALIC_FLAG, i + 1)) {
                        italicFlag.start = j + 1;
                    }
                } else {
                    italicFlag.end = j;
                    flags.add(italicFlag);
                    italicFlag = new WhatsappUtil.Flag(INVALID_INDEX, INVALID_INDEX, ITALIC_FLAG);
                }
            }
            characters.add(c);
            j++;
        }

        String formatted = WhatsappUtil.getText(characters);
        SpannableStringBuilder builder = new SpannableStringBuilder(formatted);


        for (int i = 0; i < flags.size(); i++) {

            WhatsappUtil.Flag flag = flags.get(i);
            if (flag.flag == BOLD_FLAG) {
                StyleSpan bss = new StyleSpan(Typeface.BOLD);
                builder.setSpan(bss, flag.start, flag.end, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(Color.GRAY), flag.start-1, flag.start, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(Color.GRAY), flag.end, flag.end+1, Spanned.SPAN_INCLUSIVE_INCLUSIVE);

            } else if (flag.flag == STRIKE_FLAG) {
                builder.setSpan(new StrikethroughSpan(), flag.start, flag.end, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(Color.GRAY), flag.start-1, flag.start, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(Color.GRAY), flag.end, flag.end+1, Spanned.SPAN_INCLUSIVE_INCLUSIVE);

            } else if (flag.flag == ITALIC_FLAG) {
                StyleSpan iss = new StyleSpan(Typeface.ITALIC);
                builder.setSpan(iss, flag.start, flag.end, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(Color.GRAY), flag.start-1, flag.start, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(Color.GRAY), flag.end, flag.end+1, Spanned.SPAN_INCLUSIVE_INCLUSIVE);

            }

        }

        return builder;
    }
}
