package com.tilismtech.tellotalksdk.ui.customviews;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RotateDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tilismtech.tellotalksdk.R;


public class CircularProgressBar extends FrameLayout {

    private View view;
    private ProgressBar progressBar;
    private TextView progressText;
    private int max = 0;
    private ProgressState progressState = ProgressState.PROGRESS_INDETERMINATE;
    private boolean textVisible = true;
    private FrameLayout imageButton;
    private int color = Color.TRANSPARENT;
    private ObjectAnimator objectAnimator;

    public enum ProgressState {
        PROGRESS_DETERMINATE, PROGRESS_INDETERMINATE, DOWNLOAD_BUTTON, UPLOAD_BUTTON, PLAY_BUTTON
    }


    public CircularProgressBar(Context context) {
        this(context, null);
    }

    public CircularProgressBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CircularProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        initAttributes(context, attrs);
        init(context);
    }

    public void initAttributes(Context context, AttributeSet attrs) {
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.CircularProgressBar, 0, 0);
        int state = a.getInteger(R.styleable.CircularProgressBar_progressState, 0);
        switch (state) {
            case 0:
                progressState = ProgressState.PROGRESS_INDETERMINATE;
                break;
            case 1:
                progressState = ProgressState.PROGRESS_DETERMINATE;
                break;
            case 2:
                progressState = ProgressState.DOWNLOAD_BUTTON;
                break;
        }
        a.recycle();
    }

    @SuppressLint("InflateParams")
    private void init(Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.custom_progress_bar, null);
        addView(view);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBarIndeterminate);
        imageButton = (FrameLayout) view.findViewById(R.id.image_button);
        progressText = (TextView) view.findViewById(R.id.progress_text);
        progressBar.setVisibility(VISIBLE);
    }

    public void setMax(int max) {
        this.max = max;
        progressBar.setMax(max);
    }

    public void setProgress(int progress) {
        if(progress>0){
                if(objectAnimator!=null){
                    objectAnimator.cancel();
                    progressBar.clearAnimation();
                    isFirst = true; 
                }
        }
        if (progress >= 0) {
            setProgressState(ProgressState.PROGRESS_DETERMINATE);
            progressText.setVisibility(VISIBLE);
            progressText.setText((progress * 100 / max) + "%");
            animateProgress(progress);
        }


    }
    boolean isFirst = true;
    public void setCompressingProgress(int progress) {




        if(isFirst){
            objectAnimator = ObjectAnimator.ofFloat(progressBar ,
                    "rotation", 0f, 360f);
            objectAnimator.setDuration(500); // miliseconds
            objectAnimator.setRepeatMode(ValueAnimator.RESTART);
            objectAnimator.setInterpolator(new LinearInterpolator());
            objectAnimator.setRepeatCount(ValueAnimator.INFINITE);
            objectAnimator.start();
            isFirst = false;
        }

        if (progress >= 0) {
            setProgressState(ProgressState.PROGRESS_DETERMINATE);
            //progressText.setText((progress * 100 / max) + " %");
            progressText.setVisibility(INVISIBLE);
            animateProgress(progress);
        }


    }

    public void setImmediateProgress(int progress) {

        if (progress >= 0) {
            setProgressState(ProgressState.PROGRESS_DETERMINATE);
            progressText.setText((progress * 100 / max) + "%");
            progressBar.setProgress(progress);
        }

    }

    private void animateProgress(int progress) {
        if (Build.VERSION.SDK_INT >= 11) {
//            ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", progress);
//            animation.setDuration(500);
//            animation.setInterpolator(new DecelerateInterpolator());
//            animation.start();
            progressBar.setProgress(progress);
        } else {
            progressBar.setProgress(progress);
        }
    }

    public int getProgress() {
        return progressBar.getProgress();
    }

    public void setTextColor(int color) {
        progressText.setTextColor(color);
    }

    public void setProgressColor(int color) {
        this.color = color;
        if (color != Color.TRANSPARENT) {
            if (progressState == ProgressState.PROGRESS_INDETERMINATE) {
                progressBar.getIndeterminateDrawable().setColorFilter(color, Mode.SRC_IN);
            } else if (progressState == ProgressState.PROGRESS_DETERMINATE) {
                Drawable layerDrawable =  progressBar.getProgressDrawable();
                if (layerDrawable instanceof LayerDrawable) {
                    Drawable drawable = ((LayerDrawable)layerDrawable).findDrawableByLayerId(android.R.id.progress);
                    Drawable drawableBackground = ((LayerDrawable)layerDrawable).findDrawableByLayerId(android.R.id.background);
                    drawable.setColorFilter(color, Mode.SRC_IN);
                    drawableBackground.setColorFilter(color, Mode.SRC_IN);
                }else if (layerDrawable instanceof RotateDrawable){
                     layerDrawable.setColorFilter(color,Mode.SRC_IN);
                }
                setTextColor(color);
            }
        }
    }

    public void setProgressBackgroundColor(int color) {
        if (progressState == ProgressState.PROGRESS_DETERMINATE) {
            LayerDrawable layerDrawable = (LayerDrawable) progressBar.getProgressDrawable();
            Drawable drawable = layerDrawable.findDrawableByLayerId(android.R.id.background);
            drawable.setColorFilter(color, Mode.SRC_IN);
        }
    }

    public void setProgressBackgroundDrawabble() {
        progressBar.setBackgroundResource(R.drawable.rounded_background_bg);
    }

    public void setProgressState(ProgressState progressState) {
        this.progressState = progressState;
        progressBar.setVisibility(GONE);
        imageButton.setVisibility(GONE);
        progressText.setVisibility(GONE);
        if (progressState == ProgressState.PROGRESS_INDETERMINATE) {
            progressBar = (ProgressBar) view.findViewById(R.id.progressBarIndeterminate);
            progressBar.setVisibility(VISIBLE);
        } else if (progressState == ProgressState.PROGRESS_DETERMINATE) {
            progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
            progressBar.setVisibility(VISIBLE);
            if (textVisible) {
                progressText.setVisibility(VISIBLE);
            }
            this.max = 100;
        } else if (progressState == ProgressState.DOWNLOAD_BUTTON) {
            ((ImageView) view.findViewById(R.id.image_button_icon)).setImageResource(R.drawable.ic_download_white_sdk);
            imageButton.setVisibility(VISIBLE);
            imageButton.setBackgroundResource(R.drawable.rounded_background_bg);
        } else if (progressState == ProgressState.UPLOAD_BUTTON) {
            ((ImageView) view.findViewById(R.id.image_button_icon)).setImageResource(R.drawable.ic_upload_white_sdk);
            imageButton.setVisibility(VISIBLE);
            imageButton.setBackgroundResource(R.drawable.rounded_background_bg);
        }else if (progressState == ProgressState.PLAY_BUTTON) {
            ((ImageView) view.findViewById(R.id.image_button_icon)).setImageResource(R.drawable.play_video_msg_icon_sdk);
            imageButton.setVisibility(VISIBLE);
            imageButton.setBackgroundResource(R.drawable.rounded_background_bg);
        }
        setProgressColor(color);
    }

    public ProgressState getProgressState() {
        return progressState;
    }

    public void setTextVisible(boolean visible) {
        this.textVisible = visible;
        if (visible) {
            progressText.setVisibility(VISIBLE);
        } else {
            progressText.setVisibility(GONE);
        }
    }

    public boolean isTextVisible() {
        return this.textVisible;
    }

    public void setImageResource(int resId) {
        ((ImageView) view.findViewById(R.id.image_button_icon)).setImageResource(resId);
    }

    public void setBackgroundResource(int resId) {
        ((ImageView) view.findViewById(R.id.image_button_background)).setImageResource(resId);
    }

    public void setOnClickListener(OnClickListener listener) {
        imageButton.setOnClickListener(listener);
    }
}
