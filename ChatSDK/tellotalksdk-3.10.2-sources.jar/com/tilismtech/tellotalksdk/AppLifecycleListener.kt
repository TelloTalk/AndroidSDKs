package com.tilismtech.tellotalksdk

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.tilismtech.tellotalksdk.managers.TelloApiClient

class AppLifecycleListener : DefaultLifecycleObserver {

    override fun onCreate(owner: LifecycleOwner) {

    }

    override fun onDestroy(owner: LifecycleOwner) {

    }

    override fun onStart(owner: LifecycleOwner) {
        val instance = TelloApiClient.getInstance()
        instance?.isForegroundMode = true

        super.onStart(owner)
    }

    override fun onStop(owner: LifecycleOwner) {
        val instance = TelloApiClient.getInstance()
        instance?.isForegroundMode = false
        instance?.setmCurrentConversationOpen(null)
        super.onStop(owner)
    }

    companion object {
        var defaultPingIntervalOnForegroung: Int = 60 * 1 // 60 * n minutes
        var defaultPingIntervalOnBackground: Int = 60 * 60 * 24 // a day

        const val TAG: String = "AppLifecycleListener"
    }
}
