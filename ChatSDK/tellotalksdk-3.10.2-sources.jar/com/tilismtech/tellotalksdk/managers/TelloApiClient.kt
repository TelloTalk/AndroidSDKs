package com.tilismtech.tellotalksdk.managers

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Context.POWER_SERVICE
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.PowerManager
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.children
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.imagepipeline.core.ImagePipelineConfig
import com.facebook.imagepipeline.core.ImageTranscoderType
import com.facebook.imagepipeline.core.MemoryChunkType
import com.google.android.material.behavior.SwipeDismissBehavior
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.DaoManager.Companion.instantiate
import com.tilismtech.tellotalksdk.data.db.entities.AgentModel
import com.tilismtech.tellotalksdk.data.db.entities.Department
import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations
import com.tilismtech.tellotalksdk.data.db.entities.MessageReceipt
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.NetworkClient
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.data.network.RestWebService
import com.tilismtech.tellotalksdk.data.network.module.Payload
import com.tilismtech.tellotalksdk.data.network.module.initiateChat.ChatIdRequest
import com.tilismtech.tellotalksdk.data.network.module.receipt.ReceiptModel
import com.tilismtech.tellotalksdk.data.network.module.register.OtherField
import com.tilismtech.tellotalksdk.data.network.module.register.RegisterUserObject
import com.tilismtech.tellotalksdk.data.network.module.requests.ChatFormRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.SendWcRatingRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.SubmitChatFormRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.TTMessageReceipt
import com.tilismtech.tellotalksdk.data.network.module.requests.TTWebMessagaRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.TokenAPIRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.TokenObjectRequest
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentDetailResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentListResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.ChatFormResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.FileUploadResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.SubmittedFormResponse
import com.tilismtech.tellotalksdk.data.network.module.typing.TypingObject
import com.tilismtech.tellotalksdk.data.repository.DepartmentRepository
import com.tilismtech.tellotalksdk.data.repository.TTAccountRepository
import com.tilismtech.tellotalksdk.data.repository.TTAgentRepository
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.data.usecases.implementations.AuthSocket
import com.tilismtech.tellotalksdk.data.usecases.implementations.ChatSocket
import com.tilismtech.tellotalksdk.data.usecases.implementations.MessageSocket
import com.tilismtech.tellotalksdk.data.usecases.repos.AuthRepo
import com.tilismtech.tellotalksdk.data.usecases.repos.ChatRepo
import com.tilismtech.tellotalksdk.data.usecases.repos.MessageRepo
import com.tilismtech.tellotalksdk.listeners.AnnouncementSelectionListener
import com.tilismtech.tellotalksdk.listeners.MessageCounterListener
import com.tilismtech.tellotalksdk.listeners.OnSuccessListener
import com.tilismtech.tellotalksdk.listeners.onNotificationClickListener
import com.tilismtech.tellotalksdk.utils.CryptoLib
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Calendar
import java.util.Date
import java.util.Locale


class TelloApiClient {
    private var accessKey: String? = null
    private var projectToken: String? = null
    private lateinit var telloPrefs: TelloPreferencesManager
    private lateinit var networkClient: NetworkClient
    private var webService: RestWebService? = null
    private var activity: Activity? = null
    private var showSnack: Boolean? = null
    private var messageCounterListener: MessageCounterListener? = null
    private var onNotificationClickListener: onNotificationClickListener? = null
    private var announcementSelectionListener: AnnouncementSelectionListener? = null
    private var isCorporateChat = false
    private var registerCallback: OnSuccessListener<String?>? = null
    private var account: TTAccount? = null
    internal var isForegroundMode: Boolean = false
    internal var isTelloUi: Boolean = false
    private var mCurrentConversationOpen: TTConversation? = null
    internal lateinit var telloContext: Context

    /**
     * Indicates whether the chat UI should show previous messages only.
     *
     * When set to `true`, the chat UI will display only previous messages; otherwise, it will allow sending new messages as well.
     */
    var showPreviousMessagesOnly = false

    /**
     * Indicates whether bundled text should be shown in the chat UI.
     *
     * When set to `true`, bundled text message will be displayed; otherwise, it will be hidden.
     */
    var showBundledMsg = false

    /**
     * Indicates whether the large send button should be shown in the chat UI.
     *
     * When set to `true`, the large send button will be displayed; otherwise, it will be hidden.
     */
    var showLargeSendButton = true

    /**
     * Call this method to set notification small icon that will be shown
     * in the notification for the received messages
     *
     * @param notificationIcon Resource id for the notification Icon
     */
    internal var notificationIcon = 0
        /*
              * Call this method to set notification small icon that will be shown
              * in the notification for the received messages
              *
              * @param notificationIcon Resource id for the notification Icon
              */private set

    /**
     * Indicates whether the popup would appear after the [openConversation] method has been called.
     *
     * When set to `true`, the department list will be shown; otherwise, it will be hidden.
     * When set to `false, use the [getDepartmentList] method to fetch the departments and use your
     * own customized UI to show the list and navigate to chat screen using [openConversation] method after department selection.
     *
     *
     * Default value is false
     */

    var showDepartmentListDialog = false

    internal val authParams: String
        get() {
            return "$accessKey:$projectToken"
        }
    private var isLoggedIn = false
    private val unreadCount: Int
        get() {
            return TTMessageRepository.instance?.conversationUnreadCount ?: 0
        }

    private constructor(
        accessKey: String?,
        projectToken: String?,
        mContext: Context,
        showSnack: Boolean? = false
    ) {
        this.accessKey = accessKey
        this.projectToken = projectToken
        this.telloContext = mContext
        this.showSnack = showSnack
        networkClient = NetworkClient.getInstance(authParams)
        webService = networkClient.getService()
    }

    private constructor() {
        webService = NetworkClient.getInstance(authParams).getService()
    }

    private fun <T> callAPI(
        request: Call<T>, callback: ((it: Boolean, response: Response<T>?) -> Unit)
    ) {
        request.enqueue(object : Callback<T> {
            override fun onResponse(call: Call<T>, response: Response<T>) {
                if (response.errorBody()?.string()?.lowercase(Locale.getDefault())
                        ?.contains("invalidtoken") == true
                ) {
                    getNewToken {
                        if (it == true) {
                            callAPI(request, callback)
                        }
                    }
                } else {
                    callback.invoke(response.isSuccessful, response)
                }
            }

            override fun onFailure(call: Call<T>, t: Throwable) {
                callback.invoke(false, null)
            }
        })
    }

    private fun encHeaderToken(token: String?): String? {
        val data = Base64.decode(token, Base64.DEFAULT)
        var text: String
        var decr = ""
        try {
            text = String(data, StandardCharsets.UTF_8)
            decr = CryptoLib.instance?.decrypt(text).toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Base64.encodeToString(decr.toByteArray(), Base64.NO_WRAP)
    }

    private fun listenToTyping() {
        MessageRepo(MessageSocket()).typingStatus { response ->
            ChatManager.instance?.handleTyping(response)
        }
    }

    private fun listenToReceipts() {
        val msgRepo = TTMessageRepository.instance
        MessageRepo(MessageSocket()).newReceipt { response ->
            response?.messageIds?.forEach {
                val message = TTMessageRepository.instance?.getMessage(it)
                val messages = arrayListOf<TTMessage?>()
                if (message != null) {
                    if (response.messageReceiptType == TTMessageReceipt.AckType.DELIVERED.name && message.msgStatus != TTMessage.MsgStatus.READ) {
                        message.msgStatus = (TTMessage.MsgStatus.DELIVERED)
                    } else if (response.messageReceiptType == TTMessageReceipt.AckType.READ.name) {
                        message.msgStatus = (TTMessage.MsgStatus.READ)
                    }
                    messages.add(message)
                    MessageReceipt.createReceipt(
                        TTMessageReceipt(
                            it, response.messageReceiptType, Date(), response.receiverId
                        ), message.contactId
                    )
                }
                msgRepo?.updateMessage(*messages.toTypedArray())
            }
        }
    }

    private fun listenToMessages() {
        getAccount() ?: return
        MessageRepo(MessageSocket()).newMessage {
            if (!isTelloUi && showSnack == true) {
                showSnackBar(it.messages.last())
            }
            CoroutineScope(Dispatchers.IO).launch {
                delay(1000)
                val deliveredAcks = ReceiptModel(
                    it.messages.firstOrNull()?.chatId,
                    TTMessageReceipt.AckType.DELIVERED.name,
                    getAccount()?.userName,
                    it.messages.map { it.messageId })
                val readAcks = ReceiptModel(
                    it.messages.firstOrNull()?.chatId,
                    TTMessageReceipt.AckType.READ.name,
                    getAccount()?.userName,
                    it.messages.map { it.messageId })
                ChatManager.instance?.handleTyping(TypingObject("", false))
                for (message in it.messages) {
                    ChatManager.instance?.handleMessage(message)
                }
                if (deliveredAcks.messageIds?.isNotEmpty() == true) sendAck(deliveredAcks, false)
                if (readAcks.messageIds?.isNotEmpty() == true && isTelloUi == true && isForegroundMode == true) sendAck(
                    readAcks,
                    true
                )
            }
        }
    }

    private fun sendAck(acks: ReceiptModel, isRead: Boolean) {
        MessageRepo(MessageSocket()).sendReceipt(acks) {
            val res = it.getString("statusCode")
            if (res == "200") {
                val messages = arrayListOf<TTMessage?>()
                acks.messageIds?.forEach {
                    val message = TTMessageRepository.instance?.getMessage(it)
                    if (message != null && isRead) {
                        message.displayStatus = TTMessage.MsgDisplayStatus.READ_AND_ACK.ordinal
                    }
                    messages.add(message)
                }
                TTMessageRepository.instance?.updateMessage(*messages.toTypedArray())
            }
        }

    }

    private fun getPreviousChat(profileId: String, callback: () -> Unit?) {
        val prevChatRequest = networkClient.getMessages().getPreviousMessages(
            hashMapOf("profileId" to profileId)
        )
        callAPI(prevChatRequest) { it, response ->
            if (it) {
                val body = response?.body()
                CoroutineScope(Dispatchers.IO).launch {
                    for (message in body?.messages ?: listOf()) {
                        ChatManager.instance?.handlePrevMsg(message, profileId)
                    }
                    val ttConversation =
                        instance?.getmCurrentConversationOpen()
                    if (ttConversation != null) {
                        ttConversation.isHasMessage = true
                        TTConversationRepository.getInstance().updateConversation(ttConversation)
                    }
                }
            }
            callback.invoke()
        }
    }

    private fun getUser(
        token: String?, profileId: String?, listener: OnSuccessListener<TTAccount?>
    ) {
        val userRequest = webService!!.getUser(encHeaderToken(token), profileId)
        callAPI(userRequest) { it, response ->
            if (it) {
                val ttAccount = TTAccount(
                    response?.body()!!["profileId"].toString(),
                    response.body()!!["name"].toString(),
                    "",
                    response.body()!!["tokenId"].toString(),
                    token
                )
                listener.onSuccess(ttAccount)
            } else {
                listener.onSuccess(null)
            }
        }
    }

    private fun getAnnouncement(profileId: String, departmentId: String?) {
        val account = getAccount()
        val announcementRequest = webService!!.getAnnouncement(
            encHeaderToken(account?.accessToken?:""), profileId.lowercase(
                Locale.getDefault()
            ), departmentId
        )
        callAPI(announcementRequest) { it, response ->
            if (it) {
                val body = response?.body()
                if (body != null) {
                    for (message in body.messages) {
                        ChatManager.instance?.handleMessage(message)
                        val ttConversation =
                            instance?.getmCurrentConversationOpen()
                        if (ttConversation != null && ttConversation.contactJid == message.departmentId) {
                            ttConversation.isHasMessage = true
                            TTConversationRepository.getInstance()
                                .updateConversation(ttConversation)
                        }
                    }
                }
            }
        }
    }

    private fun showSnackBar(msg: TTWebMessagaRequest) {
        if (msg.chatbotNode == null && activity != null) {
            val rootView =
                ((activity?.findViewById<ViewGroup>(android.R.id.content)?.children?.first() as ViewGroup).children.first() as ViewGroup)
            val custom: View = LayoutInflater.from(activity)
                .inflate(R.layout.view_message_snackbar, rootView, false)
            val snackbar = Snackbar.make(rootView, msg.message.toString(), 5000).setBehavior(
                BaseTransientBottomBar.Behavior().apply {
                    setSwipeDirection(SwipeDismissBehavior.SWIPE_DIRECTION_ANY)
                })
            snackbar.view.setBackgroundColor(Color.TRANSPARENT)
            snackbar.view.elevation = 0f
            (snackbar.view as ViewGroup).removeAllViews()
            (snackbar.view as ViewGroup).addView(custom)
            custom.findViewById<LinearLayout>(R.id.parent).setOnClickListener {
                snackbar.dismiss()
                CoroutineScope(Dispatchers.Main).launch {
                    delay(500)
                    openConversation(
                        activity!!, "",
                        "ہیلو دنیا"
                    )
                }
            }
            ((custom as ViewGroup).children.first().layoutParams as CoordinatorLayout.LayoutParams).behavior =
                object : SwipeDismissBehavior<Snackbar.SnackbarLayout>() {
                    override fun canSwipeDismissView(view: View): Boolean {
                        return true // Set to true to allow dismiss
                    }
                }

            val textView = custom.findViewById<TextView>(R.id.text)
            val image = custom.findViewById<ImageView>(R.id.imageView)
            textView.text = msg.message.toString()
            CoroutineScope(Dispatchers.IO).launch {
                var imageUrl = TTAgentRepository.getInstance()?.getAgent(msg.profileId)?.agentAvatar
                if (imageUrl == null) {
                    getAgentDetails(msg.profileId) {
                        TTAgentRepository.getInstance()?.insertAgent(
                            AgentModel(
                                it?.agentId.toString(),
                                it?.profileName,
                                it?.profileName_U,
                                it?.avatar,
                                it?.status,
                                it?.otherDetails
                            )
                        )
                        imageUrl = it?.avatar
                        val bitmap = downloadBitmap(imageUrl.toString())
                        launch(Dispatchers.Main) {
                            image.setImageBitmap(bitmap)
                            snackbar.show()
                        }
                    }
                } else {
                    val bitmap = downloadBitmap(imageUrl!!)
                    launch(Dispatchers.Main) {
                        image.setImageBitmap(bitmap)
                        snackbar.show()
                    }
                }
            }

            snackbar.show()
        }
    }

    private fun downloadBitmap(imageUrl: String): Bitmap? {
        return try {
            val url = URL(imageUrl)
            val connection = url.openConnection()
            connection.connect()

            val inputStream = connection.getInputStream()
            BitmapFactory.decodeStream(inputStream)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun sendTokenToClient(token: String?, userName: String?) {
        val tokenModel = TokenAPIRequest(
            userName!!, TokenObjectRequest(token!!, "F", telloContext.packageName, true)
        )
        //    RequestBody requestBody=RequestBody.create(MediaType.parse("application/json; charset=utf-8"),new Gson().toJson(tokenAPIRequest));
        val updateTokenRequest = webService!!.updateBulkToken(
            CryptoLib.instance?.encryptRsa("$accessKey:$projectToken")?.replace("\\n".toRegex(), "")
                ?.replace("\\r".toRegex(), ""),
            NetworkConstants.NOTIFICATION_URL + "client/token",
            tokenModel
        )
        callAPI(updateTokenRequest) { it, response -> }
    }

    private fun addConversations(departmentConversations: List<DepartmentConversations>) {
        val account = getAccount()
        if (account == null) {
            Log.d("TelloApiClient", "User is not registered")
            return
        }
        for (departmentConversation in departmentConversations) {
            if (departmentConversation.department.dptType == "1") {
                departmentConversation.conversation = TTConversationRepository.getInstance()
                    .getConversationForJid(departmentConversation.department.dptId)
                if (departmentConversation.conversation != null) departmentConversation.conversation.unreadCount =
                    TTMessageRepository.instance?.getPerticularConversationUnreadCount(
                        departmentConversation.department.dptId
                    ) ?: 0
            } else {
                departmentConversation.conversation =
                    TTConversationRepository.getInstance().getConversationForJid(account.userName)
                if (departmentConversation.conversation != null) departmentConversation.conversation.unreadCount =
                    TTMessageRepository.instance?.getPerticularConversationUnreadCount(account.userName)
                        ?: 0
            }
        }
    }

    /**
     *Call this method to register the user to SDK
     *
     * @param name   String value for the profileId in SDK profile
     * @param mobileNumber   String value for mobile number with user
     * @param successListener   OnSuccessListener to get status code of the API (200 = success)
     */

    @JvmOverloads
    fun registerUser(
        profileId:String,
        name: String?="",
        mobileNumber: String?="",
        customerType: String?= "Development",
        fcmToken: String?="",
        successListener: (OnSuccessListener<String?>)? = null
    ) {
        registerCallback = successListener
        val registerUserModel = RegisterUserObject(
            "123423456734567",
            "4567845674567",
            customerType,
            "A",
            null,
            "01-01-2024",
            mobileNumber,
            name,
            arrayListOf(OtherField("CNIC", "42101")),
            profileId,
            "12345678",
            deviceToken = fcmToken
        )
        setCurrentAccount(TTAccount(registerUserModel.profileId ?: "", null, null, null, null))
        NetworkClient.getInstance().reconnectBeforeRegister = false
        AuthRepo(AuthSocket(authParams)).register(registerUserModel) {registerResponse->
            val user = getAccount()
            if (registerResponse.statusCode == "200") {
                isLoggedIn = true

                telloPrefs.putString("jitsi", registerResponse.data.enableJitsi)
//                if (telloPrefs.getString(TelloPreferencesManager.FCM_TOKEN).isNotEmpty()) {
//                    updateFcmToken(telloPrefs.getString(TelloPreferencesManager.FCM_TOKEN))
//                }
                getUser(
                    user?.accessToken, registerUserModel.profileId
                ) { acc: TTAccount? ->
                    if (acc != null) {
                        TTAccountRepository.getInstance().insertAccount(acc)
                        setCurrentAccount(acc)
                    }
                    getDepartmentList {
                        getPreviousChat(user?.userName ?: ""){
                            registerCallback?.onSuccess(registerResponse.statusCode)
                            registerCallback = null
                        }
                    }

                }
            } else {
                registerCallback?.onSuccess(registerResponse.message)
            }
        }
    }


    /**
     * This method is used to set the language of the sdk.
     * current supported values are "en" for English and "ur" for Urdu
     */
    fun setLocality(lang: String?) {
        telloPrefs.putString("lang", lang)
    }

    /**
     * This method can be called from anywhere. It sets the listener on the click of the notification
     */
    fun setNotificationCLickedListener(onNotificationClickListener: onNotificationClickListener?) {
        this.onNotificationClickListener = onNotificationClickListener
    }

    /**
     * This method can be called from anywhere. It sets the listener to get
     * count of unread received messages.
     */
    fun setMessageCounterListener(messageCounterListener: MessageCounterListener?) {
        this.messageCounterListener = messageCounterListener
        onNotifyMessageCount()
    }


    /**
     * This method sets the listener on buttons of the announcement messages.
     */
    fun setAnnouncementCLickedListener(
        listener: AnnouncementSelectionListener
    ) {
        this.announcementSelectionListener = listener
    }

    /**
     * This method sets the activity of the host app which should be opened when
     * TelloSdk activity finishes but the host activity has been destroyed or is not created
     *
     * Example:
     * returnActivityName(this.javaClass.name) -> in any activity class
     */
    fun returnActivityName(activityName: String?) {
        telloPrefs.putString("client_activity", activityName)
    }

    /**
     * Call this method to set Google API Key for maps. This will be used to load
     * static map for location messages
     *
     * @param key    Google API Key for maps
     */
    fun setGoogleApiKey(key: String?) {
        telloPrefs.googleApiKey = key
    }

    /**
     * Entry point for opening one way announcements activity in the TelloSdk
     */
    fun openAnnouncements(
        activity: Activity,
        department: Department?
    ) {

        if(department==null){
            Toast.makeText(activity,"No department found",Toast.LENGTH_SHORT).show()
            return
        }
        if (!telloPrefs
                .getBoolean(TelloPreferencesManager.REGISTER_SUCCESS)
        ) {
            Log.d("TelloApiClient", "User is not registered.")
            //   throw new IllegalStateException("User is not registered");
            Toast.makeText(
                activity, "Corporate Chat is not available right now", Toast.LENGTH_SHORT
            ).show()
            return
        }
        val account = getAccount()
        if (account == null) {
            Log.d("TelloApiClient", "User is not registered")
            //    throw new IllegalStateException("User is not registered");
            Toast.makeText(
                activity, "Corporate Chat is not available right now", Toast.LENGTH_SHORT
            ).show()
            return
        }
        ChatManager.instance?.openConversationActivity(
            activity,
            "",
            department.dptName,
            department.dptId,
            department.dptType,
            false,
            "",
            department.dptType == "2",
            "",
            department.dptImage,
            department.name_u
        )
    }

    /**
     * Opens the conversation UI.
     *
     * This function serves as the entry point for launching the two-way conversation activity within the SDK.
     * It checks if the user is registered before proceeding. If the user is not registered, it displays a `Toast` message
     * and aborts the operation.
     *
     * The behavior of this function is influenced by the [showDepartmentListDialog] property.
     * - If `showDepartmentListDialog` is `true` (the default), a dialog with a list of available departments is displayed,
     *   allowing the user to select one to start a conversation.
     * - If `showDepartmentListDialog` is `false`, this function can be used to open a conversation directly with a
     *   pre-selected department. In this case, you should first obtain the department list using [getDepartmentList],
     *   allow the user to select a department in your custom UI, and then call this method passing the selected [Department] object.
     *
     * @param context The current [Context] context from which the conversation screen is being launched.
     * @param initialMsg An optional message to pre-populate in the chat input field. Can be `null`.
     * @param customData Optional custom data that can be passed along with the conversation. Can be `null`.
     * @param department The [Department] to start the conversation with. Can be `null` only when [showDepartmentListDialog] is true.
     */
    @JvmOverloads
    fun openConversation(context: Context, initialMsg: String?, customData: String?, department: Department? = null) {
        if (!telloPrefs.getBoolean(TelloPreferencesManager.REGISTER_SUCCESS)) {
            Toast.makeText(
                context, "Corporate Chat is not available right now", Toast.LENGTH_SHORT
            ).show()
            return
        }
        val account = getAccount()
        if (account == null) {
            Toast.makeText(
                context, "Corporate Chat is not available right now", Toast.LENGTH_SHORT
            ).show()
            return
        }
        if(department!=null){
            ChatManager.instance?.openDepartmentDialog(context, initialMsg, customData,department)
            return
        }
        getDepartmentList {
            ChatManager.instance?.openDepartmentDialog(context, initialMsg, customData)
        }
    }

    internal fun getNewToken(listener: OnSuccessListener<Boolean?>) {
        val account = getAccount() ?: return
        var base64 = ""
        try {
            val enc = CryptoLib.instance?.encrypt(
                account.userName.lowercase(Locale.getDefault())
            )
            base64 = Base64.encodeToString(enc?.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val tokenRequest = webService!!.gettoken(
            base64, account.userName.lowercase(
                Locale.getDefault()
            )
        )
        callAPI(tokenRequest) { it, response ->
            if (it) {
                if (response?.code() == 200) {
                    Log.d("TAG", response.toString())
                    try {
                        val js = JSONObject(response.body()!!.string())
                        account.accessToken = js.getString("authToken")
                        TTAccountRepository.getInstance().insertAccount(account)
                        setCurrentAccount(account)
                        listener.onSuccess(true)
                    } catch (_: Exception) {
                        listener.onSuccess(false)
                    }
                }
            } else {
                listener.onSuccess(false)
            }
        }
    }

    internal fun initiateChat(
        departmentId: String?, successListener: OnSuccessListener<Any>
    ) {
        val account = getAccount() ?: return
        val chatRequestModel = ChatIdRequest(
            "E", account.userName, departmentId
        )
        ChatRepo(ChatSocket()).initiateChat(chatRequestModel) {
            successListener.onSuccess(it.data.chatId)
        }
    }

    internal fun listenToEvents(isCorporateChat: Boolean) {
        val account = getAccount()
        this.isCorporateChat = isCorporateChat
        if (account == null) {
            return
        }
        listenToMessages()
        listenToReceipts()
        listenToTyping()
    }

    internal fun sendMessage(msg: TTMessage?) {
        val account = getAccount()
        val messageRequest = ChatManager.instance?.getMessageRequest(msg)
        messageRequest?.profileId = account?.userName?.lowercase(Locale.getDefault())
        MessageRepo(MessageSocket()).sendMessage(messageRequest!!) {
            if (it.statusCode == "200") {
                msg?.msgStatus = (TTMessage.MsgStatus.SENT)
                msg?.msgDate = (Calendar.getInstance().apply {
                    timeInMillis = it.msgDate ?: 0L
                }.time)
                ChatManager.instance?.isMsgSending = false
            } else {
                msg?.msgStatus = (TTMessage.MsgStatus.ERROR)
                ChatManager.instance?.isMsgSending = false
            }
            TTMessageRepository.instance?.updateMessage(msg)
            ChatManager.instance?.updateTyping(false)
        }
    }

    internal fun sendChatBotMessage(
        msg: TTMessage, id: String, listener: OnSuccessListener<Boolean?>?
    ) {
        val messageRequest = ChatManager.instance?.getMessageRequest(msg, id)
        messageRequest?.profileId = getAccount()?.userName
        MessageRepo(MessageSocket()).sendMessage(messageRequest!!) {
            if (it.statusCode == "200") {
                listener?.onSuccess(true)
                msg.msgStatus = (TTMessage.MsgStatus.SENT)
                msg.dptType = ("2")
            } else {
                listener?.onSuccess(false)
                msg.msgStatus = (TTMessage.MsgStatus.ERROR)
            }
            TTMessageRepository.instance?.updateMessage(msg)
        }
    }

    internal fun sendAck(contactId: String?) {
        val messages = TTMessageRepository.instance?.getAllMarkableMessages(contactId)
        val receipts = ReceiptModel(
            messages?.getOrNull(0)?.chatId.toString(),
            TTMessageReceipt.AckType.READ.name,
            getAccount()?.userName,
            messages?.map { it.messageId })
        for (message in messages ?: listOf()) {
            message.isRead = true
            message.isRead_count = true
            message.displayStatus = TTMessage.MsgDisplayStatus.READ.ordinal
        }
        TTMessageRepository.instance?.updateMessage(
            *messages?.toTypedArray<TTMessage>() ?: arrayOf()
        )
        if (receipts.messageIds?.isNotEmpty() == true) sendAck(receipts, true)
    }

    internal fun getAgentDetails(
        id: String?,
        successListener: OnSuccessListener<AgentDetailResponse?>
    ) {
        val chatIdRequest =
            networkClient.getMessages().getagentdetail(id)
        callAPI(chatIdRequest) { it, response ->
            if (it) {
                successListener.onSuccess(response?.body())
            } else {
                successListener.onSuccess(null)
            }
        }
    }

    internal fun getAgentList(
        departmentID: String?, successListener: OnSuccessListener<AgentListResponse?>
    ) {
        val account = getAccount() ?: return
        val chatIdRequest = webService!!.getavailableagent(
            encHeaderToken(account.accessToken), account.userName, departmentID
        )
        callAPI(chatIdRequest) { it, response ->
            if (it) {
                successListener.onSuccess(response?.body())
            } else {
                successListener.onSuccess(null)
            }
        }
    }


    /**
     * Fetches the fresh list of corporate departments from the server and stores them locally.
     *
     * This function makes an API call to get all available departments for the currently registered user.
     *
     * This method is useful to call before you need to display a list of departments to the user,
     * when [showDepartmentListDialog] is set to `false`.
     *
     * @param successListener A listener that gets triggered upon completion of the API call.
     *                        It receives the list of departments if the network request was successful,
     *                        and an empty list otherwise.
     */
    fun getDepartmentList(successListener: OnSuccessListener<List<Department>>?) {
        val account = getAccount() ?: return
        val corporateListRequest =
            networkClient.getMessages().getCorporateList()
        callAPI(corporateListRequest) { it, response ->
            val departmentList = arrayListOf<Department>()
            val body = response?.body()
            if (body != null && body.isNotEmpty()) {
                DepartmentRepository.getInstance().clearTable()
                DepartmentRepository.getInstance().insertDepartment(body)
                for (department in body) {
                    departmentList.add(department)
                    if (department.dptType == "1") getAnnouncement(
                        account.userName, department.dptId
                    )
                }
            }
            successListener?.onSuccess(departmentList)
        }
    }

    internal fun getMessageAnnouncement(isCorporateChat: Boolean, departmentID: String?) {
        val account = getAccount()
        this.isCorporateChat = isCorporateChat
        if (account == null) {
            return
        }
        getAnnouncement(account.userName, departmentID)
    }

    internal fun isNotificationIcon(): Boolean {
        return notificationIcon != 0
    }

    internal fun getUploadService(): RestWebService? {
        return webService
    }

    internal fun onNotifyMessageCount() {
        if (messageCounterListener != null) {
            messageCounterListener!!.onMessageCountUpdate(getUnreadCount("2"))
            messageCounterListener!!.onAnnouncementCountUpdate(getUnreadCount("1"))
        }
    }

    internal fun onNotificationClicked(
        message_id: String?, broadcastFrom: String?, message_type: String?, campaignId: String?
    ) {
        if (onNotificationClickListener != null) {
            onNotificationClickListener!!.onNotificationClicked(
                message_id, broadcastFrom, message_type, campaignId
            )
        }
    }


    /**
     * Launches a conversation screen directly from a notification tap.
     *
     * This function should be called when the user taps on a TelloTalk FCM notification. It handles the user registration
     * process using the data from the notification payload and then navigates to the appropriate conversation screen.
     * A progress dialog is shown during this process.
     *
     * @param activity The current [Activity] context from which to launch the conversation.
     */
    fun launchConversationFromNotification(activity: Activity,profileId: String) {
        val dialog = ProgressDialog.show(activity,"Please wait","Loading...")
        registerUser(profileId){
            val department=DepartmentRepository.getInstance().allCorporateDpt.firstOrNull { it.dptId=="departmentId" }
            dialog.dismiss()
            openConversation(activity, "hey", "hey", department)
        }
    }

    @SuppressLint("MissingPermission")
    fun showFcmNotification(data: Map<String, String>, context: Context) {
        if(isForegroundMode){
            return
        }
        val channelId = "high_importance_channel"
        val notificationId = System.currentTimeMillis().toInt()

        val notificationPayload = Gson().fromJson(data["payload"], Payload::class.java)

        val intent = Intent(context, Class.forName(context.getSharedPreferences("notificationsdk",MODE_PRIVATE).getString("returnActivityName","")?:"")).apply {
            putExtra("fromNotification", true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Create Notification Channel (For Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "App Notifications",
                NotificationManager.IMPORTANCE_NONE
            )
            val manager =
                context.getSystemService(NotificationManager::class.java) as NotificationManager
            manager.createNotificationChannel(channel)
        }

        CoroutineScope(Dispatchers.IO).launch {
            val bitmap = if (notificationPayload?.image != null) {
                try {
                    val url = URL(notificationPayload.image)
                    BitmapFactory.decodeStream(url.openConnection().getInputStream())
                } catch (e: Exception) {
                    null
                }
            } else null

            this.launch(Dispatchers.Main) {
                val notificationBuilder = NotificationCompat.Builder(context, channelId)

                notificationBuilder.setContentTitle(notificationPayload?.title)
                    .setContentText(notificationPayload?.body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(notificationPayload?.body))
                    .setContentIntent(pendingIntent)
                    .setSmallIcon(notificationIcon)
                    .setAutoCancel(true)
                if (bitmap != null) {
                    notificationBuilder.setStyle(
                        NotificationCompat.BigPictureStyle()
                            .bigPicture(bitmap)
                    )
                }


                // Show Notification
                if (ActivityCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return@launch
                }
                NotificationManagerCompat.from(context)
                    .notify(notificationId, notificationBuilder.build())
            }
        }
    }


    internal fun onAnnouncementClicked(
        message_id: String?, broadcastFrom: String?, message_type: String?, campaignId: String?
    ) {
        if (announcementSelectionListener != null) {
            announcementSelectionListener!!.onAnnouncementClicked(
                message_id, broadcastFrom, message_type, campaignId
            )
        }
    }

    /**
     * Fetches the department list from local database if [getDepartmentList] has already been called
     * and returns the list of [DepartmentConversations].
     *
     * @return A `List` of [DepartmentConversations] objects, where each object contains
     *         department details and its associated conversation information. Returns `null` if the
     *         user is not registered. The list may be initially incomplete if data is being fetched
     *         from the network.
     */
    val departmentConversations: List<DepartmentConversations?>?
        get() {
            val account = getAccount()
            if (account == null) {
                return null
            }
            return DepartmentRepository.getInstance().departmentConversation
        }


    internal fun getChatRequestForm(
        successListener: OnSuccessListener<ChatFormResponse?>?, formId: String?
    ) {
        val account = getAccount() ?: return
        val chatFormRequest = ChatFormRequest()
        chatFormRequest.profileId = account.userName
        chatFormRequest.formId = formId
        val chatFormResponseCall =
            webService!!.getChatRequestForms(encHeaderToken(account.accessToken), chatFormRequest)
        callAPI(chatFormResponseCall) { it, response ->
            val body = response?.body()
            if (response?.isSuccessful == true && body != null) {
                successListener?.onSuccess(response.body())
            } else {
                successListener?.onSuccess(null)
            }
        }
    }

    internal fun submitChatRequestForm(
        submitChatFormRequest: SubmitChatFormRequest?, successListener: OnSuccessListener<String?>
    ) {
        val account = getAccount() ?: return
        val chatIdRequest = networkClient.getMessages().submitFormRequest(submitChatFormRequest
        )
        callAPI(chatIdRequest) { it, response ->
            if (it) {
                successListener.onSuccess(response?.body()!!.formMastId)
            } else {
                successListener.onSuccess(null)
            }
        }
    }

    internal fun endChat(
        chatID: String?,
        successListener: OnSuccessListener<Boolean?>
    ) {
        ChatRepo(ChatSocket()).endChat(chatID.toString()) {
            val res = it.optString("statusCode", "0")
            if (res == "200") {
                successListener.onSuccess(true)
            } else {
                successListener.onSuccess(false)
            }
        }
    }

    internal fun sendRating(
        context: Activity?,
        option_id: Int,
        comments: String?,
        chatID: String,
        successListener: OnSuccessListener<Boolean?>
    ) {
        val account = getAccount()
        if (account == null || chatID == "") {
            return
        }
        val groupRequest =
            SendWcRatingRequest(account.userName, chatID.toInt(), option_id, comments)
        val chatIdRequest =
            webService!!.sendwcRating(encHeaderToken(account.accessToken), groupRequest)
        callAPI(chatIdRequest) { it, response ->
            if (it) {
                var requestResponse = response?.body()!!.string()
                requestResponse =
                    requestResponse.split(":".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()[1].replace("}", "").replace("\\", "").replace("\"", "")
                Toast.makeText(context, requestResponse, Toast.LENGTH_LONG).show()
                successListener.onSuccess(true)
            } else {
                successListener.onSuccess(false)
            }
        }
    }


    internal fun uploadFile(file: File, successListener: OnSuccessListener<String>) {
        val account = getAccount() ?: return
        val requestFile = file.asRequestBody("multipart/form-data".toMediaTypeOrNull())
        val filePart = MultipartBody.Part.createFormData("file", file.name, requestFile)
        val responseCall = webService!!.uploadFile(
            ChatManager.instance?.generateToken(account.accessToken), account.userName, filePart
        )
        try {
            responseCall.enqueue(object : Callback<FileUploadResponse?> {
                override fun onResponse(
                    call: Call<FileUploadResponse?>, response: Response<FileUploadResponse?>
                ) {
                    if (response.isSuccessful) {
                        val body = response.body()
                        if (body != null) {
                            successListener.onSuccess(body.path)
                            Log.e("body", body.path)
                        } else {
                            successListener.onSuccess("")
                            //   fail();
                        }
                    } else {
                        successListener.onSuccess("")
                        // fail();
                    }
                }

                override fun onFailure(call: Call<FileUploadResponse?>, t: Throwable) {
                    Log.e("error msg", t.message!!)
                    successListener.onSuccess("")
                }
            })
        } catch (e: Exception) {
            //   fail();
            e.printStackTrace()
        }
    }

    internal fun getFormData(
        viewId: String?,
        successListener: OnSuccessListener<SubmittedFormResponse?>
    ) {
        val account = getAccount() ?: return
        val chatIdRequest =
            webService!!.getformdata(encHeaderToken(account.accessToken), account.userName, viewId)
        callAPI(chatIdRequest) { it, response ->
            if (it) {
                successListener.onSuccess(response?.body())
            } else {
                successListener.onSuccess(null)
            }
        }
    }

    internal fun disconnect() {
        networkClient.disconnect()
    }

    /*
     * Builder to initialize TelloTalk SDK
     */
    class Builder {
        var accessKey: String? = null
            private set
        var projectToken: String? = null
            private set
        var cryp_lib_key: String? = null
            private set
        var cryp_lib_iv: String? = null
            private set
        var publicKey: String? = null
            private set
        var notificationIcon = 0
            private set
        lateinit var mContext: Context
            private set
        var showSnack: Boolean? = false

        /**
         * Sets the access key required for authenticating with the TelloTalk SDK.
         * This is a mandatory parameter for building the `TelloApiClient`.
         *
         * @param accessKey The access key provided by TelloTalk.
         * @return The `Builder` instance for chaining method calls.
         */
        fun accessKey(accessKey: String?): Builder {
            this.accessKey = accessKey
            return this
        }

        /**
         * Specifies the project token for authentication.
         *
         * @param projectToken The project-specific token provided for SDK initialization.
         * @return The Builder instance for chaining method calls.
         */
        fun projectToken(projectToken: String?): Builder {
            this.projectToken = projectToken
            return this
        }

        /**
         * Sets the key for the cryptographic library.
         * This is a required parameter for initializing the SDK's encryption/decryption functionalities.
         *
         * @param cryp_lib_key The cryptographic library key as a String.
         * @return The [Builder] instance for chaining.
         */
        fun CRYPTO_LIB_KEY(cryp_lib_key: String?): Builder {
            this.cryp_lib_key = cryp_lib_key
            return this
        }

        /**
         * Sets the initialization vector (IV) for the encryption library.
         * This is a required parameter for configuring the SDK's encryption.
         *
         * @param cryp_lib_iv The initialization vector string.
         * @return This Builder instance for method chaining.
         */
        fun CRYPTO_LIB_IV(cryp_lib_iv: String?): Builder {
            this.cryp_lib_iv = cryp_lib_iv
            return this
        }

        /**
         * Sets the public key for RSA encryption.
         * This key is used for secure communication, particularly for encrypting authentication credentials.
         *
         * @param publicKey The RSA public key string.
         * @return The [Builder] instance for chaining method calls.
         */
        fun PUBLIC_KEY(publicKey: String?): Builder {
            this.publicKey = publicKey?:"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA9YylzDGCd+Bv4wKF2YN3HkRKhCYmiWuuysdYSTR9+Or3rtX0/Hb+ux9QbN0RFwJ3JQHlPyJfBTPPGYr5O+QcI5G0WAlY4YzVOKpvUDMzQWAXzw+k1G60w9Q3tKIfXltAlbmPgRS7QGN2VWsQwFOLhOhEkCKL2CJ+1SrqF6aND9pPzjJXgEu9rz1QICRyMjgVBX1Yk51ctrPYc9YzCmTpVnDcGjVdUs6Vbr1pCGnazrfRxFjBRDrOxABsVUJYkGkp4HPTbCKeT0+eE+hRmLC+NvDztEXFJyS7Mq+tm65N/SS8NMfkjHKprK692cQ+YrUCM3P05G4Bz64sRib74PFRXQIDAQAB"
            return this
        }

        /**
         * Sets the small icon to be displayed in notifications for received messages.
         * This icon will appear in the status bar and the notification shade.
         *
         * @param notificationIcon The resource ID of the drawable to be used as the notification icon (e.g., `R.drawable.ic_notification`).
         * @return The [Builder] instance for chaining method calls.
         */
        fun notificationIcon(notificationIcon: Int): Builder {
            this.notificationIcon = notificationIcon
            return this
        }

        /**
         * Sets the application context for the SDK. This is a mandatory step for initialization.
         * The context is used for various SDK operations like accessing resources, managing preferences,
         * and initializing components.
         *
         * @param mContext The application context.
         * @return This Builder instance for method chaining.
         */
        fun setApplicationContext(mContext: Context): Builder {
            this.mContext = mContext
            return this
        }

        /**
         * Sets whether to show a snackbar for new messages when the chat UI is not open.
         *
         * @param show `true` to show the snackbar, `false` to hide it. Defaults to `false`.
         * @return This `Builder` instance for chaining.
         */
        fun showSnack(show: Boolean?): Builder {
            this.showSnack = show
            return this
        }

        private fun configFresco() {
            val imagePipelineConfig: ImagePipelineConfig.Builder =
                ImagePipelineConfig.newBuilder(this.mContext.applicationContext)
                    .setMemoryChunkType(MemoryChunkType.BUFFER_MEMORY)
                    .setImageTranscoderType(ImageTranscoderType.JAVA_TRANSCODER)
            Fresco.initialize(
                this.mContext.applicationContext,
                imagePipelineConfig.build(),
                null,
                false
            )
        }

        fun build(): TelloApiClient? {
            AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
//            ProcessLifecycleOwner.get().lifecycle.addObserver(AppLifecycleListener())
            instantiate(this.mContext)
            configFresco()
            return setUpClient(this)
        }
    }

    internal fun getmCurrentConversationOpen(): TTConversation? {
        return mCurrentConversationOpen
    }

    internal fun setmCurrentConversationOpen(mCurrentConversationOpen: TTConversation?) {
        this.mCurrentConversationOpen = mCurrentConversationOpen
    }

    internal fun getAccount(): TTAccount? {
        if (account == null) {
            account = TTAccountRepository.getInstance().account
        }
        return account
    }

    internal fun setCurrentAccount(ttAccount: TTAccount?): TTAccount? {
        account = ttAccount
        return account
    }

    internal fun stopEvent(typingEvents: String) {
        networkClient.stopListener(typingEvents)
    }

    /**
     * Retrieves the total count of unread messages for a specific department type.
     *
     * @param dptType The type of the department for which to retrieve the unread count.
     *                Pass `"1"` for announcement channels or `"2"` for two-way chat departments.
     * @return The number of unread messages as an [Int]. Returns 0 if no unread messages are found
     */
    private fun getUnreadCount(dptType: String?): Int {
        var count: Int
        count = TTMessageRepository.instance?.getConversationUnreadCount(dptType) ?: 0
        return count
    }

    /**
     * This method should be called when a message notification is received via FCM.
     * It fetches the latest messages or announcements based on the notification payload.
     *
     * @param mapID A HashMap containing data from the FCM notification payload.
     *              It should contain keys like "dType" and "deptId" to determine
     *              whether to fetch a regular message or an announcement.
     */
    fun onMessageNotificationReceived(mapID: HashMap<String?, String>) {
        if (!telloPrefs
                .getBoolean(TelloPreferencesManager.REGISTER_SUCCESS)
        ) {
            Log.d("TelloApiClient", "User is not registered.")
            //   throw new IllegalStateException("User is not registered");
        }
        val account = getAccount()
        if (account == null) {
            Log.d("TelloApiClient", "User is not registered")
            return
            //    throw new IllegalStateException("User is not registered");
        }
        if (mapID["dType"] == "1") {
            getAnnouncement(account.userName, mapID["deptId"])
        }
    }


    @get:Suppress("deprecation")
    @get:SuppressLint("NewApi")
    val isInteractive: Boolean
        get() {
            val pm =
                telloContext.getSystemService(POWER_SERVICE) as PowerManager
            val isScreenOn =
                pm.isInteractive
            return isScreenOn
        }

    companion object {
        private var instance: TelloApiClient? = null
        private fun setUpClient(builder: Builder): TelloApiClient? {
            instance = TelloApiClient(
                builder.accessKey,
                builder.projectToken,
                builder.mContext,
                builder.showSnack
            )
            instance?.telloPrefs = TelloPreferencesManager.getInstance()
            instance!!.notificationIcon = builder.notificationIcon
            CryptoLib.instance?.init(builder.cryp_lib_key, builder.cryp_lib_iv, builder.publicKey)
            return instance
        }

        @JvmStatic
        fun getInstance(): TelloApiClient? {
            if (instance != null) {
                return instance
            }
            return null
        }
    }
}
