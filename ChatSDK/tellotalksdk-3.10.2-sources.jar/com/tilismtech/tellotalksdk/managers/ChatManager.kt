package com.tilismtech.tellotalksdk.managers

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild
import com.tilismtech.tellotalksdk.data.db.entities.Department
import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage.MsgType
import com.tilismtech.tellotalksdk.data.network.RestWebService
import com.tilismtech.tellotalksdk.data.network.module.requests.SubmitChatFormRequest
import com.tilismtech.tellotalksdk.data.network.module.requests.TTWebMessagaRequest
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentDetailResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentListResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.ChatFormResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.SubmittedFormResponse
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.MessageRequestModel
import com.tilismtech.tellotalksdk.data.network.module.typing.TypingObject
import com.tilismtech.tellotalksdk.data.repository.DepartmentRepository
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.data.usecases.implementations.MessageSocket
import com.tilismtech.tellotalksdk.data.usecases.repos.MessageRepo
import com.tilismtech.tellotalksdk.listeners.OnSuccessListener
import com.tilismtech.tellotalksdk.listeners.UiCallback
import com.tilismtech.tellotalksdk.listeners.UiInformableCallback
import com.tilismtech.tellotalksdk.listeners.VideoCompressListener
import com.tilismtech.tellotalksdk.managers.TelloApiClient.Companion.getInstance
import com.tilismtech.tellotalksdk.managers.http.HttpConnectionManager
import com.tilismtech.tellotalksdk.services.NotificationService
import com.tilismtech.tellotalksdk.ui.activities.ConversationActivity
import com.tilismtech.tellotalksdk.ui.activities.MainListActivity
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isAppEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.CryptoLib
import com.tilismtech.tellotalksdk.utils.FileBackend
import com.tilismtech.tellotalksdk.utils.FileBackend.FileCopyException
import com.tilismtech.tellotalksdk.utils.FileUtils
import com.tilismtech.tellotalksdk.utils.ImageUtils
import com.tilismtech.tellotalksdk.utils.TelloConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.InvalidParameterException
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class ChatManager {
    val conversationActivityViewModel: ConversationActivityViewModel =
        ConversationActivityViewModel.getInstance()
    private val fileBackend: FileBackend? = FileBackend.instance
    private val httpConnectionManager = HttpConnectionManager.instance
    private val mWaitingForSmCatchup = AtomicBoolean(false)
    private val mSmCatchupMessageCounter = AtomicInteger(0)
    private var isCorporateChat = false
    private var activity: TelloActivity? = null
    private var chatID = ""
    var isMsgSending: Boolean = false
    var gson: Gson = Gson()

    fun sendMessage(message: TTMessage) {
        getInstance()!!.getAccount() ?: return
        if (chatID == "") if (message.chatId != null) chatID = message.chatId ?: return
        sendMessage(message, chatID)
    }

    fun sendMessage(message: TTMessage?, isCorporateChat: Boolean, chatID: String) {
        this.isCorporateChat = isCorporateChat
        this.chatID = chatID
        sendMessage(message, chatID)
    }

    private fun sendMessage(
        message: TTMessage?, chatID: String
    ) {
        if (message?.needsUploading() == true && message.message?.contains("http") == false) {
            CoroutineScope(Dispatchers.IO).launch {
                isMsgSending = true
                val file: File? = fileBackend?.getFile(message)
                if ((file?.length() ?: 0) > 2000000) {
                    Log.e(
                        "FILE_SIZE_ERROR",
                        "init: FILE SIZE IS GREATER THAN ALLOWED 50MB, SIZE:" + file?.length() + " bytes"
                    )
                    if (activity != null) {
                        activity!!.runOnUiThread {
                            Toast.makeText(
                                activity,
                                "File size cannot be greater than 2MBs",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    return@launch
                }
                message.transmissionCancelled = false
                message.chatId = chatID
                Log.e("UPLOADING", "FILE/IMAGE ${message.messageId}")
                httpConnectionManager?.createNewUploadConnection(message, false)
            }.invokeOnCompletion {
                isMsgSending = false
            }
        } else {
//            setThumb(message)
            message?.chatId = chatID
            getInstance()!!.sendMessage(message)
        }
        CoroutineScope(Dispatchers.IO).launch {
            val conversation = TTConversationRepository.getInstance()
                .getConversationForJid(message?.contactId ?: "")
            if (conversation != null) {
                conversation.isHasMessage = true
                TTConversationRepository.getInstance().updateConversation(conversation)
            }
        }
        conversationActivityViewModel.updateMessage(message)
    }

    fun resendChatbotMsg(
        message: TTMessage?, chatbotChild: ChatbotChild?, listener: OnSuccessListener<Boolean?>?
    ) {
        getInstance()!!.sendChatBotMessage(message!!, chatbotChild?.id.toString(), listener!!)
    }

    fun sendMessageToChatbot(
        message: TTMessage?, chatbotChild: ChatbotChild, listener: OnSuccessListener<Boolean?>?
    ) {
        getInstance()!!.getAccount() ?: return
        val ttMessage = TTMessage()
        ttMessage.contactId = message?.contactId
        ttMessage.message = chatbotChild.name
        ttMessage.isEdited = false
        ttMessage.chatId = message?.chatId
        ttMessage.departmentId = message?.departmentId
        ttMessage.conversationId = message?.conversationId
        ttMessage.msgStatus = TTMessage.MsgStatus.PENDING
        ttMessage.msgDate = Date()
        ttMessage.systemDate = Date()
        ttMessage.msgType = MsgType.TYPE_TEXT.value
        ttMessage.dptType = "2"
        ttMessage.chatbotID = message?.chatbotID
        ttMessage.chatbotNode = message?.chatbotNode
        ttMessage.customData = chatbotChild.childType
        val conversation =
            TTConversationRepository.getInstance().getConversationForJid(ttMessage.contactId ?: "")
        if (conversation != null) {
            conversation.isHasMessage = true
            conversation.lastMessage = ttMessage
            conversation.lastMessageId = ttMessage.messageId
            conversation.created = Date()
            TTConversationRepository.getInstance().updateConversation(conversation)
            conversationActivityViewModel.insertMessage(ttMessage)

        }
        getInstance()!!.sendChatBotMessage(ttMessage, chatbotChild.id.toString(), listener!!)
    }

    @Throws(InvalidParameterException::class)
    fun openDepartmentDialog(context: Context, bundledMsg: String?, customData: String?, department: Department?=null)  {
        val departments = DepartmentRepository.getInstance().allCorporateDpt
        val departmentArrayList = ArrayList<Department>()
        for (i in departments!!.indices) {
            if (departments[i].dptType != "1") {
                departmentArrayList.add(departments[i])
            }
        }
        if (departments.isEmpty()) {
            Toast.makeText(context, "No Department for Chat", Toast.LENGTH_LONG).show()
            return
        }
        val chatNames = arrayOfNulls<String>(departmentArrayList.size)
        for (i in departmentArrayList.indices) {
            chatNames[i] = departmentArrayList[i].dptName
        }
        val lastMsg = TTMessageRepository.instance?.getLastMessageOfConversation(getInstance()!!.getAccount()?.userName)
        val dep = departments.find { it.dptId == lastMsg?.departmentId }
        if (dep != null && (lastMsg?.msgType != MsgType.TYPE_CHATEND.value || !lastMsg.isFeedback)) {
            instance!!.openConversationActivity(
                context,
                lastMsg?.chatId,
                dep.dptName,
                lastMsg?.departmentId,
                dep.dptType ?: "2",
                fromChatList = false,
                bundledMsg = bundledMsg,
                isTwoWay = true,
                custom_data = customData,
                dptimage = dep.dptImage,
                dpt_uname = dep.name_u.toString()
            )
        } else {
            val builderSingle = AlertDialog.Builder(context)
            builderSingle.setTitle("Select service to chat with")
            builderSingle.setNegativeButton("cancel") { dialog: DialogInterface, which: Int -> dialog.dismiss() }
            builderSingle.setItems(
                chatNames
            ) { _, i ->
                instance!!.openConversationActivity(
                    context,
                    "",
                    departmentArrayList[i].dptName,
                    departmentArrayList[i].dptId,
                    departmentArrayList[i].dptType,
                    false,
                    bundledMsg,
                    true,
                    customData,
                    departmentArrayList[i].dptImage,
                    departmentArrayList[i].name_u
                )
            }
            if(departmentArrayList.size==1){
                val singleDep = departmentArrayList.first()
                instance!!.openConversationActivity(
                    context,
                    "",
                    singleDep.dptName,
                    singleDep.dptId,
                    singleDep.dptType?:"2",
                    false,
                    bundledMsg,
                    true,
                    customData,
                    singleDep.dptImage,
                    singleDep.name_u?:""
                )
            }else{
                if(getInstance()?.showDepartmentListDialog==true){
                    if (!(context as Activity).isDestroyed) {
                        builderSingle.show()
                    }
                }else{
                    if(department==null){
                        throw (InvalidParameterException("department parameter cannot be empty. Please set [showDepartmentListDialog] as true or fetch departments from [getDepartments] and pass the selected department in the [openConversation] method"))
                    }
                    instance!!.openConversationActivity(
                        context,
                        "",
                        department?.dptName,
                        department?.dptId,
                        department?.dptType?:"2",
                        false,
                        bundledMsg,
                        true,
                        customData,
                        department?.dptImage,
                        department?.name_u?:""
                    )
                }
            }
        }
    }


    fun openConversationActivity(
        context: Context,
        chatID: String?,
        departmentName: String?,
        departmentId: String?,
        departmentType: String,
        fromChatList: Boolean,
        bundledMsg: String?,
        isTwoWay: Boolean,
        custom_data: String?,
        dptimage: String?,
        dpt_uname: String
    ) {
        val ttAccount = getInstance()!!.getAccount()
        val conversation: TTConversation = if (departmentType == "2") {
            createOrFindConversation(
                ttAccount?.userName?.lowercase(Locale.getDefault()),
                ttAccount?.userName?.lowercase(Locale.getDefault())
            )
        } else {
            createOrFindConversation(departmentName, departmentId)
        }
        openConversation(
            context,
            conversation,
            fromChatList,
            chatID,
            departmentName,
            bundledMsg,
            isTwoWay,
            custom_data,
            dptimage,
            dpt_uname,
            departmentId
        )
    }

    private fun openConversation(
        context: Context,
        conversation: TTConversation,
        fromChatList: Boolean,
        chatID: String?,
        departmentName: String?,
        s: String?,
        isTwoWay: Boolean,
        custom_data: String?,
        dptImage: String?,
        dpt_uname: String,
        dpt_id: String?
    ) {
        val viewConversationIntent = Intent(context, ConversationActivity::class.java)
        viewConversationIntent.putExtra("conversationName", conversation.conversationName)
        viewConversationIntent.putExtra("conversationId", conversation.contactJid)
        viewConversationIntent.putExtra("fromChatList", fromChatList)
        viewConversationIntent.putExtra("isCorporateChat", true)
        if (isAppEnglish) {
            viewConversationIntent.putExtra("departmentName", departmentName)
            viewConversationIntent.putExtra("align", true)
        } else {
            if (dpt_uname == "") {
                // true right
                viewConversationIntent.putExtra("departmentName", departmentName)
                viewConversationIntent.putExtra("align", true)
            } else {
                // true left
                viewConversationIntent.putExtra("departmentName", dpt_uname)
                viewConversationIntent.putExtra("align", false)
            }
        }
        viewConversationIntent.putExtra("chatID", chatID)
        viewConversationIntent.putExtra("isTwoWayDepartment", isTwoWay)
        viewConversationIntent.putExtra("msg", s)
        viewConversationIntent.putExtra("custom_data", custom_data)
        viewConversationIntent.putExtra("dptImage", dptImage)
        viewConversationIntent.putExtra("departmentId", dpt_id)
        (context as Activity).startActivityForResult(viewConversationIntent, 420)
    }


    fun initiateChat(
        departmentID: String?, successListener: OnSuccessListener<Any>
    ) {
        getInstance()!!.initiateChat(departmentID, successListener)
    }

    fun endWebChat(
        chatID: String?,
        listener: OnSuccessListener<Boolean?>?
    ) {
        getInstance()!!.endChat(chatID, listener!!)
    }

    fun sendRating(
        context: Activity?,
        chatID: String?,
        optionID: Int,
        comments: String?,
        listener: OnSuccessListener<Boolean?>?
    ) {
        getInstance()!!.sendRating(context, optionID, comments, chatID!!, listener!!)
    }


    private fun setThumb(message: TTMessage) {
        if (message.msgType == MsgType.TYPE_IMAGE.value || message.msgType == MsgType.TYPE_VIDEO.value) {
            val thumb =
                if (message.msgType == MsgType.TYPE_VIDEO.value) ThumbnailUtils.createVideoThumbnail(
                    message.relativeFilePath ?: "", MediaStore.Video.Thumbnails.MICRO_KIND
                ) else ImageUtils.getimageThumbnail(message.relativeFilePath)
            var thumbString: String? = null
            if (thumb != null) {
                thumbString = FileUtils.getStringFromBitmap(thumb)
            }
            if (thumbString != null) {
                message.thumbnail = thumbString
                conversationActivityViewModel.updateMessage(message)
            }
        }
    }

    fun attachFileToConversation(
        contactJid: String?,
        uri: Uri?,
        filePath: String?,
        msg: TTMessage?,
        fileTag: String?,
        callback: UiInformableCallback<TTMessage>
    ) {
        if (FileBackend.weOwnFile(getInstance()!!.telloContext, uri)) {
            callback.error(R.string.security_error_invalid_file_access, null)
            return
        }
        val message: TTMessage = msg ?: TTMessage("")
        message.contactId = contactJid
        val fileName = FileBackend.getFileNameFromUri(activity?.baseContext!!, uri ?: Uri.EMPTY)
        if (!isEmptyString(fileName)) {
            message.caption = fileTag?.takeIf { it.isNotEmpty() }?:""
            message.originalFileName = fileName
        }
//        var path: String? = null
//        path = filePath ?: fileBackend?.getOriginalPath(uri)
//        val finalPath = path
        val file = File(activity?.cacheDir, FileBackend.getFileNameFromUri(activity!!,uri!!))
        CoroutineScope(Dispatchers.IO).launch {
            fun setMessageTypeWithCopressionAndCopyOfFile() {
                val path = message.relativeFilePath
                if (!isEmptyString(path)) {
                    val file = fileBackend?.getFile(message)
                    if (file?.mimeType?.startsWith("video/") == true) {
                        message.msgType = MsgType.TYPE_VIDEO.value
                        callback.success(message)
                    } else {
                        if (path?.contains(TelloConfig.TELLO_ROOT) == false) {
                            try {
                                fileBackend?.copyFileToPrivateStorage(message, uri ?: Uri.EMPTY)
                            } catch (e: FileCopyException) {
                                callback.error(e.resId, message)
                                message.relativeFilePath = path
                            }
                        }
                        if (file?.mimeType?.startsWith("audio") == true) {
                            message.msgType = MsgType.TYPE_AUDIO.value
                        } else {
                            message.msgType = MsgType.TYPE_FILE.value
                        }
                        updateFile(null, message, callback)
                    }
                }
            }
            if (file.exists()) {
                message.relativeFilePath = file.path
            } else {
                try {
                    fileBackend?.setActivity(activity)
                    fileBackend?.copyFileToPrivateStorage(message, uri)
                } catch (e: FileCopyException) {
                    e.printStackTrace()
                    callback.error(e.resId, message)
                }
            }
            setMessageTypeWithCopressionAndCopyOfFile()
        }
    }

    private fun updateFile(
        filePath: String?, message: TTMessage, callback: UiInformableCallback<TTMessage>
    ) {
        if (!isEmptyString(filePath)) {
            message.relativeFilePath = filePath
        }
        fileBackend?.updateFileParams(message)
        if (filePath == null) {
            callback.success(message)
        } else {
            callback.success(message)
        }
    }

    fun compressVideo(
        message: TTMessage, path: String?, callback: UiInformableCallback<TTMessage>
    ) {
        if (message.msgStatus != TTMessage.MsgStatus.UNCOMPRESSED && message.msgStatus != TTMessage.MsgStatus.COMPRESSING) {
            message.msgStatus = TTMessage.MsgStatus.UNCOMPRESSED
            conversationActivityViewModel.insertMessage(message)

        }
        if (Build.VERSION.SDK_INT >= 18) {
            message.msgStatus = TTMessage.MsgStatus.COMPRESSING
            conversationActivityViewModel.insertMessage(message)

            fileBackend?.videoEncoder(
                Uri.fromFile(File(message.relativeFilePath)), object : VideoCompressListener {
                    override fun onVideoCompressionSuccess(filepath: String) {
                        message.msgStatus = TTMessage.MsgStatus.PENDING
                        conversationActivityViewModel.insertMessage(message)

                        updateFile(filepath, message, callback)
                    }

                    override fun onVideoCompressionFailed() {
                        message.msgStatus = TTMessage.MsgStatus.PENDING
                        conversationActivityViewModel.insertMessage(message)

                        updateFile(path, message, callback)
                    }

                    override fun onProgress(progress: Int) {}
                })
        } else {
            message.msgStatus = TTMessage.MsgStatus.PENDING
            conversationActivityViewModel.insertMessage(message)

            updateFile(path, message, callback)
        }
    }

    val departmentConversation: ArrayList<DepartmentConversations?>?
        get() = getInstance()!!.departmentConversations as ArrayList<DepartmentConversations?>?

    fun attachImageToConversation(uri: Uri?, mimeType: String?, callback: UiCallback<TTMessage>) {
        //  if (FileBackend.weOwnFile(TelloApplication.instance, uri)) {
        //      callback.error(R.string.security_error_invalid_file_access, null);
        //      return;
        //  }
        val message = TTMessage("")
        message.msgType = MsgType.TYPE_IMAGE.value
        CoroutineScope(Dispatchers.IO).launch {
            try {
                fileBackend?.setActivity(activity)
                fileBackend?.copyImageToPrivateStorage(message, uri ?: Uri.EMPTY, mimeType ?: "")
                callback.success(message)
            } catch (e: FileCopyException) {
                callback.error(e.resId, message)
            }
        }
    }

    private fun createOrFindConversation(contactName: String?, contactId: String?): TTConversation {
        var conversation: TTConversation?
        conversation =
            TTConversationRepository.getInstance().getConversationForJid(contactId.toString())
        if (conversation == null) {
            conversation = TTConversation(contactName, contactId!!) //
            conversation.isCe = false
            conversation.created = Date()
            TTConversationRepository.getInstance().insertConversation(conversation)
        }
        return conversation
    }

    fun handlePrevMsg(message: TTWebMessagaRequest, profileId: String?) {
        val ttAccount = getInstance()!!.getAccount()
        var ttMessage = TTMessageRepository.instance?.getMessage(message.messageId)
        if(message.msgType == MsgType.TYPE_CHATEND.value){
            val lastMsg = TTMessageRepository.instance?.getLastMessageOfConversation(ttAccount?.userName)
            if(lastMsg?.msgType==MsgType.TYPE_CHATEND.value){
                return
            }
        }
        if (ttMessage != null) {
            if (!ttMessage.isDeleted || (message.isDeleted)!!) {
                ttMessage.isDeleted = (message.isDeleted)!!
            } else if ((message.isEdited)!!) {
                ttMessage.isEdited = (message.isEdited)!!
                //getDecryptedString(
                ttMessage.message = message.message
                ttMessage.msgDate = Date(message.msgDate)
                ttMessage.systemDate = (Date(message.msgDate))
            } else {
                return
            }
        }
        val currentConversationOpen = getInstance()?.getmCurrentConversationOpen()
        if (ttMessage == null) {
            ttMessage = TTMessage()
            if ((message.dptType == "2")) {
                ttMessage.contactId = ttAccount?.userName
            } else {
                ttMessage.contactId = message.departmentId?.ifEmpty { message.departmentId }
            }
            if ((message.dptType == "2")) {
                ttMessage.conversationId = ttAccount?.userName
            } else {
                ttMessage.conversationId = message.departmentId?.ifEmpty { message.departmentId }
            }
            //            }
            ttMessage.messageId = message.messageId
            ttMessage.chatId = message.chatId
            ttMessage.departmentId = message.departmentId
            ttMessage.message = (message.message)
            ttMessage.departmentName = message.departmentName
            ttMessage.caption = message.caption
            ttMessage.isDeleted = (message.isDeleted)!!
            ttMessage.isEdited = (message.isEdited)!!
            ttMessage.msgDate =
                Date((message.msgDate))
            ttMessage.systemDate =
                Date((message.msgDate))
            ttMessage.thumbnail = message.thumbnail
            ttMessage.msgURL = message.msgURL
            ttMessage.msgHeading = message.msgHeading
            if ((message.originalFileName == "")) {
                val s = message.message?.split("/".toRegex())?.dropLastWhile { it.isEmpty() }
                    ?.toTypedArray()
                ttMessage.originalFileName = s?.lastOrNull()
            } else {
                ttMessage.originalFileName = message.originalFileName
            }
            ttMessage.dptType = message.dptType
            ttMessage.button_det = gson.toJson(message.buttonDet)
            if(message.msgType == MsgType.TYPE_CHATEND.value){
                val lastMsg = TTMessageRepository.instance?.getLastMessageOfConversation(ttAccount?.userName)
                if(lastMsg?.chatId==message.chatId && lastMsg?.isFeedback==false){
                    ttMessage.isFeedback = false
                }
            }else{
                ttMessage.isFeedback = true
            }
            ttMessage.departmentName_u = message.departmentName_u
            ttMessage.dptImage = message.dImage
            ttMessage.audio_Length = message.audioLength
            //   ttMessage.setOriginalFileName(message.getOriginalFileName());
            ttMessage.isRead_count = false
            ttMessage.campaignId = message.campaignId
            ttMessage.msgExpTime = Date((message.msgExpTime)!!)
            ttMessage.chatbotID = message.chatbotID
            ttMessage.chatbotNode = gson.toJson(message.chatbotNode)
            ttMessage.agentAvatar = message.agentAvatar
            ttMessage.viewId = message.viewId
        }

        if (message.profileId.equals(profileId, ignoreCase = true)) {
            ttMessage.msgStatus = TTMessage.MsgStatus.SENT
            if (message.deliveryDate != "0") {
                ttMessage.msgStatus = TTMessage.MsgStatus.DELIVERED
            }
            if (message.readDate != "0") {
                ttMessage.msgStatus = TTMessage.MsgStatus.READ
            }
            ttMessage.profileId = message.profileId!!.lowercase(Locale.getDefault())
            ttMessage.receiverId = message.receiverId
        } else if (message.receiverId.equals(profileId, ignoreCase = true)) {
            ttMessage.receiverId = message.receiverId!!.lowercase(Locale.getDefault())
            ttMessage.profileId = message.profileId
            ttMessage.msgStatus = TTMessage.MsgStatus.RECEIVED
        }else{
            return
        }
        if ((message.isDeleted)!!) {
            ttMessage.msgType = MsgType.TYPE_DELETED.value
        } else {
            if ((message.msgType == "view")) {
                ttMessage.msgType = MsgType.TYPE_TEXT.value
            } else {
                ttMessage.msgType = message.msgType
            }
        }
        ttMessage.isRead = false
        ttMessage.displayStatus = TTMessage.MsgDisplayStatus.NONE.ordinal
        if (ttMessage.treatAsDownloadable()) {
            val connectionManager = HttpConnectionManager()
            connectionManager.createNewDownloadConnection(ttMessage)
        }
        ttMessage.replyMsgId = message.replyMsgId
        if (currentConversationOpen != null && (currentConversationOpen.contactJid == message.profileId)) {
            ttMessage.isRead = true
            ttMessage.displayStatus = TTMessage.MsgDisplayStatus.READ.ordinal
        }
        CoroutineScope(Dispatchers.IO).launch {
            conversationActivityViewModel.insertMessage(ttMessage)
        }
    }

    fun handleTyping(typingObject: TypingObject?) {
        conversationActivityViewModel.setTyping(typingObject?.typing == true)
    }

    fun updateTyping(isTyping: Boolean) {
        val lastMsg =
            conversationActivityViewModel.getLastMessageOfConversation(TelloApiClient.getInstance()!!.getAccount()?.userName)
        val agent = Gson().fromJson(
            TelloPreferencesManager.getInstance().getString(lastMsg?.chatId),
            AgentDetailResponse::class.java
        )
        if (agent==null) {
            return
        }
        MessageRepo(MessageSocket()).updateTyping(
            TypingObject(
                agent.agentId,
                isTyping,
                lastMsg?.chatId
            )
        ) {}
    }

    fun handleMessage(message: TTWebMessagaRequest) {
        val ttAccount = TelloApiClient.getInstance()!!.getAccount()
        var ttMessage: TTMessage? = TTMessageRepository.instance?.getMessage(message.messageId)

        if (ttMessage != null) {
            if ((message.isDeleted)!!) {
                ttMessage.isDeleted = (message.isDeleted)!!
                ttMessage.msgDate = Date(message.msgDate)
            } else if ((message.isEdited)!!) {
                ttMessage.isEdited = (message.isEdited)!!
                //getDecryptedString(
                ttMessage.message = message.message
                ttMessage.msgDate = Date(message.msgDate)
                ttMessage.systemDate = (Date(message.msgDate))
            } else if ((message.message == "The message has been deleted.")) {
                ttMessage.isDeleted = true
            } else {
                return
            }
            conversationActivityViewModel.updateMessage(ttMessage)
            return
        }

        val currentConversationOpen = getInstance()?.getmCurrentConversationOpen()
        val conversation: TTConversation = if ((message.dptType == "2")) {
            instance!!.createOrFindConversation(
                "+" + ttAccount?.userName?.lowercase(
                    Locale.getDefault()
                ), ttAccount?.userName?.lowercase(Locale.getDefault())
            )
        } else {
            instance!!.createOrFindConversation(
                "+" + message.departmentId,
                message.departmentId)
        }
        ttMessage = TTMessage()
        if ((message.dptType == "2")) {
            ttMessage.contactId = ttAccount?.userName?.lowercase(Locale.getDefault())
        } else {
            ttMessage.contactId = message.departmentId
        }
        ttMessage.profileId = message.profileId
        ttMessage.receiverId = message.receiverId!!.lowercase(Locale.getDefault())
        if ((message.dptType == "2")) {
            ttMessage.conversationId = ttAccount?.userName
        } else {
            ttMessage.conversationId = message.departmentId
        }
        ttMessage.messageId = message.messageId
        ttMessage.chatId = message.chatId
        ttMessage.departmentId = message.departmentId
        ttMessage.message = (message.message)
        ttMessage.departmentName = message.departmentName
        ttMessage.caption = message.caption
        ttMessage.isDeleted = (message.isDeleted)!!
        ttMessage.isEdited = (message.isEdited)!!
        ttMessage.msgDate =
            Date((message.msgDate))
        ttMessage.systemDate =
            Date((message.msgDate))
        ttMessage.thumbnail = message.thumbnail
        ttMessage.msgURL = message.msgURL
        ttMessage.msgHeading = message.msgHeading
        if ((message.msgType == MsgType.TYPE_FILE.value) && (message.originalFileName == "")) {
            val s =
                message.message!!.split("/".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            ttMessage.originalFileName = s[s.size - 1]
        } else {
            ttMessage.originalFileName = message.originalFileName
        }
        ttMessage.dptType = message.dptType
        ttMessage.button_det = gson.toJson(message.buttonDet)
        ttMessage.isFeedback = false
        ttMessage.departmentName_u = message.departmentName_u
        ttMessage.dptImage = message.dImage
        ttMessage.audio_Length = message.audioLength
        ttMessage.campaignId = message.campaignId
        ttMessage.chatbotID = message.chatbotID
        ttMessage.chatbotNode = gson.toJson(message.chatbotNode)
        ttMessage.agentAvatar = message.agentAvatar
        if (message.msgExpTime != 0L) {
            ttMessage.msgExpTime = Date((message.msgExpTime)!!)
        } else if ((message.msgExpTime.toString() == "null") || message.msgExpTime == 0L) {
            ttMessage.msgExpTime = null
        }
        ttMessage.isRead_count = true
        ttMessage.msgStatus = TTMessage.MsgStatus.RECEIVED
        if ((message.isDeleted)!!) {
            ttMessage.msgType = MsgType.TYPE_DELETED.value
        } else if ((message.message == "The message has been deleted.")) {
            ttMessage.isDeleted = true
            ttMessage.msgType = MsgType.TYPE_DELETED.value
        } else {
            if ((message.msgType == "view")) {
                ttMessage.msgType = MsgType.TYPE_TEXT.value
            } else {
                ttMessage.msgType = message.msgType
            }
        }
        ttMessage.isRead = false
        ttMessage.displayStatus = TTMessage.MsgDisplayStatus.NONE.ordinal
        if (ttMessage.treatAsDownloadable()) {
            val connectionManager = HttpConnectionManager()
            connectionManager.createNewDownloadConnection(ttMessage)
        }
        ttMessage.replyMsgId = message.replyMsgId
        if (currentConversationOpen != null && (currentConversationOpen.contactJid == message.receiverId)) {
            ttMessage.isRead = true
            ttMessage.isRead_count = false
            ttMessage.displayStatus = TTMessage.MsgDisplayStatus.READ.ordinal
        }
//        if ((ttMessage.chatbotNode != null) && (ttMessage.chatbotNode.type == "agent")) {
//            getInstance()!!
//                .sendChatBotMessage(ttMessage, ttMessage.chatbotNode.id.toString(), null)
//        }
        conversationActivityViewModel.insertMessage(ttMessage)

        conversation.lastMessageId = ttMessage.messageId
        conversation.lastMessage = ttMessage
        conversation.created = ttMessage.msgDate
        conversation.isHasMessage = true
        //  }
        TTConversationRepository.getInstance().updateConversation(conversation)
        if ((currentConversationOpen == null || currentConversationOpen.contactJid != conversation.contactJid)) {
            if (!ttMessage.isDeleted && !ttMessage.isEdited) {
                if (ttMessage.msgExpTime != null) {
                    if ((ttMessage.msgExpTime?.time ?: 0) > System.currentTimeMillis()) {
                        conversation.unreadCount += 1
                    }
                } else {
                    conversation.unreadCount += 1
                }
            }
            getInstance()?.onNotifyMessageCount()
            conversationActivityViewModel.updateMessage(ttMessage)
            TTConversationRepository.getInstance().updateConversation(conversation)
            if (ttMessage.msgExpTime != null) {
                if ((ttMessage.msgExpTime?.time ?: 0) > System.currentTimeMillis()) {
                    showNotification(ttMessage, conversation)
                }
            } else {
                showNotification(ttMessage, conversation)
            }
        }
    }

    private fun showNotification(ttMessage: TTMessage?, conversation: TTConversation?) {
        if (!TelloApiClient.getInstance()!!.isForegroundMode) {
            NotificationService.instance?.push(ttMessage, conversation)
        }
    }

    val isWaitingForSmCatchup: Boolean
        get() = mWaitingForSmCatchup.get()

    fun incrementSmCatchupMessageCounter() {
        mSmCatchupMessageCounter.incrementAndGet()
    }

    fun getMessageAnnouncement(isChat: Boolean, departmentID: String?) {
        getInstance()!!.getMessageAnnouncement(isChat, departmentID)
    }

    fun sendWebReadAck(contactJid: String?) {
        getInstance()!!.sendAck(contactJid)
    }

    val uploadService: RestWebService?
        get() = getInstance()!!.getUploadService()

    fun clearNotification(currentConversation: TTConversation?) {
        currentConversation?.let { NotificationService.instance?.clear(it) }
        getInstance()?.onNotifyMessageCount()
    }

    fun onNotificationClicked(
        message_id: String?, broadcastFrom: String?, message_type: String?, campaignId: String?
    ) {
        getInstance()!!.onNotificationClicked(message_id, broadcastFrom, message_type, campaignId)
    }

    fun onAnnouncementClicked(
        message_id: String?, broadcastFrom: String?, message_type: String?, campaignId: String?
    ) {
        getInstance()!!.onAnnouncementClicked(message_id, broadcastFrom, message_type, campaignId)
    }

    fun getMessageRequest(msg: TTMessage?, chatBotNodeId: String? = ""): MessageRequestModel {
        return MessageRequestModel(
            msg?.chatId,
            msg?.message,
            msg?.messageId,
            msg?.profileId,
            /*if (msg.msgDate != null) msg.msgDate?.time.toString() else*/ System.currentTimeMillis()
                .toString(),
            msg?.profileId,
            msg?.chatbotID,
            chatBotNodeId,
            chatBotNodeId?.isNotEmpty(),
            msg?.msgType,
            msg?.replyMsgId,
            msg?.caption,
            msg?.receiverId,
            msg?.originalFileName,
            msg?.thumbnail,
            "",
            msg?.msgType == MsgType.TYPE_DELETED.value,
            false
        )
    }

    fun getDepartment(successListener: OnSuccessListener<List<Department>>) {
        getInstance()!!.getDepartmentList(successListener)
    }

    fun setNotificationListener(mainListActivity: MainListActivity?) {
        getInstance()!!.setMessageCounterListener(mainListActivity)
    }

    fun deleteOtherUserMsgs(profileID: String?) {
        TTMessageRepository.instance?.deleteOtherUserMsg(profileID)
    }

    fun generateToken(token: String?): String? {
        val data = Base64.decode(token, Base64.DEFAULT)
        var text = ""
        var decr = ""
        try {
            text = String(data, StandardCharsets.UTF_8)
            decr = CryptoLib.instance!!.decrypt(text)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Base64.encodeToString(decr.toByteArray(), Base64.NO_WRAP)
    }

    fun getAgentDetails(id: String?, successListener: OnSuccessListener<AgentDetailResponse?>?) {
        getInstance()!!.getAgentDetails(id, successListener!!)
    }

    fun getAgentList(
        departmentID: String?, successListener: OnSuccessListener<AgentListResponse?>?
    ) {
        getInstance()!!.getAgentList(departmentID, successListener!!)
    }

    fun submitForm(
        submitChatFormRequest: SubmitChatFormRequest?, listener: OnSuccessListener<String?>?
    ) {
        getInstance()!!.submitChatRequestForm(submitChatFormRequest, listener!!)
    }

    fun getChatRequestForm(formId: String?, listener: OnSuccessListener<ChatFormResponse?>?) {
        getInstance()!!.getChatRequestForm(listener, formId)
    }

    fun uploadFileToForms(file: File?, successListener: OnSuccessListener<String>) {
        getInstance()!!.uploadFile(file!!, successListener)
    }

    fun getSubmitForm(
        viewId: String?, successListener: OnSuccessListener<SubmittedFormResponse?>?
    ) {
        getInstance()!!.getFormData(viewId, successListener!!)
    }

    companion object {
        @JvmStatic
        var instance: ChatManager? = null
            get() {
                if (field == null) {
                    field = ChatManager()
                    field!!.initSocket()
                }
                return field
            }
            private set
    }

    fun setActivity(activity: TelloActivity?) {
        this.activity = activity
    }

    fun downloadFile(message: TTMessage) {
        if (message.treatAsDownloadable()) {
            message.transmissionCancelled = false
            if (message.isDownloaded) {
                conversationActivityViewModel.updateMessage(message)
                return
            }
            val connectionManager = HttpConnectionManager()
            connectionManager.createNewDownloadConnection(message)
        }
    }

    fun listenToMessages(isCorporateChat: Boolean) {
        getInstance()?.listenToEvents(isCorporateChat)
    }

    fun initSocket() {
        val departments = DepartmentRepository.getInstance().allCorporateDpt
        val lastMsg = TTMessageRepository.instance?.getLastMessageOfConversation(TelloApiClient.getInstance()!!.getAccount()?.userName)
        val dep = departments.find { it.dptId == lastMsg?.departmentId }
        if (dep != null) {
            listenToMessages(true)
        }
    }

    /**
     * Sets whether the chat UI should only show previous messages.
     *
     * @param prvMsgOnly `false` to allow sending new messages, otherwise `true`.
     */
    fun setShowPreviousMessagesOnly(prvMsgOnly: Boolean) {
        getInstance()?.showPreviousMessagesOnly = prvMsgOnly
    }

    /**
     * Returns whether the chat UI should only show previous messages.
     *
     * @return `false` if only previous messages should be displayed, otherwise `true`.
     */
    fun isShowPreviousMessagesOnly(): Boolean {
        return getInstance()?.showPreviousMessagesOnly ?: false
    }

    /**
     * Sets whether the bundled text should be shown in the chat UI.
     *
     * @param hideMsgFromUser `true` to hide the bundled text, otherwise `false`.
     */
    fun setShowBundledText(hideMsgFromUser: Boolean) {
        getInstance()?.showBundledMsg = hideMsgFromUser
    }

    /**
     * Returns whether the bundled text should be shown in the chat UI.
     *
     * @return `true` if the bundled text should be displayed, otherwise `false`.
     */
    fun isShowBundledText(): Boolean {
        return getInstance()?.showBundledMsg ?: false
    }

    /**
     * Sets whether the large send button should be shown in the chat UI.
     *
     * @param showLargeSendButton `true` to display the large send button, otherwise `false`.
     */
    fun setShowLargeSendButton(showLargeSendButton: Boolean) {
        getInstance()?.showLargeSendButton = showLargeSendButton
    }

    /**
     * Returns whether the large send button should be shown in the chat UI.
     *
     * @return `true` if the large send button should be displayed, otherwise `false`.
     */
    fun isShowLargeSendButton(): Boolean {
        return getInstance()?.showLargeSendButton ?: true
    }

    fun stopEvent(typingEvents: String) {
        getInstance()?.stopEvent(typingEvents)
    }
}