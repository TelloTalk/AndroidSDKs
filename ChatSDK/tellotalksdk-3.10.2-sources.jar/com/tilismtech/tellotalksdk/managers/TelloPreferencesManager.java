package com.tilismtech.tellotalksdk.managers;

import android.content.Context;
import android.content.SharedPreferences;

public class TelloPreferencesManager {

    private static TelloPreferencesManager instance;
    private static final String PREFRENSE_NAME = "Tello_Pref";
    public static final String REGISTER_SUCCESS = "registered";
    public static final String CORPORATE_USER = "corporateUser";
    public static final String IS_TOKEN_UPDATED = "tokenUpdated";
    public static final String FCM_TOKEN = "fcmToken";
    public static final String LANGUAGE_PRESERVED = "language_preserved";
    public static final String GOOGLE_API_KEY = "google_api_key";
    private final SharedPreferences.Editor editor;
    private final SharedPreferences sharedPreferences;

    public static TelloPreferencesManager getInstance(){
        if (instance == null){
            instance = new TelloPreferencesManager();
        }
        return instance;
    }

    private TelloPreferencesManager(){
         sharedPreferences = TelloApiClient.getInstance().telloContext.getSharedPreferences(PREFRENSE_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public int getInt(String languagePreserved) {
        return sharedPreferences.getInt(languagePreserved, -1);
    }

    public void setIntValue(String languagePreserved, int index) {

        editor.putInt(languagePreserved , index);
        editor.apply();
    }

    public void setFeedBack(String feedBack){
        editor.putString("FeedBack" , feedBack);
        editor.apply();
    }

    public void putBoolean(String key,boolean value){
        editor.putBoolean(key , value);
        editor.apply();
    }

    public void putString(String key,String value){
        editor.putString(key , value);
        editor.apply();
    }


    public String getFeedback(){
        return sharedPreferences.getString("FeedBack", "null");
    }

    public String getString(String key){
        return sharedPreferences.getString(key,"");
    }

    public boolean getBoolean(String key){
        return sharedPreferences.getBoolean(key,false);
    }



    void clearAll(){
        editor.clear().apply();
    }

    public void setGoogleApiKey(String key){
        putString(GOOGLE_API_KEY, key);
    }

    public String getGoogleApiKey() {
        return getString(GOOGLE_API_KEY);
    }
}
