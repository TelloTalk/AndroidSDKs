package com.tilismtech.tellotalksdk.managers.http

import android.util.Log
import android.util.Pair

import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.module.requests.ProgressRequestBody
import com.tilismtech.tellotalksdk.data.network.module.responses.FileUploadResponse
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.managers.http.interfaces.Transferable
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.DownloadableFile
import com.tilismtech.tellotalksdk.utils.FileBackend
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.util.Locale

/**
 * Created by Sohail on 2/9/18.
 */
class HttpUploadConnection internal constructor() : Transferable {
    private var canceled = false
    private var account: TTAccount? = null
    private var file: DownloadableFile? = null
    private var message: TTMessage? = null
    private val transmitted = 0.0
    private var mFileInputStream: InputStream? = null
    private val fileBackend: FileBackend?

    init {
        fileBackend = FileBackend.instance
    }

    override fun start(): Boolean {
        return false
    }

    override fun getStatus(): Int {
        return Transferable.STATUS_UPLOADING
    }

    override fun getFileSize(): Long {
        return if (file == null) 0 else file!!.expectedSize
    }

    override fun getProgress(): Int {
        return if (file == null) {
            0
        } else (transmitted / file!!.expectedSize * 100).toInt()
    }

    override fun cancel() {
        canceled = true
    }

    override fun setMessage(message: TTMessage) {
        this.message = message
    }

    private fun fail(msgStatus: TTMessage.MsgStatus, error : String?="") {
        message!!.msgStatus = msgStatus
        message!!.transmissionCancelled = true
        message!!.transferable = null
        FileBackend.instance?.showToast(error?:"")
        ConversationActivityViewModel.getInstance().insertMessage(message!!)
    }

    fun init(message: TTMessage, delay: Boolean) {
        this.message = message
        CoroutineScope(Dispatchers.IO).launch {
            file = fileBackend?.getFile(message)

            if (file!!.length() > 2000000) {
                Log.e(
                    "FILE_SIZE_ERROR",
                    "init: FILE SIZE IS GREATER THAN ALLOWED 50MB, SIZE:" + file!!.length() + " bytes"
                )
                return@launch
            }
            val pair: Pair<InputStream, Int> = try {
                AbstractConnectionManager.createInputStream(file, true)
            } catch (e: FileNotFoundException) {
                fail(TTMessage.MsgStatus.PENDING)
                return@launch
            }
            file!!.expectedSize = pair.second.toLong()
            mFileInputStream = pair.first
            if (!canceled) {
                FileUploader().uploadFile()
            }
            message.transferable = this@HttpUploadConnection
            TransferableManager.getInstance()
                .setTransferableForMessage(message.messageId, this@HttpUploadConnection)
        }
    }

    private inner class FileUploader {
        fun uploadFile() {
            if(file?.length()==0L){
                ChatManager.instance?.sendMessage(message!!)
                return
            }
            val fileBody = ProgressRequestBody(file, "") { percentage ->
                if (message!!.msgStatus != TTMessage.MsgStatus.COMPRESSING) {
                    message!!.transmissionCancelled = false
                    message!!.progress = percentage
                }
            }
            val filePart = MultipartBody.Part.createFormData("file", file!!.name, fileBody)
            account = TelloApiClient.getInstance()!!.getAccount()
            try{
                val req: Call<FileUploadResponse> = ChatManager.instance!!.uploadService!!.uploadFile(
                    ChatManager.instance?.generateToken(
                        account?.accessToken
                    ), account?.userName, filePart
                )
                req.enqueue(object : Callback<FileUploadResponse> {
                    override fun onResponse(
                        call: Call<FileUploadResponse>, response: Response<FileUploadResponse>
                    ) {
                        if (response.isSuccessful) {
                            try {
                                mFileInputStream!!.close()
                            } catch (e: IOException) {
                                e.printStackTrace()
                            }
                            fileBackend!!.updateFileParams(message!!, response.body()?.path)
                            message!!.transferable = null
                            message!!.transmissionCancelled = false
                            TransferableManager.getInstance()
                                .removeTransferableFromMap(message!!.messageId)
                            ChatManager.instance!!.sendMessage(message!!)
                        } else {
                            val error = response.errorBody()?.string()
                            if (error?.lowercase(Locale.getDefault())
                                    ?.contains("invalidtoken") == true
                            ) {
                                TelloApiClient.getInstance()?.getNewToken {
                                    if (it == true) {
                                        uploadFile()
                                    }
                                }
                                fail(TTMessage.MsgStatus.PENDING)
                            }else{
                                if(response.code()==413){
                                    fail(TTMessage.MsgStatus.ERROR,"File is too large")
                                }
                            }
                        }
                    }

                    override fun onFailure(call: Call<FileUploadResponse>, throwable: Throwable) {
                        fail(TTMessage.MsgStatus.PENDING)
                    }
                })
            }catch (e:Exception){
                Log.e("FILE_UPLOAD_ERROR", e.localizedMessage)
            }

        }
    }
}