package com.tilismtech.tellotalksdk.managers.http.interfaces;

import com.tilismtech.tellotalksdk.data.db.entities.TTMessage;

import java.util.Arrays;
import java.util.List;

/**
 * Created by AbdulMomen on 2/9/18.
 */

public interface Transferable {

    List<String> VALID_IMAGE_EXTENSIONS = Arrays.asList("webp", "jpeg", "jpg", "png", "jpe");
    List<String> VALID_CRYPTO_EXTENSIONS = Arrays.asList("pgp", "gpg", "otr");
    List<String> WELL_KNOWN_EXTENSIONS = Arrays.asList("pdf","m4a","mp4","3gp","aac","amr","mp3");
    List<String> VALID_AUDIO_EXTENSIONS = Arrays.asList("mp3","3gp", "m4a","flac");
    List<String> VALID_VIDEO_EXTENSIONS = Arrays.asList("mp4","3gp", "mkv","webm");

    int STATUS_UNKNOWN = 0x200;   //512
    int STATUS_CHECKING = 0x201;  //513
    int STATUS_FAILED = 0x202;   //514
    int STATUS_OFFER = 0x203;    //515
    int STATUS_DOWNLOADING = 0x204;  //516
    int STATUS_DELETED = 0x205;     //517
    int STATUS_OFFER_CHECK_FILESIZE = 0x206;   //518
    int STATUS_UPLOADING = 0x207;    //519
    int STATUS_UPLOAD_FAILED = 0x208; //520


    boolean start();

    int getStatus();

    long getFileSize();

    int getProgress();

    void cancel();

    void setMessage(TTMessage message);
}
