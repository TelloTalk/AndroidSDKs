package com.tilismtech.tellotalksdk.managers.http;

import com.tilismtech.tellotalksdk.managers.http.interfaces.Transferable;

import java.util.HashMap;

/**
 * Created by sajjad on 27/03/2018.
 */

public class TransferableManager {
    private static final TransferableManager ourInstance = new TransferableManager();
    private HashMap<String, Transferable> transferableHashMap;

    public static TransferableManager getInstance() {
        return ourInstance;
    }

    private TransferableManager() {
        transferableHashMap = new HashMap<>();
    }

    public Transferable getTransferable(String uuid) {
        return transferableHashMap.get(uuid);
    }

    void setTransferableForMessage(String uuid, Transferable transferable) {
        transferableHashMap.put(uuid, transferable);
    }

    void removeTransferableFromMap(String uuid) {
        transferableHashMap.remove(uuid);
    }
}

