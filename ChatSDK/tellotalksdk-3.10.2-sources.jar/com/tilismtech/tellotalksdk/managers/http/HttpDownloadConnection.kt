package com.tilismtech.tellotalksdk.managers.http

import android.util.Log
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.events.DownloadFinishedEvent
import com.tilismtech.tellotalksdk.managers.http.interfaces.Transferable
import com.tilismtech.tellotalksdk.packages.eventbus.EventBus
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.Config
import com.tilismtech.tellotalksdk.utils.DownloadableFile
import com.tilismtech.tellotalksdk.utils.FileBackend
import com.tilismtech.tellotalksdk.utils.FileBackend.Companion.close
import com.tilismtech.tellotalksdk.utils.FileWriterException
import com.tilismtech.tellotalksdk.utils.TelloConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.util.Locale
import java.util.concurrent.CancellationException
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLHandshakeException

/**
 * Created by Sohail on 2/9/18.
 */
class HttpDownloadConnection internal constructor(private val httpConnectionManager: HttpConnectionManager) :
    Transferable {
    private var url: URL? = null
    var message: TTMessage? = null
        private set
    private var file: DownloadableFile? = null
    private var status = Transferable.STATUS_UNKNOWN
    private var acceptedAutomatically = false
    private var mProgress = 0
    private var canceled = false
    private val fileBackend: FileBackend?

    init {
        fileBackend = FileBackend.instance
    }

    override fun start(): Boolean {
        return if (hasInternetConnection()) {
            if (status == Transferable.STATUS_OFFER_CHECK_FILESIZE) {
                checkFileSize(true)
            } else {
                FileDownloader(true).run()
            }
            true
        } else {
            false
        }
    }

    @JvmOverloads
    fun init(message: TTMessage, interactive: Boolean = false) {
        try {
            this.message = message
            url = if (message.message?.contains("http") == true) {
                URL(this.message!!.message?.replace(" ".toRegex(), "%20"))
            } else {
                URL(
                    NetworkConstants.BASE_URL1 + this.message!!.message?.replace(
                        " ".toRegex(),
                        "%20"
                    )
                )
            }
            var extension: String? = null
            val parts = this.message!!.message?.split("\\.".toRegex())?.dropLastWhile { it.isEmpty() }
                ?.toTypedArray()
            if (url != null) {
                val nameParts = if ((parts?.size?:0) >= 1) parts?.lastOrNull()?.split("\\.".toRegex())
                    ?.dropLastWhile { it.isEmpty() }
                    ?.toTypedArray() else null
                extension = if (!nameParts.isNullOrEmpty()) {
                    nameParts[nameParts.size - 1]
                } else {
                    ""
                }
            }
            extension = extension!!.lowercase(Locale.getDefault())
            val time = System.currentTimeMillis()
            if (isEmptyString(this.message!!.relativeFilePath)) {
                if (TTMessage.MsgType.TYPE_IMAGE.value == message.msgType) {
                    this.message!!.relativeFilePath = "IMG-$time.$extension"
                } else if (TTMessage.MsgType.TYPE_AUDIO.value == message.msgType) {
                    this.message!!.relativeFilePath = "AUD-$time.$extension"
                } else if (TTMessage.MsgType.TYPE_FILE.value == message.msgType) {
                    var fileName = ""
                    fileName = if (!isEmptyString(parts?.firstOrNull())) {
                        val split = parts?.firstOrNull()?.split("/".toRegex())?.dropLastWhile { it.isEmpty() }
                            ?.toTypedArray()
                        split?.lastOrNull() + time.toString()
                    } else {
                        "FILE-$time"
                    }
                    fileName = getFinalFileName(extension, fileName)
                    this.message!!.relativeFilePath = fileName
                } else if (TTMessage.MsgType.TYPE_VIDEO.value == message.msgType) {
                    this.message!!.relativeFilePath = "VID-$time.$extension"
                } else {
                    this.message!!.relativeFilePath = "FILE-$time.$extension"
                }
                updateMessage()
            }
            CoroutineScope(Dispatchers.IO).launch {
                file = fileBackend!!.getFile(message)

                if (message.transferable == null) {
                    message.transferable = this@HttpDownloadConnection
                    TransferableManager.getInstance()
                        .setTransferableForMessage(message.messageId, this@HttpDownloadConnection)
                }
                checkFileSize(interactive)
            }
        } catch (e: MalformedURLException) {
            e.printStackTrace()
            cancel()
        }
    }

    private fun hasInternetConnection(): Boolean {
        return false
    }

    override fun getStatus(): Int {
        return status
    }

    override fun getFileSize(): Long {
        return if (file != null) {
            file!!.expectedSize
        } else {
            0
        }
    }

    override fun getProgress(): Int {
        return mProgress
    }

    override fun cancel() {
        Log.e("transmissionCancelled", "transmission cancelled for ${message?.messageId}")
        canceled = true
        httpConnectionManager.finishConnection(this)
        message!!.transferable = null
        TransferableManager.getInstance().removeTransferableFromMap(message!!.messageId)
        message!!.transmissionCancelled = true
        updateMessage()
    }

    override fun setMessage(message: TTMessage) {
        if (isEmptyString(message.relativeFilePath) && this.message != null) {
            message.relativeFilePath = this.message!!.relativeFilePath
        }
        this.message = message
    }

    private fun finish() {
        message!!.transferable = null
        TransferableManager.getInstance().removeTransferableFromMap(message!!.messageId)
        httpConnectionManager.finishConnection(this)
        message?.transmissionCancelled = false
        message!!.isDownloaded = true
        EventBus.getDefault().post(DownloadFinishedEvent(message))
        updateMessage()
    }

    private fun changeStatus(mStatus: Int) {
        status = mStatus
    }

    private fun checkFileSize(interactive: Boolean) {
        FileSizeChecker(interactive).run()
    }

    private inner class FileSizeChecker(interactive: Boolean) {
        private var interactive = false

        init {
            this.interactive = interactive
        }

        fun run() {
            CoroutineScope(Dispatchers.IO).launch {
                val size: Long
                try {
                    size = retrieveFileSize()
                } catch (e: Exception) {
                    changeStatus(Transferable.STATUS_OFFER_CHECK_FILESIZE)
                    if (!interactive) {
                        acceptedAutomatically = false
                    }
                    cancel()
                    return@launch
                }
                file!!.expectedSize = size
                acceptedAutomatically = true
                FileDownloader(interactive).run()
            }
        }

        @Throws(IOException::class)
        private fun retrieveFileSize(): Long {
            return try {
                changeStatus(Transferable.STATUS_CHECKING)
                val connection = url!!.openConnection() as HttpURLConnection
                connection.requestMethod = "HEAD"
                if (connection is HttpsURLConnection) {
                    httpConnectionManager.setupTrustManager(connection, interactive)
                }
                connection.connectTimeout = Config.SOCKET_TIMEOUT * 1000
                connection.readTimeout = Config.SOCKET_TIMEOUT * 1000
                connection.connect()
                val contentLength = connection.getHeaderField("Content-Length")
                connection.disconnect()
                if (contentLength == null) {
                    throw IOException("no content-length found in HEAD response")
                }
                contentLength.toLong(10)
            } catch (e: IOException) {
                throw e
            } catch (e: NumberFormatException) {
                throw IOException()
            }
        }
    }

    private inner class FileDownloader(interactive: Boolean) {
        private var interactive = false
        private var os: OutputStream? = null

        init {
            this.interactive = interactive
        }

        fun run() {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    changeStatus(Transferable.STATUS_DOWNLOADING)
                    download()
                    updateImageBounds()
                    finish()
                } catch (e: SSLHandshakeException) {
                    changeStatus(Transferable.STATUS_OFFER)
                } catch (e: Exception) {
                    if (!interactive) {
                        acceptedAutomatically = false
                    }
                    cancel()
                }
            }
        }

        @Throws(Exception::class)
        private fun download() {
            var `is`: InputStream? = null
            var connection: HttpURLConnection? = null
            try {
                connection = url!!.openConnection() as HttpURLConnection
                if (connection is HttpsURLConnection) {
                    httpConnectionManager.setupTrustManager(
                        connection as HttpsURLConnection?,
                        interactive
                    )
                }
                connection.setRequestProperty("User-Agent", "TelloTalk")
                val tryResume = file!!.exists() && file!!.key == null
                var resumeSize: Long = 0
                if (tryResume) {
                    resumeSize = file!!.size
                }
                connection.connectTimeout = Config.SOCKET_TIMEOUT * 1000
                connection.readTimeout = Config.SOCKET_TIMEOUT * 1000
                connection.connect()
                `is` = BufferedInputStream(connection.inputStream)
                val contentRange = connection.getHeaderField("Content-Range")
                val serverResumed =
                    tryResume && contentRange != null && contentRange.startsWith("bytes $resumeSize-")
                var transmitted: Long = 0
                val expected = file!!.expectedSize
                if (tryResume && serverResumed) {
                    transmitted = file!!.size
                    updateProgress(if (expected == 0L) 0 else (transmitted.toDouble() / expected * 100).toInt())
                    os = AbstractConnectionManager.createAppendedOutputStream(file)
                    if (os == null) {
                        throw FileWriterException()
                    }
                } else {
                    file!!.parentFile.mkdirs()
                    if (!file!!.exists() && !file!!.createNewFile()) {
                        throw FileWriterException()
                    }
                    os = AbstractConnectionManager.createOutputStream(file, true)
                }
                var count: Int
                val buffer = ByteArray(1024)
                while (`is`.read(buffer).also { count = it } != -1) {
                    transmitted += count.toLong()
                    try {
                        os?.write(buffer, 0, count)
                    } catch (e: IOException) {
                        throw FileWriterException()
                    }
                    updateProgress(if (expected == 0L) 0 else (transmitted.toDouble() / expected * 100).toInt())
                    if (canceled) {
                        throw CancellationException()
                    }
                }
                try {
                    os?.flush()
                } catch (e: IOException) {
                    throw FileWriterException()
                }
            } catch (e: CancellationException) {
                if (connection != null && connection.responseCode == 416) {
                    updateImageBounds()
                    finish()
                }
                throw e
            } catch (e: IOException) {
                if (connection != null && connection.responseCode == 416) {
                    updateImageBounds()
                    finish()
                }
                throw e
            } finally {
                close(os)
                close(`is`)
                connection?.disconnect()
            }
        }

        private fun updateImageBounds() {
            fileBackend!!.updateFileParams(message!!, url.toString())
            message!!.isDownloaded = true
            updateMessage()
        }
    }

    private fun updateMessage() {
        if (isEmptyString(message!!.relativeFilePath)) {
            if (file != null) {
                message!!.relativeFilePath = file!!.absolutePath
            }
        }
        ConversationActivityViewModel.getInstance().insertMessage(message!!)
    }

    private fun updateProgress(i: Int) {
        mProgress = i
        message!!.progress = progress
    }

    private fun getFinalFileName(extension: String, fileName: String): String {
        var fileName = fileName
        var tempCount = ""
        for (i in -1..99) {
            if (i == -1) {
                if (!File(TelloConfig.TELLO_FILE_DIRECTORY + "/" + fileName).exists()) {
                    break
                }
                tempCount = "01"
            } else if (i >= 0) {
                if (File(
                        TelloConfig.TELLO_FILE_DIRECTORY + "/" + (fileName.split("\\.".toRegex())
                            .dropLastWhile { it.isEmpty() }
                            .toTypedArray()[0] + "0" + i + "." + extension)).exists()
                ) {
                    tempCount = "0" + (i + 1)
                } else {
                    if (i > 0) {
                        tempCount = "0$i"
                        break
                    }
                }
            }
        }
        fileName = fileName.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
            .toTypedArray()[0] + tempCount + "." + extension
        return fileName
    }
}