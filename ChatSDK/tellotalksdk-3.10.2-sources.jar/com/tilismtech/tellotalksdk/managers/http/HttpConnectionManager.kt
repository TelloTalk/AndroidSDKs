package com.tilismtech.tellotalksdk.managers.http


import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.managers.TelloApiClient.Companion.getInstance
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.CopyOnWriteArrayList
import javax.net.ssl.HttpsURLConnection

/**
 * Created by Sohail on 2/9/18.
 */
class HttpConnectionManager : AbstractConnectionManager(getInstance()!!.telloContext) {
    private val downloadConnections = HashMap<String, HttpDownloadConnection>()
    private val uploadConnections: MutableList<HttpUploadConnection> = CopyOnWriteArrayList()

    fun createNewDownloadConnection(message: TTMessage): HttpDownloadConnection? {
        return this.createNewDownloadConnection(message, false)
    }

    private fun createNewDownloadConnection(
        message: TTMessage,
        interactive: Boolean
    ): HttpDownloadConnection? {
        var connection = downloadConnections[message.messageId]
        if (connection != null) {
            return connection
        }
        if (!message.transmissionCancelled) {
            connection = HttpDownloadConnection(this)
            connection.init(message, interactive)
            downloadConnections[message.messageId] = connection
            return connection
        }

        return null
    }

    fun createNewUploadConnection(message: TTMessage, delay: Boolean): HttpUploadConnection {
        val connection = HttpUploadConnection()
        connection.init(message, delay)
        uploadConnections.add(connection)
        return connection
    }

    fun finishConnection(connection: HttpDownloadConnection) {
        downloadConnections.remove(if (connection.message != null) connection.message!!.messageId else "")
    }

    fun setupTrustManager(connection: HttpsURLConnection?, interactive: Boolean) {
    }

    @get:Throws(IOException::class)
    val proxy: Proxy
        get() = Proxy(
            Proxy.Type.HTTP,
            InetSocketAddress(
                InetAddress.getByAddress(
                    byteArrayOf(
                        127,
                        0,
                        0,
                        1
                    )
                ), 8118
            )
        )

    companion object {
        var instance: HttpConnectionManager? = null
            get() {
                if (field == null) {
                    field = HttpConnectionManager()
                }
                return field
            }
            private set
    }
}