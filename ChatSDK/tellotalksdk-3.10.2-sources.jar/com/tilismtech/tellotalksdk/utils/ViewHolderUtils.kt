package com.tilismtech.tellotalksdk.utils

import android.Manifest
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toDrawable
import androidx.core.graphics.toColorInt
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.generic.RoundingParams
import com.facebook.drawee.interfaces.DraweeController
import com.facebook.drawee.view.SimpleDraweeView
import com.facebook.imagepipeline.common.ResizeOptions
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.db.entities.Contact
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.data.repository.ContactRepository
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager
import com.tilismtech.tellotalksdk.packages.easypermissions.EasyPermissions
import com.tilismtech.tellotalksdk.ui.activities.ConversationActivity
import com.tilismtech.tellotalksdk.ui.activities.MessageInfoActivity
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.adapters.ViewPagerCarouselAdapter
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.BaseMessageAdapter
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.ChatbotBubbleAdapter
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.FAQAnswersAdapter
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.VoteAdapter
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.fragment.AttachVideoFragment
import com.tilismtech.tellotalksdk.ui.customviews.CircularProgressBar
import com.tilismtech.tellotalksdk.ui.customviews.CustomExpandableTextview
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppTextView
import com.tilismtech.tellotalksdk.ui.dialog.ChatBotFormDialog
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class ViewHolderUtils{
    @JvmField
    var account: TTAccount? = null
    private var currentConversation: TTConversation? = null
    @JvmField
    var adapter: BaseMessageAdapter? = null
    private var activity: TelloActivity? = null
    @JvmField
    var selectedMessages: HashMap<String?, TTMessage?>? = null
    var mediaPlayer: TelloMediaPlayer? = null
    var isVoteSelected = false
    val gson = Gson()

    private fun openFormDialog(message: TTMessage?, isFormSubmitted: Boolean, onSuccess: (it: TTMessage?) -> Unit) {
        val chatBotFormDialog = ChatBotFormDialog()
        chatBotFormDialog.newInstance(message, isFormSubmitted,onSuccess)
        chatBotFormDialog.show(activity!!.supportFragmentManager, "ChatBotFormDialog")
    }
    private fun isVoteSelected(message: TTMessage?): Boolean {
        val msg = TTMessageRepository.Companion.instance!!.getMessage(message?.messageId)
        val chatbotNode = gson.fromJson(msg?.chatbotNode, ChatbotNode::class.java)
        return ApplicationUtils.Companion.check_vote_is_selected(
            chatbotNode.voteData ?: chatbotNode.children.getOrNull(0)?.voteData ?: listOf()
        )
    }
    fun setCurrentConversation(currentConversation: TTConversation?) {
        this.currentConversation = currentConversation
    }
    fun setActivity(activity: TelloActivity?) {
        this.activity = activity
    }
    fun stopMediaPLayer() {
        if (mediaPlayer != null) {
            if (mediaPlayer!!.isPlaying) {
                mediaPlayer!!.stop()
                mediaPlayer!!.oldPath = ""
            }
        }
    }

    companion object {
        @JvmStatic
        var instance: ViewHolderUtils? = null
            get() {
                if (field == null) {
                    field = ViewHolderUtils()
                }
                return field
            }
            private set


        fun ConstraintLayout.setupReplyContainer(message: TTMessage?){
            setOnClickListener {
                instance?.adapter?.scrollToReplyMessage(message?.replyMessage)
            }
            visibility = if (message?.replyMessage == null) View.GONE else View.VISIBLE
            findViewById<TextView?>(R.id.senderName)?.setSenderName(message?.replyMessage,findViewById<View>(R.id.leftView))
            findViewById<SimpleDraweeView?>(R.id.replyMsgImg)?.setReplyMessageImage(message?.replyMessage)
            findViewById<ImageView?>(R.id.replyMicImg)?.setReplyAudioIcon(message?.replyMessage)
            findViewById<TextView?>(R.id.replyMsgTxt)?.setReplyMessageText(message?.replyMessage)
        }
        fun ConstraintLayout.setupLinkPreview(message: TTMessage?){
            visibility = if (message?.sourceContent == null) View.GONE else View.VISIBLE
            findViewById<TextView?>(R.id.link_title)?.text = message?.sourceContent?.title
            findViewById<TextView?>(R.id.link_description)?.text = message?.sourceContent?.description
            findViewById<TextView?>(R.id.link_url)?.text = message?.sourceContent?.cannonicalUrl
            setOnClickListener {
                instance?.adapter?.onLinkClicked(message?.sourceContent?.finalUrl?:"")
            }
            findViewById<SimpleDraweeView?>(R.id.link_icon)?.setLinkImage(message?.sourceContent?.images)
        }
        fun LinearLayout.setUpFooter(message: TTMessage?){
            findViewById<TextView?>(R.id.messageTime)?.setMessageTime(message)
            findViewById<ImageView?>(R.id.editIndicator)?.visibility = if (message?.isEdited == true) View.VISIBLE else View.GONE
            findViewById<ImageView?>(R.id.messageStatus)?.setMessageStatus(message)
        }

        fun View.setMessageForeGround(message: TTMessage?) {
            var color = ContextCompat.getColor(context, android.R.color.transparent).toDrawable()
            if (instance?.selectedMessages != null && message != null && instance?.selectedMessages!!.containsKey(message.messageId) && context !is MessageInfoActivity)
                color = ContextCompat.getColor(context, R.color.colorControlActivated).toDrawable()
            foreground = color
        }

        fun LinearLayout.setHeadingArrow(message: TTMessage?) {
            if (isEmptyString(message?.msgHeading)) {
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE
            val lay_arrow_left = findViewById<LinearLayout>(R.id.lay_arrow_left)
            val lay_arrow_right = findViewById<LinearLayout>(R.id.lay_arrow_right)
            if (!ApplicationUtils.Companion.isEnglish(message?.msgHeading)) {
                lay_arrow_left.visibility = View.GONE
                lay_arrow_right.visibility = View.VISIBLE
            } else {
                lay_arrow_left.visibility = View.VISIBLE
                lay_arrow_right.visibility = View.GONE
            }
        }
        fun LinearLayout.setExpandableText(message: TTMessage?) {
            val tv_showmore = findViewById<TextView>(R.id.tv_showmore)
            val tv_expandText = findViewById<CustomExpandableTextview>(R.id.news_detail)
            val description: String = if ((message?.msgType == TTMessage.MsgType.TYPE_TEXT.value)) {
                message.message?.trim { it <= ' ' }?:""
            } else {
                message?.caption?.trim { it <= ' ' }?:""
            }
            if ((description == "")) {
                visibility = View.GONE
                return
            } else {
                visibility = View.VISIBLE
            }
            tv_expandText.text = description
            var shouldShowMore = description.length >= 200
            if (description.split("\n".toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray().size > 5) shouldShowMore = true
            tv_showmore.visibility = if (shouldShowMore) View.VISIBLE else View.GONE
            tv_expandText.setAnimationDuration(750L)
            val overshootInterpolator = OvershootInterpolator()
            tv_expandText.setInterpolator(overshootInterpolator)
            tv_expandText.expandInterpolator = overshootInterpolator
            tv_expandText.collapseInterpolator = overshootInterpolator
            tv_showmore.setOnClickListener { v: View? ->
                if (tv_expandText.isExpanded) {
                    tv_showmore.setText(R.string.show_more_txt)
                } else {
                    tv_showmore.setText(R.string.less_more_txt)
                }
                tv_expandText.toggle()
            }
            val descriptionTypeface: Typeface?
            if (!ApplicationUtils.Companion.isEnglish(description)) {
                descriptionTypeface = ResourcesCompat.getFont(context, R.font.calibri)
            } else {
                descriptionTypeface = ResourcesCompat.getFont(context, R.font.calibri);
            }
            tv_expandText.typeface = descriptionTypeface
        }
        fun LinearLayout.setReadmoreURL(message: TTMessage?) {
            if (isEmptyString(message?.msgURL)) {
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE
        }
        fun LinearLayout.setChatCarousalOption(message: TTMessage?) {
            val chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java)
            val dotscount: Int
            if (isEmptyString(message?.chatbotNode)) {
                return
            } else {
                if (!chatbotNode.type.equals("carousal",true) || chatbotNode.children.getOrNull(0)?.type != "Carousal"
                ) {
                    visibility = View.GONE
                    return
                }
            }
            visibility = View.VISIBLE
            val viewPagerCarouselView = findViewById<ViewPager>(R.id.carousel_view)
            val indicators = findViewById<LinearLayout>(R.id.SliderDots)
            val tv_carousal_des = findViewById<WhatsAppTextView>(R.id.tv_carousal_des)
            val tv_carousal_title = findViewById<WhatsAppTextView>(R.id.tv_carousal_title)
            tv_carousal_title.text = chatbotNode.children.getOrNull(0)?.carousalData?.getOrNull(0)?.title?:chatbotNode.title
            tv_carousal_des.text = chatbotNode.children.getOrNull(0)?.carousalData?.getOrNull(0)?.description?:chatbotNode.description
            val viewPagerCarouselAdapter = ViewPagerCarouselAdapter(
                (context as TelloActivity).supportFragmentManager,
                chatbotNode.children
            )
            viewPagerCarouselView.adapter = viewPagerCarouselAdapter
            viewPagerCarouselView.offscreenPageLimit = 3
            dotscount = viewPagerCarouselAdapter.count
            val dots: Array<ImageView?> = arrayOfNulls(dotscount)
            indicators.removeAllViews()
            for (i in 0 until dotscount) {
                dots[i] = ImageView(context)
                dots[i]!!
                    .setImageDrawable(
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.noo_active_dot
                        )
                    )
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.setMargins(8, 0, 8, 0)
                indicators.addView(dots[i], params)
            }
            dots[0]!!
                .setImageDrawable(ContextCompat.getDrawable(context, R.drawable.active_dot))
            viewPagerCarouselView.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
                override fun onPageScrolled(
                    position: Int,
                    positionOffset: Float,
                    positionOffsetPixels: Int
                ) {
                }

                override fun onPageSelected(position: Int) {
                    tv_carousal_title.text =
                        chatbotNode.children.getOrNull(position)?.carousalData?.getOrNull(0)?.title?:chatbotNode.title
                    tv_carousal_des.text =
                        chatbotNode.children.getOrNull(position)?.carousalData?.getOrNull(0)?.description?:chatbotNode.description
                    for (i in 0 until dotscount) {
                        dots[i]!!
                            .setImageDrawable(
                                ContextCompat.getDrawable(
                                    context,
                                    R.drawable.noo_active_dot
                                )
                            )
                    }
                    dots[position]!!.setImageDrawable(
                        ContextCompat.getDrawable(
                            context, R.drawable.active_dot
                        )
                    )
                }

                override fun onPageScrollStateChanged(state: Int) {}
            })
        }
        fun LinearLayout.setFormview(message: TTMessage?) {
            val chatbotNode = instance!!.gson.fromJson(message?.chatbotNode, ChatbotNode::class.java)
            if (isEmptyString(message?.chatbotNode)) {
                return
            } else {
                if (!chatbotNode.type.equals("form",true) || (!isEmptyString(chatbotNode.children.firstOrNull()?.type) && chatbotNode.children.getOrNull(0)?.type != "form")) {
                    visibility = View.GONE
                    return
                }
            }
            val lay_submitted = findViewById<LinearLayout>(R.id.lay_submitted)
            val lay_unfillform = findViewById<LinearLayout>(R.id.lay_unfillform)
            val children = instance!!.gson.fromJson(message?.chatbotNode, ChatbotNode::class.java)?.children
            if (children?.getOrNull(0)?.isFormSubmitted==false || !isEmptyString(message?.viewId) && message?.viewId != "0") {
                lay_submitted.visibility = View.VISIBLE
                lay_unfillform.visibility = View.GONE
            } else {
                lay_submitted.visibility = View.GONE
                lay_unfillform.visibility = View.VISIBLE
            }
            visibility = View.VISIBLE
            val tv_initiate_form = findViewById<WhatsAppTextView>(R.id.tv_initiate_form)
            tv_initiate_form.setOnClickListener { v: View? ->
                val s1: String = TelloPreferencesManager.getInstance().getString("chatid")
                val s2: Boolean = TelloPreferencesManager.getInstance().getBoolean(Constant.isAgentMsg)
                if (message?.chatId != s1) {
                    return@setOnClickListener
                }
                instance?.openFormDialog(message, false){
                    setFormview(it)
                }
            }
            val tv_view_submitform = findViewById<LinearLayout>(R.id.tv_view_submitform)
            tv_view_submitform.setOnClickListener {
                instance?.openFormDialog(
                    message,
                    true
                ) {

                }
            }
        }
        fun LinearLayout.setVoteOptions(message: TTMessage?) {

            var chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java) ?: return
            visibility = View.VISIBLE
            val face: Typeface?
            if (!ApplicationUtils.Companion.isAppEnglish) {
                face = ResourcesCompat.getFont(context, R.font.calibri)
            } else {
                face = ResourcesCompat.getFont(context, R.font.calibri)
            }
            val tv_submit = findViewById<WhatsAppTextView>(R.id.tv_submit)
            val tv_title = findViewById<WhatsAppTextView>(R.id.tv_title)
            val message_body_vote = findViewById<WhatsAppTextView>(R.id.message_body_vote)
            tv_title.text = chatbotNode.children.getOrNull(0)?.title?:chatbotNode.title
            message_body_vote.text = chatbotNode.children.getOrNull(0)?.description?:chatbotNode.description
            tv_title.typeface = face
            message_body_vote.typeface = face
            tv_submit.typeface = face
            instance?.isVoteSelected = instance?.isVoteSelected(message)?:false
            if (instance?.isVoteSelected == true) {
                tv_submit.visibility = View.GONE
                tv_submit.isEnabled = false
            } else {
                tv_submit.visibility = View.VISIBLE
                tv_submit.isEnabled = true
            }
            tv_submit.setOnClickListener {
                chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java)
                val checkedVote = chatbotNode.voteData.firstOrNull{it.voteChecked=="true"}
                if(checkedVote==null){
                    Toast.makeText(tv_submit.context,"Please select an option",Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                instance?.isVoteSelected = instance?.isVoteSelected(message)?:false
                isClickable = instance?.isVoteSelected?:false
                if (isClickable) {
                    return@setOnClickListener
                }
                isClickable = true
                val s1 = TelloPreferencesManager.getInstance().getString("chatid")
                val s2 = TelloPreferencesManager.getInstance().getBoolean(Constant.isAgentMsg)
                if (message?.chatId != s1) {
                    return@setOnClickListener
                }
                if (s1 != "" && !s2) {
                    if ((chatbotNode.childType == "agent")) {
                        TelloPreferencesManager.getInstance().putBoolean(Constant.isAgentMsg, true)
                    }
                    message.apply {
                        chatbotNode.children = arrayListOf<ChatbotChild?>().apply {
                            add(ChatbotChild().apply {
                                this.childType = chatbotNode.type
                                this.name = chatbotNode.voteData?.find { it.voteChecked=="true" }?.voteName
                                id = chatbotNode.id
                            })
                        }
                    }
                    ConversationActivityViewModel.Companion.getInstance().updateMessage(message)
                    ChatManager.Companion.instance!!.sendMessageToChatbot(
                        message,
                        chatbotNode.children[0]
                    ) {
                        isClickable = it!!
                    }
                }
            }
        }

        fun TextView.setAudioLength(message: TTMessage?) {
            try {
                CoroutineScope(Dispatchers.IO).launch {
                    val duration = message?.getAudioLength(message)
                    withContext(Dispatchers.Main) {
                        text = duration
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        fun TextView.setFileName(message: TTMessage?) {
            text = message?.originalFileName
        }
        fun TextView.setCounterPart(message: TTMessage?) {
            if (!isEmptyString(message?.contactId)) {
                if (message?.contactId?.contains("@conference") == true) {
                    val conversationForJid = TTConversationRepository.Companion.getInstance().getConversationForJid(message.contactId)
                    if (conversationForJid != null) {
                        val contactFromJid =
                            ContactRepository.getInstance().getContactFromJid(message.conversationId)
                        if (contactFromJid != null) {
                            if (contactFromJid.name != null) {
                                text = contactFromJid.name
                            } else {
                                text = "+" + message.conversationId
                            }
                        } else {
                            text = "+" + message.conversationId
                        }
                        visibility = View.VISIBLE
                    }
                }
            }
        }
        fun TextView.setMinWidthText(message: TTMessage?) {
            if (!isEmptyString(message?.replyMsgId) || message?.sourceContent != null) {
                minWidth = AndroidUtilities.dp(200f)
            } else {
                minWidth = AndroidUtilities.dp(90f)
            }
            if (message?.sourceContent != null) {
                minWidth = AndroidUtilities.dp(250f)
            }
        }
        fun TextView.setBroadcastHeading(message: TTMessage?) {
            if (isEmptyString(message?.msgHeading)) {
                visibility = View.GONE
            }
            visibility = View.VISIBLE
            val face: Typeface?
            if (!ApplicationUtils.Companion.isEnglish(message?.msgHeading)) {
                face = ResourcesCompat.getFont(context, R.font.calibri_bold)
            } else {
                face = ResourcesCompat.getFont(context, R.font.calibri_bold);
            }
            typeface = face
            text = message?.msgHeading
        }
        fun TextView.setBroadcastDescription(message: TTMessage?) {
            if (isEmptyString(message?.msgHeading)) {
                visibility = View.GONE
            }
            val face: Typeface?
            if (!ApplicationUtils.Companion.isEnglish(message?.msgHeading)) {
                face = ResourcesCompat.getFont(context, R.font.calibri_bold)
            } else {
                face = ResourcesCompat.getFont(context, R.font.calibri_bold)
            }
            typeface = face
            text = message?.msgHeading
        }
        fun TextView.setUpVisibility(contact: Contact?) {
            if (contact == null) {
                visibility = View.GONE
            }
        }
        fun TextView.setSenderName(replyMessage: TTMessage?, leftView: View) {
            if (replyMessage == null) {
                text = ""
                leftView.setBackgroundColor("#000000".toColorInt())
                setTextColor("#000000".toColorInt())
                return
            }
            var senderName: String? = ""
            var senderNumber = ""
            if (replyMessage.msgStatus != TTMessage.MsgStatus.RECEIVED) {
                senderName = "You"
                senderNumber = instance?.account?.userName ?: "000000"
            } else {
                if (instance?.currentConversation != null) {
                    senderName = instance?.currentConversation?.conversationName
                    senderNumber = instance?.currentConversation?.contactJid?:""
                }
            }
            text = senderName
            var color: Int
            try {
                color = ("#" + senderNumber.substring(
                    senderNumber.length - 6,
                    senderNumber.length
                )).toColorInt()
            } catch (e: Exception) {
                color = "#000000".toColorInt()
            }
            leftView.setBackgroundColor(color)
            setTextColor(color)
        }
        fun TextView.setReplyMessageText(replyMessage: TTMessage?) {
            if (replyMessage == null) {
                text = ""
                return
            }
            var messageText = ""
            if ((replyMessage.msgType == TTMessage.MsgType.TYPE_TEXT.value)) {
                messageText = replyMessage.message?:""
            } else if ((replyMessage.msgType == TTMessage.MsgType.TYPE_IMAGE.value) || (replyMessage.msgType == TTMessage.MsgType.TYPE_VIDEO.value)) {
                if (!isEmptyString(replyMessage.caption)) {
                    if (replyMessage.caption?.startsWith("|") == true) {
                        messageText = replyMessage.caption?.substring(1)?:""
                    } else {
                        val splitString =
                            replyMessage.caption?.split("\\|".toRegex())?.dropLastWhile { it.isEmpty() }
                                ?.toTypedArray()
                        for (i in 1 until (splitString?.size?:0)) {
                            messageText =
                                if (isEmptyString(messageText)) splitString?.getOrNull(i)?:"" else (messageText + "|" + splitString?.getOrNull(i))
                        }
                    }
                }
                if (isEmptyString(messageText)) {
                    messageText =
                        if ((replyMessage.msgType == TTMessage.MsgType.TYPE_IMAGE.value)) "Image" else "Video"
                }
            } else if ((replyMessage.msgType == TTMessage.MsgType.TYPE_AUDIO.value)) {
                CoroutineScope(Dispatchers.IO).launch {
                    val duration = replyMessage.getAudioLength(replyMessage)
                    withContext(Dispatchers.Main) {
                        messageText = "Audio Message($duration)"
                    }
                }
            } else if ((replyMessage.msgType == TTMessage.MsgType.TYPE_FILE.value)) {
                if (!isEmptyString(replyMessage.caption)) {
                    messageText = replyMessage.caption?:""
                } else if (!isEmptyString(replyMessage.relativeFilePath)) {
                    val temp = replyMessage.relativeFilePath?.split("/".toRegex())
                        ?.dropLastWhile { it.isEmpty() }
                        ?.toTypedArray()
                    messageText = temp?.lastOrNull()?:""
                } else if (!isEmptyString(replyMessage.message)) {
                    val temp =
                        replyMessage.message?.split("\\|".toRegex())?.dropLastWhile { it.isEmpty() }
                            ?.toTypedArray()
                    val temp1 =
                        temp?.lastOrNull()?.split("/".toRegex())?.dropLastWhile { it.isEmpty() }?.toTypedArray()
                    messageText = temp1?.lastOrNull()?:""
                }
            } else if ((replyMessage.msgType == TTMessage.MsgType.TYPE_LOCATION.value)) {
                if (!isEmptyString(replyMessage.caption)) {
                    messageText = replyMessage.caption?:""
                } else {
                    messageText = replyMessage.message?:""
                }
            }
            text = messageText
        }
        fun TextView.setMessageTime(message: TTMessage?) {
            try {
                val formatedTime = UIHelper.readableTimeDifferenceFull(
                    context,
                    message?.systemDate?.time ?: System.currentTimeMillis()
                )
                CoroutineScope(Dispatchers.Main).launch {
                    delay(200)
                    text = formatedTime.replace("-", "")
                }
            }catch (e: Exception) {
                e.printStackTrace()
                text = ""
            }
        }

        fun TextView.setFileSize(message: TTMessage?) {
            try {
                val size = String.format(
                    "%s",
                    AttachVideoFragment.formatFileSize(FileBackend.instance?.getFile(message)?.size?:0)
                )
                text = size
            }catch (e: Exception) {
                e.printStackTrace()
                text = ""
            }
        }

        fun ImageButton.changeAudioStatus(
            seekBar: SeekBar,
            message: TTMessage?
        ) {
            instance?.mediaPlayer = TelloMediaPlayer.getInstance()
            instance?.mediaPlayer?.setOnCompletionListener { mp: MediaPlayer? ->
                instance?.mediaPlayer?.updateOnComplete()
                instance!!.adapter!!.notifyItemChanged(instance?.adapter?.messages?.indexOfFirst{it?.messageId==instance?.mediaPlayer?.messgeId}?:0)
            }
            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        instance?.mediaPlayer?.seekToProgress(progress)
                        instance?.adapter?.messages?.firstOrNull{it?.messageId==instance?.mediaPlayer?.messgeId}?.updateProgress(progress)
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar) {}
                override fun onStopTrackingTouch(seekBar: SeekBar) {}
            })
            setOnClickListener { view1: View? ->
                try {
                    instance?.mediaPlayer?.setDataSourceAndListener(
                        message?.audioSourceAbsolutePath?:"",
                        message,
                        message?.getAudioProgressLiveData()?.value?:0,
                        message?.messageId?:""
                    )
                    updateBtnSrc(message?.apply {
                        updateMediaStatus(instance?.mediaPlayer?.isPlaying?:false)
                    },seekBar)
                } catch (e: IOException) {
                    message?.updateMediaStatus(false)
                    e.printStackTrace()
                }
                message?.maxProgress = instance?.mediaPlayer?.duration?:0
            }
        }
        fun ImageButton.updateBtnSrc(message: TTMessage?,seekBar: SeekBar) {
            if (message?.isPlaying==true) {
                setColorFilter(context.resources.getColor(R.color.audio_icon_color_sdk))
                setImageDrawable(context.resources.getDrawable(R.drawable.pause_icon_sdk))
                seekBar.setAudioProgress(message)
            } else {
                setColorFilter(context.resources.getColor(R.color.audio_icon_color_sdk))
                setImageDrawable(context.resources.getDrawable(R.drawable.play_icon_sdk))
                message?.getAudioProgressLiveData()?.removeObservers(instance!!.activity!!)
            }
        }

        fun SeekBar.setAudioProgress(message: TTMessage?) {
            message?.getAudioProgressLiveData()?.observe(instance?.activity!!){
                if(message.isPlaying && message.messageId== TelloMediaPlayer.getInstance().messgeId) {
                    setProgress(it, false)
                    max = message.maxProgress
                }
            }
        }
        fun ImageButton.checkContactExists( contactData: String?) {
            if (!EasyPermissions.hasPermissions(context, Manifest.permission.READ_CONTACTS)) {
                visibility = View.GONE
                return
            }
        }

        fun ImageView.setReplyAudioIcon(replyMessage: TTMessage?) {
            if (replyMessage == null) {
                visibility = View.GONE
                return
            }
            if ((replyMessage.msgType == TTMessage.MsgType.TYPE_AUDIO.value)) {
                visibility = View.VISIBLE
            } else {
                visibility = View.GONE
            }
        }
        fun ImageView.setMessageStatus( message: TTMessage?) {
            if (message?.isDeleted == true || (message?.msgStatus?.name == TTMessage.MsgStatus.RECEIVED.name)) {
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE
            if (message?.msgStatus == TTMessage.MsgStatus.SENT) {
                setImageResource(R.drawable.sent_icon_sdk)
                setColorFilter(
                    ContextCompat.getColor(context, R.color.colorPrimaryDarkGrey),
                    PorterDuff.Mode.SRC_IN
                )
            } else if (message?.msgStatus == TTMessage.MsgStatus.DELIVERED) {
                setImageResource(R.drawable.delivered_icon_sdk)
                setColorFilter(
                    ContextCompat.getColor(context, R.color.colorPrimaryDarkGrey),
                    PorterDuff.Mode.SRC_IN
                )
            } else if (message?.msgStatus == TTMessage.MsgStatus.READ) {
                setImageResource(R.drawable.seen_icon_sdk)
                setColorFilter(
                    ContextCompat.getColor(context, R.color.indicator),
                    PorterDuff.Mode.SRC_IN
                )
            } else if (message?.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                visibility = View.GONE
            } else if (message?.msgStatus == TTMessage.MsgStatus.ERROR) {
                setImageResource(R.drawable.error_icon_sdk)
                setColorFilter(
                    ContextCompat.getColor(context, R.color.indicator),
                    PorterDuff.Mode.SRC_IN
                )
            } else {
                setImageResource(R.drawable.clock_icon)
                setColorFilter(
                    ContextCompat.getColor(context, R.color.indicator),
                    PorterDuff.Mode.SRC_IN
                )
            }
        }
        fun ImageView.setFileIcons(message: TTMessage?) {
            if (!isEmptyString(message?.mimeType) && message?.mimeType?.startsWith("image") == true) {
                setImageResource(R.drawable.folder_icon_sdk)
            } else {
                if (message?.caption==null) {
                    setImageResource(R.drawable.folder_icon_sdk)
                    return
                }
                val splittedTag =
                    message.message?.split("\\.".toRegex())?.dropLastWhile { it.isEmpty() }?.toTypedArray()?: arrayOf()
                if (splittedTag.isNotEmpty()) {
                    if (splittedTag[splittedTag.size - 1].equals("apk", ignoreCase = true)) {
                        setImageResource(R.drawable.folder_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].equals("pdf", ignoreCase = true)) {
                        setImageResource(R.drawable.pdf_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].contains("doc") || splittedTag[splittedTag.size - 1].contains(
                            "docx"
                        )
                    ) {
                        setImageResource(R.drawable.doc_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].equals("txt", ignoreCase = true)) {
                        setImageResource(R.drawable.txt_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].contains("ppt")) {
                        setImageResource(R.drawable.ppt_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].contains("xl")) {
                        setImageResource(R.drawable.xlsx_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].contains("zip") || splittedTag[splittedTag.size - 1].contains(
                            "rar"
                        )
                    ) {
                        setImageResource(R.drawable.rar_icon_sdk)
                    } else if (splittedTag[splittedTag.size - 1].contains("jpg") || splittedTag[splittedTag.size - 1].contains(
                            "png"
                        )
                    ) {
                        setImageResource(R.drawable.folder_icon_sdk)
                    } else {
                        setImageResource(R.drawable.folder_icon_sdk)
                    }
                } else {
                    setImageResource(R.drawable.folder_icon_sdk)
                }
            }
        }

        fun SimpleDraweeView.setReplyMessageImage(replyMessage: TTMessage?) {
            if (replyMessage == null) {
                setImageURI("")
                visibility = View.GONE
                return
            }
            var uri: Uri? = null
            if ((replyMessage.msgType == TTMessage.MsgType.TYPE_LOCATION.value)) {
                val temp = replyMessage.message?.split(":".toRegex())?.dropLastWhile { it.isEmpty() }
                    ?.toTypedArray()?.firstOrNull()?.split(",".toRegex())?.dropLastWhile { it.isEmpty() }
                    ?.toTypedArray()
                val url =
                    ("https://maps.googleapis.com/maps/api/staticmap?center=" + temp?.firstOrNull()?.toDouble() + "%2c%20" + temp?.firstOrNull()?.toDouble() + "&zoom=17&markers=color:red%7Clabel:C%7C" + temp?.firstOrNull()?.toDouble() + "," + temp?.firstOrNull()?.toDouble() + "&size=420x280&key=AIzaSyDdPrOckMNIT44KRaw1y-A3e62AeDUL14s")
                val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                    .setUri(url)
                    .setAutoPlayAnimations(true)
                    .build()
                this.controller = controller
                hierarchy.roundingParams =
                    RoundingParams().setCornersRadius(AndroidUtilities.dp(12f).toFloat())
                return
            }
            if ((replyMessage.msgType == TTMessage.MsgType.TYPE_IMAGE.value) || (replyMessage.msgType == TTMessage.MsgType.TYPE_VIDEO.value)) {
                if (replyMessage.msgStatus == TTMessage.MsgStatus.RECEIVED && !replyMessage.isDownloaded) {
                    setImageBitmap(ImageUtils.fromStringToBitmap(replyMessage.thumbnail))
                } else {
                    CoroutineScope(Dispatchers.IO).launch {
                        uri = Uri.fromFile(FileBackend.instance?.getFile(replyMessage))
                        launch(Dispatchers.Main){
                            if (uri == null) {
                                setImageURI("")
                                visibility = View.GONE
                                return@launch
                            }
                            visibility = View.VISIBLE
                            val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                                .setUri(uri)
                                .setAutoPlayAnimations(false)
                                .build()
                            this@setReplyMessageImage.controller = controller
                            hierarchy.roundingParams =
                                RoundingParams().setCornersRadius(AndroidUtilities.dp(05f).toFloat())
                        }
                    }
                }
            } else if ((replyMessage.msgType == TTMessage.MsgType.TYPE_FILE.value)) {
                visibility = View.VISIBLE
                setFileIcons(replyMessage)
                return
            } else {
                setImageURI("")
                visibility = View.GONE
                return
            }
        }
        private fun SimpleDraweeView.updateImageSize(fileParams: TTMessage.FileParams?) {
            CoroutineScope(Dispatchers.Main).launch {
                if ((fileParams?.height?:0) > (fileParams?.width?:0)) {
                    return@launch
                }
                val aspectRatio = (fileParams?.height?.toFloat()?:0f) / (fileParams?.width?.toFloat()?:0f)
                val widthPixels = AndroidUtilities.displayMetrics.widthPixels * 2 / 3
                if ((aspectRatio) <= 0.5) {
                    layoutParams.height = widthPixels / 2
                    this@updateImageSize.aspectRatio = aspectRatio
                } else {
                    layoutParams.height = (widthPixels * aspectRatio).toInt()
                    this@updateImageSize.aspectRatio = aspectRatio
                }
            }
        }
        fun SimpleDraweeView.setLinkImage(imageUrls: List<String?>?) {
            var imageUrl: String? = ""
            if (imageUrls != null && imageUrls.isNotEmpty()) {
                imageUrl = imageUrls[0]
                visibility = View.VISIBLE
            } else {
                visibility = View.GONE
                return
            }
            val request = ImageRequestBuilder.newBuilderWithSource(imageUrl?.toUri())
                .setResizeOptions(ResizeOptions(AndroidUtilities.dp(45f), AndroidUtilities.dp(45f)))
                .build()
            val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                .setImageRequest(request)
                .setAutoPlayAnimations(false)
                .build()
            this.controller = controller
        }
        fun SimpleDraweeView.setThumbnail(message: TTMessage?) {
            var file : DownloadableFile? = null
            CoroutineScope(Dispatchers.IO).launch {
                file = FileBackend.instance?.getFile(message)
            }.invokeOnCompletion {
                var uri: Uri? = null
                if ((file == null) || file?.exists()==false) {
                    message?.message?.toUri()
                    ///   return;
                } else {
                    uri = Uri.fromFile(file)
                }
                val fileParams = message?.fileParams
                if (((fileParams?.height?:0) > 0) && ((fileParams?.width?:0) > 0)) {
                    updateImageSize(fileParams)
                }
                val request = ImageRequestBuilder.newBuilderWithSource(uri)
                    .setProgressiveRenderingEnabled(true)
                    .disableDiskCache()
                    .build()
                val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                    .setImageRequest(request)
                    .setAutoPlayAnimations(false)
                    .setOldController(this.controller)
                    .build()
                this.controller = controller
            }
        }
        fun SimpleDraweeView.setBroadcastImage(message: TTMessage?) {
            if (isEmptyString(message?.message)) {
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE

            val hasThumbnail = !isEmptyString(message?.thumbnail)
            val isMessageDownloaded = message?.isDownloaded
            if (hasThumbnail && isMessageDownloaded==false) {
                setImageBitmap(ImageUtils.fromStringToBitmap(message.thumbnail))
            } else if (isMessageDownloaded==false) {
                var file : DownloadableFile?
                CoroutineScope(Dispatchers.IO).launch {
                    file = FileBackend.instance?.getFile(message)
                    val uri: Uri = if (file == null || file?.exists()==false) {
                        message.message?.toUri() ?:Uri.EMPTY
                    } else {
                        Uri.fromFile(file)
                    }
                    launch(Dispatchers.Main){
                        val request = ImageRequestBuilder.newBuilderWithSource(uri)
                            .setProgressiveRenderingEnabled(true)
                            .disableDiskCache()
                            .build()
                        val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                            .setImageRequest(request)
                            .setAutoPlayAnimations(false)
                            .setOldController(this@setBroadcastImage.controller)
                            .build()
                        this@setBroadcastImage.controller = controller
                    }
                }
            } else {
                val file = FileBackend.instance?.getFile(message)
                this.setImageURI(Uri.fromFile(file))
            }
        }
        fun SimpleDraweeView.setContactAvatar(contact: Contact?) {
            if (contact != null && !isEmptyString(contact.avatar)) {
                setImageURI(NetworkConstants.BASE_URL1 + "/chatsdk" + contact.avatar)
            } else {
                setImageURI("")
            }
            hierarchy.setPlaceholderImage(R.drawable.contact_default_pic)
            hierarchy.setRoundingParams(RoundingParams().setRoundAsCircle(true))
        }
        fun SimpleDraweeView.agentAvatar(message: TTMessage?) {
            if (isEmptyString(message?.agentAvatar)) {
                return
            }
            val uri = (message?.agentAvatar)?.toUri()
            val request = ImageRequestBuilder.newBuilderWithSource(uri)
                .setProgressiveRenderingEnabled(true)
                .disableDiskCache()
                .build()
            val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                .setImageRequest(request)
                .setAutoPlayAnimations(false)
                .setOldController(controller)
                .build()
            this.controller = controller
        }
        fun SimpleDraweeView.avatarImage(message: TTMessage?) {
            if (message?.msgType == TTMessage.MsgType.TYPE_LOCATION.value) {
                val temp = message.message?.split(":".toRegex())?.dropLastWhile { it.isEmpty() }
                    ?.toTypedArray()?.firstOrNull()?.split(",".toRegex())?.dropLastWhile { it.isEmpty() }
                    ?.toTypedArray()?: arrayOf()
                val url =
                    "https://maps.googleapis.com/maps/api/staticmap?center=" + temp.firstOrNull()?.toDouble() + "%2c%20" + temp[1].toDouble() + "&zoom=17&markers=color:red%7Clabel:C%7C" + temp[0].toDouble() + "," + temp[1].toDouble() + "&size=420x280&key=" + TelloPreferencesManager.getInstance().googleApiKey
                val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                    .setUri(url)
                    .setAutoPlayAnimations(false)
                    .build()
                this.controller = controller
                hierarchy.roundingParams =
                    RoundingParams().setCornersRadius(AndroidUtilities.dp(12f).toFloat())
                return
            }
            val size = AndroidUtilities.displayMetrics.widthPixels * 2 / 3
            layoutParams.width = size
            layoutParams.height = size
            val hasThumbnail = !isEmptyString(message?.thumbnail)
            val isMessageDownloaded = message?.isDownloaded
            if (hasThumbnail && isMessageDownloaded==false) {
                setImageBitmap(ImageUtils.fromStringToBitmap(message.thumbnail))
            } else {
                var file : DownloadableFile? = null
                CoroutineScope(Dispatchers.IO).launch {
                    file = FileBackend.instance?.getFile(message)
                    val uri: Uri = if (file == null || file?.exists()==false) {
                        message?.message?.toUri()
                    } else {
                        Uri.fromFile(file)
                    }?:Uri.EMPTY
                    val fileParams = message?.fileParams
                    if ((fileParams?.height?:0) > 0 && (fileParams?.width?:0) > 0) {
                        updateImageSize(fileParams)
                    }
                    launch(Dispatchers.Main){
                        val request = ImageRequestBuilder.newBuilderWithSource(uri)
                            .setProgressiveRenderingEnabled(true)
                            .build()
                        val controller: DraweeController = Fresco.newDraweeControllerBuilder()
                            .setImageRequest(request)
                            .setAutoPlayAnimations(true)
                            .setOldController(controller)
                            .build()
                        this@avatarImage.controller = controller
                    }
                }
            }
            val roundingParams = RoundingParams.fromCornersRadius(12f)
            roundingParams.setRoundAsCircle(false)
            hierarchy.roundingParams = roundingParams
        }

        fun WhatsAppTextView.setUpFileTag(fileTag: String?="") {
            if (isEmptyString(fileTag)) {
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE
            if (!ApplicationUtils.Companion.isEnglish(fileTag)) {
                val face = ResourcesCompat.getFont(context, R.font.calibri)
                typeface = face
            } else {
                val face = ResourcesCompat.getFont(context, R.font.calibri)
                typeface = face
            }
            text = fileTag
        }
        fun WhatsAppTextView.setOptionChildTitle(message: TTMessage?) {
            if (isEmptyString(message?.chatbotNode)) {
                visibility = View.GONE
                return
            } else {
                text = message?.message
            }
        }
        fun WhatsAppTextView.setUnsupportedTextMessage(message: TTMessage?) {
            if (isEmptyString(message?.chatbotNode)) {
                val face: Typeface? = if (!ApplicationUtils.Companion.isAppEnglish) {
                    ResourcesCompat.getFont(context, R.font.calibri)
                } else {
                    ResourcesCompat.getFont(context, R.font.calibri)
                }
                typeface = face
            }
        }
        fun WhatsAppTextView.setChatbotTextMessage(message: TTMessage?) {
            val chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java)
            if (!isEmptyString(message?.chatbotNode)) {
                val face: Typeface?
                if (!ApplicationUtils.Companion.isAppEnglish) {
                    face = ResourcesCompat.getFont(context, R.font.calibri)
                } else {
                    face = ResourcesCompat.getFont(context, R.font.calibri)
                }
                if (isEmptyString(message?.chatbotNode)) {
                    text = chatbotNode.children.getOrNull(0)?.name?:chatbotNode.name
                } else {
                    text = message?.message
                }
                typeface = face
            }
        }
        fun WhatsAppTextView.setChatbotTitle(message: TTMessage?) {
            val chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java)
            if (isEmptyString(message?.chatbotNode)){
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE
            if (!isEmptyString(message?.chatbotNode)) {
                if ((chatbotNode.type.equals("carousal",true)) || (chatbotNode.children.getOrNull(0)?.type == "Carousal")) {
                    visibility = View.GONE
                } else if ((chatbotNode.type.equals("agent",true)) || (chatbotNode.type.equals("agent",true)) || (chatbotNode.children.getOrNull(0)?.type == "agent")) {
                    text = message?.message
                } else if ((chatbotNode.type.equals("form",true)) || (chatbotNode.children.getOrNull(0)?.type == "form")) {
                    visibility = View.GONE
                }
            } else {
                text = message?.message
            }
        }

        fun CircularProgressBar.setUpProgress(message: TTMessage?) {
            if ((message?.msgType == TTMessage.MsgType.TYPE_LOCATION.value)) {
                visibility = View.GONE
                return
            }
            setProgressColor(ContextCompat.getColor(context, R.color.white))
            if (message?.msgStatus == TTMessage.MsgStatus.COMPRESSING) {
                visibility = View.VISIBLE
                progressState = CircularProgressBar.ProgressState.PROGRESS_INDETERMINATE
                setProgressBackgroundDrawabble()
            } else if (message?.transferable != null && message.transmissionCancelled && message.msgStatus!= TTMessage.MsgStatus.ERROR) {
                visibility = View.VISIBLE
                progress = message.progress
                progressState = CircularProgressBar.ProgressState.PROGRESS_DETERMINATE
                setProgressBackgroundDrawabble()
            } else if ((message?.msgStatus == TTMessage.MsgStatus.RECEIVED) && message.dptType=="2" && (message.transmissionCancelled || !message.isDownloaded)) {
                visibility = View.VISIBLE
                setProgressBackgroundDrawabble()
                progressState = CircularProgressBar.ProgressState.DOWNLOAD_BUTTON
                setProgressBackgroundDrawabble()
                setOnClickListener { v: View? -> (context as ConversationActivity).downloadFile(message) }
            } else if ((message?.msgStatus != TTMessage.MsgStatus.RECEIVED) && (message?.msgStatus != TTMessage.MsgStatus.SENT) && ((message?.msgStatus != TTMessage.MsgStatus.READ)) && (message?.transmissionCancelled == true || message?.needsUploading() == true)) {
                visibility = View.VISIBLE
                progressState = CircularProgressBar.ProgressState.UPLOAD_BUTTON
                setProgressBackgroundDrawabble()
                setOnClickListener { v: View? -> (context as ConversationActivity).sendMessage(message) }
            } else {
                if ((message?.msgType == TTMessage.MsgType.TYPE_VIDEO.value)) {
                    visibility = View.VISIBLE
                    progressState = CircularProgressBar.ProgressState.PLAY_BUTTON
                    setProgressBackgroundDrawabble()
                    setOnClickListener { v: View? ->
                        if (instance?.adapter != null) {
                            instance?.adapter!!.openDownloadable(message)
                        }
                    }
                } else {
                    visibility = View.GONE
                }
            }
        }



        fun RecyclerView.setFaqOptions(message: TTMessage?) {
            if (isEmptyString(message?.button_det)) {
                visibility = View.GONE
                return
            }
            visibility = View.VISIBLE
            val faqAnswersAdapter = FAQAnswersAdapter(context as TelloActivity, message)
            adapter = faqAnswersAdapter
        }
        fun RecyclerView.setVoteListAdapter(message: TTMessage?) {
            val chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java)
            if (chatbotNode != null) adapter = VoteAdapter(
                message,
                ApplicationUtils.Companion.check_vote_is_selected(
                    chatbotNode.voteData ?: chatbotNode.children.getOrNull(0)?.voteData ?: listOf()
                )
            )
        }
        fun RecyclerView.setChatbubbleOption(message: TTMessage?) {
            val chatbotNode = instance?.gson!!.fromJson(message?.chatbotNode, ChatbotNode::class.java)
            if (isEmptyString(message?.chatbotNode)) {
                return
            }
            val msgs: List<TTMessage?>? = instance?.adapter!!.messages
            if ((chatbotNode.childType == ChatbotNode.BotType.TYPE_OPTIONCHILD.name) && (msgs?.indexOf(message)?:0) + 1 < (msgs?.size?:0)) {
                val replyMsg = msgs?.getOrNull(msgs.indexOf(message) + 1)
                val nodeChildren = chatbotNode.children
                for (i in nodeChildren.indices) {
                    if ((replyMsg?.message == nodeChildren[i].name)) {
                        nodeChildren[i].isSelected = true
                        chatbotNode.children = nodeChildren
                        break
                    }
                }
            }
            val chatbotBubbleAdapter = ChatbotBubbleAdapter(context as TelloActivity, message)
            adapter = chatbotBubbleAdapter
        }
    }
}