package com.tilismtech.tellotalksdk.utils

import androidx.core.content.FileProvider


class TelloFileProvider: FileProvider() {
}