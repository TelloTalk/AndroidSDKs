package com.tilismtech.tellotalksdk.utils

import android.media.MediaPlayer
import android.os.Handler
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import java.io.IOException

/**
 * Created by sohailahmed on 31/03/2017.
 */
class TelloMediaPlayer private constructor() : MediaPlayer() {
    var oldPath: String = ""
    var messgeId: String? = ""
        private set
    var doneProgress: Int = 0
        private set
    private val handler = Handler()
    private var telloMediaPlayerListner: TelloMediaPlayerListner? = null

    fun play(doneProgress: Int) {
        seekTo(doneProgress)
        start()
        handler.postDelayed(onEverySecond, 100)
    }

    @Throws(IOException::class, IllegalArgumentException::class, IllegalStateException::class)
    fun setDataSourceAndListener(
        newPath: String,
        listener: TelloMediaPlayerListner?,
        doneProgress: Int,
        messgeId: String
    ) {
        this.doneProgress = doneProgress
        if (this.oldPath == newPath && messgeId == this.messgeId && telloMediaPlayerListner != null) {
            if (isPlaying) {
                pause()
                handler.removeCallbacks(onEverySecond)
            } else {
                play(this.doneProgress)
            }
            telloMediaPlayerListner!!.updateMediaStatus(isPlaying)
        } else {
            if (this.telloMediaPlayerListner != null) {
                this.telloMediaPlayerListner!!.updateMediaStatus(false)
            }
            this.telloMediaPlayerListner = listener
            reset()
            this.telloMediaPlayerListner!!.updateMediaStatus(isPlaying)
            super.setDataSource(newPath)
            prepare()
            play(doneProgress)
        }
        val prevAudioMsg = ViewHolderUtils.Companion.instance!!.adapter!!.messages?.firstOrNull { it?.messageId== getInstance().messgeId && messgeId!=getInstance().messgeId }
        prevAudioMsg?.updateMediaStatus(false)
        ViewHolderUtils.Companion.instance!!.adapter!!.notifyItemChanged(ViewHolderUtils.Companion.instance!!.adapter!!.messages?.indexOf(prevAudioMsg) ?:0)
        this.oldPath = newPath
        this.messgeId = messgeId
    }

    fun stopMediaPlayer() {
        if (isPlaying) {
            pause()
            handler.removeCallbacks(onEverySecond)
            if (this.telloMediaPlayerListner != null) {
                this.telloMediaPlayerListner!!.updateMediaStatus(false)
            }
        }
    }

    fun updateOnComplete() {
        if (telloMediaPlayerListner != null) {
            (telloMediaPlayerListner as TTMessage).resetMediaState()
            doneProgress = 0
            telloMediaPlayerListner?.updateMediaStatus(false)
        }
    }

    fun setListenerBack(listener: TelloMediaPlayerListner?) {
        this.telloMediaPlayerListner = listener
        telloMediaPlayerListner!!.updateProgress(doneProgress)
        if (isPlaying) {
            handler.postDelayed(onEverySecond, 100)
        }
    }

    fun seekToProgress(progress: Int) {
        doneProgress = progress
        seekTo(progress)
        handler.postDelayed(onEverySecond, 100)
    }

    fun setPath() {
        pause()
        handler.removeCallbacks(onEverySecond)
    }

    interface TelloMediaPlayerListner {
        fun updateProgress(progress: Int)

        fun updateMediaStatus(status: Boolean)
    }

    private val onEverySecond: Runnable = Runnable {
        if (isPlaying) {
            if (telloMediaPlayerListner != null) {
                doneProgress = currentPosition
                telloMediaPlayerListner!!.updateProgress(currentPosition)
            }
            handler.postDelayed(onEverySecond, 100)
        }
    }

    companion object {
        private var instance: TelloMediaPlayer? = null
        fun removeInstance() {
            instance = null
        }

        fun getInstance(): TelloMediaPlayer {
            if (instance == null) {
                instance = TelloMediaPlayer()
            }
            return instance!!
        }
    }
}
