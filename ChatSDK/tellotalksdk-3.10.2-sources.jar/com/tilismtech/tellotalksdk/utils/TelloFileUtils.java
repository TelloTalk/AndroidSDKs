package com.tilismtech.tellotalksdk.utils;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import com.tilismtech.tellotalksdk.managers.TelloApiClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class TelloFileUtils {

    private final static String TAG = FileUtils.class.getSimpleName();

    @SuppressLint("NewApi")
    public static String getRealPathFromURI(Uri contentURI) {
        String result = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && DocumentsContract.isDocumentUri(TelloApiClient.getInstance().telloContext, contentURI)) {
            if (isExternalStorageDocument(contentURI)) {
                final String docId = DocumentsContract.getDocumentId(contentURI);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            } else if (isDownloadsDocument(contentURI)) {

                final String id = DocumentsContract.getDocumentId(contentURI);
                final Uri contentUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(TelloApiClient.getInstance().telloContext, contentUri, null, null);
            } else if (isMediaDocument(contentURI)) {
                final String docId = DocumentsContract.getDocumentId(contentURI);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{split[1]};

                return getDataColumn(TelloApiClient.getInstance().telloContext, contentUri, selection, selectionArgs);
            }
        } else if (contentURI.getScheme().equals("content")) {
            result = getDataColumn(TelloApiClient.getInstance().telloContext, contentURI, null, null);
        } else if (contentURI.getScheme().equals("file")) {
            result = contentURI.getPath();
        }
        return result;
    }

    private static String getDataColumn(Context context, Uri contentUri, String selection, String[] selectionArgs) {
        Cursor cursor = null;
        final String column = MediaStore.Images.ImageColumns.DATA;
        final String[] projection = {column};

        try {
            cursor = context.getContentResolver().query(contentUri, projection, selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static String getPathForSavingFile(String name, String extention) { // Any
        // type
        // of
        // file.
        // audio,
        // image,
        // video
        // etc
        Calendar cal = Calendar.getInstance();
        // cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss_SSS", Locale.ENGLISH);
        String fileName = name + sdf.format(cal.getTime()) + extention;
        return fileName;

    }

    public static void makeCopy(String sourceLocationPath, String targetLocationPath) {
        try {
            File sourceLocation = new File(sourceLocationPath);
            File targetLocation = new File(targetLocationPath);
            if (!sourceLocationPath.equals(targetLocationPath)) {
                if (!targetLocation.exists()) {
                    InputStream in = new FileInputStream(sourceLocation);
                    OutputStream out = new FileOutputStream(targetLocation);
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                    in.close();
                    out.close();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void copyFile(String sourceLocationPath, String targetLocationPath) throws IOException {
        if (sourceLocationPath.equals(targetLocationPath)) {
            return;
        }
        File sourceLocation = new File(sourceLocationPath);
        File targetLocation = new File(targetLocationPath);

        InputStream inputStream = new FileInputStream(sourceLocation);
        OutputStream outputStream = new FileOutputStream(targetLocation);
        copyFile(inputStream, outputStream);

    }

    public static void copyFile(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.flush();
        outputStream.close();
    }
}
