package com.tilismtech.tellotalksdk.utils.diffUtils

import android.os.Bundle
import androidx.recyclerview.widget.DiffUtil
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.managers.http.TransferableManager

/**
 * Created by AbdulMomen on 2/19/18.
 */
class MessageDiffCallback(
    private val oldMessagesList: List<TTMessage?>?,
    private val newMessagesList: List<TTMessage?>
) :
    DiffUtil.Callback() {


    override fun getOldListSize(): Int {
        return oldMessagesList?.size?:0
    }

    override fun getNewListSize(): Int {
        return newMessagesList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldMessagesList?.get(oldItemPosition)?.messageId == newMessagesList[newItemPosition]?.messageId
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldMessage = oldMessagesList?.get(oldItemPosition)
        val newMessage = newMessagesList[newItemPosition]
        return oldMessage == newMessage
    }

    override fun getChangePayload(oldItemPosition: Int, newItemPosition: Int): Any? {
        val oldMessage = oldMessagesList?.get(oldItemPosition)
        val newMessage = newMessagesList[newItemPosition]
        val transferable = TransferableManager.getInstance().getTransferable(newMessage?.messageId)
        if (transferable != null) {
            newMessage?.transferable = transferable
        }
        val diff = Bundle()

        if (newMessage?.message != null && newMessage.message == oldMessage?.message) {
            diff.putString("body", newMessage.message)
        }

        if (newMessage?.relativeFilePath != null && newMessage.relativeFilePath == oldMessage?.relativeFilePath) {
            diff.putString("relativeFilePath", newMessage.relativeFilePath)
        }

        if (newMessage?.msgStatus != oldMessage?.msgStatus) {
            diff.putInt("msgStatus", newMessage?.msgStatus?.ordinal?:oldMessage?.msgStatus?.ordinal?:TTMessage.MsgStatus.SENT.ordinal)
        }

        if (newMessage?.caption != null && newMessage.caption != oldMessage?.caption) {
            diff.putString("fileTag", newMessage.caption)
        }
        if (diff.size() == 0) {
            return null
        }
        return diff
    }
}

