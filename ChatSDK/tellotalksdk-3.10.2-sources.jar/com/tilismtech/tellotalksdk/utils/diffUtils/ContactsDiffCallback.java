package com.tilismtech.tellotalksdk.utils.diffUtils;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;

import com.tilismtech.tellotalksdk.data.db.entities.Contact;

import java.util.List;

public class ContactsDiffCallback extends DiffUtil.Callback{

    private final List<Contact> oldContactList;
    private final List<Contact> newContactList;

    public ContactsDiffCallback(List<Contact> oldContactList, List<Contact> newContactList) {
        this.oldContactList = oldContactList;
        this.newContactList = newContactList;
    }

    @Override
    public int getOldListSize() {
        return oldContactList.size();
    }

    @Override
    public int getNewListSize() {
        return newContactList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return oldContactList.get(oldItemPosition).getContactId().equals(newContactList.get(newItemPosition).getContactId());
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        Contact oldContact = oldContactList.get(oldItemPosition);
        Contact newContact = newContactList.get(newItemPosition);
        return (oldContact.equals(newContact) && oldItemPosition == newItemPosition);
    }

    @Nullable
    @Override
    public Object getChangePayload(int oldItemPosition, int newItemPosition) {
        Contact oldContact = oldContactList.get(oldItemPosition);
        Contact newContact = newContactList.get(newItemPosition);
        Bundle diff = new Bundle();
        if (!newContact.getName().equals(oldContact.getName())){
            diff.putString("contactName", newContact.getName());
        }
        if (!newContact.getContactId().equals(oldContact.getContactId())){
            diff.putString("contactNumber", newContact.getContactId());
        }
        if (diff.size()==0){
            return null;
        }
        return diff;
    }
}
