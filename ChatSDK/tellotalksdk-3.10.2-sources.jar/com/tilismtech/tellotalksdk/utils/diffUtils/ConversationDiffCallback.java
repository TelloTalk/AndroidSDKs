package com.tilismtech.tellotalksdk.utils.diffUtils;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;

import com.tilismtech.tellotalksdk.data.db.entities.TTConversation;
import com.tilismtech.tellotalksdk.data.repository.TTConversationRepository;
import com.tilismtech.tellotalksdk.utils.ApplicationUtils;

import java.util.List;

public class ConversationDiffCallback extends DiffUtil.Callback {

    private final List<TTConversation> oldConversationList;
    private final List<TTConversation> newConversationList;
    private final TTConversationRepository conversationRepository;

    public ConversationDiffCallback(List<TTConversation> oldConversationList, List<TTConversation> newConversationList) {
        this.oldConversationList = oldConversationList;
        this.newConversationList = newConversationList;
        this.conversationRepository = TTConversationRepository.getInstance();
    }

    @Override
    public int getOldListSize() {
        return oldConversationList.size();
    }

    @Override
    public int getNewListSize() {
        return newConversationList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return oldConversationList.get(oldItemPosition).getContactJid().equals(newConversationList.get(newItemPosition).getContactJid());
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        final TTConversation oldConversation = oldConversationList.get(oldItemPosition);
        final TTConversation newConversation = newConversationList.get(newItemPosition);
        return (oldConversation.equals(newConversation) && oldItemPosition == newItemPosition);
    }

    @Nullable
    @Override
    public Object getChangePayload(int oldItemPosition, int newItemPosition) {
        final TTConversation oldConversation = oldConversationList.get(oldItemPosition);
        final TTConversation newConversation = newConversationList.get(newItemPosition);

        TTConversation conversation = conversationRepository.getConversationForJid(newConversation.getContactJid());
        if (conversation != null && conversation.getLastMessage()!=null) {
            newConversation.setLastMessage(conversation.getLastMessage());
        }

        Bundle diff = new Bundle();
        if(oldConversation!=null && !ApplicationUtils.isEmptyString(newConversation.getConversationName()) && !ApplicationUtils.isEmptyString(oldConversation.getConversationName()) && !newConversation.getConversationName().equals(oldConversation.getConversationName())){
            diff.putString("conversationName", newConversation.getConversationName());
        }

        if(oldConversation!=null && newConversation.getUnreadCount() != oldConversation.getUnreadCount()){
            diff.putInt("unreadCount", newConversation.getUnreadCount());
        }

        if (newConversation.getLastMessageId()!=null && (oldConversation!=null && oldConversation.getLastMessageId()!=null)) {
            if (!newConversation.getLastMessageId().equals(oldConversation.getLastMessageId())) {
                diff.putString("lastMessageId", newConversation.getLastMessageId());
            }
        }else if(newConversation.getLastMessageId()!=null && (oldConversation!=null && oldConversation.getLastMessageId() == null)){
            diff.putString("lastMessageId", newConversation.getLastMessageId());
        }
        if (newConversation.getLastMessage()!=null) {
            if(oldConversation == null || oldConversation.getLastMessage() == null){
                diff.putString("lastMessageId", newConversation.getLastMessageId());
            }else{
                if (!newConversation.getLastMessage().getMessage().equalsIgnoreCase(oldConversation.getLastMessage().getMessage())) {
                    diff.putString("lastMessageId", newConversation.getLastMessageId());
                }
            }
        } else {
            if (oldConversation != null && oldConversation.getLastMessage()!=null)  {
                diff.putString("lastMessageId", newConversation.getLastMessageId());
            }
        }
        if (oldConversation!=null && oldConversation.getCreated() != null ) {
            if(!oldConversation.getCreated().equals(newConversation.getCreated())){
                if(newConversation.getCreated()!=null){
                    diff.putLong("dateCreated", newConversation.getCreated().getTime());
                }
            }
        }else {
            if(newConversation.getCreated() !=null){
                diff.putLong("dateCreated", newConversation.getCreated().getTime());
            }
        }
        if (diff.size()==0){
            return null;
        }
        return diff;
    }
}
