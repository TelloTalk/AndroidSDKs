package com.tilismtech.tellotalksdk.utils

class Constant {

    companion object{

        @JvmField
        var chatID: String = "chatID"
        @JvmField
        var conversationID: String = "conversationID"
        @JvmField
        var ConfirmDialog: String = "ConfirmDialog"
        @JvmField
        var isAgentMsg: String = "isAgentMsg"
        @JvmField
        var chatid: String = "chatid"
        @JvmField
        var ttmessage: String = "ttmessage"
        @JvmField
        var agentDetailResponse: String = "agentDetailResponse"
        @JvmField
        var bundle: String = "bundle"
        @JvmField
        var typeBroadcast: String = "1"
        @JvmField
        var typeAgentChat: String = "2"



    }


}