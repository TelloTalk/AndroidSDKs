package com.tilismtech.tellotalksdk.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.provider.Settings
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.tilismtech.tellotalksdk.data.db.entities.VoteData
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager
import com.tilismtech.tellotalksdk.ui.activities.WebUrlActivity
import java.util.regex.Pattern

class ApplicationUtils {
    private val mActivityManager: ActivityManager? = null

    companion object {
        @JvmStatic
        val fontPath: String
            get() = "fonts/calibiri.otf"
        @JvmStatic
        val boldFontPath: String
            get() = "fonts/calibri_bold.TTF"
        @JvmStatic
        val italicFontPath: String
            get() = "fonts/calibri_italic.ttf"

        @JvmStatic
        fun isNetworkAvailable(context: Context): Boolean {
            val status = false
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var netInfo: NetworkInfo? = null
            if (cm != null) {
                netInfo = cm.activeNetworkInfo
            }
            //should check null because in airplane mode it will be null
            return netInfo != null && netInfo.isConnected
        }

        @JvmStatic
        fun timeFormater(timeInmillisec: Long): String {
            val duration = timeInmillisec / 1000.0
            val hours = duration.toInt() / 3600
            val minutes = (duration - hours * 3600).toInt() / 60
            val second = duration - (hours * 3600 + minutes * 60)
            var seconds = 0
            seconds = if (second < 1) {
                Math.ceil(second).toInt()
            } else {
                Math.round(second.toFloat())
            }
            return if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }

        @JvmStatic
        fun openPermissionsSettings(activity: AppCompatActivity) {
            val intent = Intent()
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", activity.applicationContext.packageName, null)
            intent.setData(uri)
            activity.startActivity(intent)
        }

        @JvmStatic
        fun isEmptyString(string: String?): Boolean {
            return string == null || string.length == 0 || string == "null" || string == "(null)" || string.trim { it <= ' ' }.length == 0
        }

        @JvmStatic
        fun check_vote_is_selected(voteData: List<VoteData>): Boolean {
            var isSelected = false
            for (voteDatum in voteData) {
                if (voteDatum.voteChecked == "true") {
                    isSelected = true
                    break
                }
            }
            return isSelected
        }

        @JvmStatic
        fun hideKeyboard(activity: Activity,view:View?=null) {
            val imm = activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
            //Find the currently focused view, so we can grab the correct window token from it.
            var altView = activity.currentFocus
            //If no view currently has focus, create a new one, just so we can grab a window token from it
            if (altView == null) {
                altView = View(activity)
            }
            imm.hideSoftInputFromWindow(view?.windowToken?:altView.windowToken, 0)
        }

        @JvmStatic
        fun isEnglish(text: String?): Boolean {

            //  boolean onlyEnglish = true;
            var onlyEnglish = true
            val pp =
                Pattern.compile("(?s).*[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70‌​-\\uFEFF].*")
            if (pp.matcher(text?:"").find()) {
                onlyEnglish = false
                /*There is an Urdu character*/
            }
            val p = Pattern.compile("[a-z]")
            if (p.matcher(text?:"").find()) {
                // Do something
                onlyEnglish = true
            }
            return onlyEnglish
        }

        @JvmStatic
        fun openURLActivity(activity: Activity?, finalUrl: String?) {
            val intent = Intent(activity, WebUrlActivity::class.java)
            intent.putExtra("url", finalUrl)
            activity?.startActivity(intent)
        }

        @JvmStatic
        fun openChromeTab(activity: Activity?, finalUrl: String?) {
            try {
                val builder = CustomTabsIntent.Builder()
                val customTabsIntent = builder.build()
                customTabsIntent.launchUrl(activity!!, Uri.parse(finalUrl))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JvmStatic
        fun changeStringColor(): SpannableString {
            val s = SpannableString("Close Chat")
            s.setSpan(ForegroundColorSpan(Color.RED), 0, s.length, 0)
            return s
        }

        @SuppressLint("NewApi")
        fun errorMessage(context: Context?, message: String?) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }

        @JvmStatic
        val isAppEnglish: Boolean
            get() = (TelloPreferencesManager.getInstance().getString("lang")?:"en") == "en"

        @JvmStatic
        fun isStringContainURL(stringURL: String?=""): String {
            var stringURL = stringURL
            if (stringURL?.contains("http") == false || stringURL?.contains("https")==false) {
                stringURL = NetworkConstants.BASE_IMAGE + stringURL
            }
            return stringURL?:""
        }

        val typeface: Typeface?
            get() = null

        fun isMessageShort(string: String): Boolean {
            return (string.trim { it <= ' ' }.length < 12)
        }
    }
}