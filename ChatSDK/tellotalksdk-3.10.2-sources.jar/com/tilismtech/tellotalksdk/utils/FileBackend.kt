
package com.tilismtech.tellotalksdk.utils

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Bitmap.CompressFormat
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.system.Os
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.loader.content.CursorLoader
import com.tilismtech.tellotalksdk.R

import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.listeners.VideoCompressListener
import com.tilismtech.tellotalksdk.managers.TelloApiClient.Companion.getInstance
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import net.ypresto.androidtranscoder.MediaTranscoder
import net.ypresto.androidtranscoder.format.MediaFormatStrategyPresets
import java.io.Closeable
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Socket
import java.net.URISyntaxException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Future

class FileBackend private constructor() {
    private var mContext: Context?
    private var activity: TelloActivity? = null
    fun setActivity(activity: TelloActivity?) {
        this.activity = activity
    }

    private fun createNoMedia(path: String) {
        val nomedia = File("$path.nomedia")
        if (!nomedia.exists()) {
            try {
                nomedia.createNewFile()
            } catch (e: Exception) {
                Log.d(Config.LOGTAG, "could not create nomedia file")
            }
        }
    }

    fun getFile(message: TTMessage?): DownloadableFile {
        return getFile(message?.relativeFilePath, message?.messageId, message?.mimeType)
    }

    private fun getFile(path: String?, uuid: String?, mime: String?): DownloadableFile {
        val time = System.currentTimeMillis()
        val resolvedPath = path?:uuid
        val file: DownloadableFile = if (resolvedPath!!.startsWith("/")) {
            DownloadableFile(resolvedPath)
        } else {
            if (mime != null && mime.startsWith("image")) {
                if (mime.contains("gif")) {
                    DownloadableFile(TelloConfig.TELLO_ANIMATED_DIRECTORY + resolvedPath)
                } else {
                    DownloadableFile(TelloConfig.TELLO_IMAGE_DIRECTORY + resolvedPath)
                }
            } else if (mime != null && mime.startsWith("video")) {
                DownloadableFile(TelloConfig.TELLO_VIDEO_DIRECTORY + resolvedPath)
            } else if (mime != null && mime.startsWith("audio")) {
                DownloadableFile(TelloConfig.TELLO_AUDIO_DIRECTORY + resolvedPath)
            } else {
                DownloadableFile(TelloConfig.TELLO_FILE_DIRECTORY + resolvedPath)
            }
        }
        return file
    }

    fun resize(originalBitmap: Bitmap?, size: Int): Bitmap? {
        val w = originalBitmap!!.width
        val h = originalBitmap.height
        return if (Math.max(w, h) > size) {
            val scalledW: Int
            val scalledH: Int
            if (w <= h) {
                scalledW = (w / (h.toDouble() / size)).toInt()
                scalledH = size
            } else {
                scalledW = size
                scalledH = (h / (w.toDouble() / size)).toInt()
            }
            val result =
                Bitmap.createScaledBitmap(originalBitmap, scalledW, scalledH, true)
            if (originalBitmap != null && !originalBitmap.isRecycled) {
                originalBitmap.recycle()
            }
            result
        } else {
            originalBitmap
        }
    }

    @Throws(FileCopyException::class)
    private fun copyFileToPrivateStorage(file: File, uri: Uri) {
        file.parentFile?.mkdirs()
        var os: OutputStream? = null
        var `is`: InputStream? = null
        try {
            file.createNewFile()
            os = FileOutputStream(file)
            if (mContext == null) {
                mContext = getInstance()!!.telloContext
            }
            try {
                `is` = mContext!!.contentResolver.openInputStream(uri)
                val buffer = ByteArray(1024)
                var length: Int
                while (`is`!!.read(buffer).also { length = it } > 0) {
                    os.write(buffer, 0, length)
                }
            } catch (e: IOException) {
                throw FileWriterException()
            } catch (e: SecurityException) {
                if (activity != null) {
                    activity!!.runOnUiThread {
                        Toast.makeText(
                            mContext,
                            "Failed to fetch the file",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                os.close()
                os.flush()
                throw FileCopyException(R.string.error_unable_to_create_temporary_file)
            }
            try {
                os.flush()
            } catch (e: IOException) {
                throw FileWriterException()
            }
        } catch (e: FileNotFoundException) {
            throw FileCopyException(R.string.error_file_not_found)
        } catch (e: FileWriterException) {
            throw FileCopyException(R.string.error_unable_to_create_temporary_file)
        } catch (e: IOException) {
            e.printStackTrace()
            throw FileCopyException(R.string.error_io_exception)
        } finally {
            close(os)
            close(`is`)
        }
    }

    @Throws(FileCopyException::class)
    fun copyFileToPrivateStorage(message: TTMessage, uri: Uri) {
        if (mContext == null) {
            mContext = getInstance()!!.telloContext
        }
        val mime = MimeUtils.guessMimeTypeFromUri(mContext, uri)
        var extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
        if (extension == null) {
            extension = getExtensionFromUri(uri)
            if (mime == "audio/aac") {
                extension = "m4a"
            }
        }
        val time = System.currentTimeMillis()
        if (mime != null && mime.startsWith("audio")) {
            message.relativeFilePath = "AUD-$time.$extension"
        } else {
            message.relativeFilePath = "FILE-$time.$extension"
        }
        //message.setRelativeFilePath(message.getMessageId() + "." + extension);
        val file: File = getSendingFile(message)
        copyFileToPrivateStorage(file, uri)
        message.relativeFilePath = file.path
    }

    fun getExtensionFromUri(uri: Uri): String? {
        val projection = arrayOf(MediaStore.MediaColumns.DATA)
        var filename: String? = null
        if (mContext == null) {
            mContext = getInstance()!!.telloContext
        }
        val cursor = mContext!!.contentResolver.query(uri, projection, null, null, null)
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    filename = cursor.getString(0)
                }
            } catch (e: Exception) {
                filename = null
            } finally {
                cursor.close()
            }
        }
        val pos = filename?.lastIndexOf('.') ?: -1
        return if (pos > 0) filename!!.substring(pos + 1) else null
    }

    @Throws(FileCopyException::class)
    private fun copyImageToPrivateStorage(file: File, image: Uri, sampleSize: Int) {
        var sampleSize = sampleSize
        file.parentFile.mkdirs()
        var `is`: InputStream? = null
        var os: OutputStream? = null
        try {
            if (!file.exists() && !file.createNewFile()) {
                throw FileCopyException(R.string.error_unable_to_create_temporary_file)
            }
            if (mContext == null) {
                mContext = getInstance()!!.telloContext
            }
            `is` = mContext!!.contentResolver.openInputStream(image)
            if (`is` == null) {
                throw FileCopyException(R.string.error_not_an_image_file)
            }
            val originalBitmap: Bitmap?
            val options = BitmapFactory.Options()
            val inSampleSize = Math.pow(2.0, sampleSize.toDouble()).toInt()
            options.inSampleSize = inSampleSize
            originalBitmap = BitmapFactory.decodeStream(`is`, null, options)
            `is`.close()
            if (originalBitmap == null) {
                throw FileCopyException(R.string.error_not_an_image_file)
            }
            var scaledBitmap = resize(originalBitmap, Config.IMAGE_SIZE)!!
            //			Bitmap scaledBitmap = ImageUtils.resizeImage(file.getPath());
            val rotation = getRotation(image)
            scaledBitmap = rotate(scaledBitmap, rotation)
            var targetSizeReached = false
            var quality = Config.IMAGE_QUALITY
            while (!targetSizeReached) {
                os = FileOutputStream(file)
                val success = scaledBitmap.compress(Config.IMAGE_FORMAT, quality, os)
                if (!success) {
                    throw FileCopyException(R.string.error_compressing_image)
                }
                os.flush()
                targetSizeReached = file.length() <= Config.IMAGE_MAX_SIZE || quality <= 50
                quality -= 5
            }
            scaledBitmap.recycle()
        } catch (e: FileNotFoundException) {
            throw FileCopyException(R.string.error_file_not_found)
        } catch (e: IOException) {
            e.printStackTrace()
            throw FileCopyException(R.string.error_io_exception)
        } catch (e: SecurityException) {
            throw FileCopyException(R.string.error_security_exception_during_image_copy)
        } catch (e: OutOfMemoryError) {
            ++sampleSize
            if (sampleSize <= 3) {
                copyImageToPrivateStorage(file, image, sampleSize)
            } else {
                throw FileCopyException(R.string.error_out_of_memory)
            }
        } finally {
            close(os)
            close(`is`)
        }
    }

    @Throws(FileCopyException::class)
    fun copyImageToPrivateStorage(file: File, image: Uri) {
        copyImageToPrivateStorage(file, image, 0)
    }

    @Throws(FileCopyException::class)
    fun copyImageToPrivateStorage(message: TTMessage, image: Uri, mimeType: String) {
        val time = System.currentTimeMillis()
        //		String path = context.getFileBackend().getOriginalPath(image);
        val isGif = false
        if (mimeType.contains("gif")) {
            message.relativeFilePath =
                TelloConfig.TELLO_ANIMATED_DIRECTORY + "Sent/GIF-" + time + ".gif"
            createNoMedia(TelloConfig.TELLO_ANIMATED_DIRECTORY + "Sent/")
            CoroutineScope(Dispatchers.IO).launch {
                copyFileToPrivateStorage(getFile(message), image)
            }
            updateFileParams(message)
            return
        }
        when (Config.IMAGE_FORMAT) {
            CompressFormat.JPEG ->                 /*if (path != null) {
                    message.setRelativeFilePath(path);
				} else {
					message.setRelativeFilePath(message.getMessageId() + ".jpg");
				}*/message.relativeFilePath =
                TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/IMG-" + time + ".jpg"

            CompressFormat.PNG ->                 /*if (path != null) {
                message.setRelativeFilePath(path);
			} else{
				message.setRelativeFilePath(message.getMessageId() + ".png");
			}*/message.relativeFilePath =
                TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/IMG-" + time + ".png"

            CompressFormat.WEBP ->                /*if (path != null) {
				message.setRelativeFilePath(path);
			} else{
				message.setRelativeFilePath(message.getMessageId() + ".webp");
			}*/message.relativeFilePath =
                TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/IMG-" + time + ".webp"

            else -> {}
        }
        createNoMedia(TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/")
        CoroutineScope(Dispatchers.IO).launch {
            copyImageToPrivateStorage(getFile(message), image)
        }
        updateFileParams(message)
    }

    private fun getRotation(file: File): Int {
        return getRotation(Uri.parse("file://" + file.absolutePath))
    }

    private fun getRotation(image: Uri): Int {
        var `is`: InputStream? = null
        return try {
            if (mContext == null) {
                mContext = getInstance()!!.telloContext
            }
            `is` = mContext!!.contentResolver.openInputStream(image)
            ExifHelper.getOrientation(`is`)
        } catch (e: FileNotFoundException) {
            0
        } finally {
            close(`is`)
        }
    }

    @Throws(FileNotFoundException::class)
    fun getThumbnail(message: TTMessage, size: Int, cacheOnly: Boolean): Bitmap? {
        val uuid = message.messageId
        //        final LruCache<String,Bitmap> cache = TelloApplication.telloApplication.getBitmapCache();
//        Bitmap thumbnail = cache.get(uuid);
        var thumbnail: Bitmap? = null
        if (thumbnail == null && !cacheOnly) {
            synchronized(THUMBNAIL_LOCK) {

//                thumbnail = cache.get(uuid);
                if (thumbnail != null) {
                    return thumbnail
                }
                var file : DownloadableFile? = null
                CoroutineScope(Dispatchers.IO).launch {
                    file = getFile(message)
                }.invokeOnCompletion {
                    val mime = file?.mimeType
                    if (mime?.startsWith("video/")==true) {
                        thumbnail = getVideoPreview(file as File, size)
                    } else {
                        val fullsize = getFullsizeImagePreview(file as File, size)
                            ?: throw FileNotFoundException()
                        thumbnail = resize(fullsize, size)
                        thumbnail = rotate(thumbnail!!, getRotation(file as File))
                        if (mime == "image/gif") {
                            val withGifOverlay =
                                thumbnail!!.copy(Bitmap.Config.ARGB_8888, true)
                            drawOverlay(withGifOverlay, R.drawable.play_gif_sdk, 1.0f)
                            thumbnail!!.recycle()
                            thumbnail = withGifOverlay
                        }
                    }
                }
            }
        }
        return thumbnail
    }


    private fun getFullsizeImagePreview(file: File, size: Int): Bitmap {
        val options = BitmapFactory.Options()
        options.inSampleSize = calcSampleSize(file, size)
        return try {
            BitmapFactory.decodeFile(file.absolutePath, options)
        } catch (e: OutOfMemoryError) {
            options.inSampleSize *= 2
            BitmapFactory.decodeFile(file.absolutePath, options)
        }
    }

    private fun drawOverlay(bitmap: Bitmap?, resource: Int, factor: Float) {
        if (mContext == null) {
            mContext = getInstance()!!.telloContext
        }
        val overlay = BitmapFactory.decodeResource(mContext!!.resources, resource)
        val canvas = Canvas(bitmap!!)
        val paint = Paint()
        paint.isAntiAlias = true
        paint.isFilterBitmap = true
        paint.isDither = true
        val targetSize = Math.min(canvas.width, canvas.height) * factor
        val left = (canvas.width - targetSize) / 2.0f
        val top = (canvas.height - targetSize) / 2.0f
        val dst = RectF(left, top, left + targetSize - 1, top + targetSize - 1)
        canvas.drawBitmap(overlay, null, dst, paint)
    }

    private fun getVideoPreview(file: File, size: Int): Bitmap? {
        val metadataRetriever = MediaMetadataRetriever()
        var frame: Bitmap?
        if (file.length() > 0) {
            try {
                metadataRetriever.setDataSource(file.absolutePath)
                frame = metadataRetriever.getFrameAtTime(0)
                try {
                    metadataRetriever.release()
                } catch (e: IOException) {
                    throw RuntimeException(e)
                }
                frame = resize(frame, AndroidUtilities.dp(200f))
            } catch (e: IllegalArgumentException) {
                frame = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                frame.eraseColor(-0x1000000)
            } catch (e: NullPointerException) {
                frame = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                frame.eraseColor(-0x1000000)
            } catch (e: RuntimeException) {
                frame = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                frame.eraseColor(-0x1000000)
            }
            drawOverlay(frame, R.drawable.play_video_sdk, 0.3f)
            return frame
        }
        return null
    }

    val takePhotoUri: Uri?
        get() {
            if (mContext == null) {
                mContext = getInstance()!!.telloContext
            }
            val file =
                File(TelloConfig.TELLO_IMAGE_DIRECTORY + "IMG_" + IMAGE_DATE_FORMAT.format(Date()) + ".jpg")
            file.parentFile?.mkdirs()
            return getUriForFile(mContext, file)
        }

    val takeVideoUri: Uri?
        get() {
            if (mContext == null) {
                mContext = getInstance()!!.telloContext
            }
            val file =
                File(TelloConfig.TELLO_VIDEO_DIRECTORY + "VID_" + IMAGE_DATE_FORMAT.format(Date()) + ".mp4")
            file.parentFile?.mkdirs()
            return getUriForFile(mContext, file)
        }

    @JvmOverloads
    fun updateFileParams(message: TTMessage, url: String? = null) {
        val file = getFile(message)
        val mime = file.mimeType
        val image =
            message.msgType == TTMessage.MsgType.TYPE_IMAGE.value || (mime != null && mime.startsWith(
                "image/"
            ))
        val video = mime != null && mime.startsWith("video/")
        if (image || video) {
            try {
                val dimensions = if (image) getImageDimensions(file) else getVideoDimensions(file)
                if (url == null) {
                    message.message =
                        file.size.toString() + '|' + dimensions.width + '|' + dimensions.height
                } else {
                    if (message.message?.contains("zindigi") == true || url.contains("http")) {
                        message.message = url
                    } else {
                        message.message = NetworkConstants.BASE_URL1 + url
                    }
                }
                return
            } catch (notAVideoFile: NotAVideoFile) {
                //fall threw
            }
        }
        if (url != null) {
            if (message.message?.contains("zindigi") == true || url.contains("http")) {
                message.message = url
            } else {
                message.message = NetworkConstants.BASE_URL1 + url
            }
        } else {
            message.message = file.size.toString()
        }
    }

    private fun getImageDimensions(file: File): Dimensions {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.absolutePath, options)
        val rotation = getRotation(file)
        val rotated = rotation == 90 || rotation == 270
        val imageHeight = if (rotated) options.outWidth else options.outHeight
        val imageWidth = if (rotated) options.outHeight else options.outWidth
        return Dimensions(imageHeight, imageWidth)
    }

    @Throws(NotAVideoFile::class)
    private fun getVideoDimensions(file: File): Dimensions {
        val metadataRetriever = MediaMetadataRetriever()
        try {
            metadataRetriever.setDataSource(file.absolutePath)
        } catch (e: Exception) {
            throw NotAVideoFile()
        }
        val hasVideo =
            metadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
                ?: throw NotAVideoFile()
        val rotation = extractRotationFromMediaRetriever(metadataRetriever)
        val rotated = rotation == 90 || rotation == 270
        val height: Int
        height = try {
            val h =
                metadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            h!!.toInt()
        } catch (e: Exception) {
            -1
        }
        val width: Int
        width = try {
            val w =
                metadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            w!!.toInt()
        } catch (e: Exception) {
            -1
        }
        try {
            metadataRetriever.release()
        } catch (e: IOException) {
            throw RuntimeException(e)
        }
        return if (rotated) Dimensions(width, height) else Dimensions(height, width)
    }

    private fun extractRotationFromMediaRetriever(metadataRetriever: MediaMetadataRetriever): Int {
        val rotation: Int =
            metadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()?:0
        return rotation
    }

    private inner class Dimensions(val height: Int, val width: Int)
    private inner class NotAVideoFile : Exception()
    inner class FileCopyException(val resId: Int) : Exception() {

        private val serialVersionUID = -1010013599132881427L
    }

    private var mFuture: Future<Void>? = null

    init {
        mContext = getInstance()!!.telloContext
    }

    fun videoEncoder(uri: Uri, listener: VideoCompressListener) {
        val file: File = try {
            val outputDir = File(TelloConfig.TELLO_VIDEO_DIRECTORY)
            if (!outputDir.exists()) {
                outputDir.mkdirs()
            }
            val sentDir = File("$outputDir/Sent")
            if (!sentDir.exists()) {
                sentDir.mkdirs()
            }
            File.createTempFile("VID", ".mp4", sentDir)
        } catch (e: IOException) {
            onTranscodeFinished(false, "Transcoder error occurred.", null, listener)
            //				Toast.makeText(mXmppConnectionService, "Failed to create temporary file.", Toast.LENGTH_LONG).show();
            return
        }
        val resolver = getInstance()!!.telloContext.contentResolver
        val parcelFileDescriptor: ParcelFileDescriptor? = try {
            resolver?.openFileDescriptor(uri, "r")
        } catch (e: FileNotFoundException) {
            onTranscodeFinished(false, "Transcoder error occurred.", null, listener)
            return
        }
        val fileDescriptor = parcelFileDescriptor!!.fileDescriptor
        val startTime = SystemClock.uptimeMillis()
        if (uri.path!!.contains(TelloConfig.TELLO_VIDEO_DIRECTORY)) {
            onTranscodeFinished(false, "Transcoder error occurred.", parcelFileDescriptor, listener)
            return
        }
        val mediaTranscoderListner: MediaTranscoder.Listener = object : MediaTranscoder.Listener {
            override fun onTranscodeProgress(progress: Double) {
                listener.onProgress(Math.ceil(progress * 100).toInt())
                Log.d("compressingProgress", "Progress is : " + Math.ceil(progress * 100).toInt())
            }

            override fun onTranscodeCompleted() {
                onTranscodeFinished(true, file.toString(), parcelFileDescriptor, listener)
            }

            override fun onTranscodeCanceled() {
                onTranscodeFinished(false, "Transcoder canceled.", parcelFileDescriptor, listener)
            }

            override fun onTranscodeFailed(exception: Exception) {
                onTranscodeFinished(
                    false,
                    "Transcoder error occurred.",
                    parcelFileDescriptor,
                    listener
                )
            }
        }
        mFuture = MediaTranscoder.getInstance().transcodeVideo(
            fileDescriptor,
            file.absolutePath,
            MediaFormatStrategyPresets.createAndroid720pStrategy(),
            mediaTranscoderListner
        )
    }

    private fun onTranscodeFinished(
        isSuccess: Boolean,
        filePath: String,
        parcelFileDescriptor: ParcelFileDescriptor?,
        listener: VideoCompressListener
    ) {
        try {
            parcelFileDescriptor!!.close()
            if (isSuccess) {
                listener.onVideoCompressionSuccess(filePath)
            } else {
                listener.onVideoCompressionFailed()
            }
        } catch (e: Exception) {
            listener.onVideoCompressionFailed()
            Log.e("Error while closing", e.toString())
            Toast.makeText(mContext, e.toString(), Toast.LENGTH_LONG).show();
        }
    }



    fun getSendingFile(message: TTMessage): DownloadableFile {
        return getSendingFile(message, true)
    }

    fun getSendingFile(message: TTMessage, decrypted: Boolean): DownloadableFile {
        val file: DownloadableFile
        var path = message.relativeFilePath
        val time = System.currentTimeMillis()
        if (path == null) {
            path = message.messageId
        }
        file = if (path.startsWith("/")) {
            DownloadableFile(path)
        } else {
            val mime = message.mimeType
            if (mime != null && mime.startsWith("image")) {
                if (mime.contains("gif")) {
                    DownloadableFile(TelloConfig.TELLO_ANIMATED_DIRECTORY + "Sent/" + path)
                } else {
                    DownloadableFile(TelloConfig.TELLO_IMAGE_DIRECTORY + "Sent/" + path)
                }
            } else if (mime != null && mime.startsWith("video")) {
                DownloadableFile(TelloConfig.TELLO_VIDEO_DIRECTORY + "Sent/" + path)
            } else if (mime != null && mime.startsWith("audio")) {
                DownloadableFile(TelloConfig.TELLO_AUDIO_DIRECTORY + "Sent/" + path)
            } else {
                DownloadableFile(TelloConfig.TELLO_FILE_DIRECTORY + "Sent/" + path)
            }
        }
        return file
    }
    fun getImageContentUri(context: Context, imageFile: File): Uri? {
        val filePath = imageFile.absolutePath
        val cursor = context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID),
            MediaStore.Images.Media.DATA + "=? ",
            arrayOf(filePath),
            null
        )
        return if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID))
            val baseUri = Uri.parse("content://media/external/images/media")
            Uri.withAppendedPath(baseUri, id.toString())
        } else {
            if (imageFile.exists()) {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DATA, filePath)
                context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            } else {
                null
            }
        }
    }


    fun showToast(msg: String){
        if(msg.isNotEmpty()){
            Toast.makeText(instance?.mContext!!,msg, Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private val THUMBNAIL_LOCK = Any()
        private val IMAGE_DATE_FORMAT = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
        private const val FILE_PROVIDER = ".provider"
        @JvmStatic
        var instance: FileBackend? = null
            get() {
                if (field == null) {
                    field = FileBackend()
                }
                return field
            }
            private set

        fun weOwnFile(context: Context, uri: Uri?): Boolean {
            return if (uri == null || ContentResolver.SCHEME_FILE != uri.scheme) {
                false
            } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                fileIsInFilesDir(context, uri)
            } else {
                weOwnFileLollipop(uri)
            }
        }

        fun rotate(bitmap: Bitmap, degree: Int): Bitmap {
            if (degree == 0) {
                return bitmap
            }
            val w = bitmap.width
            val h = bitmap.height
            val mtx = Matrix()
            mtx.postRotate(degree.toFloat())
            val result = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true)
            if (bitmap != null && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            return result
        }

        @JvmStatic
        fun getUriForFile(context: Context?, file: File?): Uri {
            return try {
                val packageId = context!!.packageName
                val authority = "$packageId.sdk.provider"
                FileProvider.getUriForFile(context, authority, file!!)
            } catch (e: IllegalArgumentException) {
                throw SecurityException()
            }
        }

        private fun calcSampleSize(image: File, size: Int): Int {
            val options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeFile(image.absolutePath, options)
            return calcSampleSize(options, size)
        }

        fun calcSampleSize(options: BitmapFactory.Options, size: Int): Int {
            val height = options.outHeight
            val width = options.outWidth
            var inSampleSize = 1
            if (height > size || width > size) {
                val halfHeight = height / 2
                val halfWidth = width / 2
                while (halfHeight / inSampleSize > size && halfWidth / inSampleSize > size) {
                    inSampleSize *= 2
                }
            }
            return inSampleSize
        }

        @JvmStatic
        fun close(stream: Closeable?) {
            if (stream != null) {
                try {
                    stream.close()
                } catch (e: IOException) {
                }
            }
        }

        fun close(socket: Socket?) {
            if (socket != null) {
                try {
                    socket.close()
                } catch (e: IOException) {
                }
            }
        }

        /**
         * This is more than hacky but probably way better than doing nothing
         * Further 'optimizations' might contain to get the parents of CacheDir and NoBackupDir
         * and check against those as well
         */
        private fun fileIsInFilesDir(context: Context, uri: Uri): Boolean {
            return try {
                val haystack = context.filesDir.parentFile.canonicalPath
                val needle = File(uri.path).canonicalPath
                needle.startsWith(haystack)
            } catch (e: IOException) {
                false
            }
        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        private fun weOwnFileLollipop(uri: Uri): Boolean {
            return try {
                val file = File(uri.path)
                val fd = ParcelFileDescriptor.open(
                    file,
                    ParcelFileDescriptor.MODE_READ_ONLY
                ).fileDescriptor
                val st = Os.fstat(fd)
                st.st_uid == Process.myUid()
            } catch (e: FileNotFoundException) {
                false
            } catch (e: Exception) {
                true
            }
        }

        fun getFileNameFromUri(context: Context, uri: Uri): String {
            return when (uri.scheme) {
                "content" -> {
                    var name = ""
                    context.contentResolver.query(
                        uri,
                        arrayOf(OpenableColumns.DISPLAY_NAME),
                        null,
                        null,
                        null
                    )?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (idx >= 0) name = cursor.getString(idx)
                        }
                    }
                    name             // may be empty if the provider doesn’t expose DISPLAY_NAME
                }
                "file" -> File(uri.path!!).name
                else    -> uri.lastPathSegment ?: "unknown"
            }
        }

        @JvmStatic
        @SuppressLint("NewApi")
        @Throws(URISyntaxException::class)
        fun getFilePath(context: Context, uri: Uri): String? {
            var uri = uri
            var selection: String? = null
            var selectionArgs: Array<String>? = null
            // Uri is different in versions after KITKAT (Android 4.4), we need to
            if (DocumentsContract.isDocumentUri(context.applicationContext, uri)) {
                if (isExternalStorageDocument(uri)) {
                    val docId = DocumentsContract.getDocumentId(uri)
                    val split = docId.split(":".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()
                    return Environment.getExternalStorageDirectory().toString() + "/" + split[1]
                } else if (isDownloadsDocument(uri)) {
                    val id = DocumentsContract.getDocumentId(uri)
                    uri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"),
                        java.lang.Long.valueOf(id)
                    )
                } else if (isMediaDocument(uri)) {
                    val docId = DocumentsContract.getDocumentId(uri)
                    val split = docId.split(":".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()
                    val type = split[0]
                    if ("image" == type) {
                        uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    } else if ("video" == type) {
                        uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    } else if ("audio" == type) {
                        uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    }
                    selection = "_id=?"
                    selectionArgs = arrayOf(split[1])
                }
            }
            if ("content".equals(uri.scheme, ignoreCase = true)) {
                val projection = arrayOf(MediaStore.Images.Media.DATA)
                var cursor: Cursor? = null
                try {
                    cursor = context.contentResolver.query(
                        uri,
                        projection,
                        selection,
                        selectionArgs,
                        null
                    )
                    val column_index = cursor!!.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                    if (cursor.moveToFirst()) {
                        return cursor.getString(column_index)
                    }
                } catch (e: Exception) {
                }
            } else if ("file".equals(uri.scheme, ignoreCase = true)) {
                return uri.path
            }
            return null
        }

        fun isExternalStorageDocument(uri: Uri): Boolean {
            return "com.android.externalstorage.documents" == uri.authority
        }

        fun isDownloadsDocument(uri: Uri): Boolean {
            return "com.android.providers.downloads.documents" == uri.authority
        }

        fun isMediaDocument(uri: Uri): Boolean {
            return "com.android.providers.media.documents" == uri.authority
        }
    }
}
