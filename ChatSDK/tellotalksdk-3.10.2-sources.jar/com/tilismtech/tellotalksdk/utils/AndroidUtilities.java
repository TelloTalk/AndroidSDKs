package com.tilismtech.tellotalksdk.utils;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Point;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import com.tilismtech.tellotalksdk.managers.TelloApiClient;

import java.util.regex.Pattern;

public class AndroidUtilities {

    public static float density = 1;
    private static Point displaySize = new Point();
    public static DisplayMetrics displayMetrics = new DisplayMetrics();
    private static Boolean isTablet = null;

    static {
        try {
            final String GOOD_IRI_CHAR = "a-zA-Z0-9\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF";
            final Pattern IP_ADDRESS = Pattern.compile(
                    "((25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\\.(25[0-5]|2[0-4]"
                            + "[0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]"
                            + "[0-9]{2}|[1-9][0-9]|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}"
                            + "|[1-9][0-9]|[0-9]))");
            final String IRI = "[" + GOOD_IRI_CHAR + "]([" + GOOD_IRI_CHAR + "\\-]{0,61}[" + GOOD_IRI_CHAR + "]){0,1}";
            final String GOOD_GTLD_CHAR = "a-zA-Z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF";
            final String GTLD = "[" + GOOD_GTLD_CHAR + "]{2,63}";
            final String HOST_NAME = "(" + IRI + "\\.)+" + GTLD;
            final Pattern DOMAIN_NAME = Pattern.compile("(" + HOST_NAME + "|" + IP_ADDRESS + ")");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static {
        checkDisplaySize(TelloApiClient.getInstance().telloContext, null);
    }

    public static int dp(float value) {
        if (value == 0) {
            return 0;
        }
        return (int) Math.ceil(density * value);
    }

    private static void checkDisplaySize(Context context, Configuration newConfiguration) {
        try {
            density = context.getResources().getDisplayMetrics().density;
            Configuration configuration = newConfiguration;
            if (configuration == null) {
                configuration = context.getResources().getConfiguration();
            }
            WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (manager != null) {
                Display display = manager.getDefaultDisplay();
                if (display != null) {
                    display.getMetrics(displayMetrics);
                    display.getSize(displaySize);
                }
            }
            if (configuration.screenWidthDp != Configuration.SCREEN_WIDTH_DP_UNDEFINED) {
                int newSize = (int) Math.ceil(configuration.screenWidthDp * density);
                if (Math.abs(displaySize.x - newSize) > 3) {
                    displaySize.x = newSize;
                }
            }
            if (configuration.screenHeightDp != Configuration.SCREEN_HEIGHT_DP_UNDEFINED) {
                int newSize = (int) Math.ceil(configuration.screenHeightDp * density);
                if (Math.abs(displaySize.y - newSize) > 3) {
                    displaySize.y = newSize;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isTablet() {
        if (isTablet == null) {
            isTablet = true;
        }
        return isTablet;
    }

//    public static void setListViewEdgeEffectColor(AbsListView listView, int color) {
//        if (Build.VERSION.SDK_INT >= 21) {
//            try {
//                Field field = AbsListView.class.getDeclaredField("mEdgeGlowTop");
//                field.setAccessible(true);
//                EdgeEffect mEdgeGlowTop = (EdgeEffect) field.get(listView);
//                if (mEdgeGlowTop != null) {
//                    mEdgeGlowTop.setColor(color);
//                }
//
//                field = AbsListView.class.getDeclaredField("mEdgeGlowBottom");
//                field.setAccessible(true);
//                EdgeEffect mEdgeGlowBottom = (EdgeEffect) field.get(listView);
//                if (mEdgeGlowBottom != null) {
//                    mEdgeGlowBottom.setColor(color);
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
