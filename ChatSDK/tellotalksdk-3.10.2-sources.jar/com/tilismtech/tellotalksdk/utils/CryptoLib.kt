package com.tilismtech.tellotalksdk.utils

import android.util.Base64
import java.io.UnsupportedEncodingException
import java.security.InvalidAlgorithmParameterException
import java.security.InvalidKeyException
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.security.SecureRandom
import java.security.spec.X509EncodedKeySpec
import javax.crypto.BadPaddingException
import javax.crypto.Cipher
import javax.crypto.IllegalBlockSizeException
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

internal class CryptoLib private constructor() {
    /**
     * Encryption mode enumeration
     */
    private enum class EncryptMode {
        ENCRYPT,
        DECRYPT
    }

    var key: String? = null
    var iv: String? = null
    var publicKey: String? = null
    fun init(key: String?, iv: String?,publicKey:String?) {
        try {
            this.key = SHA256(key, 32)
            this.iv = iv
            this.publicKey = publicKey
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: UnsupportedEncodingException) {
            e.printStackTrace()
        }
    }

    /**
     * @param _inputText     Text to be encrypted or decrypted
     * @param _encryptionKey Encryption key to used for encryption / decryption
     * @param _mode          specify the mode encryption / decryption
     * @param _initVector    Initialization vector
     * @return encrypted or decrypted string based on the mode
     * @throws UnsupportedEncodingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    @Throws(
        UnsupportedEncodingException::class,
        InvalidKeyException::class,
        InvalidAlgorithmParameterException::class,
        IllegalBlockSizeException::class,
        BadPaddingException::class,
        IllegalArgumentException::class
    )
    private fun encryptDecrypt(inputText: String?, encryptionKey: String?,
                               mode: EncryptMode, initVector: String?): String {
        val key = ByteArray(32) // 256 bit key space
        val iv = ByteArray(16) // 128 bit IV

        val keyLen = minOf(encryptionKey?.toByteArray(Charsets.UTF_8)?.size?:0, key.size)
        val ivLen = minOf(initVector?.toByteArray(Charsets.UTF_8)?.size?:0, iv.size)

        System.arraycopy(encryptionKey?.toByteArray(Charsets.UTF_8)?: byteArrayOf(), 0, key, 0, keyLen)
        System.arraycopy(initVector?.toByteArray(Charsets.UTF_8)?: byteArrayOf(), 0, iv, 0, ivLen)

        val cipher: Cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        val keySpec = SecretKeySpec(key, "AES")
        val ivSpec = IvParameterSpec(iv)

        val output: ByteArray
        if (mode == EncryptMode.ENCRYPT) {
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
            output = cipher.doFinal(inputText?.toByteArray(Charsets.UTF_8))
            return Base64.encodeToString(output, Base64.DEFAULT)
        } else if (mode == EncryptMode.DECRYPT) {
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            val decodedValue = Base64.decode(inputText, Base64.DEFAULT)
            output = cipher.doFinal(decodedValue)
            return String(output, Charsets.UTF_8)
        }

        return ""
    }

    /***
     * This function encrypts the plain text to cipher text using the key
     * provided. You'll have to use the same key for decryption
     *
     * @param plainText
     * Plain text to be encrypted
     * @param _key
     * Encryption Key. You'll have to use the same key for decryption
     * @param _iv
     * initialization Vector
     * @return returns encrypted (cipher) text
     * @throws InvalidKeyException
     * @throws UnsupportedEncodingException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    @Throws(
        InvalidKeyException::class,
        UnsupportedEncodingException::class,
        InvalidAlgorithmParameterException::class,
        IllegalBlockSizeException::class,
        BadPaddingException::class,
        IllegalArgumentException::class
    )
    fun encrypt(plainText: String): String {
        return encryptDecrypt(plainText, key, EncryptMode.ENCRYPT, iv)
    }

    /***
     * This funtion decrypts the encrypted text to plain text using the key
     * provided. You'll have to use the same key which you used during
     * encryprtion
     *
     * @param _encryptedText
     * Encrypted/Cipher text to be decrypted
     * @param _key
     * Encryption key which you used during encryption
     * @param _iv
     * initialization Vector
     * @return encrypted value
     * @throws InvalidKeyException
     * @throws UnsupportedEncodingException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    @Throws(
        InvalidKeyException::class,
        UnsupportedEncodingException::class,
        InvalidAlgorithmParameterException::class,
        IllegalBlockSizeException::class,
        BadPaddingException::class,
        IllegalArgumentException::class
    )
    fun decrypt(_encryptedText: String): String {
        return encryptDecrypt(_encryptedText, key, EncryptMode.DECRYPT, iv)
    }

    companion object {
        @JvmStatic
        var instance: CryptoLib? = null
            get() {
                if (field == null) {
                    field = CryptoLib()
                }
                return field
            }
        private set

        /**
         * Note: This function is no longer used.
         * This function generates md5 hash of the input string
         *
         * @param inputString
         * @return md5 hash of the input string
         */
        fun md5(inputString: String): String {
            val MD5 = "MD5"
            try {
                // Create MD5 Hash
                val digest = MessageDigest.getInstance(MD5)
                digest.update(inputString.toByteArray())
                val messageDigest = digest.digest()
                // Create Hex String
                val hexString = StringBuilder()
                for (aMessageDigest in messageDigest) {
                    var h = Integer.toHexString(0xFF and aMessageDigest.toInt())
                    while (h.length < 2) h = "0$h"
                    hexString.append(h)
                }
                return hexString.toString()
            } catch (e: NoSuchAlgorithmException) {
                e.printStackTrace()
            }
            return ""
        }

        /***
         * This function computes the SHA256 hash of input string
         * @param text input text whose SHA256 hash has to be computed
         * @param length length of the text to be returned
         * @return returns SHA256 hash of input text
         * @throws NoSuchAlgorithmException
         * @throws UnsupportedEncodingException
         */
        @Throws(NoSuchAlgorithmException::class, UnsupportedEncodingException::class)
        private fun SHA256(text: String?, length: Int): String {
            val resultStr: String
            val md = MessageDigest.getInstance("SHA-256")
            md.update(text?.toByteArray(charset("UTF-8"))?: byteArrayOf())
            val digest = md.digest()
            val result = StringBuffer()
            for (b in digest) {
                result.append(String.format("%02x", b)) //convert to hex
            }
            resultStr = if (length > result.toString().length) {
                result.toString()
            } else {
                result.toString().substring(0, length)
            }
            return resultStr
        }

        /**
         * this function generates random string for given length
         *
         * @param length Desired length
         * * @return
         */
        fun generateRandomIV(length: Int): String {
            val ranGen = SecureRandom()
            val aesKey = ByteArray(16)
            ranGen.nextBytes(aesKey)
            val result = StringBuffer()
            for (b in aesKey) {
                result.append(String.format("%02x", b)) //convert to hex
            }
            return if (length > result.toString().length) {
                result.toString()
            } else {
                result.toString().substring(0, length)
            }
        }
    }

    fun encryptRsa(plainText: String): String {
        try {
            // Decode the public key
            val publicKeyBytes = Base64.decode(publicKey?:"",Base64.DEFAULT)
            val keySpec = X509EncodedKeySpec(publicKeyBytes)
            val keyFactory = KeyFactory.getInstance("RSA")
            val publicKey = keyFactory.generatePublic(keySpec)

            // Initialize the RSA cipher for encryption
            val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
            cipher.init(Cipher.ENCRYPT_MODE, publicKey)

            // Encrypt the plaintext
            val encryptedBytes = cipher.doFinal(plainText.toByteArray())

            // Encode the encrypted bytes to Base64
            return Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            return ""
        }
    }
}