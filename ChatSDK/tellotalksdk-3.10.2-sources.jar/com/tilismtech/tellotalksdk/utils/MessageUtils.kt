package com.tilismtech.tellotalksdk.utils

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.Html
import android.text.InputFilter
import android.text.InputFilter.LengthFilter
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.util.Patterns
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatSpinner
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.widget.CompoundButtonCompat
import androidx.recyclerview.widget.RecyclerView
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.MediaAttachment
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.network.module.responses.FormFieldResponse
import com.tilismtech.tellotalksdk.listeners.UiCallback
import com.tilismtech.tellotalksdk.listeners.UiInformableCallback
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.packages.easypermissions.EasyPermissions
import com.tilismtech.tellotalksdk.ui.activities.ConversationActivity
import com.tilismtech.tellotalksdk.ui.activities.TelloActivity
import com.tilismtech.tellotalksdk.ui.adapters.ChatFormDropDownAdapter
import com.tilismtech.tellotalksdk.ui.adapters.recyclerViews.FormFilelistAdapter
import com.tilismtech.tellotalksdk.ui.attachmentconfirmation.AttachmentConfirmationActivity
import com.tilismtech.tellotalksdk.ui.customviews.bolditalictextview.WhatsAppEditText
import com.tilismtech.tellotalksdk.ui.dialog.PermissionDialogFragment
import com.tilismtech.tellotalksdk.ui.dialog.PermissionDialogFragment.BaseDialogListener
import com.tilismtech.tellotalksdk.ui.gallery.Gallery
import com.tilismtech.tellotalksdk.ui.viewmodels.ConversationActivityViewModel
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.openPermissionsSettings
import com.tilismtech.tellotalksdk.utils.FileBackend.Companion.getUriForFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.net.URISyntaxException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.LinkedList
import java.util.Locale

class MessageUtils {
    private val mPendingDownloadableMessage: TTMessage? = null
    private val conversationActivityViewModel = ConversationActivityViewModel.getInstance()
    private val chatManager = ChatManager.instance

    var activityCallback :((it:Intent?)-> Unit)?={}


    fun manageMediaResult(
        activity: TelloActivity,
        uris: List<Uri>,
        callback:(it:Intent?) -> Unit={}
    ) {
        activityCallback = callback
        val attachments = getMediaAttachmentsFromUri(uris, activity)
        if (!attachments.isEmpty()) openImageEditor(
            attachments,
            activity,
        )
    }
    fun managePhotoResult(activity: TelloActivity,
                          uri:Uri,
                          callback:(it:Intent?)->Unit={}){
        activityCallback = callback
        val attachments = arrayListOf<MediaAttachment>()
        val mediaAttachment = MediaAttachment()
        mediaAttachment.fileUri = uri
        mediaAttachment.mimeType = "image/*"
        attachments.add(mediaAttachment)
        openImageEditor(attachments, activity)
    }

    fun manageFileResult(activity: TelloActivity, contactJid:String?, uri:Uri){
        attachFileToConversation(
            activity,
            contactJid,
            uri,
            null,
            FileUtils.getPath(activity, uri)
        )
    }

    fun processAttachments(activity: TelloActivity,intent: Intent,contactJid: String?){
        val uris = intent.getParcelableArrayListExtra<MediaAttachment>("uris")
        val i = uris!!.iterator()
        while (i.hasNext()) {
            val mediaAttachment = i.next()
            if (mediaAttachment.mimeType.startsWith("video")) {
                attachFileToConversation(
                    activity,
                    contactJid,
                    mediaAttachment.fileUri,
                    null,
                    mediaAttachment.fileTag
                )
            } else {
                attachImageToConversation(
                    activity,
                    contactJid,
                    mediaAttachment.fileUri,
                    mediaAttachment.mimeType,
                    mediaAttachment.fileTag
                )
            }
            i.remove()
        }
    }

    private fun attachImageToConversation(
        activity: TelloActivity,
        contactJid: String?,
        uri: Uri,
        mimeType: String,
        fileTag: String
    ) {
        Toast.makeText(activity, activity.getText(R.string.preparing_image), Toast.LENGTH_LONG)
            .show()
        chatManager!!.attachImageToConversation(uri, mimeType, object : UiCallback<TTMessage> {
            override fun success(message: TTMessage) {
                message.caption = fileTag
                message.contactId = contactJid
                message.msgDate = Date()
                message.systemDate = Date()
                if (activity is ConversationActivity) {
                    activity.checkAndSetReplyMessage(message)
                }
                sendMessage(message, activity)
            }

            override fun error(errorCode: Int, message: TTMessage) {}
            override fun userInputRequired(pi: PendingIntent, message: TTMessage) {}
        })
    }

    fun attachFileToConversation(
        context: TelloActivity,
        contactJid: String?,
        uri: Uri?,
        filePath: String?,
        fileTag: String?
    ) {
        val message = TTMessage("")
        if (uri != null) {
            try {
                val file = FileUtils.copyUriToFile(context, uri)
                if (file.exists() && file.length() > 2000000) {
                    Toast.makeText(
                        context,
                        "File size cannot be greater than 2MBs",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
            } catch (e: URISyntaxException) {
                e.printStackTrace()
            }
        } else if (filePath != null) {
            val file = File(filePath)
            if (file.exists() && file.length() > 2000000) {
                Toast.makeText(context, "File size cannot be greater than 2MBs", Toast.LENGTH_LONG)
                    .show()
                return
            }
        }
        var prepareFileToast: Toast? =null
        context.runOnUiThread {
            prepareFileToast = Toast.makeText(context, context.getText(R.string.preparing_file), Toast.LENGTH_LONG)
            prepareFileToast?.show()
        }
        chatManager!!.attachFileToConversation(
            contactJid,
            uri,
            filePath,
            message,
            fileTag,
            object : UiInformableCallback<TTMessage> {
                override fun success(message: TTMessage) {
                    message.contactId = contactJid
                    message.msgDate = Date()
                    message.systemDate = Date()
                    message.msgStatus = TTMessage.MsgStatus.PENDING
                    if (context is ConversationActivity) {
                        context.checkAndSetReplyMessage(message)
                    }
                    if (message.msgType == TTMessage.MsgType.TYPE_VIDEO.value) {
                        compressVideo(context, message, prepareFileToast)
                    } else {
                        sendMessage(message, context)
                        hidePrepareFileToast(prepareFileToast, context)
                        context.runOnUiThread { context.hideToast() }
                    }
                }

                override fun error(errorCode: Int, message: TTMessage) {
                    hidePrepareFileToast(prepareFileToast, context)
                    context.runOnUiThread { context.replaceToast(context.getString(errorCode)) }
                }

                override fun userInputRequired(pi: PendingIntent, message: TTMessage) {
                    hidePrepareFileToast(prepareFileToast, context)
                }

                override fun inform(text: String) {
                    hidePrepareFileToast(prepareFileToast, context)
                    context.runOnUiThread { context.replaceToast(text) }
                }
            })
    }

    private fun getMediaAttachmentsFromUri(
        uris: List<Uri>,
        context: Context
    ): ArrayList<MediaAttachment> {
        val mediaAttachments = ArrayList<MediaAttachment>()
        val cR = context.contentResolver
        for (uri in uris) {
            val attachment = MediaAttachment()
            attachment.fileUri = uri
            mediaAttachments.add(attachment)
            val type = cR.getType(uri)
            if (type == null) {
            } else if (type.contains("video")) {
                attachment.mimeType = "video/*"
            } else if (type.contains("gif")) {
                attachment.mimeType = "image/gif"
            } else {
                attachment.mimeType = "image/*"
            }
        }
        return mediaAttachments
    }

    private fun openGallery(requestCode: Int, activity: TelloActivity, mode: Int) {
        val intent = Intent(activity, Gallery::class.java)
        intent.putExtra("title", "Select media")
        intent.putExtra("mode", mode)
        intent.putExtra("maxSelection", 5)
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        activity.startActivityForResult(intent, requestCode)
    }

    private fun openImageEditor(uri: ArrayList<MediaAttachment>?, context: TelloActivity, ) {
        val intent = Intent(context, AttachmentConfirmationActivity::class.java)
        val filtered = ArrayList<MediaAttachment>()
        for (attachment in uri!!) {
            try {
                var file : File?
                if(attachment.mimeType.contains("image")){
                    file = FileUtils.copyMediaUriToFile(context, attachment.fileUri)
                }else{
                    file = FileUtils.copyUriToFile(context, attachment.fileUri)
                }
                if (file.length() > 2000000) {
                    Toast.makeText(
                        context,
                        "Some files are larger than 2MB and will be removed",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    filtered.add(attachment)
                }
            } catch (e: IOException) {
                e.printStackTrace()
                Log.d("MessageUtils", "exception: " + e.message)
            } catch (e: URISyntaxException) {
                e.printStackTrace()
                Log.d("MessageUtils", "exception: " + e.message)
            }
        }
        intent.putParcelableArrayListExtra("uris",filtered)
        activityCallback?.invoke(intent)
    }


    private fun compressVideo(context: TelloActivity, message: TTMessage, prepareFileToast: Toast?) {
        chatManager!!.compressVideo(
            message,
            message.relativeFilePath,
            object : UiInformableCallback<TTMessage> {
                override fun success(`object`: TTMessage) {
                    hidePrepareFileToast(prepareFileToast, context)
                    sendMessage(message, context)
                }

                override fun error(errorCode: Int, `object`: TTMessage) {}
                override fun userInputRequired(pi: PendingIntent, `object`: TTMessage) {}
                override fun inform(text: String) {}
            })
    }

    private fun sendMessage(message: TTMessage, context: TelloActivity) {
        if (context is ConversationActivity) {
            context.sendAndSaveMessage(message)
        }
    }

    fun attachFileToMessage(attachmentChoice: Int, context: TelloActivity) {
        if (attachmentChoice == Config.ATTACHMENT_CHOICE_LOCATION) {
            if (!hasLocationPermission(context, attachmentChoice)) {
                return
            }
        } else if (attachmentChoice == Config.ATTACHMENT_CHOICE_TAKE_PHOTO) {
            if (!checkCameraPermission(context, attachmentChoice)) {
                return
            }
        }
        val intent = Intent()
        var fallbackPackageId: String? = null
        var chooser = false
        when (attachmentChoice) {
            Config.ATTACHMENT_CHOICE_CHOOSE_VIDEO -> {
                intent.setAction(Intent.ACTION_GET_CONTENT)
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                intent.setType("video/*")
                openGallery(attachmentChoice, context, 3)
                return
            }

            Config.ATTACHMENT_CHOICE_CHOOSE_AUDIO -> {
                intent.setAction(Intent.ACTION_GET_CONTENT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                intent.setType("audio/*")
                chooser = true
            }

            Config.ATTACHMENT_CHOICE_CHOOSE_FILE -> {
                chooser = true
                val mimeTypes = arrayOf(
                    "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  // .doc & .docx
                    "application/vnd.ms-powerpoint",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",  // .ppt & .pptx
                    "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  // .xls & .xlsx
                    "text/plain",
                    "application/pdf",
                    "application/zip"
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    intent.setType(if (mimeTypes.size == 1) mimeTypes[0] else "*/*")
                    if (mimeTypes.size > 0) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    }
                } else {
                    intent.setType("*/*")
                }
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                intent.setAction(Intent.ACTION_GET_CONTENT)
            }

            Config.ATTACHMENT_CHOICE_RECORD_VOICE -> {
                intent.setAction(MediaStore.Audio.Media.RECORD_SOUND_ACTION)
                fallbackPackageId = "com.tilismtech.tellotalk.voicerecorder"
            }

            Config.ATTACHMENT_CHOICE_LOCATION -> {
                try {
                    //   Intent intent1 = new Intent(context, PlacesActivity.class);
                    //   context.startActivityForResult(intent1, attachmentChoice);
                    //context.startActivityForResult(builder.build(context), attachmentChoice);
                } catch (e: Exception) {
                    Toast.makeText(
                        context,
                        "Sorry, could not get location.Try again",
                        Toast.LENGTH_LONG
                    ).show()
                    e.printStackTrace()
                }
                return
            }
        }
        if (intent.resolveActivity(context.packageManager) != null) {
            if (chooser) {
                context.startActivityForResult(
                    Intent.createChooser(
                        intent,
                        context.getString(R.string.perform_action_with)
                    ), attachmentChoice
                )
            } else {
                context.startActivityForResult(intent, attachmentChoice)
            }
        } else if (fallbackPackageId != null) {
            context.startActivity(getInstallApkIntent(fallbackPackageId, context))
        }
    }

    private fun getInstallApkIntent(packageId: String, context: Context): Intent {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setData(Uri.parse("market://details?id=$packageId"))
        return if (intent.resolveActivity(context.packageManager) != null) {
            intent
        } else {
            intent.setData(Uri.parse("http://play.google.com/store/apps/details?id=$packageId"))
            intent
        }
    }

    fun checkCameraPermission(context: TelloActivity, requestCode: Int): Boolean {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            val permissions = arrayOf(Manifest.permission.CAMERA)
            if (!EasyPermissions.hasPermissions(context, *permissions)) {
                EasyPermissions.requestPermissions(
                    context,
                    Html.fromHtml(context.getString(R.string.camera_storage_permission)).toString(),
                    requestCode,
                    *permissions
                )
                return false
            }
        } else {
            val permissions = arrayOf(Manifest.permission.CAMERA)
            if (!EasyPermissions.hasPermissions(context, *permissions)) {
                EasyPermissions.requestPermissions(
                    context,
                    Html.fromHtml(context.getString(R.string.camera_storage_permission)).toString(),
                    requestCode,
                    *permissions
                )
                return false
            }
        }
        return true
    }

    private fun hasLocationPermission(context: TelloActivity, requestCode: Int): Boolean {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (!EasyPermissions.hasPermissions(context, *permissions)) {
            EasyPermissions.requestPermissions(
                context,
                Html.fromHtml(context.getString(R.string.location_permission)).toString(),
                requestCode,
                *permissions
            )
            return false
        }
        return true
    }

    private fun getPermissionsMessage(requestCode: Int, selectedPermissions: Array<String?>): Int {
        var message = 0
        if (requestCode == ConversationActivity.REQUEST_RECORD_AUDIO) {
            if (selectedPermissions.size == 2) {
                message = R.string.record_storage_per
            } else if (selectedPermissions.size == 1 && selectedPermissions[0] == Manifest.permission.READ_EXTERNAL_STORAGE) {
                message = R.string.storage_per
            } else if (selectedPermissions.size == 1 && selectedPermissions[0] == Manifest.permission.RECORD_AUDIO) {
                message = R.string.record_per
            }
        } else if (requestCode == Config.ATTACHMENT_CHOICE_LOCATION) {
            message = R.string.location_per
        } else if (requestCode == Config.ATTACHMENT_CHOICE_CONTACT) {
            message = R.string.contact_per
        } else if (requestCode != Config.ATTACHMENT_CHOICE_TAKE_PHOTO) {
            message = R.string.storage_per
        } else {
            message = if (selectedPermissions.size == 3) {
                R.string.camera_storage_per
            } else if (selectedPermissions.size == 2) {
                R.string.storage_per
            } else {
                R.string.camera_storage_per
            }
        }
        return message
    }

    fun showPermissionRequestDialog(
        requestCode: Int,
        activity: TelloActivity,
        selectedPermissions: Array<String?>
    ) {
        val imageResources = ArrayList<Int?>()
        val message = getPermissionsMessage(requestCode, selectedPermissions)
        if (requestCode == ConversationActivity.REQUEST_RECORD_AUDIO) {
            if (selectedPermissions.size == 2) {
                imageResources.add(R.drawable.audio_recording_icon_sdk)
                imageResources.add(R.drawable.file_icon_sdk)
            } else if (selectedPermissions.size == 1 && selectedPermissions[0] == Manifest.permission.READ_EXTERNAL_STORAGE) {
                imageResources.add(R.drawable.file_icon_sdk)
            } else if (selectedPermissions.size == 1 && selectedPermissions[0] == Manifest.permission.RECORD_AUDIO) {
                imageResources.add(R.drawable.audio_recording_icon_sdk)
            }
        } else if (requestCode == Config.ATTACHMENT_CHOICE_LOCATION) {
            imageResources.add(R.drawable.location_permission_icon_sdk)
        } else if (requestCode == Config.ATTACHMENT_CHOICE_CONTACT) {
            imageResources.add(R.drawable.contacts_icon_sdk)
        } else if (requestCode != Config.ATTACHMENT_CHOICE_TAKE_PHOTO) {
            imageResources.add(R.drawable.file_icon_sdk)
        } else {
            if (selectedPermissions.size == 3) {
                imageResources.add(R.drawable.camera_permission_icon_sdk)
                imageResources.add(R.drawable.file_icon_sdk)
            } else if (selectedPermissions.size == 2) {
                imageResources.add(R.drawable.file_icon_sdk)
            } else {
                imageResources.add(R.drawable.camera_permission_icon_sdk)
            }
        }
        val manager = activity.supportFragmentManager
        val dialogFragment =
            PermissionDialogFragment(imageResources, message, true, object : BaseDialogListener {
                override fun onDialogPositiveClick(dialog: PermissionDialogFragment?) {
                    openPermissionsSettings(activity)
                }

                override fun onDialogNegativeClick(dialog: PermissionDialogFragment?) {
                    if (requestCode == Config.ATTACHMENT_CHOICE_TAKE_PHOTO) {
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    } else if (requestCode == ConversationActivity.REQUEST_RECORD_AUDIO) {
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    } else if (requestCode == Config.ATTACHMENT_CHOICE_CONTACT) {
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        dialogFragment.show(manager, "PermissionDialogFragment")
    }

    fun onPermissionsGranted(
        requestCode: Int,
        perms: List<String?>,
        activity: TelloActivity,
        mode: Int
    ) {
        if (requestCode == TelloActivity.REQUEST_SYNC_CONTACTS) {
//            ((ConversationActivity) activity).refreshContacts();
        }
        if (requestCode == Config.ATTACHMENT_CHOICE_LOCATION) {
            attachFileToMessage(Config.ATTACHMENT_CHOICE_LOCATION, activity)
        } else if (requestCode == Config.ATTACHMENT_CHOICE_TAKE_PHOTO) {
            if (perms.size == 3) {
                attachFileToMessage(Config.ATTACHMENT_CHOICE_TAKE_PHOTO, activity)
            }
        } else if (requestCode == Config.ATTACHMENT_CHOICE_CHOOSE_AUDIO || requestCode == Config.ATTACHMENT_CHOICE_CHOOSE_FILE || requestCode == Config.ATTACHMENT_CHOICE_CHOOSE_IMAGE) {
            attachFileToMessage(requestCode, activity)
        } else if (requestCode == ConversationActivity.REQUEST_START_DOWNLOAD) {
            if (mPendingDownloadableMessage != null) {
                startDownloadable(mPendingDownloadableMessage, mode, activity)
            }
        }
    }

    fun onPermissionsDenied(requestCode: Int, perms1: List<String?>?, activity: TelloActivity) {
        val perms: MutableList<String> = LinkedList(perms1)
        if (requestCode == TelloActivity.REQUEST_SYNC_CONTACTS) {
            Toast.makeText(activity, "Need to read contacts for syncing", Toast.LENGTH_SHORT).show()
        }
        if (requestCode == Config.ATTACHMENT_CHOICE_LOCATION) {
            if (EasyPermissions.somePermissionPermanentlyDenied(activity, perms)) {
                showPermissionRequestDialog(requestCode, activity, perms.toTypedArray<String?>())
            }
        } else if (requestCode == Config.ATTACHMENT_CHOICE_TAKE_PHOTO) {
            if (perms.size == 1 || perms.size == 2) {
                if (EasyPermissions.somePermissionPermanentlyDenied(activity, perms)) {
                    showPermissionRequestDialog(
                        requestCode,
                        activity,
                        perms.toTypedArray<String?>()
                    )
                }
            } else {
                if (perms.size == 3) {
                    if (!EasyPermissions.permissionPermanentlyDenied(activity, perms[0])) {
                        perms.removeAt(0)
                    }
                    if (!EasyPermissions.somePermissionPermanentlyDenied(activity, perms)) {
                        perms.clear()
                    }
                    if (!perms.isEmpty()) {
                        showPermissionRequestDialog(
                            requestCode,
                            activity,
                            perms.toTypedArray<String?>()
                        )
                    }
                }
            }
        } else if (requestCode == Config.ATTACHMENT_CHOICE_CHOOSE_AUDIO || requestCode == Config.ATTACHMENT_CHOICE_CHOOSE_FILE || requestCode == Config.ATTACHMENT_CHOICE_CHOOSE_IMAGE) {
            if (EasyPermissions.somePermissionPermanentlyDenied(activity, perms)) {
                showPermissionRequestDialog(requestCode, activity, perms.toTypedArray<String?>())
            }
        }
    }

    fun startDownloadable(message: TTMessage?, conversationMode: Int, activity: TelloActivity?) {
//        if (!Config.ONLY_INTERNAL_STORAGE && !hasStoragePermission(activity, REQUEST_START_DOWNLOAD)) {
//            this.mPendingDownloadableMessage = message;
//            return;
//        }
//        Transferable transferable = message.getTransferable();
//        if (transferable != null) {
//            if (!transferable.start()) {
//                Toast.makeText(activity, R.string.not_connected_try_again, Toast.LENGTH_SHORT).show();
//            }
//        } else if (message.treatAsDownloadable()) {
//            chatManager.getHttpConnectionManager(conversationMode).createNewDownloadConnection(message, true);
//        }
    }

    fun shareWith(message: TTMessage?, context: Context) {
        val shareIntent = Intent()
        shareIntent.setAction(Intent.ACTION_SEND)
        if (message == null) {
            return
        }
        if (GeoHelper.isGeoUri(message.message)) {
            shareIntent.putExtra(Intent.EXTRA_TEXT, message.message)
            shareIntent.setType("text/plain")
        } else if (!message.isFileOrImage) {
            shareIntent.putExtra(Intent.EXTRA_TEXT, message.message)
            shareIntent.setType("text/plain")
        } else {
            var file: DownloadableFile? = null
            CoroutineScope(Dispatchers.IO).launch {
                file = FileBackend.instance!!.getFile(message)
            }.invokeOnCompletion {
                try {
                    shareIntent.putExtra(Intent.EXTRA_STREAM, getUriForFile(context, file))
                } catch (e: SecurityException) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.no_permission_to_access_x, file?.absolutePath),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@invokeOnCompletion
                }
                shareIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                var mime = message.mimeType
                if (mime == null) {
                    mime = "*/*"
                }
                shareIntent.setType(mime)
            }
            try {
                context.startActivity(
                    Intent.createChooser(
                        shareIntent,
                        context.getText(R.string.share_with)
                    )
                )
            } catch (e: ActivityNotFoundException) {
                //This should happen only on faulty androids because normally chooser is always available
                Toast.makeText(
                    context,
                    R.string.no_application_found_to_open_file,
                    Toast.LENGTH_SHORT
                )
                    .show()
            }
        }
    }

    fun showDeleteMessageDialog(
        selectedMessage: HashMap<String?, TTMessage?>?,
        context: Context?,
        chatID: String?
    ) {
        val builder1 = AlertDialog.Builder(
            context!!
        )
        builder1.setMessage("Delete Message?")
        builder1.setCancelable(true)
        builder1.setPositiveButton("Delete") { dialog: DialogInterface, id: Int ->
            val message = arrayOfNulls<TTMessage>(selectedMessage?.size ?: 0)
            var i = 0
            for ((_, msg) in selectedMessage ?: hashMapOf()) {
                msg?.setEditedCustom(false)
                msg?.isDeleted = true
                msg?.msgType = TTMessage.MsgType.TYPE_DELETED.value
                message[i++] = msg
                ChatManager.instance!!.sendMessage(msg, true, chatID!!)
            }
            conversationActivityViewModel.updateMessage(*message)
            // messageRepository.deleteMessage(message);
            if (context is ConversationActivity) {
                val messageList = context.messageList
                context.setLastMessage(if (messageList?.isNotEmpty() == true) messageList[messageList.size - 1] else null)
            }
            if (context is ConversationActivity) {
                context.removeMultiSelect()
            }
            dialog.cancel()
        }
        var showUnsend = true
        for ((_, message) in selectedMessage ?: hashMapOf()) {
            if ((message?.msgStatus == TTMessage.MsgStatus.SENT || message?.msgStatus == TTMessage.MsgStatus.DELIVERED || message?.msgStatus == TTMessage.MsgStatus.READ) && context is ConversationActivity) {
            } else {
                showUnsend = false
            }
        }
        if (showUnsend) {
//            builder1.setNegativeButton("Unsend", (dialog, id) -> {
//                for (Map.Entry<String, TTMessage> entry : selectedMessage.entrySet()) {
//                    removeMessageFromBothEnd(entry.getValue(), context);
//                }
//                if (context instanceof ConversationActivity) {
//                    ((ConversationActivity) context).removeMultiSelect();
//                }
//                dialog.cancel();
//            });
            builder1.setNeutralButton("Cancel") { dialog: DialogInterface, id: Int -> dialog.cancel() }
        } else {
            builder1.setNegativeButton("Cancel") { dialog: DialogInterface, id: Int -> dialog.cancel() }
        }
        val alert11 = builder1.create()
        alert11.setOnShowListener { arg0: DialogInterface? ->
            alert11.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(
                ContextCompat.getColor(
                    context, R.color.colorPrimaryTello
                )
            )
            alert11.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(
                ContextCompat.getColor(
                    context, R.color.colorPrimaryTello
                )
            )
            alert11.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(
                ContextCompat.getColor(
                    context, R.color.colorPrimaryTello
                )
            )
        }
        alert11.show()
    }

    private fun hidePrepareFileToast(prepareFileToast: Toast?, activity: TelloActivity) {
        if (prepareFileToast != null) {
            activity.runOnUiThread { prepareFileToast.cancel() }
        }
    }


    fun selectText(message: TTMessage?, context: Context) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (message != null) {
            val clip = ClipData.newPlainText("Copied Message.", message.message)
            if (clipboard != null) {
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Copied Message.", Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        val myCalendar = Calendar.getInstance()
        private val formFilelistAdapterHashMap = HashMap<String, FormFilelistAdapter>()
        var hashMap = HashMap<String, ArrayList<String?>>()
        private var TempAdapter: FormFilelistAdapter? = null
        private var tempFormID = ""
        fun getPath(context: Context, uri: Uri?): String {
            var result: String? = null
            val proj = arrayOf(MediaStore.Images.Media.DATA)
            val cursor = context.contentResolver.query(uri!!, proj, null, null, null)
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    val column_index = cursor.getColumnIndexOrThrow(proj[0])
                    result = cursor.getString(column_index)
                }
                cursor.close()
            }
            if (result == null) {
                result = "Not found"
            }
            return result
        }

        @SuppressLint("NewApi")
        private fun extractUriFromIntent(intent: Intent?): List<Uri?> {
            val uris: MutableList<Uri?> = ArrayList()
            if (intent == null) {
                return uris
            }
            val uri = intent.data
            if ( uri == null) {
                val clipData = intent.clipData
                if (clipData != null) {
                    for (i in 0 until clipData.itemCount) {
                        uris.add(clipData.getItemAt(i).uri)
                    }
                }
            } else {
                uris.add(uri)
            }
            return uris
        }

        fun createDropDown(
            formFieldResponse: FormFieldResponse,
            context: Context?,
            layFormsData: LinearLayout
        ) {
            val spinner = AppCompatSpinner(
                context!!
            )
            val spinnerArrayAdapter =
                ChatFormDropDownAdapter(formFieldResponse.fieldOptionList, context)
            spinner.tag = formFieldResponse
            spinner.setSelection(0)
            spinner.adapter = spinnerArrayAdapter
            //  spinner.setBackgroundResource(R.drawable.spinner_background);
            spinner.onItemSelectedListener = object : OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View,
                    position: Int,
                    id: Long
                ) {
                    for (formFieldOptionResponse in formFieldResponse.fieldOptionList) {
                        formFieldOptionResponse.isOptionSelected =
                            formFieldResponse.fieldOptionList[position].fieldOptionId == formFieldOptionResponse.fieldOptionId
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }


            // spinner.setBackground(getDrawable(R.drawable.spinner_background));
            layFormsData.addView(spinner)
        }

        fun createSeperator(context: Context?, layFormsData: LinearLayout) {
            val viewDivider = View(context)
            val dividerHeight =
                ((context?.resources?.displayMetrics?.density ?: 0f) * 1).toInt() // 1dp to pixels
            val params =
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dividerHeight)
            viewDivider.layoutParams = params
            params.setMargins(0, 10, 0, 10)
            //     viewDivider.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            viewDivider.setBackgroundColor(Color.parseColor("#c3c3c3"))
            layFormsData.addView(viewDivider)
        }

        fun createButton(
            formFieldResponse: FormFieldResponse,
            context: Context,
            layFormsData: LinearLayout
        ) {
            val layoutInflater =
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val v = layoutInflater.inflate(R.layout.form_btn, null)
            val tv_noimage_placeholder = v.findViewById<TextView>(R.id.tv_noimage_placeholder)
            val tv_browseimg = v.findViewById<TextView>(R.id.tv_browseimg)
            val recyclerView = v.findViewById<RecyclerView>(R.id.rv_imglist)
            v.tag = formFieldResponse
            val formFilelistAdapter = FormFilelistAdapter(ArrayList())
            recyclerView.adapter = formFilelistAdapter
            formFilelistAdapterHashMap[formFieldResponse.fieldId] = formFilelistAdapter
            //
            tv_browseimg.tag = formFieldResponse
            //
            tv_browseimg.setOnClickListener(View.OnClickListener { v -> //   hasStoragePermission((TelloActivity) context,770);
                val permissions = arrayOf(
                    Manifest.permission.RECORD_AUDIO
                )
                if (!EasyPermissions.hasPermissions(context, *permissions)) {
                    val permissionText =
                        Html.fromHtml(context.getString(R.string.storage_permission)).toString()
                    EasyPermissions.requestPermissions(
                        (context as Activity),
                        permissionText,
                        ConversationActivity.REQUEST_RECORD_AUDIO,
                        *permissions
                    )
                    return@OnClickListener
                }
                val fieldResponse = v.tag as FormFieldResponse
                TempAdapter = formFilelistAdapterHashMap[fieldResponse.fieldId]
                tempFormID = formFieldResponse.fieldId
                selectImage(context as ConversationActivity, formFieldResponse)
            })
            layFormsData.addView(v)
        }

        private fun selectImage(
            context: ConversationActivity,
            formFieldResponse: FormFieldResponse
        ) {
            val options = arrayOf<CharSequence>("Take Photo", "Choose from Gallery", "Cancel")
            val builder = AlertDialog.Builder(context)
            builder.setTitle("Choose your profile picture")
            builder.setItems(options) { dialog: DialogInterface, item: Int ->
                if (options[item] == "Take Photo") {
                    val takePicture = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    context.startActivityForResult(takePicture, 2)
                } else if (options[item] == "Choose from Gallery") {
                    val intent = Intent()
                    intent.setType("image/*")
                    intent.setAction(Intent.ACTION_GET_CONTENT)
                    context.startActivityForResult(
                        Intent.createChooser(intent, "Select Picture"),
                        3
                    )
                } else if (options[item] == "Cancel") {
                    dialog.dismiss()
                }
            }
            builder.show()
        }

        fun createTextView(
            formFieldResponse: FormFieldResponse,
            context: Context,
            layFormsData: LinearLayout
        ) {
            val textView = TextView(context)
            val wordtoSpan: Spannable
            if (formFieldResponse.isRequired == "Y") {
                wordtoSpan = SpannableString(formFieldResponse.fieldLabel + " *")
                wordtoSpan.setSpan(
                    ForegroundColorSpan(Color.RED),
                    wordtoSpan.toString().length - 1,
                    wordtoSpan.toString().length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            } else {
                wordtoSpan = SpannableString(formFieldResponse.fieldLabel)
            }
            textView.text = wordtoSpan
            val face = ResourcesCompat.getFont(context!!, R.font.calibri)
            textView.typeface = face
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(30, 10, 10, 10)
            textView.setTextColor(Color.parseColor("#A9ACB6"))
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            textView.layoutParams = params
            layFormsData.addView(textView)
        }

        fun createFilesizeTextview(
            formFieldResponse: FormFieldResponse?,
            context: Context?,
            layFormsData: LinearLayout
        ) {
            val textView = TextView(context)
            var wordtoSpan: Spannable
            textView.text = "Maximum size 1 MB (.png .jpg. jpeg. gif)"
            val face = ResourcesCompat.getFont(context!!, R.font.calibri)
            textView.typeface = face
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(30, 10, 10, 10)
            textView.setTextColor(Color.parseColor("#A9ACB6"))
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            textView.layoutParams = params
            layFormsData.addView(textView)
        }

        fun createTimeEdittext(
            formFieldResponse: FormFieldResponse,
            context: Context,
            layFormsData: LinearLayout
        ) {
            val layoutInflater =
                context?.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val v = layoutInflater.inflate(R.layout.edt_time, null)
            val params = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(10, 20, 10, 20)
            // v.setPadding(30, 30, 20, 30);
            v.layoutParams = params
            val whatsAppEditText = v.findViewById<WhatsAppEditText>(R.id.edt_formdate)
            whatsAppEditText.hint = formFieldResponse.fieldLabel
            v.tag = formFieldResponse
            whatsAppEditText.isClickable = false
            whatsAppEditText.isCursorVisible = false
            whatsAppEditText.isFocusable = false
            whatsAppEditText.isFocusableInTouchMode = false
            val mcurrentTime = Calendar.getInstance()
            val hour = mcurrentTime[Calendar.HOUR_OF_DAY]
            val minute = mcurrentTime[Calendar.MINUTE]
            val mTimePicker: TimePickerDialog
            mTimePicker = TimePickerDialog(
                context,
                { timePicker, selectedHour, selectedMinute -> whatsAppEditText.setText("$selectedHour:$selectedMinute") },
                hour,
                minute,
                true
            ) //Yes 24 hour time
            mTimePicker.setTitle("Select Time")
            whatsAppEditText.setOnClickListener { mTimePicker.show() }
            layFormsData.addView(v)
        }

        fun createDateEdittext(
            formFieldResponse: FormFieldResponse,
            context: Context,
            layFormsData: LinearLayout
        ) {
            val layoutInflater =
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val v = layoutInflater.inflate(R.layout.edt_date, null)
            val params = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(10, 20, 10, 20)
            // v.setPadding(30, 30, 20, 30);
            v.layoutParams = params
            val edt_dat = v.findViewById<WhatsAppEditText>(R.id.edt_formdate)
            edt_dat.hint = formFieldResponse.fieldLabel
            v.tag = formFieldResponse
            edt_dat.isClickable = false
            edt_dat.isCursorVisible = false
            edt_dat.isFocusable = false
            edt_dat.isFocusableInTouchMode = false
            val date = OnDateSetListener { view, year, month, day ->
                myCalendar[Calendar.YEAR] = year
                myCalendar[Calendar.MONTH] = month
                myCalendar[Calendar.DAY_OF_MONTH] = day
                updateLabel(edt_dat)
            }
            edt_dat.setOnClickListener { view: View? ->
                DatePickerDialog(
                    context,
                    date,
                    myCalendar[Calendar.YEAR],
                    myCalendar[Calendar.MONTH],
                    myCalendar[Calendar.DAY_OF_MONTH]
                ).show()
            }
            layFormsData.addView(v)
        }

        fun createEditText(
            formFieldResponse: FormFieldResponse,
            context: Context,
            layFormsData: LinearLayout
        ) {
            val whatsAppEditText = WhatsAppEditText(context)
            whatsAppEditText.hint = formFieldResponse.fieldLabel
            val face = ResourcesCompat.getFont(context, R.font.calibri)
            whatsAppEditText.typeface = face
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(10, 10, 10, 20)
            whatsAppEditText.setPadding(30, 30, 20, 30)
            whatsAppEditText.tag = formFieldResponse
            val maxLength = formFieldResponse.fieldMaxValue.toInt()
            val filters = arrayOfNulls<InputFilter>(1)
            filters[0] = LengthFilter(maxLength)
            when (formFieldResponse.fieldType) {
                "ShortText" -> whatsAppEditText.filters = filters
                "LongText" -> {
                    if (formFieldResponse.fieldMaxValue.toInt() > 0) {
                        whatsAppEditText.filters = filters
                    }
                    whatsAppEditText.maxLines = 6
                    whatsAppEditText.setLines(6)
                    whatsAppEditText.gravity = Gravity.TOP or Gravity.START
                }

                "Numeric" -> whatsAppEditText.inputType = InputType.TYPE_CLASS_NUMBER
            }
            whatsAppEditText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            whatsAppEditText.setTextColor(Color.parseColor("#000000"))
            whatsAppEditText.background = context.getDrawable(R.drawable.chat_form_sheet)
            whatsAppEditText.layoutParams = params
            layFormsData.addView(whatsAppEditText)
        }

        fun updateLabel(whatsAppEditText: WhatsAppEditText) {
            val myFormat = "MM/dd/yy"
            val dateFormat = SimpleDateFormat(myFormat, Locale.US)
            whatsAppEditText.setText(dateFormat.format(myCalendar.time))
        }

        fun createCheckBox(
            formFieldResponse: FormFieldResponse,
            context: Context,
            layFormsData: LinearLayout
        ) {
            for (formFieldOptionResponse in formFieldResponse.fieldOptionList) {
                val layoutInflater =
                    context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
                val v = layoutInflater.inflate(R.layout.custom_checkbox, null)
                val cb = v.findViewById<CheckBox>(R.id.cb_options)
                v.tag = formFieldResponse
                cb.setOnCheckedChangeListener { buttonView, isChecked ->
                    formFieldOptionResponse.isOptionSelected = isChecked
                }
                cb.text = formFieldOptionResponse.fieldOptionValue
                layFormsData.addView(v)
            }
        }

        fun createRadioButton(
            formFieldResponse: FormFieldResponse,
            context: Context?,
            layFormsData: LinearLayout
        ) {
            val rg = RadioGroup(context) //create the RadioGroup
            rg.orientation = RadioGroup.VERTICAL //or RadioGroup.VERTICAL
            val face = ResourcesCompat.getFont(context!!, R.font.calibri)
            rg.tag = formFieldResponse
            for (formFieldOptionResponse in formFieldResponse.fieldOptionList) {
                val rb = RadioButton(context)
                rb.typeface = face
                rb.text = formFieldOptionResponse.fieldOptionValue
                rg.addView(rb)
                val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                val colors = intArrayOf(Color.parseColor("#0BB18D"), Color.parseColor("#E7ECF0"))
                CompoundButtonCompat.setButtonTintList(rb, ColorStateList(states, colors))
                rb.setOnCheckedChangeListener { buttonView, isChecked ->
                    formFieldOptionResponse.isOptionSelected = isChecked
                }
            }
            layFormsData.addView(rg)
            //you add the whole RadioGroup to the layout
        }

        fun isValidEmail(target: CharSequence?): Boolean {
            return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }
}