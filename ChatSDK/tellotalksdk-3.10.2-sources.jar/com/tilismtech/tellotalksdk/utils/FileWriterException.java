package com.tilismtech.tellotalksdk.utils;

/**
 * Created by AbdulMomen on 2/12/18.
 */

public class FileWriterException extends Exception {
}
