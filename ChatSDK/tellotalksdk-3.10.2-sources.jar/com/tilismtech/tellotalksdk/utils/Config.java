package com.tilismtech.tellotalksdk.utils;

import android.graphics.Bitmap;

public final class Config {

    public static final int ATTACHMENT_CHOICE_CHOOSE_IMAGE = 0x0301;  // 769
    public static final int ATTACHMENT_CHOICE_CHOOSE_VIDEO = 0x0307;  // 775
    public static final int ATTACHMENT_CHOICE_CHOOSE_AUDIO = 0x0308;  // 776
    public static final int ATTACHMENT_CHOICE_TAKE_PHOTO = 0x0302;    //770
    public static final int ATTACHMENT_CHOICE_RECORD_VIDEO = 0x0313;    //770
    public static final int ATTACHMENT_CHOICE_CHOOSE_FILE = 0x0303;   // 771
    public static final int ATTACHMENT_CHOICE_RECORD_VOICE = 0x0304;  // 772
    public static final int ATTACHMENT_CHOICE_LOCATION = 0x0305;    // 773
    public static final int ATTACHMENT_CHOICE_CONTACT = 0x0310;     //775
    public static final int ATTACHMENT_CONFIRMATION = 0x0311;     //776
    public static final int ATTACHMENT_CHOICE_GIF = 0x0312;     //776

    public static final String LOGTAG = "TelloTalk";
    public static final int IMAGE_SIZE = 1032;

    public static final Bitmap.CompressFormat IMAGE_FORMAT = Bitmap.CompressFormat.JPEG;
    public static final int IMAGE_QUALITY = 75;
    public static final int IMAGE_MAX_SIZE = 524288; //512KiB

    public static final boolean REPORT_WRONG_FILESIZE_IN_OTR_JINGLE = true;

    public static final boolean ONLY_INTERNAL_STORAGE = false; //use internal storage instead of sdcard to save attachments

    public static final int TYPING_TIMEOUT = 1;
    public static final int SOCKET_TIMEOUT = 30;

    private Config() {
    }
}
