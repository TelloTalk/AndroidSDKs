package com.tilismtech.tellotalksdk.utils;

import android.content.Intent;
import android.net.Uri;

import com.tilismtech.tellotalksdk.data.db.entities.TTMessage;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GeoHelper {
    private static Pattern GEO_URI = Pattern.compile("geo:([\\-0-9.]+),([\\-0-9.]+)(?:,([\\-0-9.]+))?(?:\\?(.*))?", Pattern.CASE_INSENSITIVE);

    public static boolean isGeoUri(String body) {
        return body != null && GEO_URI.matcher(body).matches();
    }

    public static ArrayList<Intent> createGeoIntentsFromMessage(TTMessage message, String label) {
        final ArrayList<Intent> intents = new ArrayList<>();
        Matcher matcher = GEO_URI.matcher(message.getMessage());
        if (!matcher.matches()) {
            return intents;
        }
        double latitude;
        double longitude;
        try {
            latitude = Double.parseDouble(matcher.group(1));
            if (latitude > 90.0 || latitude < -90.0) {
                return intents;
            }
            longitude = Double.parseDouble(matcher.group(2));
            if (longitude > 180.0 || longitude < -180.0) {
                return intents;
            }
        } catch (NumberFormatException nfe) {
            return intents;
        }
        try {
            label = "(" + URLEncoder.encode(label, "UTF-8") + ")";
        } catch (UnsupportedEncodingException e) {
            label = "";
        }
        Intent locationPluginIntent = new Intent("com.tilismtech.tellotalk.location.show");
        locationPluginIntent.putExtra("latitude", latitude);
        locationPluginIntent.putExtra("longitude", longitude);
        intents.add(locationPluginIntent);

        Intent geoIntent = new Intent(Intent.ACTION_VIEW);
        geoIntent.setData(Uri.parse("geo:" + String.valueOf(latitude) + "," + String.valueOf(longitude) + "?q=" + String.valueOf(latitude) + "," + String.valueOf(longitude) + label));
        intents.add(geoIntent);

        Intent httpIntent = new Intent(Intent.ACTION_VIEW);
        httpIntent.setData(Uri.parse("https://maps.google.com/maps?q=loc:" + String.valueOf(latitude) + "," + String.valueOf(longitude) + label));
        intents.add(httpIntent);
        return intents;
    }
}