package com.tilismtech.tellotalksdk.utils

import android.content.Context
import android.text.format.DateUtils
import androidx.core.util.Pair
import com.tilismtech.tellotalksdk.R
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.repository.ContactRepository
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.managers.TelloApiClient.Companion.getInstance
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isAppEnglish
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Created by sohail on 2/8/18.
 */
object UIHelper {
    private val PUNCTIONATION: List<Char> = mutableListOf('.', ',', '?', '!', ';', ':')
    private const val SHORT_DATE_FLAGS = (DateUtils.FORMAT_SHOW_DATE
            or DateUtils.FORMAT_NO_YEAR or DateUtils.FORMAT_ABBREV_ALL)
    private const val FULL_DATE_FLAGS = (DateUtils.FORMAT_SHOW_TIME
            or DateUtils.FORMAT_ABBREV_ALL or DateUtils.FORMAT_SHOW_DATE)

    fun readableTimeDifference(context: Context, time: Long): String {
        return readableTimeDifference(context, time, false)
    }

    @JvmStatic
    fun readableTimeDifferenceFull(context: Context?, time: Long): String {
        return readableTimeDifference(context, time, true)
    }

    private fun readableTimeDifference(
        context: Context?, time: Long,
        fullDate: Boolean
    ): String {
        try {
            if (time == 0L) {
                return context?.getString(R.string.just_now)?:""
            }
            val date = Date(time)
            val difference = (System.currentTimeMillis() - time) / 1000
            if (difference < 60) {
                return context?.getString(R.string.just_now)?:""
            } else if (difference < 60 * 2) {
                return context?.getString(R.string.minute_ago)?:""
            } else if (difference < 60 * 15) {
                return context?.getString(R.string.minutes_ago, Math.round(difference / 60.0))?:""
            } else if (today(date)) {
                //     java.text.DateFormat df = DateFormat.getTimeFormat(context);
                //     return df.format(date);
                return DateUtils.getRelativeTimeSpanString(
                    date.time,
                    Calendar.getInstance().timeInMillis,
                    DateUtils.MINUTE_IN_MILLIS
                ).toString()
            } else {
                if (fullDate) {
                    if (Locale.getDefault().displayLanguage == "اردو") {
                        var s: String
                        try {
                            val split =
                                DateUtils.formatDateTime(context, date.time, FULL_DATE_FLAGS)
                                    .split(" ".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            s = if (split.size > 3) {
                                split[0] + " " + split[1] + " " + split[3] + " " + split[2]
                            } else {
                                split[0] + " " + split[1] + " " + split[2]
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            s = ""
                        }
                        return s
                    } else {
                        return DateUtils.formatDateTime(
                            context, date.time,
                            FULL_DATE_FLAGS
                        )
                    }
                } else {
                    return DateUtils.formatDateTime(
                        context, date.time,
                        SHORT_DATE_FLAGS
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return ""
        }
    }

    fun exactReadableTimeDifferenceFull(context: Context, time: Long): String {
        if (time == 0L) {
            return context.getString(R.string.just_now)
        }
        val date = Date(time)
        val sdf = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        return sdf.format(date.time)
    }

    private fun today(date: Date): Boolean {
        return sameDay(date, Date(System.currentTimeMillis()))
    }

    private fun sameDay(a: Date, b: Date): Boolean {
        val cal1 = Calendar.getInstance()
        val cal2 = Calendar.getInstance()
        cal1.time = a
        cal2.time = b
        return cal1[Calendar.YEAR] == cal2[Calendar.YEAR] && cal1[Calendar.DAY_OF_YEAR] == cal2[Calendar.DAY_OF_YEAR]
    }

    fun getFileDescriptionString(context: Context, message: TTMessage): String? {
        try {
            if (message.msgType == TTMessage.MsgType.TYPE_IMAGE.value) {
                return if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.image)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.image_received_msg)
                    }
                }
            }
            if (message.msgType == TTMessage.MsgType.TYPE_TEXT.value) {
                return if (message.isDeleted) {
                    context.getString(R.string.this_message_was_deleted)
                } else {
                    message.message
                }
            }
            if (message.msgType == TTMessage.MsgType.TYPE_CHATEND.value) {
                return message.message
            }
            val mime = message.mimeType
            return if (mime == null) {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.file)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.file_received_msg)
                    }
                }
            } else if (mime.startsWith("audio/")) {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.audio)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.audio_received_msg)
                    }
                }
            } else if (mime.startsWith("video/")) {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.video)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.video_received_msg)
                    }
                }
            } else if (mime.startsWith("image/")) {
                if (message.msgType == TTMessage.MsgType.TYPE_VIDEO.value) {
                    if (isAppEnglish) {
                        if (message.isDeleted) {
                            context.getString(R.string.delete_message)
                        } else {
                            context.getString(R.string.video)
                        }
                    } else {
                        if (message.isDeleted) {
                            context.getString(R.string.this_message_was_deleted)
                        } else {
                            context.getString(R.string.video_received_msg)
                        }
                    }
                } else {
                    if (isAppEnglish) {
                        if (message.isDeleted) {
                            context.getString(R.string.delete_message)
                        } else {
                            context.getString(R.string.image)
                        }
                    } else {
                        if (message.isDeleted) {
                            context.getString(R.string.this_message_was_deleted)
                        } else {
                            context.getString(R.string.image_received_msg)
                        }
                    }
                }
            } else if (mime.contains("pdf")) {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.pdf_document)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.file_received_msg)
                    }
                }
            } else if (mime.contains("application/vnd.android.package-archive")) {
                if (message.isDeleted) {
                    context.getString(R.string.delete_message)
                } else {
                    context.getString(R.string.apk)
                }
            } else if (mime.contains("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.excel_document)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.file_received_msg)
                    }
                }
            } else if (mime.contains("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        context.getString(R.string.Word_document)
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.file_received_msg)
                    }
                }
            } else if (mime.contains("vcard")) {
                context.getString(R.string.vcard)
            } else {
                if (isAppEnglish) {
                    if (message.isDeleted) {
                        context.getString(R.string.delete_message)
                    } else {
                        mime
                    }
                } else {
                    if (message.isDeleted) {
                        context.getString(R.string.this_message_was_deleted)
                    } else {
                        context.getString(R.string.file_received_msg)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return ""
        }
    }

    fun getMessagePreview(context: Context, message: TTMessage): Pair<String?, Boolean> {
        val d = message.transferable
        if (message.msgType == TTMessage.MsgType.TYPE_VIDEO.value || message.msgType == TTMessage.MsgType.TYPE_FILE.value || message.msgType == TTMessage.MsgType.TYPE_IMAGE.value || message.msgType == TTMessage.MsgType.TYPE_AUDIO.value) {
            return if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                Pair(
                    context.getString(
                        R.string.received_x_file,
                        getFileDescriptionString(context, message)
                    ), true
                )
            } else {
                Pair(
                    getFileDescriptionString(
                        context,
                        message
                    ), true
                )
            }
        } else if (message.msgType == TTMessage.MsgType.TYPE_CONTACT.value) {
            var body = message.caption
            if (isEmptyString(body)) {
                body = ""
            }
            return Pair(body, true)
        } else {
            val body = message.message
            if (GeoHelper.isGeoUri(message.message)) {
                return if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
                    Pair(
                        context.getString(R.string.received_location),
                        true
                    )
                } else {
                    Pair(
                        context.getString(R.string.location),
                        true
                    )
                }
            } else if (message.treatAsDownloadable() && message.msgType !== TTMessage.MsgType.TYPE_TEXT.value) {
                return Pair(
                    context.getString(
                        R.string.x_file_offered_for_download,
                        getFileDescriptionString(context, message)
                    ), true
                )
            } else {
                val lines =
                    body!!.split("\n".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                val builder = StringBuilder()
                for (l in lines) {
                    if (l.length > 0) {
                        val first = l[0]
                        if ((first != '>' || !isPositionFollowedByQuoteableCharacter(
                                l,
                                0
                            )) && first != '\u00bb'
                        ) {
                            val line = l.trim { it <= ' ' }
                            if (line.isEmpty()) {
                                continue
                            }
                            val last = line[line.length - 1]
                            if (builder.length != 0) {
                                builder.append(' ')
                            }
                            builder.append(line)
                            if (!PUNCTIONATION.contains(last)) {
                                break
                            }
                        }
                    }
                }
                if (builder.length == 0) {
                    builder.append(body.trim { it <= ' ' })
                }
                return Pair(
                    if (builder.length > 256) builder.substring(
                        0,
                        256
                    ) else builder.toString(), false
                )
            }
        }
    }

    private fun isPositionFollowedByQuoteableCharacter(body: CharSequence, pos: Int): Boolean {
        return !isPositionFollowedByNumber(body, pos)
                && !isPositionFollowedByEmoticon(body, pos)
                && !isPositionFollowedByEquals(body, pos)
    }

    private fun isPositionFollowedByNumber(body: CharSequence, pos: Int): Boolean {
        var previousWasNumber = false
        for (i in pos + 1 until body.length) {
            val c = body[i]
            previousWasNumber = if (Character.isDigit(body[i])) {
                true
            } else if (previousWasNumber && (c == '.' || c == ',')) {
                false
            } else {
                return (Character.isWhitespace(c) || c == '%' || c == '+') && previousWasNumber
            }
        }
        return previousWasNumber
    }

    private fun isPositionFollowedByEquals(body: CharSequence, pos: Int): Boolean {
        return body.length > pos + 1 && body[pos + 1] == '='
    }

    private fun isPositionFollowedByEmoticon(body: CharSequence, pos: Int): Boolean {
        if (body.length <= pos + 1) {
            return false
        } else {
            val first = body[pos + 1]
            return first == ';' || first == ':' || smallerThanBeforeWhitespace(body, pos + 1)
        }
    }

    private fun smallerThanBeforeWhitespace(body: CharSequence, pos: Int): Boolean {
        for (i in pos until body.length) {
            val c = body[i]
            if (Character.isWhitespace(c)) {
                return false
            } else if (c == '<') {
                return body.length == i + 1 || Character.isWhitespace(body[i + 1])
            }
        }
        return false
    }

    fun getMessageHint(context: Context, conversation: TTConversation): String {
        return context.getString(R.string.send_message_to_x, conversation.conversationName)
    }


    fun getMessageDisplayName(message: TTMessage, ttConversation: TTConversation?): String {
        if (message.msgStatus == TTMessage.MsgStatus.RECEIVED) {
            val contact =
                ContactRepository.getInstance().getContactFromJid(ttConversation?.contactJid)
            return if (contact != null) contact.name else ttConversation?.conversationName?:""
        } else {
            return if (TelloApiClient.getInstance()!!.getAccount() != null) TelloApiClient.getInstance()!!.getAccount()!!
                .displayName else ""
        }
    }

    fun lastseen(context: Context, active: Boolean, time: Long): String {
        val difference = (System.currentTimeMillis() - time) / 1000
        return if (active) {
            context.getString(R.string.online_right_now)
        } else if (difference < 60) {
            context.getString(R.string.last_seen_now)
        } else if (difference < 60 * 2) {
            context.getString(R.string.last_seen_min)
        } else if (difference < 60 * 60) {
            context.getString(
                R.string.last_seen_mins,
                Math.round(difference / 60.0)
            )
        } else if (difference < 60 * 60 * 2) {
            context.getString(R.string.last_seen_hour)
        } else if (difference < 60 * 60 * 24) {
            context.getString(
                R.string.last_seen_hours,
                Math.round(difference / (60.0 * 60.0))
            )
        } else if (difference < 60 * 60 * 48) {
            context.getString(R.string.last_seen_day)
        } else {
            context.getString(
                R.string.last_seen_days,
                Math.round(difference / (60.0 * 60.0 * 24.0))
            )
        }
    }

    fun getLastSeen(difference: Long): String {
        val context: Context = getInstance()!!.telloContext
        return if (difference < 60) {
            context.getString(R.string.last_seen_now)
        } else if (difference < 60 * 2) {
            context.getString(R.string.last_seen_min)
        } else if (difference < 60 * 60) {
            context.getString(
                R.string.last_seen_mins,
                Math.round(difference / 60.0)
            )
        } else if (difference < 60 * 60 * 2) {
            context.getString(R.string.last_seen_hour)
        } else if (difference < 60 * 60 * 24) {
            context.getString(
                R.string.last_seen_hours,
                Math.round(difference / (60.0 * 60.0))
            )
        } else if (difference < 60 * 60 * 48) {
            context.getString(R.string.last_seen_day)
        } else {
            context.getString(
                R.string.last_seen_days,
                Math.round(difference / (60.0 * 60.0 * 24.0))
            )
        }
    } //    public static void applyFilters(int position, ImageView imageView, Bitmap bitmap, Context context) {
    //        imageView.setImageBitmap(null);
    //        Filter myFilter;
    //        myFilter = new Filter();
    //        if (bitmap != null) {
    //            imageView.setImageBitmap(bitmap.copy(Bitmap.Config.ARGB_8888, true));
    //        }
    //        switch (position) {
    //            case 0:
    //                myFilter.addSubFilter(new SaturationSubfilter(2.3f));
    //                break;
    //            case 1:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.7f, 0.0f, 1.0f));
    //                break;
    //            case 2:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.2f, 0.2f, 0.0f));
    //                break;
    //            case 3:
    //                myFilter.addSubFilter(new ContrastSubfilter(1.2f));
    //                break;
    //            case 4:
    //                myFilter.addSubFilter(new BrightnessSubfilter(30));
    //                break;
    //            case 5:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.0f, 0.4f, 1.0f));
    //                break;
    //            case 6:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.5f, 0.5f, 0.5f));
    //                break;
    //            case 7:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.1f, 1.0f, 0.8f));
    //                break;
    //            case 8:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.3f, 0.5f, 0.0f));
    //                break;
    //            case 9:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.8f, 0.0f, 0.5f));
    //                break;
    //            case 10:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 1.0f, 0.5f, 0.0f));
    //                break;
    //            case 11:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.0f, 0.0f, 1.0f));
    //                break;
    //            case 12:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 1.0f, 0.5f, 0.0f));
    //                break;
    //            case 13:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.3f, 0.0f, 0.8f));
    //                break;
    //            case 14:
    //                myFilter.addSubFilter(new VignetteSubfilter(context, 200));
    //                break;
    //            case 15:
    //                myFilter.addSubFilter(new ToneCurveSubfilter(new Point[]{new Point(0.0f, 0.0f), new Point(100.0f, 159.0f), new Point(255.0f, 255.0f)}, null, null, null));
    //                break;
    //            case 16:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.8f, 0.0f, 0.0f));
    //                break;
    //            case 17:
    //                myFilter.addSubFilter(new ColorOverlaySubfilter(100, 0.0f, 0.6f, 0.0f));
    //                break;
    //            case 18:
    //                myFilter.addSubFilter(new ToneCurveSubfilter(new Point[]{new Point(0.0f, 0.0f), new Point(100.0f, 200.0f), new Point(255.0f, 255.0f)}, null, null, null));
    //                break;
    //            case 19:
    //                myFilter.addSubFilter(new SaturationSubfilter(4.3f));
    //                break;
    //            default:
    //        }
    //        if (bitmap != null) {
    //            imageView.setImageBitmap(myFilter.processFilter(bitmap.copy(Bitmap.Config.ARGB_8888, true)));
    //        }
    //   }
}