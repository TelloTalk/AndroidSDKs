package com.tilismtech.tellotalksdk.utils;

import android.os.Environment;

import com.tilismtech.tellotalksdk.managers.TelloApiClient;

import java.io.File;

/**
 * Created by Sohail on 1/18/18.
 */

public class TelloConfig {
    public static final int REFRESH_LAST_TIME = 60000;

    public static final String DATABASE_NAME = "TelloTalkSdkDb";

    public static String folderName = "TelloCastSDK";
    public static String TELLO_ROOT = TelloApiClient.getInstance().telloContext.getExternalFilesDir(null) + File.separator;
    public static String TELLO_IMAGE_DIRECTORY = TelloApiClient.getInstance().telloContext.getExternalFilesDir(Environment.DIRECTORY_DCIM) + File.separator + folderName +
            "" + File.separator;
    public static String TELLO_AUDIO_DIRECTORY = TelloApiClient.getInstance().telloContext.getExternalFilesDir(Environment.DIRECTORY_MUSIC) + File.separator + folderName + File.separator;
    public static String TELLO_VIDEO_DIRECTORY = TelloApiClient.getInstance().telloContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES) + File.separator + folderName + File.separator;
    public static String TELLO_FILE_DIRECTORY = TelloApiClient.getInstance().telloContext.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) + File.separator + folderName + File.separator;
    public static String TELLO_PROFILE_DIRECTORY = TelloApiClient.getInstance().telloContext.getExternalFilesDir(Environment.DIRECTORY_PICTURES) + File.separator + folderName + File.separator;
    public static String TELLO_ANIMATED_DIRECTORY = TelloApiClient.getInstance().telloContext.getExternalFilesDir(null) + File.separator + folderName + File.separator;

}
