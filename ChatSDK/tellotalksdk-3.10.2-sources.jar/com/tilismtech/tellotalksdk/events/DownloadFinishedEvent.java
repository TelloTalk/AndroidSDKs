package com.tilismtech.tellotalksdk.events;


import com.tilismtech.tellotalksdk.data.db.entities.TTMessage;

/**
 */

public class DownloadFinishedEvent {
    public TTMessage message ;
    public DownloadFinishedEvent(TTMessage message) {
        this.message = message;
    }
}
