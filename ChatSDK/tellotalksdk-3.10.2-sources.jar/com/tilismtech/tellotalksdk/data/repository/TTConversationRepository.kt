package com.tilismtech.tellotalksdk.data.repository

import androidx.lifecycle.LiveData
import com.tilismtech.tellotalksdk.data.db.DaoManager
import com.tilismtech.tellotalksdk.data.db.dao.TTConversationDao
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TTConversationRepository {
    private val cacheConversations: HashMap<String, TTConversation> = HashMap()
    private val conversationDao: TTConversationDao = DaoManager.instance!!.tTConversationDao
    private val ttConversation: TTConversation? = null

    fun getConversationForJid(jid: String?): TTConversation? {
        var conversation = getConversationFromMap(jid)
        if (conversation == null) {
            conversation = conversationDao.getConversation(jid)
        }
        return conversation
    }

    private fun getConversationFromMap(jid: String?): TTConversation? {
        return cacheConversations[jid]
    }

    fun updateConversation(conversation: TTConversation?) {
        CoroutineScope(Dispatchers.IO).launch {
            conversationDao.updateConversation(conversation)
            addConversationInMap(conversation)
        }
    }

    private fun addConversationInMap(conversation: TTConversation?) {
        val conversation1 = cacheConversations[conversation?.contactJid]
        if (conversation1 != null) {
            conversation1.lastMessage = conversation?.lastMessage
            conversation1.lastMessageId = conversation?.lastMessageId
            conversation1.unreadCount = conversation?.unreadCount?:0
        }
        cacheConversations.getOrDefault(conversation?.contactJid!!,TTConversation())
    }

    private fun removeConversationFromMap(conversation: TTConversation) {
        cacheConversations.remove(conversation.contactJid)
    }

    val conversationsList: LiveData<List<TTConversation>>
        get() = conversationDao.getAllConversationList(false)
    val allConversations: List<TTConversation>
        get() = conversationDao.allConversations

    fun insertConversation(conversation: TTConversation): Long {
        val id = conversationDao.insertConversation(conversation)
        addConversationInMap(conversation)
        return id
    }

    //
    fun deleteConversation(conversation: TTConversation) {
        conversationDao.deleteConversation(conversation)
        removeConversationFromMap(conversation)
    }

    fun getFilteredConversationList(query: String?): LiveData<List<TTConversation>> {
        return conversationDao.getFilteredConversationList(query)
    }

    val conversationUnreadCount: Int
        get() = conversationDao.conversationUnreadCount

    companion object {
        @JvmStatic
        private var instance: TTConversationRepository? = null
        @JvmStatic
        fun getInstance():TTConversationRepository{
            if (instance == null) {
                instance = TTConversationRepository()
            }
            return instance!!
        }
    }
}
