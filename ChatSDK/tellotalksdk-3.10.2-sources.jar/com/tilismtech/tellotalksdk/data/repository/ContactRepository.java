package com.tilismtech.tellotalksdk.data.repository;

import androidx.lifecycle.LiveData;

import com.tilismtech.tellotalksdk.data.db.entities.Contact;
import com.tilismtech.tellotalksdk.data.db.dao.ContactDao;
import com.tilismtech.tellotalksdk.data.db.DaoManager;

import java.util.List;

/**
 * Created by lpt-034 on 14/01/2019.
 */

public class ContactRepository {

    private static ContactRepository instance;
    private ContactDao contactDao;
    public static ContactRepository getInstance() {
        if (instance == null){
            instance =  new ContactRepository();
        }
        return instance;
    }

    private ContactRepository(){
        this.contactDao = DaoManager.getInstance().getContactDao();
    }

    public void insertContact(Contact contact) {
        contactDao.insertContact(contact);
    }

    public void insertContacts(List<Contact> contacts) {
        contactDao.insertContacts(contacts);
    }

    public Contact getContact() {
        return contactDao.getContact();
    }

    public void clearTable() {
        contactDao.clearTable();
    }

    public void clearTableForCorporate() {
        contactDao.clearTableForCorporate();
    }

    public Contact getContactFromJid(String contactJid) {
        return contactDao.getContactFromJid(contactJid);
    }

    public LiveData<List<Contact>> getAllTelloContactList(){
        return contactDao.getAllTelloContacts();
    }

    public Contact[] getAllCorporateContacts(){
        return contactDao.getAllCorporateContacts();
    }

    public LiveData<List<Contact>> getAllFilteredTelloContacts(String query) {
        return contactDao.getAllFilteredTelloContacts(query);
    }

    public LiveData<List<Contact>> getAllContactsForConversation(String id){
        return contactDao.getAllFilteredTelloContacts(id);
    }

    public void clearCustomContacts() {
        contactDao.clearTableForCustomContacts();
    }
}
