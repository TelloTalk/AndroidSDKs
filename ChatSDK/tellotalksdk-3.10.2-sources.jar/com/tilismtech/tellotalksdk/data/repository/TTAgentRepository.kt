package com.tilismtech.tellotalksdk.data.repository

import com.tilismtech.tellotalksdk.data.db.entities.AgentModel
import com.tilismtech.tellotalksdk.data.db.dao.TTAgentDao
import com.tilismtech.tellotalksdk.data.db.DaoManager

class TTAgentRepository {

    private var ttAgentDao: TTAgentDao? = null

    companion object {
        private var instance: TTAgentRepository? = null

        fun getInstance(): TTAgentRepository? {
            if (instance == null) {
                instance = TTAgentRepository()
            }
            return instance
        }

    }
    init {
        ttAgentDao = DaoManager.instance?.agentDao
    }

    fun insertAgent(agentModel: AgentModel) {
        ttAgentDao?.insertAgent(agentModel)
    }

    fun  getAgent(agentid: String?) : AgentModel? {
      return  ttAgentDao?.getAgentFromDB(agentid?:"")
    }


}