package com.tilismtech.tellotalksdk.data.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tilismtech.tellotalksdk.data.db.DaoManager
import com.tilismtech.tellotalksdk.data.db.dao.TTMessageDao
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage.MsgType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Created by lpt-034 on 14/01/2019.
 */
class TTMessageRepository private constructor() {
    val apiMessageLiveData = MutableLiveData<List<TTMessage>>()
    private val messageDao: TTMessageDao = DaoManager.instance!!.tTMessageDao
    private val apiMessages = arrayListOf<TTMessage>()

    fun insertMessage(vararg message: TTMessage) {
        messageDao.insertMessage(*message)
        Log.e("INSERT","in insertMessage")
        checkAndAddDateMessage(*message)
    }

    fun updateMessageStatus(uuid: String?, msgStatus: Int) {
        messageDao.updateMessageStatus(uuid, msgStatus)
        Log.e("UPDATE","in updateMessageStatus")
    }

    fun deleteMessage(messages: TTMessage?) {
        messageDao.deleteMessage(messages)
    }

    fun deleteTypingMessages() {
        messageDao.deleteTypingMessages(MsgType.TYPE_TYPING.ordinal)
    }

    fun updateMessage(vararg messages: TTMessage?) {
        messageDao.updateMessage(*messages)
        Log.e("UPDATE","in updateMessage")
        checkAndAddDateMessage(*messages)
    }

    fun deletePrevMessages(chatId: String?) {
//        apiMessages.removeIf { it.chatId!=chatId }
//        Log.e("POSTED","deletePrevMessages")
//        apiMessageLiveData.postValue(apiMessages)
        messageDao.deleteAllMessageForPreviousConvoa(chatId)
    }

    fun deleteOtherUserMsg(uuid: String?) {
        messageDao.deleteOtherUserMsg(uuid)
    }

    fun updateMessageFileTag(uuid: String?, fileTag: String?) {
        messageDao.updateMessageFileTag(uuid, fileTag)
    }




    fun getAllConversationMessages(conversationId: String?,offset:Int): LiveData<List<TTMessage>> {
        return messageDao.getAllConversationMessages(conversationId)
    }
    fun getAllMessagesByProfileId(conversationId: String?,offset:Int): List<TTMessage> {
        return messageDao.getAllMessagesByProfileId(conversationId)
    }

    fun getAllOneWayMessages(conversationId: String?): LiveData<List<TTMessage>> {
        return messageDao.getAllOneWayMessages(conversationId)
    }

    fun getAllConversationMessagess(conversationId: String?): List<TTMessage> {
        return messageDao.getAllConversationMessagess(conversationId)
    }

    fun getAllUnsendMsg(conversationId: String?): List<TTMessage> {
        return messageDao.getAllUnsendMsg(conversationId)
    }

    fun getMessage(messaId: String?): TTMessage? {
        return messageDao.getMessage(messaId)
    }

    fun getMessageFromObserver(messaId: String?): LiveData<List<TTMessage>> {
        return messageDao.getMessageFromObserver(messaId)
    }



    private fun checkAndAddDateMessage(vararg ttMessages: TTMessage?) {
        for (ttMessage in ttMessages) {
            val pattern = "dd MMM yyyy"
            val simpleDateFormat = SimpleDateFormat(pattern, Locale.ENGLISH)
            val today = Calendar.getInstance()
            today.time = ttMessage?.systemDate
            today[Calendar.MILLISECOND] = 1
            today[Calendar.SECOND] = 1
            today[Calendar.MINUTE] = 0
            today[Calendar.HOUR_OF_DAY] = 0
            val date = today.time
            val formatDate = simpleDateFormat.format(date)
            var messageForDate = getMessageForDate(formatDate, ttMessage?.contactId.toString(), MsgType.TYPE_DATE.value)
            if (messageForDate == null) {
                messageForDate = TTMessage(formatDate)
                messageForDate.messageId = ttMessage?.contactId + "_" + formatDate
                messageForDate.msgDate = Date(date.time - 1)
                messageForDate.systemDate = Date(date.time - 1)
                messageForDate.msgType = MsgType.TYPE_DATE.value
                messageForDate.msgStatus = TTMessage.MsgStatus.DELIVERED
                messageForDate.contactId = ttMessage?.contactId
                messageForDate.chatId = ttMessage?.chatId
                messageDao.insertMessageForDate(messageForDate)
                Log.e("INSERT","in checkAndAddDateMessage")
            }
        }
    }

    fun getReplyMessageFromUid(replyMessageId: String?): TTMessage? {
        return messageDao.getMessage(replyMessageId)
    }

    fun getConversationUnreadCount(dptType: String?): Int {
        return messageDao.getConversationUnreadCount(dptType)
    }

    val conversationUnreadCount: Int
        get() = messageDao.conversationUnreadCountForAll

    fun getPerticularConversationUnreadCount(conversationID: String?): Int {
        return messageDao.getPerticularConversationUnreadCount(conversationID)
    }

    fun resetReadCountForDepartment(depId: String){
        messageDao.resetReadCountForDepartment(depId.toInt())
    }

    fun deleteAllConversationMessages(uuid: String?) {
        messageDao.deleteMessageForConversation(uuid)
    }

    fun deleteHistoryOneWayMsg(dtype: String?, date: Long?) {
        messageDao.deleteHistoryOneWayMsg(dtype, date)
    }

    fun getPerticularUserMsgUnreadCount(uuid: String?): Int {
        return messageDao.getPerticularUserMsgUnreadCount(uuid)
    }

    fun getAllMarkableMessages(conversationId: String?): ArrayList<TTMessage> {
        return messageDao.getAllMarkableMessages(conversationId) as ArrayList<TTMessage>
    }

    fun getFirstUnreadMessage(conversationId: String?): TTMessage {
        return messageDao.getFirstUnreadMessage(conversationId)
    }

    val allUnSentMessagesForP2P: ArrayList<TTMessage>
        get() = messageDao.allUnSentMessagesForP2P as ArrayList<TTMessage>

    fun getLastMessageOfConversation(conversationId: String?): TTMessage? {
        return messageDao.getLastMessageOfConversation(conversationId)
    }
    fun getTypingMessageFromDB(messageId: String?): TTMessage? {
        return messageDao.getTypingMessageFromDB(messageId)
    }

    private fun getMessageForDate(
        formatDate: String,
        conversationId: String,
        typeDate: String
    ): TTMessage? {
        return messageDao.getMessageForDate(formatDate, conversationId, typeDate)
    }

    companion object {
        @JvmStatic
        var instance: TTMessageRepository? = null
            get() {
                if (field == null) {
                    field = TTMessageRepository()
                }
                return field
            }
            private set
    }
}
