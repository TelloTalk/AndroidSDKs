package com.tilismtech.tellotalksdk.data.repository;

import com.tilismtech.tellotalksdk.data.db.entities.TTAccount;
import com.tilismtech.tellotalksdk.data.db.DaoManager;

/**
 * Created by lpt-034 on 14/01/2019.
 */

public class TTAccountRepository {

    private static TTAccountRepository instance;

    public static TTAccountRepository getInstance() {
        if (instance == null){
            instance =  new TTAccountRepository();
        }
        return instance;
    }

    public void insertAccount(TTAccount ttAccount) {
        DaoManager.getInstance().getTTAccountDao().insertAccount(ttAccount);
    }

    public TTAccount getAccount() {
        return DaoManager.getInstance().getTTAccountDao().getAccount();
    }

    public TTAccount getAccount(String username) {
        return DaoManager.getInstance().getTTAccountDao().getAccount(username);
    }

    public void clearTable(){
        DaoManager.getInstance().getTTAccountDao().clearTable();
    }
}
