package com.tilismtech.tellotalksdk.data.repository;

import com.tilismtech.tellotalksdk.data.db.DaoManager;
import com.tilismtech.tellotalksdk.data.db.entities.Department;
import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations;
import com.tilismtech.tellotalksdk.data.db.dao.DepartmentDao;

import java.util.List;

public class DepartmentRepository {
    private static DepartmentRepository instance;
    private DepartmentDao departmentDao;
    public static DepartmentRepository getInstance() {
        if (instance == null){
            instance =  new DepartmentRepository();
        }
        return instance;
    }

    private DepartmentRepository(){
        this.departmentDao = DaoManager.getInstance().getDepartmentDao();
    }

    public void insertDepartment(Department department) {
        departmentDao.insertDepartment(department);
    }

    public void insertDepartment(List<Department> departments) {
        departmentDao.insertDepartments(departments);
    }

    public Department getDepartment() {
        return departmentDao.getDepartment();
    }

    public void clearTable() {
        departmentDao.clearTable();
    }

//    public void clearTableForCorporate() {
//        departmentDao.clearTableForCorporate();
//    }
//
    public Department getDepartmentByID(String departID) {
        return departmentDao.getdepartByID(departID);
    }
//
//    public LiveData<List<Department>> getAllTelloContactList(){
//        return departmentDao.getAllTelloContacts();
//    }
//
    public Department[] getAllCorporateDpt(){
        return departmentDao.getAllDepartment();
    }

    public List<DepartmentConversations> getDepartmentConversation(){
        return departmentDao.getDepartmentConversation();
    }
//
//    public LiveData<List<Contact>> getAllFilteredTelloContacts(String query) {
//        return departmentDao.getAllFilteredTelloContacts(query);
//    }
//
//    public LiveData<List<Contact>> getAllContactsForConversation(String id){
//        return departmentDao.getAllFilteredTelloContacts(id);
//    }
//
//    public void clearCustomContacts() {
//        departmentDao.clearTableForCustomContacts();
//    }
}
