package com.tilismtech.tellotalksdk.data.repository;

import androidx.lifecycle.LiveData;

import com.tilismtech.tellotalksdk.data.db.DaoManager;
import com.tilismtech.tellotalksdk.data.db.entities.MessageReceipt;
import com.tilismtech.tellotalksdk.data.db.dao.MessageReceiptDao;

import java.util.List;

public class MessageReceiptRepository {

    private MessageReceiptDao messageReceiptDao;

    private static MessageReceiptRepository instance;

    public static MessageReceiptRepository getInstance() {
        if (instance == null){
            instance =  new MessageReceiptRepository();
        }
        return instance;
    }

    private MessageReceiptRepository(){
        messageReceiptDao = DaoManager.getInstance().getMessageReceiptDao();
    }


    public LiveData<List<MessageReceipt>> getAllReadMessageReceiptForConversation(String conversationId){
        return messageReceiptDao.getAllReadMessageReceiptForConversation(conversationId);
    }

    public LiveData<List<MessageReceipt>> getAllDeliveredMessageReceiptForConversation(String conversationId){
        return messageReceiptDao.getAllDeliveredMessageReceiptForConversation(conversationId);
    }

    public LiveData<List<MessageReceipt>> getAllSentMessageReceiptForConversation(String conversationId){
        return messageReceiptDao.getAllSentMessageReceiptForConversation(conversationId);
    }

    public int countOfUsers(String messageId){
        return messageReceiptDao.getTotalUserCount(messageId);
    }

    public MessageReceipt getMessageReceiptForSingleMessage(String messageId, String contactJid){
        return messageReceiptDao.getMessageReceiptForSingleMessage(messageId, contactJid);
    }

    public synchronized void insertMessageReceipt(MessageReceipt messageReceipt){
        messageReceiptDao.insertMessageReceipt(messageReceipt);
    }

    public void updateMessageReceipt(MessageReceipt messageReceipt){
        messageReceiptDao.updateMessageReceipt(messageReceipt);
    }

    public void deleteMessageReceipt(MessageReceipt messageReceipt){
        messageReceiptDao.deleteMessageReceipt(messageReceipt);
    }

    public LiveData<MessageReceipt> getReceiptForP2p(String uuid) {
        return messageReceiptDao.getReceiptForP2(uuid);
    }

    public int getDeliveredReceiptCount(String messageId) {
        return messageReceiptDao.getDeliveredReceiptCount(messageId);
    }

    public int getReadReceiptCount(String messageId) {
        return messageReceiptDao.getReadReceiptCount(messageId);
    }

    public void deleteReceiptsForConversation(String conversationId) {
        messageReceiptDao.deleteReceiptsForConversation(conversationId);
    }

    public void deleteMessageReceiptForMessage(String messageId) {
        messageReceiptDao.deleteMessageReceiptForMessage(messageId);
    }
}
