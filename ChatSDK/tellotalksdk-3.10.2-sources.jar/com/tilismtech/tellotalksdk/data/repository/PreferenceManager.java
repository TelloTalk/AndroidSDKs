package com.tilismtech.tellotalksdk.data.repository;

import com.tilismtech.tellotalksdk.data.db.DaoManager;
import com.tilismtech.tellotalksdk.data.db.entities.Preference;
import com.tilismtech.tellotalksdk.data.db.dao.PreferenceDao;

public class PreferenceManager {

    public static final String CHAT_ID = "chat_id";
    public static final String DEPARTMENT_ID = "department_id";
    public static final String DEPARTMENT_NAME = "department_name";

    PreferenceDao preferenceDao;
    private static PreferenceManager instance = null;

    public PreferenceManager() {
        preferenceDao = DaoManager.getInstance().getPreferenceDao();
    }

    public static PreferenceManager getInstance() {
        if (instance == null){
            instance =  new PreferenceManager();
        }
        return instance;
    }

    public void putString(String key, String value) {
        Preference pref = new Preference(key, value);
        insertPreference(pref);

    }

    public void putInt(String key, int value) {
        Preference pref = new Preference(key, "" + value);
        DaoManager.getInstance().getPreferenceDao().insertValue(pref);
    }

//    public void putParcelable(String key, Parcelable obj){
//        Preference pref = new Preference(key, "" + obj);
//        DaoManager.getInstance().getPreferenceDao().insertValue(pref);
//    }
//
//    public Parcelable getParcelable(String key){
//        Preference preference = preferenceDao.getValue(key);
//        return preference.setValue()];
//    }

    public void putLong(String key, long value) {
        Preference pref = new Preference(key, "" + value);
        preferenceDao.insertValue(pref);

    }

    public void putDouble(String key, double value) {
        Preference pref = new Preference(key, "" + value);
        preferenceDao.insertValue(pref);

    }

    public void putBoolean(String key, boolean value) {
        Preference pref = new Preference(key, "" + value);
//        preferenceDao.insertValue(pref);
        insertPreference(pref);

    }


    public void deleteValue(String key) {
        preferenceDao.deleteValue(new Preference(key, null));
    }

    public void updateValue(String key, String value) {
        preferenceDao.updateValue(new Preference(key, value));
    }

    public void updateValue(String key, int value) {
        preferenceDao.updateValue(new Preference(key, "" + value));
    }

    public void updateValue(String key, boolean value) {
        preferenceDao.updateValue(new Preference(key, "" + value));
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        Preference preference = preferenceDao.getValue(key);
        return preference != null ? Boolean.parseBoolean(preference.getValue()) : defaultValue;
    }

    public int getInt(String key, int defaultValue) {
        Preference preference = preferenceDao.getValue(key);
        try {
            return preference == null ? defaultValue : Integer.parseInt(preference.getValue());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public long getLong(String key, long defaultValue) {
        Preference preference = preferenceDao.getValue(key);
        try {
            return preference == null ? defaultValue : Long.parseLong(preference.getValue());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public double getDouble(String key, double defaultValue) {
        Preference preference = preferenceDao.getValue(key);
        try {
            return preference == null ? defaultValue : Double.parseDouble(preference.getValue());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public String getString(String key, String defaultValue) {
        Preference preference = preferenceDao.getValue(key);
        return preference != null ? preference.getValue() : defaultValue;
    }

    private void insertPreference(Preference preference) {
        preferenceDao.insertValue(preference);
//        new InsertPreferenceTask(OPERATION_INSERT).execute(preference);
    }

//    private class InsertPreferenceTask extends AsyncTask<Preference, Void, Void> {
//
//        private int Operation = 0;
//
//        public InsertPreferenceTask(int operationInsert) {
//            this.Operation = operationInsert;
//        }
//
//        @Override
//        protected Void doInBackground(Preference... news) {
//            switch (Operation) {
//                case OPERATION_INSERT:
//                    preferenceDao.insertValue(news);
//                    break;
//                case OPERATION_DELETE:
//                    preferenceDao.deleteValue(news);
//                    break;
//                case OPERATION_UPDATE:
//                    preferenceDao.deleteValue(news);
//                    break;
//
//            }
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(Void aVoid) {
//            super.onPostExecute(aVoid);
//        }
//    }


//    public String getHttpEncKey(){
//        return getString(PreferenceManager.ENC_KEY_HTTP, "SezTe7ooA1jzUwZKLpzXndc8D5DJxxn7");
//    }
//
//    public String getHttpIVEncKey(){
//        return getString(PreferenceManager.ENC_KEY_HTTP_IV, "sA@A&mskMJ!RmS?J");
//    }
//
//    public String getEncKeyXmpp(){
//        return getString(PreferenceManager.ENC_KEY_XMPP, "1234567812345678");
//    }


}

