package com.tilismtech.tellotalksdk.data.usecases.implementations

import com.google.gson.Gson
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.network.NetworkClient
import com.tilismtech.tellotalksdk.data.network.module.register.RegisterUserObject
import com.tilismtech.tellotalksdk.data.network.module.register.response.RegisterResponse
import com.tilismtech.tellotalksdk.data.usecases.abstractions.AuthDatasource
import com.tilismtech.tellotalksdk.managers.TelloApiClient

class AuthSocket(authParams:String?="") : AuthDatasource {

    private val socket = NetworkClient.getInstance(authParams)
    override fun register(registerUserObject: RegisterUserObject, callback:(it:RegisterResponse)->Unit) {
        if(TelloApiClient.getInstance()!!.getAccount()==null){
            TelloApiClient.getInstance()?.setCurrentAccount(TTAccount(registerUserObject.profileId.toString(),registerUserObject.name,"","",""))
        }
        socket.emit(registerUserObject,"register"){
            if(it.optInt("statusCode")==200){
                val registerResponse = Gson().fromJson(it.toString(),RegisterResponse::class.java)
                callback(registerResponse)
            }else{
                callback(RegisterResponse(message = it.optString("error")))
            }
        }
    }
}