package com.tilismtech.tellotalksdk.data.usecases.implementations

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.tilismtech.tellotalksdk.data.network.NetworkClient
import com.tilismtech.tellotalksdk.data.network.module.initiateChat.ChatIdRequest
import com.tilismtech.tellotalksdk.data.network.module.initiateChat.response.ChatIdResponse
import com.tilismtech.tellotalksdk.data.usecases.abstractions.ChatDatasource
import org.json.JSONObject

class ChatSocket : ChatDatasource {
    override fun initiateChat(chatRequest: ChatIdRequest, callback: (ChatIdResponse) -> Unit) {
        NetworkClient.getInstance().emit(chatRequest,"initiateChat"){
            val res = Gson().fromJson(it.toString(), ChatIdResponse::class.java)
            callback(res)
        }
    }

    override fun endChat(chatId: String, callback: (JSONObject) -> Unit) {
        NetworkClient.getInstance().emit(JsonObject().apply {
            addProperty("chatId", chatId)
        },"endChat"){
            callback(it)
        }
    }
}