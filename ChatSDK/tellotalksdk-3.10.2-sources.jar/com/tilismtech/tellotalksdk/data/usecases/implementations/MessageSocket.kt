package com.tilismtech.tellotalksdk.data.usecases.implementations

import com.google.gson.Gson
import com.tilismtech.tellotalksdk.data.network.NetworkClient
import com.tilismtech.tellotalksdk.data.network.module.newMessages.AgentMessageResponse
import com.tilismtech.tellotalksdk.data.network.module.receipt.ReceiptModel
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.MessageRequestModel
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.response.MessageResponseModel
import com.tilismtech.tellotalksdk.data.network.module.typing.TypingObject
import com.tilismtech.tellotalksdk.data.usecases.abstractions.MessageDatasource
import org.json.JSONObject

class MessageSocket:MessageDatasource {

    override fun sendMessage(
        request: MessageRequestModel,
        callback: (MessageResponseModel?) -> Unit
    ) {
        NetworkClient.getInstance().emit(request,"sendMessage"){
            val res = Gson().fromJson(it.toString(), MessageResponseModel::class.java)
            callback(res)
        }
    }

    override fun newMessage(callback: (AgentMessageResponse?) -> Unit) {
        NetworkClient.getInstance().newMessage {
            callback(it)
        }
    }

    override fun sendAck(request: ReceiptModel, callback: (JSONObject?) -> Unit) {
        NetworkClient.getInstance().emit(request,"sendReceipt"){
            val res = it.getString("statusCode")
            if(res=="200"){
                callback(it)
            }
        }
    }

    override fun newAck(callback: (ReceiptModel?) -> Unit) {
        NetworkClient.getInstance().newReceipt {
            callback(it)
        }
    }

    override fun typingStatus(callback: (TypingObject?) -> Unit) {
        NetworkClient.getInstance().typing {
            callback(it)
        }
    }

    override fun updateTyping(request: TypingObject, callback: (TypingObject?) -> Unit) {
        NetworkClient.getInstance().emit(request,"updateTypingStatus"){
            val res = Gson().fromJson(it.toString(), TypingObject::class.java)
            callback(res)
        }
    }

}