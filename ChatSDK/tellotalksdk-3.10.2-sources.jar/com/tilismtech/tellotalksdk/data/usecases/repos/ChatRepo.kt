package com.tilismtech.tellotalksdk.data.usecases.repos

import com.tilismtech.tellotalksdk.data.network.module.initiateChat.ChatIdRequest
import com.tilismtech.tellotalksdk.data.network.module.initiateChat.response.ChatIdResponse
import com.tilismtech.tellotalksdk.data.usecases.abstractions.ChatDatasource
import org.json.JSONObject

class ChatRepo(private val chatSource:ChatDatasource) {
    fun initiateChat(chatIdRequest: ChatIdRequest, callback: (it:ChatIdResponse)->Unit){
        chatSource.initiateChat(chatIdRequest){
            callback(it)
        }
    }

    fun endChat(chatId:String,callback: (it:JSONObject)->Unit){
        chatSource.endChat(chatId){
            callback(it)
        }
    }
}