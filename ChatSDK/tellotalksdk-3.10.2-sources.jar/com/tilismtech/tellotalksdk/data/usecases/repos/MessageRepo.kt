package com.tilismtech.tellotalksdk.data.usecases.repos

import com.tilismtech.tellotalksdk.data.network.module.newMessages.AgentMessageResponse
import com.tilismtech.tellotalksdk.data.network.module.receipt.ReceiptModel
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.MessageRequestModel
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.response.MessageResponseModel
import com.tilismtech.tellotalksdk.data.network.module.typing.TypingObject
import com.tilismtech.tellotalksdk.data.usecases.abstractions.MessageDatasource
import org.json.JSONObject

class MessageRepo(private val messageSocket:MessageDatasource) {
    fun sendMessage(request: MessageRequestModel, callback: (it: MessageResponseModel) -> Unit) {
        messageSocket.sendMessage(request) {
            callback(it!!)
        }
    }

    fun sendReceipt(request: ReceiptModel, callback: (it: JSONObject) -> Unit) {
        messageSocket.sendAck(request) {
            callback(it!!)
        }
    }

    fun newMessage(callback: (it: AgentMessageResponse) -> Unit) {
        messageSocket.newMessage {
            callback(it!!)
        }
    }

    fun newReceipt(callback: (it: ReceiptModel?) -> Unit){
        messageSocket.newAck {
            callback(it)
        }
    }

    fun typingStatus(callback: (it: TypingObject?) -> Unit){
        messageSocket.typingStatus {
            callback(it)
        }
    }

    fun updateTyping(request: TypingObject, callback: (it: TypingObject?) -> Unit){
        messageSocket.updateTyping(request) {
            callback(it)
        }
    }
}