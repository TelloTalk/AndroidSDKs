package com.tilismtech.tellotalksdk.data.usecases.repos

import com.tilismtech.tellotalksdk.data.db.entities.TTAccount
import com.tilismtech.tellotalksdk.data.network.module.register.RegisterUserObject
import com.tilismtech.tellotalksdk.data.network.module.register.response.RegisterResponse
import com.tilismtech.tellotalksdk.data.repository.TTAccountRepository
import com.tilismtech.tellotalksdk.data.usecases.abstractions.AuthDatasource
import com.tilismtech.tellotalksdk.managers.ChatManager
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.managers.TelloPreferencesManager

class AuthRepo(private val datasource: AuthDatasource) {
    fun register(registerModel:RegisterUserObject, callback:(it:RegisterResponse)->Unit){
        datasource.register(registerModel){
            if(it.statusCode=="200"){
                val instance = TelloPreferencesManager.getInstance()
                instance.putBoolean(TelloPreferencesManager.REGISTER_SUCCESS, true)
                val ttAccount = TTAccount(
                    registerModel.profileId.toString(), registerModel.profileId, "", "", it.data.legacyToken
                )
                TTAccountRepository.getInstance().insertAccount(ttAccount)
                TelloApiClient.getInstance()?.setCurrentAccount(ttAccount)
                ChatManager.instance?.deleteOtherUserMsgs(registerModel.profileId)
                instance.putBoolean(
                    TelloPreferencesManager.CORPORATE_USER, it.data.CorporateUser.toBoolean()
                )
            }
            callback(it)
        }
    }
}