package com.tilismtech.tellotalksdk.data.usecases.abstractions

import com.tilismtech.tellotalksdk.data.network.module.register.RegisterUserObject
import com.tilismtech.tellotalksdk.data.network.module.register.response.RegisterResponse

interface AuthDatasource {
    fun register(registerUserObject: RegisterUserObject,callback:(RegisterResponse)->Unit)
}