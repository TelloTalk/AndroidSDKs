package com.tilismtech.tellotalksdk.data.usecases.abstractions

import com.tilismtech.tellotalksdk.data.network.module.initiateChat.ChatIdRequest
import com.tilismtech.tellotalksdk.data.network.module.initiateChat.response.ChatIdResponse
import org.json.JSONObject

interface ChatDatasource {
    fun initiateChat(chatRequest: ChatIdRequest, callback:(ChatIdResponse)->Unit)
    fun endChat(chatId: String, callback:(JSONObject)->Unit)
}