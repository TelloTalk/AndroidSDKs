package com.tilismtech.tellotalksdk.data.usecases.abstractions

import com.tilismtech.tellotalksdk.data.network.module.newMessages.AgentMessageResponse
import com.tilismtech.tellotalksdk.data.network.module.receipt.ReceiptModel
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.MessageRequestModel
import com.tilismtech.tellotalksdk.data.network.module.sendMessage.response.MessageResponseModel
import com.tilismtech.tellotalksdk.data.network.module.typing.TypingObject
import org.json.JSONObject

interface MessageDatasource {
    fun sendMessage(request: MessageRequestModel, callback:(MessageResponseModel?)->Unit)
    fun newMessage(callback:(AgentMessageResponse?)->Unit)
    fun sendAck(request: ReceiptModel, callback:(JSONObject?)->Unit)
    fun newAck(callback:(ReceiptModel?)->Unit)
    fun typingStatus(callback:(TypingObject?)->Unit)
    fun updateTyping(request: TypingObject, callback:(TypingObject?)->Unit)
}