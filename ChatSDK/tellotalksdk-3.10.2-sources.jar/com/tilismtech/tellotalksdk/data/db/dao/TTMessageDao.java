package com.tilismtech.tellotalksdk.data.db.dao;

import static androidx.room.OnConflictStrategy.IGNORE;
import static androidx.room.OnConflictStrategy.REPLACE;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.TTMessage;

import java.util.List;

/**
 * Created by lpt-034 on 14/01/2019.
 */

@Dao
public interface TTMessageDao {

    @Query("SELECT * FROM messages LIMIT 1")
    List<TTMessage> getMessages();

    @Insert(onConflict = REPLACE)
    void insertMessages(List<TTMessage> messages);

    @Insert(onConflict = REPLACE)
    void insertMessages(TTMessage... messages);

    @Delete
    void deleteMessages(TTMessage... messages);

    @Update
    void updateMEssage(TTMessage message);

    @Query("DELETE FROM messages")
    void clearTable();

    @Query("SELECT * FROM messages WHERE contactId = :contactId ORDER BY systemDate ASC")
    LiveData<List<TTMessage>> getAllConversationMessages(String contactId);



    @Query("SELECT * FROM messages WHERE contactId = :contactId ORDER BY systemDate ASC")
    List<TTMessage> getAllMessagesByProfileId(String contactId);

    @Query("SELECT * FROM messages WHERE contactId = :contactId AND isDeleted = 0 ORDER BY systemDate ASC")
    LiveData<List<TTMessage>> getAllOneWayMessages(String contactId);

    @Query("SELECT * FROM messages WHERE contactId = :contactId")
    List<TTMessage> getAllConversationMessagess(String contactId);

    @Query("SELECT * FROM messages WHERE contactId = :conversationId AND msgStatus = 0 OR msgStatus= 7")
    List<TTMessage> getAllUnsendMsg(String conversationId);

    @Query("SELECT * FROM messages WHERE contactId = :contactId ORDER BY systemDate DESC LIMIT 1")
    TTMessage getLatestMessageOfConversation(String contactId);

    @Query("SELECT COUNT(*) FROM messages WHERE contactId = :contactId AND isRead = 0")
    int getUnreadMessageCount(String contactId);

    @Query("SELECT * FROM messages WHERE isRead = 0 AND msgStatus = 4")
    List<TTMessage> getAllUnreadMessage();

    @Query("SELECT * FROM messages WHERE messageId = :messageId OR messageId = :messageId")
    TTMessage getMessage(String messageId);

    @Query("SELECT * FROM messages WHERE message = :message AND contactId = :contactId AND msgType = :msgType")
    TTMessage getMessageForDate(String message, String contactId, String msgType);

    @Insert(onConflict = REPLACE)
    void insertMessage(TTMessage... message);

    @Delete
    void deleteMessage(TTMessage... message);

    @Query("DELETE FROM messages WHERE msgType = :msgType")
    void deleteTypingMessages(int msgType);

    @Update
    void updateMessage(TTMessage... message);

    @Query("DELETE FROM messages WHERE contactId = :contactId")
    void deleteMessageForConversation(String contactId);

    @Query("DELETE FROM messages WHERE chatId != :chatId")
    void deleteAllMessageForPreviousConvoa(String chatId);

    @Query("SELECT * FROM messages where receiverId = :contactId AND isRead = 0 AND msgStatus = 4 ORDER BY systemDate DESC")
    List<TTMessage> getAllMarkableMessages(String contactId);

    @Query("SELECT * FROM messages where contactId = :contactId AND isRead = 0 AND msgStatus = 4 AND msgType != 10  ORDER BY systemDate ASC LIMIT 1")
    TTMessage getFirstUnreadMessage(String contactId);

    @Query("SELECT * FROM messages WHERE msgStatus = 0 AND contactId NOT LIKE '%@c%'")
    List<TTMessage> getAllUnSentMessagesForP2P();

    @Query("SELECT * FROM messages WHERE messageId = :messaId")
    LiveData<List<TTMessage>> getMessageFromObserver(String messaId);

    @Query("SELECT * FROM messages WHERE contactId = :contactId AND msgType != 'typing' AND chatId != '' AND chatId != '0'  ORDER BY systemDate DESC LIMIT 1")
    TTMessage getLastMessageOfConversation(String contactId);

    @Query("SELECT * FROM messages WHERE messageId = :messageId LIMIT 1")
    TTMessage getTypingMessageFromDB(String messageId);

    @Query("UPDATE messages SET caption = :caption WHERE messageId = :messageId")
    void updateMessageFileTag(String messageId, String caption);

    @Query("UPDATE messages SET msgStatus = :msgStatus WHERE messageId = :messageId")
    void updateMessageStatus(String messageId, int msgStatus);

    @Insert(onConflict = IGNORE)
    void insertMessageForDate(TTMessage message);

    @Query("SELECT SUM(isRead_count) FROM messages WHERE dptType = :dptType ")
    int getConversationUnreadCount(String dptType);

    @Query("UPDATE messages SET isRead_count = 0 WHERE departmentId =:dptId")
    int resetReadCountForDepartment(int dptId);

    @Query("SELECT SUM(isRead_count) FROM messages")
    int getConversationUnreadCountForAll();

    @Query("SELECT SUM(isRead_count) FROM messages where conversationId = :conversationId")
    int getPerticularConversationUnreadCount(String conversationId);

    @Query("DELETE FROM messages WHERE receiverId != :contactId AND profileId != :contactId AND contactId!= :contactId")
    void deleteOtherUserMsg(String contactId);

    @Query("DELETE FROM messages WHERE dptType = :dptType AND msgDate < :date")
    void deleteHistoryOneWayMsg(String dptType, Long date);

    @Query("SELECT COUNT(*) FROM messages where receiverId == :contactId OR profileId == :contactId")
    int getPerticularUserMsgUnreadCount(String contactId);

}
