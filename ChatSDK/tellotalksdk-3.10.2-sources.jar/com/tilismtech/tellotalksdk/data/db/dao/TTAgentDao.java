package com.tilismtech.tellotalksdk.data.db.dao;

import static androidx.room.OnConflictStrategy.REPLACE;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.tilismtech.tellotalksdk.data.db.entities.AgentModel;

@Dao
public interface TTAgentDao {


    @Insert(onConflict = REPLACE)
    void insertAgent(AgentModel... agentModels);

    @Query("DELETE FROM agents")
    void clearTable();


    @Query("SELECT * FROM agents WHERE agentId = :agentId")
    AgentModel getAgentFromDB(String agentId);


}
