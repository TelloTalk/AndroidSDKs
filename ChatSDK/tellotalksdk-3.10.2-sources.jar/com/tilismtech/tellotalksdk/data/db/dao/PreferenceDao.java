package com.tilismtech.tellotalksdk.data.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.Preference;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface PreferenceDao {

    @Query("SELECT * FROM preference WHERE `key` = :key LIMIT 1")
    Preference getValue(String key);

    @Insert(onConflict = REPLACE)
    void insertValue(Preference ... preference);

    @Update
    void updateValue(Preference ... preference);

    @Delete
    void deleteValue(Preference ... preference);

    @Query("DELETE FROM preference")
    void clearTable();
}
