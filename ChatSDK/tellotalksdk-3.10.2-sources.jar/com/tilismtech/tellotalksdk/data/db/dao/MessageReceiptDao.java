package com.tilismtech.tellotalksdk.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.MessageReceipt;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface MessageReceiptDao {

    @Insert(onConflict = REPLACE)
    void insertMessageReceipt(MessageReceipt messageReceipt);

    @Update
    void updateMessageReceipt(MessageReceipt messageReceipt);

    @Delete
    void deleteMessageReceipt(MessageReceipt messageReceipt);

    @Query("SELECT * FROM receipt WHERE messageId = :conversationId")
    List<MessageReceipt> getAllMessageReceiptForConversation(String conversationId);

    @Query("SELECT * FROM receipt WHERE messageId = :conversationId AND timeRead!=0")
    LiveData<List<MessageReceipt>> getAllReadMessageReceiptForConversation(String conversationId);

    @Query("SELECT * FROM receipt WHERE messageId = :conversationId AND timeDelivered!=0 AND timeRead == 0 ")
    LiveData<List<MessageReceipt>> getAllDeliveredMessageReceiptForConversation(String conversationId);

    @Query("SELECT * FROM receipt WHERE messageId = :conversationId AND timeRead == 0 AND timeDelivered == 0")
    LiveData<List<MessageReceipt>> getAllSentMessageReceiptForConversation(String conversationId);

    @Query("SELECT * FROM receipt WHERE messageId = :messageId AND contactJid = :contactJid LIMIT 1")
    MessageReceipt getMessageReceiptForSingleMessage(String messageId, String contactJid);

    @Query("SELECT COUNT(*) FROM receipt WHERE messageId = :messageId")
    int getTotalUserCount(String messageId);

    @Query("SELECT * FROM receipt WHERE messageId = :uuid LIMIT 1")
    LiveData<MessageReceipt> getReceiptForP2(String uuid);

    @Query("SELECT COUNT(*) FROM receipt WHERE messageId = :messageId AND timeDelivered!=0")
    int getDeliveredReceiptCount(String messageId);

    @Query("SELECT COUNT(*) FROM receipt WHERE messageId = :messageId AND timeRead!=0")
    int getReadReceiptCount(String messageId);

    @Query("DELETE  FROM receipt WHERE conversationId= :conversationId")
    void deleteReceiptsForConversation(String conversationId);

    @Query("DELETE  FROM receipt WHERE messageId= :messageId")
    void deleteMessageReceiptForMessage(String messageId);
}
