package com.tilismtech.tellotalksdk.data.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.TTAccount;

import static androidx.room.OnConflictStrategy.REPLACE;

/**
 * Created by lpt-034 on 14/01/2019.
 */

@Dao
public interface TTAccountDao {

    @Query("SELECT * FROM account LIMIT 1")
    TTAccount getAccount();

    @Query("SELECT * FROM account WHERE username = :username  LIMIT 1")
    TTAccount getAccount(String username);

    @Insert(onConflict = REPLACE)
    void insertAccount(TTAccount account);

    @Delete
    void deleteAccount(TTAccount account);

    @Update
    void updateAccount(TTAccount account);

    @Query("DELETE FROM account")
    void clearTable();

}
