package com.tilismtech.tellotalksdk.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.TTConversation;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface TTConversationDao {

    @Query("SELECT * FROM conversation WHERE isCe = :isCeNeeded AND created != 0 AND hasMessage = 1 ORDER BY orderFlag DESC , created DESC")
    LiveData<List<TTConversation>> getAllConversationList(boolean isCeNeeded);

    @Query("SELECT * FROM conversation")
    List<TTConversation> getAllConversations();

    @Query("SELECT * FROM conversation WHERE contactJid = :contactJid LIMIT 1")
    TTConversation getConversation(String contactJid);

    @Insert(onConflict = REPLACE)
    long insertConversation(TTConversation conversation);

    @Delete
    void deleteConversation(TTConversation conversation);

    @Update
    void updateConversation(TTConversation conversation);

    @Query("SELECT * FROM conversation WHERE isCe = 0 AND conversationName LIKE :query ORDER BY orderFlag DESC , created DESC")
    LiveData<List<TTConversation>> getFilteredConversationList(String query);

    @Query("DELETE FROM conversation")
    void clearTable();

    @Query("SELECT SUM(unreadCount) FROM conversation")
    int getConversationUnreadCount();

}
