package com.tilismtech.tellotalksdk.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.Contact;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

/**
 * Created by lpt-034 on 14/01/2019.
 */

@Dao
public interface ContactDao {

    @Query("SELECT * FROM contact LIMIT 1")
    Contact getContact();

    @Insert(onConflict = REPLACE)
    void insertContact(Contact contact);

    @Insert(onConflict = REPLACE)
    void insertContacts(List<Contact> contact);

    @Delete
    void deleteContact(Contact contact);

    @Update
    void updateContact(Contact contact);

    @Query("DELETE FROM contact where status = 0")
    void clearTable();

    @Query("DELETE FROM contact where status = 1")
    void clearTableForCorporate();

    @Query("DELETE FROM contact where status = 2")
    void clearTableForCustomContacts();

    @Query("SELECT * FROM contact WHERE contactId = :contactJid  LIMIT 1")
    Contact getContactFromJid(String contactJid);

    @Query("SELECT * FROM contact WHERE name <> '' AND (status = 0 OR status = 2) ORDER BY  name") // WHERE status = 0
    LiveData<List<Contact>> getAllTelloContacts();

    @Query("SELECT * FROM contact WHERE name <> '' AND status = 1 ORDER BY  name") // WHERE status = 0
    Contact[] getAllCorporateContacts();

    @Query("SELECT * FROM contact WHERE (name LIKE :query OR contactId LIKE :query )  AND name <> '' AND (status = 0 OR status = 2) ORDER BY name") // WHERE status = 0
    LiveData<List<Contact>> getAllFilteredTelloContacts(String query);

}
