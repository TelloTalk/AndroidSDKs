package com.tilismtech.tellotalksdk.data.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.tilismtech.tellotalksdk.data.db.entities.Department;
import com.tilismtech.tellotalksdk.data.db.entities.DepartmentConversations;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface DepartmentDao {

    @Query("SELECT * FROM departments LIMIT 1")
    Department getDepartment();

    @Insert(onConflict = REPLACE)
    void insertDepartment(Department department);

    @Insert(onConflict = REPLACE)
    void insertDepartments(List<Department> departments);

    @Delete
    void deleteDepartments(Department department);

    @Update
    void updateDepartment(Department department);

    @Query("DELETE FROM departments")
    void clearTable();

    //    @Query("DELETE FROM contact where status = 1")
//    void clearTableForCorporate();
//
//    @Query("DELETE FROM contact where status = 2")
//    void clearTableForCustomContacts();
//
    @Query("SELECT * FROM departments WHERE dptId = :contactJid  LIMIT 1")
    Department getdepartByID(String contactJid);
//
//    @Query("SELECT * FROM contact WHERE name <> '' AND (status = 0 OR status = 2) ORDER BY  name") // WHERE status = 0
//    LiveData<List<Contact>> getAllTelloContacts();
//
    @Query("SELECT * FROM departments ORDER BY  dptId")
    // WHERE status = 0
    Department[] getAllDepartment();



    @Query("SELECT departments.*, conversation.* FROM departments LEFT JOIN conversation ON departments.dptId = conversation.contactJid")
    List<DepartmentConversations> getDepartmentConversation();

//
//    @Query("SELECT * FROM contact WHERE (name LIKE :query OR contactId LIKE :query )  AND name <> '' AND (status = 0 OR status = 2) ORDER BY name") // WHERE status = 0
//    LiveData<List<Contact>> getAllFilteredTelloContacts(String query);
}
