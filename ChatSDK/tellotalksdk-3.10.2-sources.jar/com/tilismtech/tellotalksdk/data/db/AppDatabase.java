package com.tilismtech.tellotalksdk.data.db;

import android.util.Log;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import com.tilismtech.tellotalksdk.data.db.dao.ContactDao;
import com.tilismtech.tellotalksdk.data.db.dao.DepartmentDao;
import com.tilismtech.tellotalksdk.data.db.dao.MessageReceiptDao;
import com.tilismtech.tellotalksdk.data.db.dao.PreferenceDao;
import com.tilismtech.tellotalksdk.data.db.dao.TTAccountDao;
import com.tilismtech.tellotalksdk.data.db.dao.TTAgentDao;
import com.tilismtech.tellotalksdk.data.db.dao.TTConversationDao;
import com.tilismtech.tellotalksdk.data.db.dao.TTMessageDao;
import com.tilismtech.tellotalksdk.data.db.entities.AgentModel;
import com.tilismtech.tellotalksdk.data.db.entities.Contact;
import com.tilismtech.tellotalksdk.data.db.entities.Department;
import com.tilismtech.tellotalksdk.data.db.entities.MessageReceipt;
import com.tilismtech.tellotalksdk.data.db.entities.Preference;
import com.tilismtech.tellotalksdk.data.db.entities.TTAccount;
import com.tilismtech.tellotalksdk.data.db.entities.TTConversation;
import com.tilismtech.tellotalksdk.data.db.entities.TTMessage;

@Database(entities = {TTAccount.class, TTMessage.class, Preference.class, TTConversation.class, Contact.class, MessageReceipt.class, Department.class, AgentModel.class}, version = 24)
public abstract class AppDatabase extends RoomDatabase {

    public static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN customData TEXT");
        }
    };
    public static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE conversation "
                    + " ADD COLUMN hasMessage INTEGER NOT NULL  DEFAULT 0");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN conversationId TEXT");
        }
    };


    public static final Migration MIGRATION_3_4 = new Migration(3, 4) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN departmentName VARCHAR(50) NOT NULL");
        }
    };

    public static final Migration MIGRATION_4_5 = new Migration(4, 5) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE departments "
                    + " ADD COLUMN dptType VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_5_6 = new Migration(5, 6) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN viewId VARCHAR(50)");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN viewDet VARCHAR(50)");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN viewOptionId VARCHAR(50)");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN originalFileName VARCHAR(50)");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN msgHeading VARCHAR(50)");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN msgURL VARCHAR(50)");

        }
    };
    public static final Migration MIGRATION_6_7 = new Migration(6, 7) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("hmigration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN dptType VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_7_8 = new Migration(7, 8) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE departments "
                    + " ADD COLUMN dptImage VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_8_9 = new Migration(8, 9) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN isFeedback INTEGER DEFAULT 0 NOT NULL");
        }
    };

    public static final Migration MIGRATION_9_10 = new Migration(9, 10) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE departments "
                    + " ADD COLUMN deptTag VARCHAR(50)");
        }
    };


    public static final Migration MIGRATION_10_11 = new Migration(10, 11) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE departments "
                    + " ADD COLUMN name_u VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_11_12 = new Migration(11, 12) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN departmentName_u VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_12_13 = new Migration(12, 13) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN dptImage VARCHAR(50)");
//            database.execSQL("ALTER TABLE messages "
//                    + " ADD COLUMN audioLength VARCHAR(50)");
        }
    };
    public static final Migration MIGRATION_13_14 = new Migration(13, 14) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN audio_Length VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_14_15 = new Migration(14, 15) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN read_count INTEGER DEFAULT 0 NOT NULL");
        }
    };

    public static final Migration MIGRATION_15_16 = new Migration(15, 16) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE account "
                    + " ADD COLUMN accessToken VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_17_18 = new Migration(17, 18) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN campaignId VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_19_20 = new Migration(19, 20) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN msgExpTime VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_20_21 = new Migration(20, 21) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE messages "
                    + " ADD COLUMN agentAvatar VARCHAR(50)");
        }
    };

    public static final Migration MIGRATION_22_23 = new Migration(22, 23) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE IF NOT EXISTS  `agents` (`agentId` TEXT, `agentName` TEXT,`agentAvatar` TEXT,`status` TEXT, PRIMARY KEY(`agentId`))");
        }
    };

    public static final Migration MIGRATION_24_25 = new Migration(24, 25) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            Log.d("migration", database.getVersion() + "");
            database.execSQL("ALTER TABLE agents "
                    + " ADD COLUMN status VARCHAR(50)");
        }
    };


//    public static final Migration MIGRATION_20_21 = new Migration(20,21) {
//        @Override
//        public void migrate(@NonNull SupportSQLiteDatabase database) {
//            Log.d("migration", database.getVersion() + "");
//            database.execSQL("ALTER TABLE messages "
//                    + " ADD COLUMN chatbotID VARCHAR(50)");
//         //   database.execSQL("ALTER TABLE messages "
//         //           + " ADD COLUMN chatbotNode VARCHAR(50)");
//        }
//    };


//    public static final Migration MIGRATION_12_13 = new Migration(12,13) {
//        @Override
//        public void migrate(@NonNull SupportSQLiteDatabase database) {
//            Log.d("migration", database.getVersion() + "");
//            database.execSQL("ALTER TABLE conversation "
//                    + " ADD COLUMN departmentId VARCHAR(50)");
//        }
//    };


    public abstract TTAccountDao accountDao();

    public abstract TTMessageDao ttMessageDao();

    public abstract PreferenceDao preferenceDao();

    public abstract TTConversationDao ttConversationDao();

    public abstract ContactDao contactDao();

    public abstract MessageReceiptDao messageReceiptDao();

    public abstract DepartmentDao departmentDao();

    public abstract TTAgentDao agentModelDao();

    public void clearDb() {
        clearAllTables();
    }
}