package com.tilismtech.tellotalksdk.data.db.entities;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.tilismtech.tellotalksdk.data.db.entities.converters.DateConverter;

import java.util.Date;

/**
 * Created by lpt-034 on 16/01/2019.
 */

@Entity(tableName = "conversation")
@TypeConverters(DateConverter.class)
public class TTConversation implements Parcelable {

    @PrimaryKey
    @NonNull
    private String contactJid = "";
    private String conversationName;
    private int status;
    private Date created;
    private int mode;
    private boolean isCe;
    private String attributes;
    private String lastMessageId;
    private int unreadCount = 0;
    private int orderFlag;
    private int role;
    private boolean hasMessage;
    @Ignore
    private TTMessage lastMessage;
    @Ignore
    private TTMessage correctingMsg;

    protected TTConversation(Parcel in) {
        contactJid = in.readString();
        conversationName = in.readString();
        status = in.readInt();
        mode = in.readInt();
        isCe = in.readByte() != 0;
        attributes = in.readString();
        lastMessageId = in.readString();
        unreadCount = in.readInt();
        orderFlag = in.readInt();
        role = in.readInt();
        hasMessage = in.readByte() != 0;
    }

    public static final Creator<TTConversation> CREATOR = new Creator<TTConversation>() {
        @Override
        public TTConversation createFromParcel(Parcel in) {
            return new TTConversation(in);
        }

        @Override
        public TTConversation[] newArray(int size) {
            return new TTConversation[size];
        }
    };

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        TTConversation conversation = (TTConversation) obj;
        if (!contactJid.equals(conversation.contactJid)) return false;
        if (status != conversation.status) return false;
        if (mode != conversation.mode) return false;
        if (isCe != conversation.isCe) return false;
        if (created == null || !created.equals(conversation.getCreated())) return false;
        if (attributes != null) {
            if (!attributes.equals(conversation.attributes)) {
                return false;
            }
        } else {
            if (conversation.attributes != null) {
                return false;
            }
        }
        if (lastMessageId != null) {
            if (!lastMessageId.equals(conversation.getLastMessageId())) {
                return false;
            }
        } else {
            if (conversation.getLastMessageId() != null) {
                return false;
            }
        }
        if (unreadCount != conversation.unreadCount) return false;
        if (orderFlag != conversation.orderFlag) return false;
        return conversationName != null ? conversationName.equals(conversation.conversationName) : conversation.conversationName == null;
    }

    public TTConversation(String conversationName, @NonNull String contactJid, int status, Date created, int mode, boolean isCe, String attributes) {
        this();
        this.conversationName = conversationName;
        this.contactJid = contactJid;
        this.status = status;
        this.created = created;
        this.mode = mode;
        this.isCe = isCe;
        this.attributes = attributes;
    }

    @Ignore
    public TTConversation(String conversationName, @NonNull String contactJid) {
        this();
        this.conversationName = conversationName;
        this.contactJid = contactJid;
    }

    @Ignore
    public TTConversation() {
    }


    
    public String getConversationName() {
        return conversationName;
    }

    public void setConversationName(String conversationName) {
        this.conversationName = conversationName;
    }
    
    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    @NonNull
    public String getContactJid() {
        return contactJid;
    }

    public void setContactJid(@NonNull String contactJid) {
        this.contactJid = contactJid;
    }
    
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    
    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    
    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public boolean isCe() {
        return isCe;
    }

    public void setCe(boolean ce) {
        isCe = ce;
    }

    
    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    
    public String getLastMessageId() {
        return lastMessageId;
    }

    public void setLastMessageId(String lastMessageId) {
        this.lastMessageId = lastMessageId;
    }

    
    public int getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(int unreadCount) {
        this.unreadCount = unreadCount;
    }

    
    public int getOrderFlag() {
        return orderFlag;
    }

    public void setOrderFlag(int orderFlag) {
        this.orderFlag = orderFlag;
    }

    
    public TTMessage getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(TTMessage lastMessage) {
        this.lastMessage = lastMessage;
    }

    public TTMessage getCorrectingMsg() {
        return correctingMsg;
    }

    public void setCorrectingMsg(TTMessage correctingMsg) {
        this.correctingMsg = correctingMsg;
    }

    public boolean isHasMessage() {
        return hasMessage;
    }

    public void setHasMessage(boolean hasMessage) {
        this.hasMessage = hasMessage;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(contactJid);
        dest.writeString(conversationName);
        dest.writeInt(status);
        dest.writeInt(mode);
        dest.writeByte((byte) (isCe ? 1 : 0));
        dest.writeString(attributes);
        dest.writeString(lastMessageId);
        dest.writeInt(unreadCount);
        dest.writeInt(orderFlag);
        dest.writeInt(role);
        dest.writeByte((byte) (hasMessage ? 1 : 0));
    }
}
