package com.tilismtech.tellotalksdk.data.db.entities.converters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tilismtech.tellotalksdk.data.network.module.register.OtherField

object ListConverter {
    @TypeConverter
    fun fromOtherFieldList(value: List<OtherField?>?): String {
        return Gson().toJson(value)
    }

    @TypeConverter
    fun toOtherFieldList(value: String): List<OtherField?>? {
        val listType = object : TypeToken<List<OtherField?>?>() {}.type
        return Gson().fromJson(value, listType)
    }
}
