package com.tilismtech.tellotalksdk.data.db.entities.converters;

import androidx.room.TypeConverter;

import java.util.Date;

/**
 * Created by AbdulMomen on 1/23/18.
 */

public class DateConverter {

    @TypeConverter
    public Date fromTimeStamp(Long value){
        return value == 0 ? null : new Date(value);
    }

    @TypeConverter
    public Long dateToTimeStamp(Date date){
        return date == null ? 0 : date.getTime();
    }


}
