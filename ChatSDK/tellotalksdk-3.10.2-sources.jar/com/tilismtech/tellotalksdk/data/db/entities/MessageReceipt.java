package com.tilismtech.tellotalksdk.data.db.entities;

import androidx.room.Entity;
import androidx.room.TypeConverters;
import androidx.annotation.NonNull;

import com.tilismtech.tellotalksdk.data.db.entities.converters.DateConverter;
import com.tilismtech.tellotalksdk.data.repository.MessageReceiptRepository;
import com.tilismtech.tellotalksdk.data.network.module.requests.TTMessageReceipt;

import java.util.Date;

@Entity(tableName = "receipt" ,primaryKeys= {"contactJid","messageId"})
@TypeConverters(DateConverter.class)
public class MessageReceipt {

    @NonNull
    private String contactJid;
    private String conversationId;
    private Date timeRead;
    private Date timeDelivered;
    @NonNull
    private String messageId;

    public MessageReceipt() {
    }

    @NonNull
    public String getContactJid() {
        return contactJid;
    }

    public void setContactJid(@NonNull String contactJid) {
        this.contactJid = contactJid;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public Date getTimeRead() {
        return timeRead;
    }

    public void setTimeRead(Date timeRead) {
        this.timeRead = timeRead;
    }

    public Date getTimeDelivered() {
        return timeDelivered;
    }

    public void setTimeDelivered(Date timeDelivered) {
        this.timeDelivered = timeDelivered;
    }

    @NonNull
    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(@NonNull String messageId) {
        this.messageId = messageId;
    }

    public static void createReceipt(TTMessageReceipt receipt, String conversationId){
        MessageReceipt messageReceipt = MessageReceiptRepository.getInstance().getMessageReceiptForSingleMessage(receipt.getMessageId(), conversationId);
        if (messageReceipt == null){
            messageReceipt = new MessageReceipt();
            messageReceipt.setContactJid(conversationId);
            messageReceipt.setConversationId(conversationId);
            messageReceipt.setMessageId(receipt.getMessageId());
        }
        if (receipt.getAckType().equals(TTMessageReceipt.AckType.DELIVERED.name)){
            if (messageReceipt.getTimeRead()!= null && messageReceipt.getTimeRead().before(receipt.getMessageTime())){
                messageReceipt.setTimeDelivered(messageReceipt.getTimeRead());
            }else{
                messageReceipt.setTimeDelivered(receipt.getMessageTime());
            }
        }else{
            if (messageReceipt.getTimeDelivered() == null){
                messageReceipt.setTimeDelivered(receipt.getMessageTime());
            }
            messageReceipt.setTimeRead(receipt.getMessageTime());
        }
        MessageReceiptRepository.getInstance().insertMessageReceipt(messageReceipt);
    }
}