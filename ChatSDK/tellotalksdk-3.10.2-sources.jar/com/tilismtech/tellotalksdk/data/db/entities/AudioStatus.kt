package com.tilismtech.tellotalksdk.data.db.entities

data class AudioStatus(
    var audioProgress: Int = 0,
    var isPlaying: Boolean = false,
    var messageId: String = ""
)