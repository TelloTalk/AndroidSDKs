package com.tilismtech.tellotalksdk.data.db.entities.converters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode

object ChatbotNodeConverter {
    @TypeConverter
    fun storedStringToMyObjects(data: String?): ChatbotNode {
        val gson = Gson()
        //   Type listType = new TypeToken<List<ChatbotNode>>() {}.getType();
        return gson.fromJson(data, ChatbotNode::class.java)
    }

    @TypeConverter
    fun myObjectsToStoredString(myObjects: ChatbotNode?): String {
        val gson = Gson()
        return gson.toJson(myObjects)
    }
}
