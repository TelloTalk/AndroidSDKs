package com.tilismtech.tellotalksdk.data.db.entities;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CarousalData implements Parcelable {


    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("title")
    @Expose
    private String title;


    protected CarousalData(Parcel in) {
        description = in.readString();
        image = in.readString();
        title = in.readString();
    }

    public static final Creator<CarousalData> CREATOR = new Creator<CarousalData>() {
        @Override
        public CarousalData createFromParcel(Parcel in) {
            return new CarousalData(in);
        }

        @Override
        public CarousalData[] newArray(int size) {
            return new CarousalData[size];
        }
    };

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(description);
        dest.writeString(image);
        dest.writeString(title);
    }
}
