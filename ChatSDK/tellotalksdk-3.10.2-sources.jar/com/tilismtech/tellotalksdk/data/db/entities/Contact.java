package com.tilismtech.tellotalksdk.data.db.entities;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;


@Entity(tableName = "contact")
public class Contact {

    @PrimaryKey
    @NonNull
    @SerializedName("contactId")
    private String contactId;
    @Ignore
    @SerializedName("profileId")
    private String profileId;
    @SerializedName("name")
    private String name;
    @SerializedName("avatar")
    private String avatar;
    @SerializedName("bBlock")
    private Boolean block = false;
    private int status = 0;


    public Contact(@NonNull String contactId, String name, Boolean block, String avatar, int status) {
        this.contactId = contactId;
        this.name = name;
        this.block = block;
        this.avatar = avatar;
        this.status = status;
    }

    @Ignore
    public Contact(@NonNull String contactId, String name) {
        this.contactId = contactId;
        this.name = name;
        block = false;
        this.avatar = "";
    }


    @NonNull
    public String getContactId() {
        return contactId;
    }

    public void setContactId(@NonNull String contactId) {
        this.contactId = contactId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getBlock() {
        return block;
    }

    public void setBlock(Boolean block) {
        this.block = block;
    }

    public String getContactJid() {
        return contactId + "@im.tellotalk.com";
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }
}
