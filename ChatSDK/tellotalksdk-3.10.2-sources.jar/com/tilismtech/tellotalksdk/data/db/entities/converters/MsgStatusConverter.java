package com.tilismtech.tellotalksdk.data.db.entities.converters;

import androidx.room.TypeConverter;

import com.tilismtech.tellotalksdk.data.db.entities.TTMessage;

public class MsgStatusConverter {
    @TypeConverter
    public static TTMessage.MsgStatus toStatus(int status) {
        if (status == TTMessage.MsgStatus.PENDING.ordinal()) {
            return TTMessage.MsgStatus.PENDING;
        } else if (status == TTMessage.MsgStatus.SENT.ordinal()) {
            return TTMessage.MsgStatus.SENT;
        } else if (status == TTMessage.MsgStatus.DELIVERED.ordinal()) {
            return TTMessage.MsgStatus.DELIVERED;
        } else if (status == TTMessage.MsgStatus.RECEIVED.ordinal()) {
            return TTMessage.MsgStatus.RECEIVED;
        } else if (status == TTMessage.MsgStatus.READ.ordinal()) {
            return TTMessage.MsgStatus.READ;
        } else if (status == TTMessage.MsgStatus.COMPRESSING.ordinal()) {
            return TTMessage.MsgStatus.COMPRESSING;
        } else if (status == TTMessage.MsgStatus.UNCOMPRESSED.ordinal()) {
            return TTMessage.MsgStatus.UNCOMPRESSED;
        } else if (status == TTMessage.MsgStatus.ERROR.ordinal()) {
            return TTMessage.MsgStatus.ERROR;
        } else if (status == TTMessage.MsgStatus.UNSEND_LOCATION.ordinal()) {
            return TTMessage.MsgStatus.UNSEND_LOCATION;
        } else {
            throw new IllegalArgumentException("Could not recognize status");
        }
    }

    @TypeConverter
    public static int toInteger(TTMessage.MsgStatus status) {
        if (status == null){
            return 0;
        }
        return status.ordinal();
    }
}