package com.tilismtech.tellotalksdk.data.db.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ChatbotNode {

    @SerializedName("chatBotName")
    @Expose
    private String chatBotName;
    @SerializedName("masterId")
    @Expose
    private String masterId;
    @SerializedName("parentId")
    @Expose
    private Integer parentId;
    @SerializedName("parent")
    @Expose
    private Object parent;
    @SerializedName("appId")
    @Expose
    private String appId;
    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("CarousalData")
    @Expose
    private List<CarousalData> carousalData = null;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("childType")
    @Expose
    private String childType;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("voteImage")
    @Expose
    private String voteImage;
    @SerializedName("voteDescription")
    @Expose
    private String voteDescription;
    @SerializedName("voteData")
    @Expose
    private List<VoteData> voteData = new ArrayList<>();
    @SerializedName("formData")
    @Expose
    private List<FormObject> formData = null;
    @SerializedName("macroData")
    @Expose
    private List<MacroData> macroData = null;
    @SerializedName("childParentId")
    @Expose
    private String childParentId;
    @SerializedName("OwnId")
    @Expose
    private String ownId;
    @SerializedName("children")
    @Expose
    private List<ChatbotChild> children = new ArrayList<>();


    public enum BotType {
        TYPE_OPTIONCHILD("optionChild"),
        TYPE_VOTE("vote"),
        TYPE_TEXT("text"),
        TYPE_PDMESSAGE("pdmessage"),
        TYPE_FORM("form"),
        TYPE_AGENT("agent");

        public String name;

        BotType(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public String getChatBotName() {
        return chatBotName;
    }

    public void setChatBotName(String chatBotName) {
        this.chatBotName = chatBotName;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Object getParent() {
        return parent;
    }

    public void setParent(Object parent) {
        this.parent = parent;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<CarousalData> getCarousalData() {
        return carousalData;
    }

    public void setCarousalData(List<CarousalData> carousalData) {
        this.carousalData = carousalData;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getChildType() {
        return childType;
    }

    public void setChildType(String childType) {
        this.childType = childType;
    }

    public String getType() {
        return type;
    }



    public void setFormData(List<FormObject> formData) {
        this.formData = formData;
    }



    public void setMacroData(List<MacroData> macroData) {
        this.macroData = macroData;
    }

    public List<FormObject> getFormData() {
        return formData;
    }
    public List<MacroData> getMacroData() {
        return macroData;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVoteImage() {
        return voteImage;
    }

    public void setVoteImage(String voteImage) {
        this.voteImage = voteImage;
    }

    public String getVoteDescription() {
        return voteDescription;
    }

    public void setVoteDescription(String voteDescription) {
        this.voteDescription = voteDescription;
    }

    public List<VoteData> getVoteData() {
        return voteData;
    }

    public void setVoteData(List<VoteData> voteData) {
        this.voteData = voteData;
    }

    public String getChildParentId() {
        return childParentId;
    }

    public void setChildParentId(String childParentId) {
        this.childParentId = childParentId;
    }

    public String getOwnId() {
        return ownId;
    }

    public void setOwnId(String ownId) {
        this.ownId = ownId;
    }

    public List<ChatbotChild> getChildren() {
        return children;
    }

    public void setChildren(List<ChatbotChild> children) {
        this.children = children;
    }
}
