package com.tilismtech.tellotalksdk.data.db.entities;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

@Entity(tableName = "departments")
public class Department implements Parcelable {

    @PrimaryKey
    @NonNull
    @SerializedName("id")
    private String dptId;
    @SerializedName("name")
    private String dptName;
    @SerializedName("dType")
    private String dptType;
    @SerializedName("dImage")
    private String dptImage;
    @SerializedName("deptTag")
    private String deptTag;
    @SerializedName("name_u")
    private String name_u;



    public Department() {
    }

    public Department(@NonNull String dptId, String dptName, String dptType, String dptImage,String deptTag,String name_u) {
        this.dptId = dptId;
        this.dptName = dptName;
        this.dptType = dptType;
        this.dptImage = dptImage;
        this.deptTag = deptTag;
        this.name_u = name_u;
    }

    protected Department(Parcel in) {
        dptId = in.readString();
        dptName = in.readString();
        dptType = in.readString();
        dptImage = in.readString();
        deptTag = in.readString();
        name_u = in.readString();
    }

    public static final Creator<Department> CREATOR = new Creator<Department>() {
        @Override
        public Department createFromParcel(Parcel in) {
            return new Department(in);
        }

        @Override
        public Department[] newArray(int size) {
            return new Department[size];
        }
    };

    public String getDptType() {
        return dptType;
    }

    public void setDptType(String dptType) {
        this.dptType = dptType;
    }

    @NonNull
    public String getDptId() {
        return dptId;
    }

    public void setDptId(@NonNull String dptId) {
        this.dptId = dptId;
    }

    public String getDptName() {
        return dptName;
    }

    public void setDptName(String dptName) {
        this.dptName = dptName;
    }

    public String getDptImage() {
        return dptImage;
    }

    public void setDptImage(String dptImage) {
        this.dptImage = dptImage;
    }

    public String getDeptTag() {
        return deptTag;
    }

    public void setDeptTag(String deptTag) {
        this.deptTag = deptTag;
    }

    public String getName_u() {
        return name_u;
    }

    public void setName_u(String name_u) {
        this.name_u = name_u;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(dptId);
        dest.writeString(dptName);
        dest.writeString(dptType);
        dest.writeString(dptImage);
        dest.writeString(deptTag);
        dest.writeString(name_u);
    }
}
