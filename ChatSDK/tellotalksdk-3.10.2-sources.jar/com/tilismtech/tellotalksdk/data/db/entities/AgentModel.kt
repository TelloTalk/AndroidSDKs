package com.tilismtech.tellotalksdk.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.tilismtech.tellotalksdk.data.db.entities.converters.ListConverter
import com.tilismtech.tellotalksdk.data.network.module.register.OtherField

@Entity(tableName = "agents")
@TypeConverters(ListConverter::class)
class AgentModel {
    @PrimaryKey
    @SerializedName("agentId")
    @Expose
    private var agentId: String = ""

    @SerializedName("agentName")
    @Expose
    var agentName: String? = null

    @SerializedName("agentName_U")
    @Expose
    var agentName_U: String? = "رم1"

    @SerializedName("agentAvatar")
    @Expose
    var agentAvatar: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("otherDetail")
    @Expose
    var otherDetails: List<OtherField?>? = null

    constructor()

    constructor(agentId: String, agentName: String?, agentName_U: String?, agentAvatar: String?, status: String?, otherDetails: List<OtherField?>?) {
        this.agentId = agentId
        this.agentName = agentName
        this.agentName_U = agentName_U
        this.agentAvatar = agentAvatar
        this.status = status
        this.otherDetails = otherDetails
    }

    fun getAgentId(): String {
        return agentId!!
    }

    fun setAgentId(agentId: String) {
        this.agentId = agentId
    }
}