package com.tilismtech.tellotalksdk.data.db.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VoteData {


    @SerializedName("voteName")
    @Expose
    private String voteName;
    @SerializedName("voteChecked")
    @Expose
    private String voteChecked;

    public String getVoteName() {
        return voteName;
    }

    public void setVoteName(String voteName) {
        this.voteName = voteName;
    }

    public String getVoteChecked() {
        return voteChecked;
    }

    public void setVoteChecked(String voteChecked) {
        this.voteChecked = voteChecked;
    }
}
