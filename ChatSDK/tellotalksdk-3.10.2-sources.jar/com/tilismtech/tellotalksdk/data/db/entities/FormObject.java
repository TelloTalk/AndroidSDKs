package com.tilismtech.tellotalksdk.data.db.entities;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FormObject implements Parcelable {

    @SerializedName("fieldName")
    @Expose
    private String fieldName;
    @SerializedName("fieldType")
    @Expose
    private String fieldType;

    public FormObject() {
    }

    protected FormObject(Parcel in) {
        fieldName = in.readString();
        fieldType = in.readString();
    }

    public static final Creator<FormObject> CREATOR = new Creator<FormObject>() {
        @Override
        public FormObject createFromParcel(Parcel in) {
            return new FormObject(in);
        }

        @Override
        public FormObject[] newArray(int size) {
            return new FormObject[size];
        }
    };

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fieldName);
        dest.writeString(fieldType);
    }
}
