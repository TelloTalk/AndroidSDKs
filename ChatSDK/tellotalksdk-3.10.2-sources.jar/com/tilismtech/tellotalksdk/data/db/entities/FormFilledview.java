package com.tilismtech.tellotalksdk.data.db.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class FormFilledview {



    private String fieldId;
    private String fieldValue;
    private String fieldType;
    private String fieldLabel;
    private ArrayList<String> fieldOptions;


    public FormFilledview(String fieldId, String fieldValue, String fieldType, String fieldLabel, ArrayList<String> fieldOptions) {
        this.fieldId = fieldId;
        this.fieldValue = fieldValue;
        this.fieldType = fieldType;
        this.fieldLabel = fieldLabel;
        this.fieldOptions = fieldOptions;
    }

    public ArrayList<String> getFieldOptions() {
        return fieldOptions;
    }

    public void setFieldOptions(ArrayList<String> fieldOptions) {
        this.fieldOptions = fieldOptions;
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    public String getFieldLabel() {
        return fieldLabel;
    }

    public void setFieldLabel(String fieldLabel) {
        this.fieldLabel = fieldLabel;
    }
}
