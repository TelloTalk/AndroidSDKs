package com.tilismtech.tellotalksdk.data.db.entities;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;
import androidx.annotation.NonNull;

import com.tilismtech.tellotalksdk.data.db.entities.converters.DateConverter;

@Entity(tableName = "account")
@TypeConverters(DateConverter.class)
        public class TTAccount {

    @PrimaryKey
    @NonNull
    private String userName;
    private String displayName;
    private String avatar;
    private String tokenId;
    private String accessToken;

    @Ignore
    public TTAccount() {

    }

    public TTAccount(@NonNull String userName, String displayName, String avatar, String tokenId,String accessToken) {
        this();
        this.userName = userName;
        this.displayName = displayName;
        this.avatar = avatar;
        this.tokenId = tokenId;
        this.accessToken = accessToken;
    }

    @NonNull
    public String getUserName() {
        return userName;
    }

    public void setUserName(@NonNull String userName) {
        this.userName = userName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getJidString() {
        return this.userName + "@im.tellotalk.com";
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}