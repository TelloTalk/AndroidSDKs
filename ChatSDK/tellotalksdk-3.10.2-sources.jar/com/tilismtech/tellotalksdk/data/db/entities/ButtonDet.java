package com.tilismtech.tellotalksdk.data.db.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ButtonDet {

    @SerializedName(value = "buttonId",alternate = {"bId"})
    @Expose
    private String bId;
    @SerializedName(value = "buttonType",alternate = {"bType"})
    @Expose
    private String bType;
    @SerializedName(value = "buttonLabel",alternate = {"bLabel"})
    @Expose
    private String bLabel;
    @SerializedName(value = "buttonValue",alternate = {"bValue"})
    @Expose
    private String bValue;
    @SerializedName("isSelected")
    @Expose
    private boolean isSelected;
    @SerializedName(value = "buttonKeyValue",alternate = {"bKeyValue"})
    @Expose
    private List<KeyValueModel> keyValueModels;

    public ButtonDet() {
    }

    public List<KeyValueModel> getKeyValueModels() {
        return keyValueModels;
    }

    public void setKeyValueModels(List<KeyValueModel> keyValueModels) {
        this.keyValueModels = keyValueModels;
    }

    public String getBId() {
        return bId;
    }

    public void setBId(String bId) {
        this.bId = bId;
    }

    public String getBType() {
        return bType;
    }

    public void setBType(String bType) {
        this.bType = bType;
    }

    public String getBLabel() {
        return bLabel;
    }

    public void setBLabel(String bLabel) {
        this.bLabel = bLabel;
    }

    public String getBValue() {
        return bValue;
    }

    public void setBValue(String bValue) {
        this.bValue = bValue;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
