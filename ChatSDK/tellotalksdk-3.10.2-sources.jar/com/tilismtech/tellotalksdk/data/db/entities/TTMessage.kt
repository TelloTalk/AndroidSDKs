package com.tilismtech.tellotalksdk.data.db.entities

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.AsyncTask
import android.os.Parcel
import android.os.Parcelable
import android.os.Parcelable.Creator
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName

import com.tilismtech.tellotalksdk.data.db.entities.converters.DateConverter
import com.tilismtech.tellotalksdk.data.db.entities.converters.MsgStatusConverter
import com.tilismtech.tellotalksdk.data.network.NetworkConstants
import com.tilismtech.tellotalksdk.data.repository.TTMessageRepository
import com.tilismtech.tellotalksdk.managers.TelloApiClient.Companion.getInstance
import com.tilismtech.tellotalksdk.managers.http.AesGcmURLStreamHandler
import com.tilismtech.tellotalksdk.managers.http.interfaces.Transferable
import com.tilismtech.tellotalksdk.ui.linkpreview.LinkPreviewCallback
import com.tilismtech.tellotalksdk.ui.linkpreview.SourceContent
import com.tilismtech.tellotalksdk.ui.linkpreview.TextCrawler
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.isEmptyString
import com.tilismtech.tellotalksdk.utils.ApplicationUtils.Companion.timeFormater
import com.tilismtech.tellotalksdk.utils.Constant
import com.tilismtech.tellotalksdk.utils.DownloadableFile
import com.tilismtech.tellotalksdk.utils.FileBackend
import com.tilismtech.tellotalksdk.utils.MimeUtils
import com.tilismtech.tellotalksdk.utils.TelloMediaPlayer.TelloMediaPlayerListner
import java.net.MalformedURLException
import java.net.URL
import java.util.Date
import java.util.Locale
import java.util.UUID

@Entity(tableName = "messages", indices = [Index(value = ["contactId", "systemDate"])])
@TypeConverters(
    DateConverter::class
)
open class TTMessage : TelloMediaPlayerListner, Parcelable {
    @PrimaryKey
    @SerializedName("messageId")
    var messageId: String=UUID.randomUUID().toString()
        set(value) {
            field = value
        }

    @SerializedName("message")
    var message: String? = null
        set(value) {
            field = value
        }

    @SerializedName("msgType")
    
    var msgType: String? = null
        set(value) {
            field = value
        }

    @SerializedName("contactId")
    
    var contactId: String? = null
        set(value) {
            field = value
        }

    @SerializedName("msgStatus")
    @TypeConverters(MsgStatusConverter::class)
    
    var msgStatus: MsgStatus? = null
        set(value) {
            field = value
        }

    @SerializedName("isDeleted")
    
    var isDeleted = false
        set(value) {
            field = value
        }

    @SerializedName("isEdited")
    
    var isEdited = false
        set(value) {
            field = value
        }

    @SerializedName("replyMsgId")
    
    var replyMsgId: String? = null
        set(value) {
            field = value
        }

    @SerializedName("msgDate")
    
    var msgDate: Date? = null
        set(value) {
            field = value
        }

    @SerializedName("systemDate")
    
    var systemDate: Date? = null
        set(value) {
            field = value
        }

    @SerializedName("caption")
    
    var caption: String? = null
        set(value) {
            field = value
        }
    @Ignore
    @Transient
    
    var replyMessage: TTMessage? = null
        set(replyMessage) {
            field = replyMessage
        }

    @Ignore
    @Transient
    
    var transferable: Transferable? = null
        set(value) {
            field = value
            if (field != null) {
                field!!.setMessage(this)
            }
        }
    @Ignore
    @Transient
    
    var progress: Int = 0
        set(progress) {
            field = progress
        }
    @Ignore
    @Transient

    private var audioProgress: MutableLiveData<Int> = MutableLiveData<Int>(0)

    fun getAudioProgressLiveData() : LiveData<Int>{
        return audioProgress
    }

    @Ignore
    @Transient

    var isPlaying: Boolean = false
        set(playing) {
            field = playing
        }

    var isDownloaded = false
        set(value) {
            field = value
        }

    var relativeFilePath: String? = ""
        set(value) {
            field = value

        }


    var transmissionCancelled = false

    @JvmField
    @SerializedName("conversationId")
    var conversationId: String? = null

    @JvmField
    @SerializedName("customData")
    var customData: String? = null

    @JvmField
    @SerializedName("receiverId")
    var receiverId: String? = ""

    @JvmField
    @SerializedName("profileId")
    var profileId: String? = null

    @JvmField
    @SerializedName("chatId")
    var chatId: String? = null

    @JvmField
    @SerializedName("departmentId")
    var departmentId: String? = null

    @JvmField
    @SerializedName("departmentName")
    var departmentName: String? = null

    @JvmField
    @SerializedName("viewId")
    var viewId: String? = null

    @JvmField
    @SerializedName("viewDet")
    var viewDet: String? = null

    @JvmField
    @SerializedName("viewOptionId")
    var viewOptionId: String? = null

    @JvmField
    @SerializedName("originalFileName")
    var originalFileName: String? = null

    @JvmField
    @SerializedName("msgHeading")
    var msgHeading: String? = null

    @JvmField
    @SerializedName("msgURL")
    var msgURL: String? = null

    @JvmField
    @SerializedName("thumbnail")
    var thumbnail: String? = null

    @SerializedName("dType")
    var dptType: String? = Constant.typeAgentChat

    @JvmField
    @SerializedName("buttonDet")
    var button_det: String? = null

    @JvmField
    @SerializedName("isFeedback")
    var isFeedback: Boolean = false

    @JvmField
    @SerializedName("departmentName_u")
    var departmentName_u: String? = null

    @JvmField
    @SerializedName("dImage")
    var dptImage: String? = null

    @JvmField
    @SerializedName("audioLength")
    var audio_Length: String? = null

    @SerializedName("read_count")
    var isRead_count: Boolean = false

    @JvmField
    @SerializedName("campaignId")
    var campaignId: String? = null

    @JvmField
    @SerializedName("msgExpTime")
    var msgExpTime: Date? = null

    @JvmField
    @SerializedName("chatbotNode")
    var chatbotNode: String? = null

    @JvmField
    @SerializedName("chatbotID")
    var chatbotID: String? = null

    @JvmField
    @SerializedName("agentAvatar")
    var agentAvatar: String? = null

    @Ignore
    @Transient
    var file: DownloadableFile? = null

    @Ignore
    @Transient
    var textCrawler: TextCrawler? = null

    @Ignore
    @Transient
    var sourceContent: SourceContent? = null

    @JvmField
    @Ignore
    @Transient
    var maxProgress: Int = 0

    @JvmField
    var displayStatus: Int = 0
    @JvmField
    var isRead: Boolean = false

    protected constructor(`in`: Parcel) {
        messageId = `in`.readString()!!
        contactId = `in`.readString()
        conversationId = `in`.readString()
        message = `in`.readString()
        msgType = `in`.readString()
        isDeleted = `in`.readByte().toInt() != 0
        isEdited = `in`.readByte().toInt() != 0
        replyMsgId = `in`.readString()
        caption = `in`.readString()
        customData = `in`.readString()
        receiverId = `in`.readString()
        profileId = `in`.readString()
        chatId = `in`.readString()
        departmentId = `in`.readString()
        departmentName = `in`.readString()
        viewId = `in`.readString()
        viewDet = `in`.readString()
        viewOptionId = `in`.readString()
        originalFileName = `in`.readString()
        msgHeading = `in`.readString()
        msgURL = `in`.readString()
        thumbnail = `in`.readString()
        dptType = `in`.readString()
        isFeedback = `in`.readByte().toInt() != 0
        departmentName_u = `in`.readString()
        dptImage = `in`.readString()
        audio_Length = `in`.readString()
        isRead_count = `in`.readByte().toInt() != 0
        campaignId = `in`.readString()
        chatbotID = `in`.readString()
        agentAvatar = `in`.readString()
        displayStatus = `in`.readInt()
        isDownloaded = `in`.readByte().toInt() != 0
        relativeFilePath = `in`.readString()
        transmissionCancelled = `in`.readByte().toInt() != 0
        isRead = `in`.readByte().toInt() != 0
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(messageId)
        dest.writeString(contactId)
        dest.writeString(conversationId)
        dest.writeString(message)
        dest.writeString(msgType)
        dest.writeByte((if (isDeleted) 1 else 0).toByte())
        dest.writeByte((if (isEdited) 1 else 0).toByte())
        dest.writeString(replyMsgId)
        dest.writeString(caption)
        dest.writeString(customData)
        dest.writeString(receiverId)
        dest.writeString(profileId)
        dest.writeString(chatId)
        dest.writeString(departmentId)
        dest.writeString(departmentName)
        dest.writeString(viewId)
        dest.writeString(viewDet)
        dest.writeString(viewOptionId)
        dest.writeString(originalFileName)
        dest.writeString(msgHeading)
        dest.writeString(msgURL)
        dest.writeString(thumbnail)
        dest.writeString(dptType)
        dest.writeByte((if (isFeedback) 1 else 0).toByte())
        dest.writeString(departmentName_u)
        dest.writeString(dptImage)
        dest.writeString(audio_Length)
        dest.writeByte((if (isRead_count) 1 else 0).toByte())
        dest.writeString(campaignId)
        dest.writeString(chatbotID)
        dest.writeString(agentAvatar)
        dest.writeInt(displayStatus)
        dest.writeByte((if (isDownloaded) 1 else 0).toByte())
        dest.writeString(relativeFilePath)
        dest.writeByte((if (transmissionCancelled) 1 else 0).toByte())
        dest.writeByte((if (isRead) 1 else 0).toByte())
    }

    enum class MsgType(val value: String) {
        TYPE_TEXT("text"),
        TYPE_IMAGE("image"),
        TYPE_VIDEO("video"),
        TYPE_AUDIO("audio"),
        TYPE_FILE("file"),
        TYPE_LOCATION("location"),
        TYPE_CONTACT("contact"),
        TYPE_DELETED("deleted"),
        TYPE_DATE("date"),
        TYPE_UNREAD("unread"),
        TYPE_CHOICES("choices"),
        TYPE_NEWS("news"),
        TYPE_NEWSWB("newswb"),
        TYPE_CARDVIEWS("cardView"),
        TYPE_INVITE("invite_channel"),
        TYPE_CHATEND("chatEnd"),
        TYPE_CHATBOT("Chatbot"),
        TYPE_TYPING("typing")
    }

    enum class MsgStatus {
        PENDING,
        SENT,
        DELIVERED,
        READ,
        RECEIVED,
        COMPRESSING,
        UNCOMPRESSED,
        ERROR,
        UNSEND_LOCATION
    }


    enum class MsgDisplayStatus {
        NONE,
        READ,
        READ_AND_ACK
    }


    constructor(body: String?="") {
        this.message = body
    }

    constructor(
        messageId: String,
        contactId: String?,
        message: String?,
        msgType: String?,
        msgStatus: MsgStatus?,
        isDeleted: Boolean,
        isEdited: Boolean,
        replyMsgId: String?,
        msgDate: Date?,
        systemDate: Date?,
        caption: String?,
        isDownloaded: Boolean,
        relativeFilePath: String?,
        transmissionCancelled: Boolean,
        isRead: Boolean,
        thumbnail: String?
    ) {
        this.messageId = messageId
        this.message = message
        this.msgStatus = msgStatus
        this.msgDate = msgDate
        this.systemDate = systemDate
        this.caption = caption
        this.relativeFilePath = relativeFilePath
        this.msgType = msgType
        this.isDownloaded = isDownloaded
        this.transmissionCancelled = transmissionCancelled
        this.contactId = contactId
        this.isRead = isRead
        this.thumbnail = thumbnail
        this.isDeleted = isDeleted
        this.isEdited = isEdited
        this.replyMsgId = replyMsgId
    }









    fun setEditedCustom(isEdited: Boolean) {
        this.isEdited = isEdited
    }


    val mimeType: String?
        get() {
            if (relativeFilePath != null) {
                val start = relativeFilePath!!.lastIndexOf('.') + 1
                return if (start < relativeFilePath!!.length) {
                    MimeUtils.guessMimeTypeFromExtension(
                        relativeFilePath!!.substring(start).split("\\|".toRegex())
                            .dropLastWhile { it.isEmpty() }.toTypedArray()[0]
                    )
                } else {
                    ""
                }
            } else {
                if (!caption!!.contains(".")) {
                    try {
                        return MimeUtils.guessMimeTypeFromExtension(
                            extractRelevantExtension(
                                URL(message!!.trim { it <= ' ' })
                            )!!.split("\\|".toRegex())
                                .dropLastWhile { it.isEmpty() }.toTypedArray()[0]
                        )
                    } catch (e: MalformedURLException) {
                        e.printStackTrace()
                    }
                } else {
                    return MimeUtils.guessMimeTypeFromExtension(
                        caption!!.split("\\.".toRegex())
                            .dropLastWhile { it.isEmpty() }.toTypedArray()[1]
                    )
                }
                return ""
            }
        }

    fun treatAsDownloadable(): Boolean {
        if (this.msgType != MsgType.TYPE_FILE.value && this.msgType != MsgType.TYPE_IMAGE.value && this.msgType != MsgType.TYPE_VIDEO.value && this.msgType != MsgType.TYPE_AUDIO.value && this.msgType != MsgType.TYPE_NEWS.value && this.msgType != MsgType.TYPE_NEWSWB.value) {
            return false
        }
        //        if (message != null && message.trim().contains(" ")) {
//            return false;
//        }
        try {
            val url = if (message!!.contains("http")) {
                URL(message)
            } else {
                URL(NetworkConstants.BASE_URL1 + message)
            }
            val ref = url.ref
            val protocol = url.protocol
            val encrypted = ref != null && ref.matches("([A-Fa-f0-9]{2}){48}".toRegex())
            if (!encrypted) {
                return true
            }
            return (AesGcmURLStreamHandler.PROTOCOL_NAME.equals(
                protocol,
                ignoreCase = true
            ) && encrypted)
                    || (("http".equals(protocol, ignoreCase = true) || "https".equals(
                protocol,
                ignoreCase = true
            )) && (encrypted))
        } catch (e: MalformedURLException) {
            return false
        }
    }

    private val baseMessage: TTMessage
        get() = this

    fun setAssets() {
        file = FileBackend.instance!!.getFile(baseMessage)
    }

    fun getAudioLength(replyMessage: TTMessage?): String {
        if (file == null) {
            file = FileBackend.instance!!.getFile(baseMessage)
        }
        if (file!!.exists() && file!!.size > 0) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(getInstance()!!.telloContext, Uri.fromFile(file))
                val timeInmillisec =
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!
                        .toLong()
                return timeFormater(timeInmillisec)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return ""
    }

    fun needsUploading(): Boolean {
        return isFileOrImage && fileParams.url == null
    }

    val isFileOrImage: Boolean
        get() = this.msgType == MsgType.TYPE_FILE.value || this.msgType == MsgType.TYPE_IMAGE.value || this.msgType == MsgType.TYPE_VIDEO.value || this.msgType == MsgType.TYPE_AUDIO.value

    inner class FileParams {
        var url: URL? = null
        var size: Long = 0
        var width: Int = 0
        var height: Int = 0
    }

    val fileParams: FileParams
        get() {
            var params = legacyFileParams
            if (params != null) {
                return params
            }
            params = FileParams()
            if (this.transferable != null) {
                params.size = transferable!!.fileSize
            }
            if (message == null) {
                return params
            }
            val parts =
                message!!.split("\\|".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            when (parts.size) {
                1 -> try {
                    params.size = parts[0].toLong()
                } catch (e: NumberFormatException) {
                    try { //BASE_URL1 +
                        params.url = URL(parts[0])
                    } catch (e1: MalformedURLException) {
                        params.url = null
                    }
                }

                2, 4 -> {
                    try {
                        if (parts[0].contains("http")) {
                            params.url = URL(parts[0])
                        } else {
                            params.url = URL(NetworkConstants.BASE_URL1 + parts[0])
                        }
                    } catch (e1: MalformedURLException) {
                        params.url = null
                    }
                    try {
                        params.size = parts[1].toLong()
                    } catch (e: NumberFormatException) {
                        params.size = 0
                    }
                    try {
                        params.width = parts[2].toInt()
                    } catch (e: NumberFormatException) {
                        params.width = 0
                    } catch (e: ArrayIndexOutOfBoundsException) {
                        params.width = 0
                    }
                    try {
                        params.height = parts[3].toInt()
                    } catch (e: NumberFormatException) {
                        params.height = 0
                    } catch (e: ArrayIndexOutOfBoundsException) {
                        params.height = 0
                    }
                }

                3 -> {
                    try {
                        params.size = parts[0].toLong()
                    } catch (e: NumberFormatException) {
                        params.size = 0
                    }
                    try {
                        params.width = parts[1].toInt()
                    } catch (e: NumberFormatException) {
                        params.width = 0
                    }
                    try {
                        params.height = parts[2].toInt()
                    } catch (e: NumberFormatException) {
                        params.height = 0
                    }
                }
            }
            return params
        }

    private val legacyFileParams: FileParams?
        get() {
            val params = FileParams()
            if (message == null) {
                return params
            }
            val parts =
                message!!.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            if (parts.size == 3) {
                try {
                    params.size = parts[0].toLong()
                } catch (e: NumberFormatException) {
                    return null
                }
                try {
                    params.width = parts[1].toInt()
                } catch (e: NumberFormatException) {
                    return null
                }
                try {
                    params.height = parts[2].toInt()
                } catch (e: NumberFormatException) {
                    return null
                }
                return params
            } else {
                return null
            }
        }

    fun getLinkPreview(repository: TTMessageRepository) {
        try {
            if (sourceContent == null) {
                sourceContent = Gson().fromJson(
                    caption,
                    SourceContent::class.java
                )
                if (isEmptyString(caption) && textCrawler == null && sourceContent == null) {
                    textCrawler = TextCrawler()
                    textCrawler!!.makePreview(object : LinkPreviewCallback {
                        override fun onPre() {
                        }

                        override fun onPos(sourceContent: SourceContent, isNull: Boolean) {
                            if (!isNull) {
                                object : AsyncTask<Void?, Void?, Void?>() {

                                    override fun doInBackground(vararg params: Void?): Void? {
                                        try {
                                            val message = repository.getMessage(messageId)
                                            if (message != null) {
                                                message.caption = Gson().toJson(sourceContent)
                                                repository.updateMessageFileTag(
                                                    message.messageId,
                                                    message.caption
                                                )
                                            }
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }
                                        return null
                                    }
                                }.execute()
                            }
                            textCrawler = null
                        }
                    }, message)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun updateProgress(progress: Int) {
        audioProgress.postValue(progress)
    }

    override fun updateMediaStatus(status: Boolean) {
        isPlaying = status
    }

    val audioSourceAbsolutePath: String
        get() {
            if (!file!!.exists()) {
                return ""
            }
            return file!!.absolutePath
        }

    fun resetMediaState() {
        isPlaying = false
        audioProgress.postValue(0)
        maxProgress = 0
    }

    override fun equals(obj: Any?): Boolean {
        if (this === obj) return true
        if (obj == null || javaClass != obj.javaClass) return false
        val message = obj as TTMessage
        if (this.messageId != message.messageId) return false
        if (msgStatus != message.msgStatus) return false
        if (relativeFilePath != null && relativeFilePath != message.relativeFilePath) return false
        if (msgType != message.msgType) return false
        if (isDownloaded != message.isDownloaded) return false
        if (transmissionCancelled != message.transmissionCancelled) return false
        if (isEdited != message.isEdited) return false
        if (isDeleted != message.isDeleted) return false
        if (contactId != message.contactId) return false
        if (isRead != message.isRead) return false
        if (replyMsgId != null && replyMsgId != message.replyMsgId) return false
        if (caption != null && caption != message.caption) return false
        return if (this.message != null) (this.message == message.message) else message.message == null
    }

    override fun hashCode(): Int {
        var result = messageId.hashCode()
        result = 31 * result + (contactId?.hashCode() ?: 0)
        result = 31 * result + (conversationId?.hashCode() ?: 0)
        result = 31 * result + (message?.hashCode() ?: 0)
        result = 31 * result + (msgType?.hashCode() ?: 0)
        result = 31 * result + (msgStatus?.hashCode() ?: 0)
        result = 31 * result + isDeleted.hashCode()
        result = 31 * result + isEdited.hashCode()
        result = 31 * result + (replyMsgId?.hashCode() ?: 0)
        result = 31 * result + (msgDate?.hashCode() ?: 0)
        result = 31 * result + (systemDate?.hashCode() ?: 0)
        result = 31 * result + (caption?.hashCode() ?: 0)
        result = 31 * result + (customData?.hashCode() ?: 0)
        result = 31 * result + (receiverId?.hashCode() ?: 0)
        result = 31 * result + (profileId?.hashCode() ?: 0)
        result = 31 * result + (chatId?.hashCode() ?: 0)
        result = 31 * result + (departmentId?.hashCode() ?: 0)
        result = 31 * result + (departmentName?.hashCode() ?: 0)
        result = 31 * result + (viewId?.hashCode() ?: 0)
        result = 31 * result + (viewDet?.hashCode() ?: 0)
        result = 31 * result + (viewOptionId?.hashCode() ?: 0)
        result = 31 * result + (originalFileName?.hashCode() ?: 0)
        result = 31 * result + (msgHeading?.hashCode() ?: 0)
        result = 31 * result + (msgURL?.hashCode() ?: 0)
        result = 31 * result + (thumbnail?.hashCode() ?: 0)
        result = 31 * result + (dptType?.hashCode() ?: 0)
        result = 31 * result + (button_det?.hashCode() ?: 0)
        result = 31 * result + isFeedback.hashCode()
        result = 31 * result + (departmentName_u?.hashCode() ?: 0)
        result = 31 * result + (dptImage?.hashCode() ?: 0)
        result = 31 * result + (audio_Length?.hashCode() ?: 0)
        result = 31 * result + isRead_count.hashCode()
        result = 31 * result + (campaignId?.hashCode() ?: 0)
        result = 31 * result + (msgExpTime?.hashCode() ?: 0)
        result = 31 * result + (chatbotNode?.hashCode() ?: 0)
        result = 31 * result + (chatbotID?.hashCode() ?: 0)
        result = 31 * result + (agentAvatar?.hashCode() ?: 0)
        result = 31 * result + (transferable?.hashCode() ?: 0)
        result = 31 * result + (file?.hashCode() ?: 0)
        result = 31 * result + (textCrawler?.hashCode() ?: 0)
        result = 31 * result + (sourceContent?.hashCode() ?: 0)
        result = 31 * result + maxProgress
        result = 31 * result + displayStatus
        result = 31 * result + isDownloaded.hashCode()
        result = 31 * result + (relativeFilePath?.hashCode() ?: 0)
        result = 31 * result + transmissionCancelled.hashCode()
        result = 31 * result + isRead.hashCode()
        return result
    }

    companion object {
        @JvmField
        val CREATOR: Creator<TTMessage?> = object : Creator<TTMessage?> {
            override fun createFromParcel(`in`: Parcel): TTMessage? {
                return TTMessage(`in`)
            }

            override fun newArray(size: Int): Array<TTMessage?> {
                return arrayOfNulls(size)
            }
        }

        private fun extractRelevantExtension(url: URL): String? {
            val path = url.path
            return extractRelevantExtension(path)
        }

        private fun extractRelevantExtension(path: String?): String? {
            if (path.isNullOrEmpty()) {
                return null
            }
            val filename = path.substring(path.lastIndexOf('/') + 1).lowercase(Locale.getDefault())
            val dotPosition = filename.lastIndexOf(".")
            if (dotPosition != -1) {
                val extension = filename.substring(dotPosition + 1)
                // we want the real file extension, not the crypto one
                return if (Transferable.VALID_CRYPTO_EXTENSIONS.contains(
                        extension
                    )
                ) {
                    extractRelevantExtension(filename.substring(0, dotPosition))
                } else {
                    extension
                }
            }
            return null
        }
    }
}