package com.tilismtech.tellotalksdk.data.db.entities;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ChatbotChild implements Parcelable {

    @SerializedName("chatBotName")
    @Expose
    private String chatBotName;
    @SerializedName("masterId")
    @Expose
    private String masterId;
    @SerializedName("parentId")
    @Expose
    private Integer parentId;
    @SerializedName("parent")
    @Expose
    private Object parent;
    @SerializedName("appId")
    @Expose
    private String appId;
    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("CarousalData")
    @Expose
    private List<CarousalData> carousalData;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("childType")
    @Expose
    private String childType;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("voteImage")
    @Expose
    private String voteImage;
    @SerializedName("voteDescription")
    @Expose
    private String voteDescription;
    @SerializedName("VoteData")
    @Expose
    private List<VoteData> voteData ;
    @SerializedName("FormData")
    @Expose
    private List<FormObject> formData;
    @SerializedName("childParentId")
    @Expose
    private String childParentId;
    @SerializedName("OwnId")
    @Expose
    private String ownId;
    @SerializedName("children")
    @Expose
    private List<ChatbotChild> children ;
    @SerializedName("isSelected")
    @Expose
    private boolean isSelected ;
    @SerializedName("isFormSubmitted")
    @Expose
    private boolean isFormSubmitted ;




    public ChatbotChild(){

    }

    protected ChatbotChild(Parcel in) {
        chatBotName = in.readString();
        masterId = in.readString();
        if (in.readByte() == 0) {
            parentId = null;
        } else {
            parentId = in.readInt();
        }
        appId = in.readString();
        clientId = in.readString();
        if (in.readByte() == 0) {
            id = null;
        } else {
            id = in.readInt();
        }
        carousalData = in.createTypedArrayList(CarousalData.CREATOR);
        name = in.readString();
        title = in.readString();
        description = in.readString();
        image = in.readString();
        childType = in.readString();
        type = in.readString();
        voteImage = in.readString();
        voteDescription = in.readString();
        childParentId = in.readString();
        ownId = in.readString();
        children = in.createTypedArrayList(ChatbotChild.CREATOR);
        isSelected = in.readByte() != 0;
        isFormSubmitted = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(chatBotName);
        dest.writeString(masterId);
        if (parentId == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(parentId);
        }
        dest.writeString(appId);
        dest.writeString(clientId);
        if (id == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(id);
        }
        dest.writeTypedList(carousalData);
        dest.writeString(name);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(image);
        dest.writeString(childType);
        dest.writeString(type);
        dest.writeString(voteImage);
        dest.writeString(voteDescription);
        dest.writeString(childParentId);
        dest.writeString(ownId);
        dest.writeTypedList(children);
        dest.writeByte((byte) (isSelected ? 1 : 0));
        dest.writeByte((byte) (isFormSubmitted ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ChatbotChild> CREATOR = new Creator<ChatbotChild>() {
        @Override
        public ChatbotChild createFromParcel(Parcel in) {
            return new ChatbotChild(in);
        }

        @Override
        public ChatbotChild[] newArray(int size) {
            return new ChatbotChild[size];
        }
    };

    public String getChatBotName() {
        return chatBotName;
    }

    public void setChatBotName(String chatBotName) {
        this.chatBotName = chatBotName;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Object getParent() {
        return parent;
    }

    public void setParent(Object parent) {
        this.parent = parent;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<CarousalData> getCarousalData() {
        return carousalData;
    }

    public void setCarousalData(List<CarousalData> carousalData) {
        this.carousalData = carousalData;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getChildType() {
        return childType;
    }

    public void setChildType(String childType) {
        this.childType = childType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVoteImage() {
        return voteImage;
    }

    public void setVoteImage(String voteImage) {
        this.voteImage = voteImage;
    }

    public String getVoteDescription() {
        return voteDescription;
    }

    public void setVoteDescription(String voteDescription) {
        this.voteDescription = voteDescription;
    }

    public List<VoteData> getVoteData() {
        return voteData;
    }

    public void setVoteData(List<VoteData> voteData) {
        this.voteData = voteData;
    }

    public List<FormObject> getFormData() {
        return formData;
    }

    public void setFormData(List<FormObject> formData) {
        this.formData = formData;
    }

    public String getChildParentId() {
        return childParentId;
    }

    public void setChildParentId(String childParentId) {
        this.childParentId = childParentId;
    }

    public String getOwnId() {
        return ownId;
    }

    public void setOwnId(String ownId) {
        this.ownId = ownId;
    }

    public List<ChatbotChild> getChildren() {
        return children;
    }

    public void setChildren(List<ChatbotChild> children) {
        this.children = children;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isFormSubmitted() {
        return isFormSubmitted;
    }

    public void setFormSubmitted(boolean formSubmitted) {
        isFormSubmitted = formSubmitted;
    }
}
