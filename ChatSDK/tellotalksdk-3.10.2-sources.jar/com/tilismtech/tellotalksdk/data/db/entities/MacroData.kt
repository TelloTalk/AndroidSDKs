package com.tilismtech.tellotalksdk.data.db.entities

data class MacroData(
    val appId: String,
    val chatId: String,
    val clientId: String,
    val key: String,
    val ticketId: Int,
    val ticketPriority: String,
    val ticketStatus: String,
    val type: String,
    val value: String
)