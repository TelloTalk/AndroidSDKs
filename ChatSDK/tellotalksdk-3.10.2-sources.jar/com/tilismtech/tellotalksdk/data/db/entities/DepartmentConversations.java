package com.tilismtech.tellotalksdk.data.db.entities;

import androidx.room.Embedded;

public class DepartmentConversations {

    @Embedded
    Department department;

    @Embedded
    TTConversation conversation;

    public DepartmentConversations() {
    }

    public DepartmentConversations(Department department, TTConversation conversation) {
        this.department = department;
        this.conversation = conversation;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public TTConversation getConversation() {
        return conversation;
    }

    public void setConversation(TTConversation conversation) {
        this.conversation = conversation;
    }
}
