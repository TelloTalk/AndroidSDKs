package com.tilismtech.tellotalksdk.data.db

import android.content.Context
import androidx.room.Room
import com.tilismtech.tellotalksdk.data.db.dao.ContactDao
import com.tilismtech.tellotalksdk.data.db.dao.DepartmentDao
import com.tilismtech.tellotalksdk.data.db.dao.MessageReceiptDao
import com.tilismtech.tellotalksdk.data.db.dao.PreferenceDao
import com.tilismtech.tellotalksdk.data.db.dao.TTAccountDao
import com.tilismtech.tellotalksdk.data.db.dao.TTAgentDao
import com.tilismtech.tellotalksdk.data.db.dao.TTConversationDao
import com.tilismtech.tellotalksdk.data.db.dao.TTMessageDao
import com.tilismtech.tellotalksdk.utils.TelloConfig

/**
 * Created by lpt-034 on 14/01/2019.
 */
class DaoManager private constructor(context: Context) {
    private val database: AppDatabase

    init {
        database =
            Room.databaseBuilder(context, AppDatabase::class.java, TelloConfig.DATABASE_NAME)
                .addMigrations(
                    AppDatabase.MIGRATION_1_2,
                    AppDatabase.MIGRATION_2_3,
                    AppDatabase.MIGRATION_3_4,
                    AppDatabase.MIGRATION_4_5,
                    AppDatabase.MIGRATION_5_6,
                    AppDatabase.MIGRATION_6_7,
                    AppDatabase.MIGRATION_7_8,
                    AppDatabase.MIGRATION_8_9,
                    AppDatabase.MIGRATION_9_10,
                    AppDatabase.MIGRATION_10_11,
                    AppDatabase.MIGRATION_11_12,
                    AppDatabase.MIGRATION_12_13,
                    AppDatabase.MIGRATION_13_14,
                    AppDatabase.MIGRATION_14_15,
                    AppDatabase.MIGRATION_15_16,
                    AppDatabase.MIGRATION_17_18,
                    AppDatabase.MIGRATION_19_20,
                    AppDatabase.MIGRATION_20_21,
                    AppDatabase.MIGRATION_22_23,
                    AppDatabase.MIGRATION_24_25
                )
                .allowMainThreadQueries().fallbackToDestructiveMigration(true).build()
    }

    fun clearDb() {
        database.clearDb()
    }

    val tTAccountDao: TTAccountDao
        get() = database.accountDao()
    val tTMessageDao: TTMessageDao
        get() = database.ttMessageDao()
    val preferenceDao: PreferenceDao
        get() = database.preferenceDao()
    val tTConversationDao: TTConversationDao
        get() = database.ttConversationDao()
    val contactDao: ContactDao
        get() = database.contactDao()
    val messageReceiptDao: MessageReceiptDao
        get() = database.messageReceiptDao()
    val departmentDao: DepartmentDao
        get() = database.departmentDao()
    val agentDao: TTAgentDao
        get() = database.agentModelDao()


    companion object {
        @JvmStatic
        var instance: DaoManager? = null
            private set

        @JvmStatic
        fun instantiate(application: Context) {
            if (instance == null) {
                instance = DaoManager(application)
            }
        }
    }
}
