package com.tilismtech.tellotalksdk.data.network;


public class NetworkConstants {

//
    public static final String BASE_URL1 = "https://chatapi.tilismcast.com";
    public static final String BASE_URL = "https://chatapi.tilismcast.com/sdkapp/";
    public static final String BASE_URL_STAGING = "https://chatapi-staging.tilismcast.com/sdkapp/";
    public static final String SOCKET_URL = "https://client-socket.tilismcast.com/";
    public static final String BASE_IMAGE = "https://chatapi.tilismcast.com/chatsdk";

    //only used for token fetch and clear.
    public static final String NOTIFICATION_URL = "https://notification-api.tellocast.com/";

    public static String LOCAL_SOCKET_URL = "http://192.168.18.201:3001/";


}
