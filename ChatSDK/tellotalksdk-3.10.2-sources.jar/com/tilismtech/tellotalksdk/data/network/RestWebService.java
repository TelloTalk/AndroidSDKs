package com.tilismtech.tellotalksdk.data.network;

import com.tilismtech.tellotalksdk.data.network.module.responses.AgentDetailResponse;
import com.tilismtech.tellotalksdk.data.network.module.responses.AgentListResponse;
import com.tilismtech.tellotalksdk.data.network.module.requests.BlockContactRequest;
import com.tilismtech.tellotalksdk.data.network.module.responses.BlockContactResponse;
import com.tilismtech.tellotalksdk.data.network.module.responses.BlockListResponse;
import com.tilismtech.tellotalksdk.data.network.module.requests.ChatFormRequest;
import com.tilismtech.tellotalksdk.data.network.module.responses.ChatFormResponse;
import com.tilismtech.tellotalksdk.data.network.module.requests.FeedBackRequest;
import com.tilismtech.tellotalksdk.data.network.module.responses.FeedBackResponse;
import com.tilismtech.tellotalksdk.data.network.module.responses.FileUploadResponse;
import com.tilismtech.tellotalksdk.data.network.module.responses.FormSubmitResponse;
import com.tilismtech.tellotalksdk.data.network.module.newMessages.AgentMessageResponse;
import com.tilismtech.tellotalksdk.data.network.module.requests.SendFeedBackRequest;
import com.tilismtech.tellotalksdk.data.network.module.requests.SendWcRatingRequest;
import com.tilismtech.tellotalksdk.data.network.module.responses.SendWebMessageResponse;
import com.tilismtech.tellotalksdk.data.network.module.requests.SubmitChatFormRequest;
import com.tilismtech.tellotalksdk.data.network.module.responses.SubmittedFormResponse;
import com.tilismtech.tellotalksdk.data.network.module.requests.TTMessageReceipt;
import com.tilismtech.tellotalksdk.data.network.module.requests.TokenAPIRequest;
import com.tilismtech.tellotalksdk.data.network.module.requests.UpdateTokenRequest;
import com.tilismtech.tellotalksdk.data.network.module.register.RegisterUserObject;
import com.tilismtech.tellotalksdk.data.db.entities.Department;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface RestWebService {

    @Headers("isAuthorizable: true")
    @POST("V2/register/")
    Call<Map<String, Object>> registerUser(@Header("Token") String token, @Body RegisterUserObject registerUserObject);

    @Multipart
    @POST("user/setavatar/{profileId}")
    Call<FileUploadResponse> postImage(@Path("profileId") String profileId, @Part MultipartBody.Part image);

    @Headers("isAuthorizable: true")
    @Multipart
    @POST("V2/uploadfile/{profileId}")
    Call<FileUploadResponse> uploadFile(@Header("Token") String token, @Path("profileId") String profileId, @Part MultipartBody.Part image);

    //  @GET("user/getuser/{profileId}")
    //  Call<RegisterUserObject> getUser(@Path("profileId") String profileId);
    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getuser")
    Call<Map<String, Object>> getUser(@Header("Token") String token, @Field("profileId") String profileId);

    //  @GET("user/login/{profileId}")
    // Call<Map<String, Object>> login(@Path("profileId") String profileId);
    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/login")
    Call<Map<String, Object>> login(@Header("Token") String token, @Field("profileId") String profileId);

    @Headers("isAuthorizable: true")
    @GET("user/getBlockList/{profileId}")
    Call<List<BlockListResponse>> getBlockedContacts(@Path("profileId") String profileId);


    @POST("user/blockcontact")
    Call<BlockContactResponse> blockContact(@Body BlockContactRequest blockContactRequest);
    @Headers("isAuthorizable: true")
    @POST("V2/updateToken")
    Call<Void> updateToken(@Header("Token") String token, @Body UpdateTokenRequest message);


    // For Corporate Channels
    //getCorporateListnew
    //getCorporateList
    //getCorporateListwow
    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getCorporateList")
    Call<List<Department>> getCorporateList(@Header("Token") String token, @Field("profileId") String profileId);

    @Headers("isAuthorizable: true")
    @POST("V2/sendwebmsg/")
    Call<SendWebMessageResponse> sendWebMessage(@Header("Token") String token, @Body RequestBody params);


    @Headers("isAuthorizable: true")
    @POST("V2/sendwebmsg/")
    Call<SendWebMessageResponse> sendChatbotMessage(@Header("Token") String token, @Body RequestBody params);


    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getwebmsg")
    Call<AgentMessageResponse> getWebMessage(@Header("Token") String token, @Field("profileId") String profileId);

    // @GET("message/getwebmsg/{profileId}")
    // Call<AgentMessageResponse> getWebMessage(@Path("profileId") String profileId);
    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/gethistorymsgs")
    Call<AgentMessageResponse> gethistorymsgs(@Header("Token") String token, @Field("profileId") String profileId);

    @POST("message/history")
    Call<AgentMessageResponse> getPreviousMessages(@Body Map<String,String> body);

    @GET("configuration/getCorporateList")
    Call<List<Department>> getCorporateList();

    @GET("agent/other-detail")
    Call<AgentDetailResponse> getagentdetail(@Query("profileId") String profileId);

    //  @GET("message/gethistorymsgs/{profileId}")
    //  Call<AgentMessageResponse> gethistorymsgs(@Path("profileId") String profileId);
    @Headers("isAuthorizable: true")
    @POST("V2/wcRating")
    Call<ResponseBody> sendwcRating(@Header("Token") String token, @Body SendWcRatingRequest sendWcRatingRequest);

    @Headers("isAuthorizable: true")
    @POST("V2/bykeaRating")
    Call<ResponseBody> sendwcFeedbackRating(@Header("Token") String token, @Body SendFeedBackRequest sendWcRatingRequest);

    //  @GET("message/endWebChat/{profileId}")
    //  Call<ResponseBody> endWebChat(@Path("profileId") String profileId);
    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/endWebChat")
    Call<ResponseBody> endWebChat(@Header("Token") String token, @Field("profileId") String profileId, @Field("chatId") String chatId);


    @Headers("isAuthorizable: true")
    @POST("V2/weback")
    Call<List<TTMessageReceipt>> sendWebAck(@Header("Token") String token, @Body List<TTMessageReceipt> ttMessageReceiptList);


    @Headers("isAuthorizable: true")
    @POST("V2/bcack")
    Call<List<TTMessageReceipt>> sendBcAck (@Header("Token") String token, @Body List<TTMessageReceipt> ttMessageReceiptList);



    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getbcmsg")
    Call<AgentMessageResponse> getAnnouncement(@Header("Token") String token, @Field("profileId") String profileId, @Field("departmentId") String departmentId);


    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getrtime")
    Call<ResponseBody> getrtime(@Header("Token") String token, @Field("profileId") String profileId);

    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getavailableagent")
    Call<AgentListResponse> getavailableagent(@Header("Token") String token, @Field("profileId") String profileId, @Field("departmentId") String departmentId);

    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/gettoken")
    Call<ResponseBody> gettoken(@Header("Token") String token, @Field("profileId") String profileId);

    @Headers("isAuthorizable: true")
    @POST("V2/getfeedbacksetting")
    Call<FeedBackResponse> getFeedBackSetting(@Header("Token") String token, @Body FeedBackRequest feedBackRequest);

    @Headers("isAuthorizable: true")
    @POST("V2/getformfields")
    Call< ChatFormResponse> getChatRequestForms(@Header("Token") String token, @Body ChatFormRequest chatFormRequest);

    @POST("legacy/submit-form")
    Call<FormSubmitResponse> submitFormRequest(@Body SubmitChatFormRequest chatFormRequest);

    @Headers("isAuthorizable: true")
    @FormUrlEncoded
    @POST("V2/getformdata")
    Call<SubmittedFormResponse> getformdata(@Header("Token") String token,@Field("profileId") String profileId, @Field("formDataId") String formDataId);

    @Headers("isAuthorizable: false")
    @POST
    Call<ResponseBody> updateBulkToken(
            @Header("Authorization") String header,
            @Url String url,
            @Body TokenAPIRequest tokenAPIRequest);

    @Headers("isAuthorizable: false")
    @FormUrlEncoded
    @HTTP(method = "DELETE", hasBody = true)
    Call<ResponseBody> removeBulkToken(
            @Header("Authorization") String header,
            @Url String url,
            @Field("profileId") String profileId);

}
