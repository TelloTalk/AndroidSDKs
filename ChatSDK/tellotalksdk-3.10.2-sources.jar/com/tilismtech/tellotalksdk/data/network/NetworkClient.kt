package com.tilismtech.tellotalksdk.data.network

import android.util.Base64
import android.util.Log
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.tilismtech.tellotalksdk.BuildConfig
import com.tilismtech.tellotalksdk.data.network.module.newMessages.AgentMessageResponse
import com.tilismtech.tellotalksdk.data.network.module.receipt.ReceiptModel
import com.tilismtech.tellotalksdk.data.network.module.register.OtherField
import com.tilismtech.tellotalksdk.data.network.module.register.RegisterUserObject
import com.tilismtech.tellotalksdk.data.network.module.requests.TTWebMessagaRequest
import com.tilismtech.tellotalksdk.data.network.module.typing.TypingObject
import com.tilismtech.tellotalksdk.data.repository.TTAccountRepository
import com.tilismtech.tellotalksdk.managers.TelloApiClient
import com.tilismtech.tellotalksdk.utils.CryptoLib
import com.tilismtech.tellotalksdk.utils.DateDeserializer
import io.socket.client.Ack
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Dispatcher
import okhttp3.Interceptor
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.net.CookieManager
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

class NetworkClient private constructor() {

    private var socket: Socket? = null
    private lateinit var authParams: String
    private var shouldReconnect = true
    val isDebuggable = BuildConfig.DEBUG

    companion object {
        private var instance: NetworkClient? = null

        const val TYPING_EVENTS = "incomingTypingStatus"
        const val CHAT_ENDED_EVENT = "chatEnded"
        const val RECEIPT_EVENTS = "newReceipt"
        const val MESSAGE_EVENTS = "newMessage"
        @JvmStatic
        @JvmOverloads
        fun getInstance(authParams: String? = ""): NetworkClient {
            if (instance == null) {
                instance = NetworkClient()
                instance?.authParams = authParams.toString()
            }
            return instance!!
        }
    }

    fun getService(): RestWebService {
        val dispatcher = Dispatcher()
        dispatcher.maxRequests = 2
        val okHttpClient = OkHttpClient().newBuilder().addInterceptor { chain: Interceptor.Chain ->
            val request = chain.request()
            val isAuthorized = request.headers["isAuthorizable"] == "true"
            val re = request.newBuilder().removeHeader("isAuthorizable").removeHeader("Content-Length")
            if (isAuthorized) {
                re.addHeader(
                    "Authorization", Base64.encodeToString(authParams.toByteArray(), Base64.NO_WRAP)
                )
            }
            chain.proceed(re.build())
        }.connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS).dispatcher(dispatcher)
            .retryOnConnectionFailure(true)



        if (isDebuggable) {
            okHttpClient.addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
        }
        val gson = GsonBuilder().registerTypeAdapter(Date::class.java, DateDeserializer())
            .enableComplexMapKeySerialization().serializeNulls().setDateFormat(DateFormat.LONG)
            .setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).setPrettyPrinting()
            .setVersion(1.0).create()
        val retrofit =
            Retrofit.Builder().client(okHttpClient.build()).baseUrl(NetworkConstants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson)).build()
        return retrofit.create(RestWebService::class.java)

    }

    private var auth: String = ""
    private fun getAuth(): String {
        if (auth.isEmpty()) {
            auth = CryptoLib.instance?.encryptRsa(instance?.authParams ?: "") ?: ""
        }
        return auth
    }

    fun getMessages(): RestWebService {
        val dispatcher = Dispatcher()
        dispatcher.maxRequests = 2
        val okHttpClient = OkHttpClient().newBuilder().addInterceptor { chain: Interceptor.Chain ->
            val request = chain.request().apply {

            }
            val requestBuilder = request.newBuilder().addHeader(
                "Authorization", getAuth()
            )
            chain.proceed(requestBuilder.build())
        }.connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS).dispatcher(dispatcher)

        if (isDebuggable) {
            okHttpClient.addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
        }
        val gson = GsonBuilder().registerTypeAdapter(Date::class.java, DateDeserializer())
            .enableComplexMapKeySerialization().serializeNulls().setDateFormat(DateFormat.LONG)
            .setVersion(1.0).create()
        val retrofit = Retrofit.Builder().client(okHttpClient.build()).baseUrl(NetworkConstants.SOCKET_URL)
            .addConverterFactory(GsonConverterFactory.create(gson)).build()
        return retrofit.create(RestWebService::class.java)

    }

    private fun createSocket() {
        val client = OkHttpClient.Builder().build()
        try {
            if (socket != null) {
                socket?.off()
                socket?.disconnect()
            }
            val okHttpClient = OkHttpClient.Builder()
                .cookieJar(JavaNetCookieJar(CookieManager()))
                .build()
            val options = IO.Options().apply {
                reconnection = true
                reconnectionAttempts = Int.MAX_VALUE
                reconnectionDelay = 500
                reconnectionDelayMax = 5000
                timeout = 20000
                forceNew = true
                transports = arrayOf("websocket")
                auth = mapOf(
                    "token" to CryptoLib.instance?.encryptRsa(
                        TelloApiClient.getInstance()?.getAccount()?.userName ?: ""
                    ), "authorization" to getAuth()
                )
                callFactory = okHttpClient
                webSocketFactory = okHttpClient
            }

            socket = IO.socket(NetworkConstants.SOCKET_URL, options)
        } catch (e: Exception) {
            Log.d("exceptionConn", e.localizedMessage.toString())
        }
        socket?.onAnyOutgoing {
            it.forEach {
                if(isDebuggable)
                Log.d("eventOut", it?.toString() ?: "")
            }
        }
        socket?.on("error") {
            Log.d("errorAck", it.getOrNull(0).toString())
        }
        socket?.on(Socket.EVENT_DISCONNECT) {
            Log.d("eventDis", it.getOrNull(0).toString())
        }
    }

    fun connect(callback: (() -> Unit)? = {}) {
        createSocket()
        var timer = 0
        socket?.off(Socket.EVENT_CONNECT)
        socket?.on(Socket.EVENT_CONNECT) {
            Log.d("evenConn", it?.getOrNull(0)?.toString() ?: "")
            socket?.off("authorized")
            socket?.on("authorized") {
                Log.d("authorized", "")
                callback?.invoke()
            }
//            callback?.invoke()
//            newMessage(onNewMessageCallBack)
//            newReceipt(onNewReceiptCallBack)
        }
        socket?.connect()
        CoroutineScope(Dispatchers.IO).launch {
            while (timer<=3){
                delay(1000)
                timer+=1
                if(!isConnected() && timer==3){
                    callback?.invoke()
                }
            }
        }
    }

    private fun connectionError(callback: (it: JSONObject) -> Unit) {
        socket?.off(Socket.EVENT_CONNECT_ERROR)
        socket?.on(Socket.EVENT_CONNECT_ERROR) {
            Log.d("eventConnErr", it.joinToString(separator = "|"))
        }
    }

    var onNewMessageCallBack: ((it: AgentMessageResponse?) -> Unit) = {}
    var onNewReceiptCallBack: ((it: ReceiptModel?) -> Unit) = {}
    var onTypingCallBack: ((it: TypingObject?) -> Unit) = {}

    fun newMessage(callback: (it: AgentMessageResponse?) -> Unit) {
        onNewMessageCallBack = callback
        socket?.off(MESSAGE_EVENTS)
        socket?.on(MESSAGE_EVENTS) {
            if(isDebuggable)
            Log.d(MESSAGE_EVENTS, it.getOrNull(0).toString())
            val response = AgentMessageResponse()
            response.messages = arrayListOf<TTWebMessagaRequest>().apply {
                add(
                    Gson().fromJson(
                        it?.getOrNull(0).toString(), TTWebMessagaRequest::class.java
                    )
                )
            }

            onNewMessageCallBack(response)
        }
    }

    fun newReceipt(callback: (it: ReceiptModel?) -> Unit) {
        onNewReceiptCallBack = callback
        socket?.off(RECEIPT_EVENTS)
        socket?.on(RECEIPT_EVENTS) {
            if(isDebuggable)
            Log.d(RECEIPT_EVENTS, it.getOrNull(0).toString())
            val response = Gson().fromJson(it.getOrNull(0).toString(), ReceiptModel::class.java)
            onNewReceiptCallBack(response)
        }
    }

    fun typing(callback: (it: TypingObject?) -> Unit) {
        onTypingCallBack = callback
        socket?.off(TYPING_EVENTS)
        socket?.on(TYPING_EVENTS) {
            if(isDebuggable)
            Log.d(TYPING_EVENTS, it.getOrNull(0).toString())
            val response = Gson().fromJson(it.getOrNull(0).toString(), TypingObject::class.java)
            onTypingCallBack(response)
        }
    }

    var reconnectBeforeRegister = false
    fun <T : Any> emit(payload: T, method: String, callback: (it: JSONObject) -> Unit) {
        if (!isConnected() || !reconnectBeforeRegister) {
            connect {
                if(!isConnected()){
                    callback.invoke(JSONObject().put("error","Connection failed"))
                    return@connect
                }
                reconnectBeforeRegister = true
                emit(payload, method, callback)
            }
        } else {
            socket?.emit(method, JSONObject(Gson().toJson(payload)), Ack {
                try {
                    if(isDebuggable)
                    Log.d("$method\\Ack", it.getOrNull(0).toString())
                    val statusCode =
                        JSONObject(it.getOrNull(0).toString()).getString("statusCode")
                    if (statusCode == "401") {
                        validateSession {
                            emit(payload, method, callback)
                        }
                    } else {
                        callback(JSONObject(it.getOrNull(0).toString()))
                    }
                } catch (e: Exception) {
//                    callback(JSONObject().put("error",e.localizedMessage.toString()))
                    Log.e("emiiter", e.localizedMessage.toString())
                }
            })
        }
        connectionError(callback)
    }


    fun disconnect() {
        shouldReconnect = false
        socket?.disconnect()
    }

    private fun isConnected(): Boolean {
        return socket?.connected() ?: false
    }

    private fun validateSession(failedCall: () -> Unit) {
        val account = TelloApiClient.getInstance()?.getAccount()
        val registerUserModel = RegisterUserObject(
            "123423456734567",
            "4567845674567",
            "Development",
            "A",
            "m.fawwaz.faial@gmail.com",
            "01-01-2024",
            "03001234567",
            account?.displayName,
            arrayListOf(OtherField("CNIC", "42101")),
            account?.userName,
            "12345678"
        )
        emit(registerUserModel, "register") {
            val statusCode = it.getString("statusCode")
            if (statusCode == "200") {
                val ttAccount = TelloApiClient.getInstance()?.getAccount()
                ttAccount?.accessToken = it.getJSONObject("data").getString("legacyToken")
                TTAccountRepository.getInstance().insertAccount(ttAccount)
                TelloApiClient.getInstance()?.setCurrentAccount(ttAccount)
                failedCall()
            } else {
                if (statusCode != "429") {
                    CoroutineScope(Dispatchers.IO).launch {
                        delay(30000)
                        validateSession(failedCall)
                    }
                }
            }
        }
    }

    fun stopListener(eventName:String){
        while (instance?.socket?.hasListeners(eventName) == true){
            instance?.socket?.off(eventName)
        }
    }

}