package com.tilismtech.tellotalksdk.data.network.module.newMessages

data class ChatBotMessageResponse(
    val chatBotMsg: Boolean,
    val chatId: String?="",
    val chatbotID: String?="",
    val chatbotNode: ChatbotNode,
    var chatbotNodeId: Int,
    val customData: String?="",
    val departmentId: Int,
    val isDeleted: Boolean?=false,
    val isEdited: Boolean?=false,
    val message: String?="",
    val messageId: String?="",
    val msgDate: Long,
    val msgType: String?="",
    val profileId: String?="",
    val receiverId: String?="",
    val sentDate: Long?=0L,
    val viewId: String?=""
)