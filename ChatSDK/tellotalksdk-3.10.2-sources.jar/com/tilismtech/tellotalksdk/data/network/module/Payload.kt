package com.tilismtech.tellotalksdk.data.network.module

import com.google.gson.annotations.SerializedName
import kotlinx.serialization.Serializable

@Serializable
data class Payload(
    @SerializedName("body")
    var body: String? = null,
    @SerializedName("departmentId")
    var departmentId: String? = null,
    @SerializedName("profileId")
    var profileId: String? = null,
    @SerializedName("title")
    var title: String? = null,
    @SerializedName("type")
    var type: String? = null,
    @SerializedName("image")
    var image: String? = null
)