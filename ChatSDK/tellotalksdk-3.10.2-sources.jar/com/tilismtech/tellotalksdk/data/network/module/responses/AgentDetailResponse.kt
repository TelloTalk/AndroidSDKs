package com.tilismtech.tellotalksdk.data.network.module.responses

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.tilismtech.tellotalksdk.data.network.module.register.OtherField

class AgentDetailResponse protected constructor(`in`: Parcel) : Parcelable {
    @SerializedName("agentId")
    @Expose
    var agentId: String? = `in`.readString()

    @SerializedName("profileName")
    @Expose
    var profileName: String? = `in`.readString()

    @SerializedName("profileName_u")
    @Expose
    var profileName_U: String? = `in`.readString()

    @SerializedName("avatar")
    @Expose
    var avatar: String? = `in`.readString()

    @SerializedName("isSupervisor")
    @Expose
    var isSupervisor: String? = `in`.readString()

    @SerializedName("status")
    @Expose
    var status: String? = `in`.readString()

    @SerializedName("ipAddress")
    @Expose
    var ipAddress: String? = `in`.readString()

    @SerializedName("otherDetail")
    @Expose
    var otherDetails: List<OtherField?>? = null

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(agentId)
        dest.writeString(profileName)
        dest.writeString(profileName_U)
        dest.writeString(avatar)
        dest.writeString(isSupervisor)
        dest.writeString(status)
        dest.writeString(ipAddress)
    }

    companion object {
        @JvmField
        val CREATOR: Parcelable.Creator<AgentDetailResponse?> =
            object : Parcelable.Creator<AgentDetailResponse?> {
                override fun createFromParcel(`in`: Parcel): AgentDetailResponse {
                    return AgentDetailResponse(`in`)
                }

                override fun newArray(size: Int): Array<AgentDetailResponse?> {
                    return arrayOfNulls<AgentDetailResponse>(size)
                }
            }
    }
}
