package com.tilismtech.tellotalksdk.data.network.module.requests;


import com.google.gson.annotations.SerializedName;

public class SendWcRatingRequest {

    @SerializedName("profileId")
    private String profileId;
    @SerializedName("chatId")
    private int chatId;
    @SerializedName("optionId")
    private int optionId;
    @SerializedName("comments")
    private String comments;

    public SendWcRatingRequest() {
    }

    public SendWcRatingRequest(String profileId,int chatId, int optionId, String comments) {
        this.chatId = chatId;
        this.optionId = optionId;
        this.comments = comments;
        this.profileId = profileId;
    }

    public int getChatId() {
        return chatId;
    }

    public void setChatId(int chatId) {
        this.chatId = chatId;
    }

    public int getOptionId() {
        return optionId;
    }

    public void setOptionId(int optionId) {
        this.optionId = optionId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }
}
