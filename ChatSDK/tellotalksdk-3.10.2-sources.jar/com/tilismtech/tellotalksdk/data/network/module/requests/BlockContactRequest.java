package com.tilismtech.tellotalksdk.data.network.module.requests;


import com.google.gson.annotations.SerializedName;

/**
 * Created by lpt-034 on 07/01/2019.
 */

public class BlockContactRequest {

    @SerializedName("profileId")
    private String profileId;
    @SerializedName("name")
    private String name;
    @SerializedName("contactId")
    private String contactId;
    @SerializedName("bBlock")
    private boolean bBlock;

    public BlockContactRequest(String profileId, String name, String contactId, boolean bBlock) {
        this.profileId = profileId;
        this.name = name;
        this.contactId = contactId;
        this.bBlock = bBlock;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public boolean isbBlock() {
        return bBlock;
    }

    public void setbBlock(boolean bBlock) {
        this.bBlock = bBlock;
    }
}
