package com.tilismtech.tellotalksdk.data.network.module.sendMessage.response

import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode

data class MessageResponseModel(
    val profileId: String? = "",
    val statusCode: String? = "",
    val receiverId: String?="",
    val messageId: String? = "",
    val message: Any? = null,
    val msgType: String? = "",
    val viewObject: String? = "",
    val isDeleted: Boolean?=false,
    val isEdited: Boolean?=false,
    val replyMsgId: String? = "",
    val msgDate: Long?=0,
    val sentDate: Long?=0,
    val caption: String? = "",
    val thumbnail: String? = "",
    val customData: String? = "",
    val departmentid: String? = "",
    val chatId: String? = "",
    val msgHeading: String? = "",
    val originalFileName: String?="",
    val viewId: String?="",
    val viewOptionId: String?="",
    val msgURL: String?="",
    val buttonDet: List<String>? = listOf(),
    val departmentName: String? = "",
    val departmentName_u: String? = "",
    val dType: String? = "",
    val departmentType: String? = "",
    val campaignId: String?= "",
    val msgExpTime: String? = "",
    val chatbotID: String? = "",
    val agentAvatar: String? = "",
    val chatbotNode: ChatbotNode? = ChatbotNode()
)

