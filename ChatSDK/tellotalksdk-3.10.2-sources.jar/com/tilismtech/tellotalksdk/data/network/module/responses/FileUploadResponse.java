package com.tilismtech.tellotalksdk.data.network.module.responses;


import com.google.gson.annotations.SerializedName;

/**
 * Created by lpt-034 on 07/01/2019.
 */

public class FileUploadResponse {

    @SerializedName("path")
    private String path;

    public FileUploadResponse(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
