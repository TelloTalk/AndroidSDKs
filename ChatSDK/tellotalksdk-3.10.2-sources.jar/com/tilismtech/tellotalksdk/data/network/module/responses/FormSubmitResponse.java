package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FormSubmitResponse {

    @SerializedName("FormMastId")
    @Expose
    private String formMastId;

    public String getFormMastId() {
        return formMastId;
    }

    public void setFormMastId(String formMastId) {
        this.formMastId = formMastId;
    }
}
