package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SubmittedFormFieldResponse {

    @SerializedName("fieldId")
    @Expose
    private String fieldId;
    @SerializedName("fieldValue")
    @Expose
    private Object fieldValue;
    @SerializedName("fieldType")
    @Expose
    private String fieldType;
    @SerializedName("addToChat")
    @Expose
    private Object addToChat;
    @SerializedName("isInternal")
    @Expose
    private Object isInternal;
    @SerializedName("fieldName")
    @Expose
    private String fieldName;
    @SerializedName("fieldOptions")
    @Expose
    private List<FieldOptionResponse> fieldOptions;

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public Object getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(Object fieldValue) {
        this.fieldValue = fieldValue;
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    public Object getAddToChat() {
        return addToChat;
    }

    public void setAddToChat(Object addToChat) {
        this.addToChat = addToChat;
    }

    public Object getIsInternal() {
        return isInternal;
    }

    public void setIsInternal(Object isInternal) {
        this.isInternal = isInternal;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public List<FieldOptionResponse> getFieldOptions() {
        return fieldOptions;
    }

    public void setFieldOptions(List<FieldOptionResponse> fieldOptions) {
        this.fieldOptions = fieldOptions;
    }
}
