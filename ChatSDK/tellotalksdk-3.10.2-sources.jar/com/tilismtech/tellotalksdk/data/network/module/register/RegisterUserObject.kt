package com.tilismtech.tellotalksdk.data.network.module.register

import com.tilismtech.tellotalksdk.BuildConfig

data class RegisterUserObject(
    val cnic: String? = "",
    val consignmentNumber: String? = "",
    val customerType: String? = "",
    val deviceType: String? = "",
    val email: String? = "",
    val joiningDate: String? = "",
    val mobileNumber: String? = "",
    val name: String? = "",
    val otherFields: List<OtherField> = arrayListOf(),
    val profileId: String? = "",
    val tokenId: String? = "",
    var sdkVersion: String? = "",
    var deviceToken: String? = "",
){
    init {
        sdkVersion = BuildConfig.VERSION_NAME
    }
}