package com.tilismtech.tellotalksdk.data.network.module.newMessages

import com.tilismtech.tellotalksdk.data.db.entities.CarousalData
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotChild

data class ChatbotNode(
    val carousalData: List<CarousalData>,
    val chatbotId: String,
    val chatbotName: Any,
    val childType: String,
    val children: List<ChatbotChild>,
    val description: String,
    val formData: List<Any>,
    val id: Int,
    val image: Any,
    val name: String,
    val parentId: Int,
    val title: String,
    val type: String,
    val voteData: List<Any>
)