package com.tilismtech.tellotalksdk.data.network.module.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChatFormRequest {

    @SerializedName("profileId")
    @Expose
    private String profileId;
    @SerializedName("formId")
    @Expose
    private String formId;

    public ChatFormRequest() {
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }
}
