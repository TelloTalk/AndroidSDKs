package com.tilismtech.tellotalksdk.data.network.module.requests

import com.google.gson.annotations.SerializedName

data class TokenAPIRequest(

    @SerializedName("profileId") val profileId: String,
    @SerializedName("token") val token: TokenObjectRequest,



    )
