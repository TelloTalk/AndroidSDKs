package com.tilismtech.tellotalksdk.data.network.module.responses;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ChatFormResponse implements Parcelable {

    @SerializedName("formId")
    @Expose
    private String formId;
    @SerializedName("formTitle")
    @Expose
    private String formTitle;
    @SerializedName("formDescription")
    @Expose
    private String formDescription;
    @SerializedName("fieldList")
    @Expose
    private ArrayList<FormFieldResponse> fieldList = null;

    protected ChatFormResponse(Parcel in) {
        formId = in.readString();
        formTitle = in.readString();
        formDescription = in.readString();
        fieldList = in.createTypedArrayList(FormFieldResponse.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(formId);
        dest.writeString(formTitle);
        dest.writeString(formDescription);
        dest.writeTypedList(fieldList);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ChatFormResponse> CREATOR = new Creator<ChatFormResponse>() {
        @Override
        public ChatFormResponse createFromParcel(Parcel in) {
            return new ChatFormResponse(in);
        }

        @Override
        public ChatFormResponse[] newArray(int size) {
            return new ChatFormResponse[size];
        }
    };

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getFormTitle() {
        return formTitle;
    }

    public void setFormTitle(String formTitle) {
        this.formTitle = formTitle;
    }

    public String getFormDescription() {
        return formDescription;
    }

    public void setFormDescription(String formDescription) {
        this.formDescription = formDescription;
    }

    public ArrayList<FormFieldResponse> getFieldList() {
        return fieldList;
    }

    public void setFieldList(ArrayList<FormFieldResponse> fieldList) {
        this.fieldList = fieldList;
    }
}
