package com.tilismtech.tellotalksdk.data.network.module.responses;


import com.google.gson.annotations.SerializedName;

/**
 * Created by lpt-034 on 07/01/2019.
 */

public class BlockListResponse {

    @SerializedName("blockprofileId")
    private String blockprofileId;


    public BlockListResponse(String blockprofileId) {
        this.blockprofileId = blockprofileId;
    }

    public String getBlockprofileId() {
        return blockprofileId;
    }

    public void setBlockprofileId(String blockprofileId) {
        this.blockprofileId = blockprofileId;
    }
}
