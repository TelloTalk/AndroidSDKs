package com.tilismtech.tellotalksdk.data.network.module.sendMessage


data class MessageRequestModel(
    val chatId: String?="",
    val message: String?="",
    val messageId: String?="",
    var profileId: String?="",
    val sentDate: String?="",
    var tempProfileId: String?="",
    var chatbotID: String?="",
    var chatbotNodeId: String?="",
    val chatBotMsg: Boolean? = false,
    val msgType: String?="text",
    val replyMsgId: String?="",
    val caption: String?="",
    val receiverId: String?="",
    val originalFileName: String?="",
    val thumbnail: String?="",
    val viewObject: String?="",
    val isDeleted: Boolean? = false,
    val isEdited: Boolean?= false
)