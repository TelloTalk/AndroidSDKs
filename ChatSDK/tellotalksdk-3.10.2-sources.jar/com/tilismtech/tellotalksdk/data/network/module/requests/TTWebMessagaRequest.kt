package com.tilismtech.tellotalksdk.data.network.module.requests

import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import com.tilismtech.tellotalksdk.data.db.entities.ButtonDet
import com.tilismtech.tellotalksdk.data.db.entities.ChatbotNode
import com.tilismtech.tellotalksdk.data.network.module.newMessages.ChatBotMessageResponse
import com.tilismtech.tellotalksdk.data.network.module.responses.ChannelCommandResponse

data class TTWebMessagaRequest(
        @PrimaryKey
        @SerializedName("messageId")
        var messageId: String = "",
        @SerializedName("caption")
        var caption: String? = "",
        @SerializedName("customData")
        var customData: String? = "",
        @SerializedName("msgDate")
        var msgDate: Long=0L,
        @SerializedName("message")
        var message: String? = "",
        @SerializedName("replyMsgId")
        var replyMsgId: String? = "",
        @SerializedName("profileId")
        var profileId: String? = "",
        @SerializedName("msgType")
        var msgType: String? = "",
        @SerializedName("isDeleted")
        var isDeleted: Boolean? = false,
        @SerializedName("isEdited")
        var isEdited: Boolean? =false,
        @SerializedName("receiverId")
        var receiverId: String? = "",
        @SerializedName("thumbnail")
        var thumbnail: String? = "",
        @SerializedName("viewObject")
        var viewObject: String? = "",
        @SerializedName("chatId")
        var chatId: String? = "",
        @SerializedName("departmentId", alternate = ["departmentid"])
        var departmentId: String? = "",
        @SerializedName("sentDate")
        var sentDate: Long? = 0L,
        @SerializedName("departmentName")
        var departmentName: String? = "",
        @SerializedName("viewId")
        var viewId: String? = "",
        @SerializedName("viewDet")
        var viewDet: ChannelCommandResponse? = null,
        @SerializedName("viewOptionId")
        var viewOptionId: String? = "",
        @SerializedName("originalFileName")
        var originalFileName: String? = "",
        @SerializedName("msgHeading")
        var msgHeading: String? = "",
        @SerializedName("msgURL")
        var msgURL: String? = "",
        @SerializedName("dType", alternate = ["departmentType"])
        var dptType: String? = "2",
        @SerializedName("buttonDet")
        var buttonDet: ArrayList<ButtonDet>?= arrayListOf(),
        @SerializedName("departmentName_u")
        var departmentName_u: String? = "",
        @SerializedName("dImage")
        var dImage: String? = "",
        @SerializedName("readDate")
        var readDate: String? = "0",
        @SerializedName("deliveryDate")
        var deliveryDate: String? = "0",
        @SerializedName("audioLength")
        var audioLength: String? = "",
        @SerializedName("campaignId")
        var campaignId: String? = "",
        @SerializedName("msgExpTime")
        var msgExpTime: Long? = 0L,
        @SerializedName("chatbotNode")
        var chatbotNode: ChatbotNode? = null,
        @SerializedName("chatbotID")
        var chatbotID: String? = "",
        @SerializedName("agentAvatar")
        var agentAvatar: String? = ""
){
        constructor(
                messageId: String,
                caption: String?,
                msgDate: Long,
                message: String?,
                replyMsgId: String?,
                profileId: String?,
                msgType: String?,
                isDeleted: Boolean,
                isEdited: Boolean,
                receiverId: String?,
                thumbnail: String?,
                viewObject: String?,
                chatId: String?
        ) : this() {
                this.messageId = messageId
                this.caption = caption
                this.msgDate = msgDate
                this.message = message
                this.replyMsgId = replyMsgId
                this.profileId = profileId
                this.msgType = msgType
                this.isDeleted = isDeleted
                this.isEdited = isEdited
                this.receiverId = receiverId
                this.thumbnail = thumbnail
                this.viewObject = viewObject
                this.chatId = chatId
        }

        constructor(chatBotModel: ChatBotMessageResponse?) : this(){
                this.messageId = chatBotModel?.messageId.toString()
                this.caption = ""
                this.msgDate = chatBotModel?.msgDate ?:0L
                this.message = chatBotModel?.message
                this.replyMsgId = ""
                this.profileId = chatBotModel?.profileId
                this.msgType = chatBotModel?.msgType
                this.isDeleted = chatBotModel?.isDeleted
                this.isEdited = chatBotModel?.isEdited
                this.receiverId = chatBotModel?.receiverId
                this.thumbnail = ""
                this.viewObject = ""
                this.viewId = chatBotModel?.viewId
                this.departmentId = chatBotModel?.departmentId.toString()
                this.customData = chatBotModel?.customData
                this.chatId = chatBotModel?.chatId
                this.chatbotID = chatBotModel?.chatbotID
                this.chatbotNode = ChatbotNode()
        }
}