package com.tilismtech.tellotalksdk.data.network.module.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FeedBackRequest {
    @SerializedName("profileId")
    @Expose
    private String profileId;

    public FeedBackRequest(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }
}
