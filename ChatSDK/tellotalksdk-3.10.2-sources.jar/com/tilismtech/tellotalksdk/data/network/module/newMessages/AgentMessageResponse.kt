package com.tilismtech.tellotalksdk.data.network.module.newMessages

import com.google.gson.annotations.SerializedName
import com.tilismtech.tellotalksdk.data.network.module.requests.TTMessageReceipt
import com.tilismtech.tellotalksdk.data.network.module.requests.TTWebMessagaRequest

data class AgentMessageResponse(
    @field:SerializedName("Messages") var messages: ArrayList<TTWebMessagaRequest> = arrayListOf(),
    @field:SerializedName("Receipts") var receipts: List<TTMessageReceipt>? = listOf()
)
