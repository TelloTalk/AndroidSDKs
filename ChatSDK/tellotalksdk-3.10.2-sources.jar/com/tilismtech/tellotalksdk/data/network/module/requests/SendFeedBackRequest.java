package com.tilismtech.tellotalksdk.data.network.module.requests;

import com.google.gson.annotations.SerializedName;

public class SendFeedBackRequest {

    @SerializedName("profileId")
    private String profileId;
    @SerializedName("chatId")
    private int chatId;
    @SerializedName("rating1")
    private String rating1;
    @SerializedName("rating2")
    private String rating2;

    public SendFeedBackRequest() {
    }

    public SendFeedBackRequest(String profileId, int chatId, String rating1, String rating2) {
        this.profileId = profileId;
        this.chatId = chatId;
        this.rating1 = rating1;
        this.rating2 = rating2;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public int getChatId() {
        return chatId;
    }

    public void setChatId(int chatId) {
        this.chatId = chatId;
    }

    public String getRating1() {
        return rating1;
    }

    public void setRating1(String rating1) {
        this.rating1 = rating1;
    }

    public String getRating2() {
        return rating2;
    }

    public void setRating2(String rating2) {
        this.rating2 = rating2;
    }
}
