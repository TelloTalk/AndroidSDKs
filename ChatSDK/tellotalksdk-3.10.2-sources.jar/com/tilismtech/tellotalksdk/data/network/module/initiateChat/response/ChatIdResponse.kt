package com.tilismtech.tellotalksdk.data.network.module.initiateChat.response

data class ChatIdResponse(
    val `data`: Data,
    val statusCode: Int
)