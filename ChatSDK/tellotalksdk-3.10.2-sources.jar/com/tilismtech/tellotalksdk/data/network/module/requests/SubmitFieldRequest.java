package com.tilismtech.tellotalksdk.data.network.module.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tilismtech.tellotalksdk.data.network.module.responses.SubmitFieldOption;

import java.util.List;

public class SubmitFieldRequest {

    @SerializedName("fieldId")
    @Expose
    private String fieldId;
    @SerializedName("fieldValue")
    @Expose
    private String fieldValue;
    @SerializedName("fieldOptions")
    @Expose
    private List<SubmitFieldOption> fieldOptions = null;

    public SubmitFieldRequest(String fieldId, String fieldValue, List<SubmitFieldOption> fieldOptions) {
        this.fieldId = fieldId;
        this.fieldValue = fieldValue;
        this.fieldOptions = fieldOptions;
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    public List<SubmitFieldOption> getFieldOptions() {
        return fieldOptions;
    }

    public void setFieldOptions(List<SubmitFieldOption> fieldOptions) {
        this.fieldOptions = fieldOptions;
    }



}
