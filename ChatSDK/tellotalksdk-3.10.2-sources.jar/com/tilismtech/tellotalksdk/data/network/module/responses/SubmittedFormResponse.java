package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SubmittedFormResponse {

    @SerializedName("agentId")
    @Expose
    private String agentId;
    @SerializedName("profileId")
    @Expose
    private String profileId;
    @SerializedName("formId")
    @Expose
    private String formId;
    @SerializedName("Mobile")
    @Expose
    private String mobile;
    @SerializedName("cName")
    @Expose
    private String cName;
    @SerializedName("cType")
    @Expose
    private String cType;
    @SerializedName("cCity")
    @Expose
    private String cCity;
    @SerializedName("BookingId")
    @Expose
    private String bookingId;
    @SerializedName("chatId")
    @Expose
    private String chatId;
    @SerializedName("chatNextAction")
    @Expose
    private String chatNextAction;
    @SerializedName("formDataMasterId")
    @Expose
    private String formDataMasterId;
    @SerializedName("formTitle")
    @Expose
    private String formTitle;
    @SerializedName("messageId")
    @Expose
    private String messageId;
    @SerializedName("masterId")
    @Expose
    private String masterId;
    @SerializedName("nodeId")
    @Expose
    private String nodeId;
    @SerializedName("formData")
    @Expose
    private List<SubmittedFormFieldResponse> formData;


    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getcType() {
        return cType;
    }

    public void setcType(String cType) {
        this.cType = cType;
    }

    public String getcCity() {
        return cCity;
    }

    public void setcCity(String cCity) {
        this.cCity = cCity;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    public String getChatNextAction() {
        return chatNextAction;
    }

    public void setChatNextAction(String chatNextAction) {
        this.chatNextAction = chatNextAction;
    }

    public String getFormDataMasterId() {
        return formDataMasterId;
    }

    public void setFormDataMasterId(String formDataMasterId) {
        this.formDataMasterId = formDataMasterId;
    }

    public String getFormTitle() {
        return formTitle;
    }

    public void setFormTitle(String formTitle) {
        this.formTitle = formTitle;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public List<SubmittedFormFieldResponse> getFormData() {
        return formData;
    }

    public void setFormData(List<SubmittedFormFieldResponse> formData) {
        this.formData = formData;
    }
}
