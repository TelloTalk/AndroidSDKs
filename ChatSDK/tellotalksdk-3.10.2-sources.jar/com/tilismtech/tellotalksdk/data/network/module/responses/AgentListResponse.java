package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tilismtech.tellotalksdk.data.db.entities.AgentModel;

import java.util.List;

public class AgentListResponse {

    @SerializedName("expectedTime")
    @Expose
    private String expectedTime;
    @SerializedName("agentList")
    @Expose
    private List<AgentModel> agentList = null;

    public String getExpectedTime() {
        return expectedTime;
    }

    public void setExpectedTime(String expectedTime) {
        this.expectedTime = expectedTime;
    }

    public List<AgentModel> getAgentList() {
        return agentList;
    }

    public void setAgentList(List<AgentModel> agentList) {
        this.agentList = agentList;
    }

}
