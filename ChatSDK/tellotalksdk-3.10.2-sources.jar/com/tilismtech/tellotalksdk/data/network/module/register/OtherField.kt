package com.tilismtech.tellotalksdk.data.network.module.register

data class OtherField(
    val value: String? ="",
    val label: String? = "",
    val key: String? = "",
)