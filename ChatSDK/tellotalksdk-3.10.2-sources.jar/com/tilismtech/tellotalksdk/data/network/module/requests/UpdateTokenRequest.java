package com.tilismtech.tellotalksdk.data.network.module.requests;


import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * Created by lpt-034 on 07/01/2019.
 */

public class UpdateTokenRequest {

    @SerializedName("profileId")
    private String profileId;
    @SerializedName("tokenId")
    private String tokenId;
    @SerializedName("tokenDate")
    private Date tokenDate;


    public UpdateTokenRequest(String profileId, String tokenId, Date tokenDate) {
        this.profileId = profileId;
        this.tokenId = tokenId;
        this.tokenDate = tokenDate;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public Date getTokenDate() {
        return tokenDate;
    }

    public void setTokenDate(Date tokenDate) {
        this.tokenDate = tokenDate;
    }
}
