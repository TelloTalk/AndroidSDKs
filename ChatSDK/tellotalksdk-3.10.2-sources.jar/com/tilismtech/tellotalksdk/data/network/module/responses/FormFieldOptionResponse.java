package com.tilismtech.tellotalksdk.data.network.module.responses;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FormFieldOptionResponse implements Parcelable {

    @SerializedName("fieldOptionId")
    @Expose
    private final String fieldOptionId;
    @SerializedName("fieldOptionValue")
    @Expose
    private final String fieldOptionValue;
    @SerializedName("isOptionSelected")
    @Expose
    private  boolean isOptionSelected;

    public boolean isOptionSelected() {
        return isOptionSelected;
    }

    public void setOptionSelected(boolean optionSelected) {
        isOptionSelected = optionSelected;
    }

    protected FormFieldOptionResponse(Parcel in) {
        fieldOptionId = in.readString();
        fieldOptionValue = in.readString();
        isOptionSelected = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fieldOptionId);
        dest.writeString(fieldOptionValue);
        dest.writeByte((byte) (isOptionSelected ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<FormFieldOptionResponse> CREATOR = new Creator<FormFieldOptionResponse>() {
        @Override
        public FormFieldOptionResponse createFromParcel(Parcel in) {
            return new FormFieldOptionResponse(in);
        }

        @Override
        public FormFieldOptionResponse[] newArray(int size) {
            return new FormFieldOptionResponse[size];
        }
    };

    public String getFieldOptionId() {
        return fieldOptionId;
    }

    public String getFieldOptionValue() {
        return fieldOptionValue;
    }

}
