package com.tilismtech.tellotalksdk.data.network.module.responses;


import com.google.gson.annotations.SerializedName;

/**
 * Created by lpt-034 on 07/01/2019.
 */

public class BlockContactResponse {

    @SerializedName("blocked")
    private boolean blocked;

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }
}
