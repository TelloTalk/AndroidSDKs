package com.tilismtech.tellotalksdk.data.network.module.initiateChat;


import com.google.gson.annotations.SerializedName;

public class ChatIdRequest {

    @SerializedName("language")
    private String language;
    @SerializedName("profileId")
    private String profileId;
    @SerializedName("departmentId")
    private String departmentId;

    public ChatIdRequest() {
    }

    public ChatIdRequest(String language, String profileId, String departmentId) {
        this.language = language;
        this.profileId = profileId;
        this.departmentId = departmentId;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }
}
