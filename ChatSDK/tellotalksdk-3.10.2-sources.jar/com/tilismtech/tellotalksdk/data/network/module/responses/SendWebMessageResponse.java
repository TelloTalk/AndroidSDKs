package com.tilismtech.tellotalksdk.data.network.module.responses;


import com.google.gson.annotations.SerializedName;

import java.util.Date;

public class SendWebMessageResponse {

    @SerializedName("messageId")
    private String messageId;
    @SerializedName("messageTime")
    private Date messageTime;
    @SerializedName("ackType")
    private String ackType;

    public SendWebMessageResponse(String messageId, Date messageTime, String ackType) {
        this.messageId = messageId;
        this.messageTime = messageTime;
        this.ackType = ackType;
    }

    public SendWebMessageResponse(String messageId, Date messageTime) {
        this.messageId = messageId;
        this.messageTime = messageTime;
    }

    public String getAckType() {
        return ackType;
    }

    public void setAckType(String ackType) {
        this.ackType = ackType;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public Date getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(Date messageTime) {
        this.messageTime = messageTime;
    }

}
