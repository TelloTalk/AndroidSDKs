package com.tilismtech.tellotalksdk.data.network.module.register.response

data class Data(
    val AppName: String?="",
    val ChatList: String?="",
    val CorporateUser: String?="",
    val MessageAvailable: String?="",
    val StoreData: String?="",
    val SyncContact: String?="",
    val legacyToken: String?="",
    val enableJitsi: String?="false",
)