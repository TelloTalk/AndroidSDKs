package com.tilismtech.tellotalksdk.data.network.module.responses;


import com.google.gson.annotations.SerializedName;

public class ChoiceListResponse {

    @SerializedName("itemId")
    private String itemId;
    @SerializedName("itemName")
    private String itemName;
    @SerializedName("command")
    private String command;
    @SerializedName("type")
    private String type;
    @SerializedName("isSelected")
    private boolean isSelected;

    public ChoiceListResponse() {
    }

    public ChoiceListResponse(String itemId, String itemName, String command, String type, boolean isSelected) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.command = command;
        this.type = type;
        this.isSelected = isSelected;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
