package com.tilismtech.tellotalksdk.data.network.module.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class SubmitChatFormRequest {


    @SerializedName("profileId")
    @Expose
    private String profileId;
    @SerializedName("formId")
    @Expose
    private Integer formId;
    @SerializedName("formData")
    @Expose
    private ArrayList<SubmitFieldRequest> submitFieldRequests = null;
    @SerializedName("nodeId")
    @Expose
    private String nodeId;
    @SerializedName("chatId")
    @Expose
    private String chatId;
    @SerializedName("messageId")
    @Expose
    private String messageId;
    @SerializedName("masterId")
    @Expose
    private String masterId;

    public SubmitChatFormRequest() {
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public Integer getFormId() {
        return formId;
    }

    public void setFormId(Integer formId) {
        this.formId = formId;
    }

    public ArrayList<SubmitFieldRequest> getSubmitFieldRequests() {
        return submitFieldRequests;
    }

    public void setSubmitFieldRequests(ArrayList<SubmitFieldRequest> submitFieldRequests) {
        this.submitFieldRequests = submitFieldRequests;
    }
}
