package com.tilismtech.tellotalksdk.data.network.module.register.response

data class RegisterResponse(
    val `data`: Data = Data(),
    val statusCode: String?="",
    val message: String?=""
)