package com.tilismtech.tellotalksdk.data.network.module.receipt

data class ReceiptModel(
    var chatId: String? = "",
    var messageReceiptType: String? = "",
    var receiverId: String? = "",
    var messageIds: List<String>? = listOf(),
)