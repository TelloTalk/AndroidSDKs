package com.tilismtech.tellotalksdk.data.network.module.requests

import com.google.gson.annotations.SerializedName

data class TokenObjectRequest(


    @SerializedName("tokenString") val tokenString: String,
    @SerializedName("tokenType") val tokenType: String,
    @SerializedName("bundleId") val bundleId: String,
    @SerializedName("sandbox") val sandbox: Boolean,


    )