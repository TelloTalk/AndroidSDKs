package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FieldOptionResponse {

    @SerializedName("fieldOptionsDet")
    @Expose
    private String fieldOptionsDet;
    @SerializedName("fieldOptionsDetValue")
    @Expose
    private String fieldOptionsDetValue;
    @SerializedName("aFile")
    @Expose
    private String aFile;
    @SerializedName("aFileType")
    @Expose
    private String aFileType;

    public String getFieldOptionsDet() {
        return fieldOptionsDet;
    }

    public void setFieldOptionsDet(String fieldOptionsDet) {
        this.fieldOptionsDet = fieldOptionsDet;
    }

    public String getFieldOptionsDetValue() {
        return fieldOptionsDetValue;
    }

    public void setFieldOptionsDetValue(String fieldOptionsDetValue) {
        this.fieldOptionsDetValue = fieldOptionsDetValue;
    }

    public String getaFile() {
        return aFile;
    }

    public void setaFile(String aFile) {
        this.aFile = aFile;
    }

    public String getaFileType() {
        return aFileType;
    }

    public void setaFileType(String aFileType) {
        this.aFileType = aFileType;
    }
}
