package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ChannelCommandResponse {

    @SerializedName("body")
    private String body;
    @SerializedName("choicesOptions")
    private List<ChoiceListResponse> choices;
    @SerializedName("isSelected")
    private boolean isSelected;
    @SerializedName("msgType")
    private String msgType;


    public ChannelCommandResponse() {
    }

    public ChannelCommandResponse(String body, List<ChoiceListResponse> choices, boolean isSelected) {
        this.body = body;
        this.choices = choices;
        this.isSelected = isSelected;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public List<ChoiceListResponse> getChoices() {
        return choices;
    }

    public void setChoices(List<ChoiceListResponse> choices) {
        this.choices = choices;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
