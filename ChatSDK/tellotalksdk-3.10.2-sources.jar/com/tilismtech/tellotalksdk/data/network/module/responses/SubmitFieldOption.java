package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SubmitFieldOption {

    @SerializedName("aFile")
    @Expose
    private String aFile;
    @SerializedName("afileType")
    @Expose
    private String afileType;
    @SerializedName("fieldOptionsDet")
    @Expose
    private String fieldOptionsDet;

    public SubmitFieldOption(String aFile, String afileType, String fieldOptionsDet) {
        this.aFile = aFile;
        this.afileType = afileType;
        this.fieldOptionsDet = fieldOptionsDet;
    }

    public SubmitFieldOption() {
    }

    public String getFieldOptionsDet() {
        return fieldOptionsDet;
    }

    public void setFieldOptionsDet(String fieldOptionsDet) {
        this.fieldOptionsDet = fieldOptionsDet;
    }

    public String getaFile() {
        return aFile;
    }

    public void setaFile(String aFile) {
        this.aFile = aFile;
    }

    public String getAfileType() {
        return afileType;
    }

    public void setAfileType(String afileType) {
        this.afileType = afileType;
    }

}
