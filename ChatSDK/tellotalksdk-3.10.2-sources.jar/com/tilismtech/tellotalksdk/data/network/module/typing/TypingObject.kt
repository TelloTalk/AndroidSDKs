package com.tilismtech.tellotalksdk.data.network.module.typing

data class TypingObject(
    val profileId: String? = "",
    val typing: Boolean? = false,
    val chatId: String? = "",
)