package com.tilismtech.tellotalksdk.data.network.module.requests;

import android.net.Uri;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

public class ProgressRequestBody extends RequestBody {
    private File mFile;
    private String mPath;
    private UploadCallbacks mListener;
    private String content_type;

    private static final int DEFAULT_BUFFER_SIZE = 2048;

    public ProgressRequestBody(final File file, String content_type, final UploadCallbacks listener) {
        this.content_type = content_type;
        mFile = file;
        mListener = listener;
    }

    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    @Override
    public MediaType contentType() {
        Uri uri = Uri.fromFile(mFile);
        if (uri == null){
            return null;
        }
        return MediaType.parse(getMimeType(uri.toString()));
    }

    @Override
    public long contentLength() throws IOException {
        return mFile.length();
    }

    @Override
    public void writeTo(BufferedSink sink) throws IOException {
        long fileLength = mFile.length();
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        FileInputStream in = new FileInputStream(mFile);
        long uploaded = 0;

        try {
            int read;
            while ((read = in.read(buffer)) != -1) {


                uploaded += read;
                sink.write(buffer, 0, read);
                // update progress on UI thread
                if (mListener != null){
                    mListener.onProgressUpdate((int) (100 * uploaded / fileLength));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class ProgressUpdater implements Runnable {
        private long mUploaded;
        private long mTotal;

        public ProgressUpdater(long uploaded, long total) {
            mUploaded = uploaded;
            mTotal = total;
        }

        @Override
        public void run() {
            if (mListener != null){
                mListener.onProgressUpdate((int) (100 * mUploaded / mTotal));
            }
        }
    }

    public interface UploadCallbacks {
        public void onProgressUpdate(int percentage);
    }
}