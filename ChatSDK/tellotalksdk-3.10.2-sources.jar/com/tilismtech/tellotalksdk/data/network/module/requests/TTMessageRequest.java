package com.tilismtech.tellotalksdk.data.network.module.requests;

import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.util.Date;


public class TTMessageRequest {

    @PrimaryKey
    @NonNull
    @SerializedName("messageId")
    private String messageId;
    @SerializedName("profileId")
    private String profileId;
    @SerializedName("contactId")
    private String contactId;
    @SerializedName("receiverId")
    private String receiverId;
    @SerializedName("message")
    private String message;
    @SerializedName("msgType")
    private String msgType;
    @SerializedName("isDeleted")
    private boolean isDeleted;
    @SerializedName("isEdited")
    private boolean isEdited;
    @SerializedName("replyMsgId")
    private String replyMsgId;
    @SerializedName("msgDate")
    private Date msgDate;
    @SerializedName("sentDate")
    private Date sentDate;
    @SerializedName("caption")
    private String caption;
    @SerializedName("thumbnail")
    private String thumbnail;
    @SerializedName("customData")
    private String customData;

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public enum MsgType {
        TYPE_TEXT("text"),
        TYPE_IMAGE("image"),
        TYPE_VIDEO("video"),
        TYPE_AUDIO("audio"),
        TYPE_FILE("file"),
        TYPE_LOCATION("location"),
        TYPE_DELETED("deleted"),
        TYPE_DATE("date"),
        TYPE_UNREAD("unread"),
        TYPE_CHOICES("choices"),
        TYPE_CARDVIEWS("cardView"),
        TYPE_INVITE("invite_channel");

        public String name;

        MsgType(String name) {
            this.name = name;
        }
    }


    public TTMessageRequest(String profileId, String receiverId, String messageId, String message, String msgType, boolean isDeleted, boolean isEdited, String replyMsgId, Date msgDate, String caption, String thumbnail,String customData) {
        this.profileId = profileId;
        this.receiverId = receiverId;
        this.messageId = messageId;
        this.message = message;
        this.msgType = msgType;
        this.isDeleted = isDeleted;
        this.isEdited = isEdited;
        this.replyMsgId = replyMsgId;
        this.msgDate = msgDate;
        this.caption = caption;
        this.thumbnail = thumbnail;
        this.customData = customData;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

//    public Object getViewObject() {
//        return viewObject;
//    }
//
//    public void setViewObject(Object viewObject) {
//        this.viewObject = viewObject;
//    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public boolean isEdited() {
        return isEdited;
    }

    public void setEdited(boolean edited) {
        isEdited = edited;
    }

    public String getReplyMsgId() {
        return replyMsgId;
    }

    public void setReplyMsgId(String replyMsgId) {
        this.replyMsgId = replyMsgId;
    }

    public Date getMsgDate() {
        return msgDate;
    }

    public void setMsgDate(Date msgDate) {
        this.msgDate = msgDate;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getCustomData() {
        return customData;
    }

    public void setCustomData(String customData) {
        this.customData = customData;
    }
}
