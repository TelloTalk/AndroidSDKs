package com.tilismtech.tellotalksdk.data.network.module.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FeedBackResponse {


        @SerializedName("fbHeading")
        @Expose
        private String fbHeading;
        @SerializedName("fbHeading_u")
        @Expose
        private String fbHeadingU;
        @SerializedName("fbDescription")
        @Expose
        private String fbDescription;
        @SerializedName("fbDescription_u")
        @Expose
        private String fbDescriptionU;
        @SerializedName("fbOptions")
        @Expose
        private List<FbOption> fbOptions = null;

        public String getFbHeading() {
            return fbHeading;
        }

        public void setFbHeading(String fbHeading) {
            this.fbHeading = fbHeading;
        }

        public String getFbHeadingU() {
            return fbHeadingU;
        }

        public void setFbHeadingU(String fbHeadingU) {
            this.fbHeadingU = fbHeadingU;
        }

        public String getFbDescription() {
            return fbDescription;
        }

        public void setFbDescription(String fbDescription) {
            this.fbDescription = fbDescription;
        }

        public String getFbDescriptionU() {
            return fbDescriptionU;
        }

        public void setFbDescriptionU(String fbDescriptionU) {
            this.fbDescriptionU = fbDescriptionU;
        }

        public List<FbOption> getFbOptions() {
            return fbOptions;
        }

        public void setFbOptions(List<FbOption> fbOptions) {
            this.fbOptions = fbOptions;
        }



    public class FbOption {

        @SerializedName("fbOptionId")
        @Expose
        private String fbOptionId;
        @SerializedName("fbOptionDet")
        @Expose
        private String fbOptionDet;
        @SerializedName("fbOptionDet_u")
        @Expose
        private String fbOptionDetU;

        public String getFbOptionId() {
            return fbOptionId;
        }

        public void setFbOptionId(String fbOptionId) {
            this.fbOptionId = fbOptionId;
        }

        public String getFbOptionDet() {
            return fbOptionDet;
        }

        public void setFbOptionDet(String fbOptionDet) {
            this.fbOptionDet = fbOptionDet;
        }

        public String getFbOptionDetU() {
            return fbOptionDetU;
        }

        public void setFbOptionDetU(String fbOptionDetU) {
            this.fbOptionDetU = fbOptionDetU;
        }

    }
}
