package com.tilismtech.tellotalksdk.data.network.module.initiateChat.response

data class Data(
    val chatId: Int
)