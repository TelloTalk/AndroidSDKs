package com.tilismtech.tellotalksdk.data.network.module.requests;


import com.google.gson.annotations.SerializedName;

import java.util.Date;

public class TTMessageReceipt {

    @SerializedName("messageId")
    private String messageId;
    @SerializedName("ackType")
    private String ackType;
    @SerializedName("messageTime")
    private Date messageTime;
    @SerializedName("profileId")
    private String profileId;


    public enum AckType {
        SENT("sent"),
        DELIVERED("delivered"),
        READ("read"),
        FAIL("fail");
        public String name;

        AckType(String name) {
            this.name = name;
        }
    }

    public TTMessageReceipt(String messageId, String ackType, Date messageTime, String profileId) {
        this.messageId = messageId;
        this.ackType = ackType;
        this.messageTime = messageTime;
        this.profileId = profileId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getAckType() {
        return ackType;
    }

    public void setAckType(String ackType) {
        this.ackType = ackType;
    }

    public Date getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(Date messageTime) {
        this.messageTime = messageTime;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }
}
