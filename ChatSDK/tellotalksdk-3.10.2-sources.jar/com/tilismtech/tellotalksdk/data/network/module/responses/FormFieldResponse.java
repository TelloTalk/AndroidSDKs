package com.tilismtech.tellotalksdk.data.network.module.responses;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class FormFieldResponse implements Parcelable {


    @SerializedName("fieldId")
    @Expose
    private String fieldId;
    @SerializedName("fieldLabel")
    @Expose
    private String fieldLabel;
    @SerializedName("fieldDescription")
    @Expose
    private String fieldDescription;
    @SerializedName("isRequired")
    @Expose
    private String isRequired;
    @SerializedName("fieldType")
    @Expose
    private String fieldType;
    @SerializedName("fieldValidationType")
    @Expose
    private String fieldValidationType;
    @SerializedName("fieldMinValue")
    @Expose
    private String fieldMinValue;
    @SerializedName("fieldMaxValue")
    @Expose
    private String fieldMaxValue;
    @SerializedName("fieldRegExp")
    @Expose
    private String fieldRegExp;
    @SerializedName("fieldOptionList")
    @Expose
    private ArrayList<FormFieldOptionResponse> fieldOptionList = null;

    public enum FIELDREQUIRED {
        N,
        Y,
    }


    public enum NodeType {

        SHORTTEXT("ShortText"),
        URL("URL"),
        EMAIL("Email"),
        NUMERIC("Numeric"),
        DROPDOWNLIST("DropdownList"),
        DATESELECTOR("DateSelector"),
        TIMESELECTOR("TimeSelector"),
        LONGTEXT("LongText"),
        CHECKBOX("CheckBox"),
        OPTIONLIST("OptionList"),
        FILEUPLOAD("FileUpload");

        public String name;

        NodeType(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }


    protected FormFieldResponse(Parcel in) {
        fieldId = in.readString();
        fieldLabel = in.readString();
        fieldDescription = in.readString();
        isRequired = in.readString();
        fieldType = in.readString();
        fieldValidationType = in.readString();
        fieldMinValue = in.readString();
        fieldMaxValue = in.readString();
        fieldRegExp = in.readString();
        fieldOptionList = in.createTypedArrayList(FormFieldOptionResponse.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fieldId);
        dest.writeString(fieldLabel);
        dest.writeString(fieldDescription);
        dest.writeString(isRequired);
        dest.writeString(fieldType);
        dest.writeString(fieldValidationType);
        dest.writeString(fieldMinValue);
        dest.writeString(fieldMaxValue);
        dest.writeString(fieldRegExp);
        dest.writeTypedList(fieldOptionList);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<FormFieldResponse> CREATOR = new Creator<FormFieldResponse>() {
        @Override
        public FormFieldResponse createFromParcel(Parcel in) {
            return new FormFieldResponse(in);
        }

        @Override
        public FormFieldResponse[] newArray(int size) {
            return new FormFieldResponse[size];
        }
    };

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public String getFieldLabel() {
        return fieldLabel;
    }

    public void setFieldLabel(String fieldLabel) {
        this.fieldLabel = fieldLabel;
    }

    public String getFieldDescription() {
        return fieldDescription;
    }

    public void setFieldDescription(String fieldDescription) {
        this.fieldDescription = fieldDescription;
    }

    public String getIsRequired() {
        return isRequired;
    }

    public void setIsRequired(String isRequired) {
        this.isRequired = isRequired;
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    public String getFieldValidationType() {
        return fieldValidationType;
    }

    public void setFieldValidationType(String fieldValidationType) {
        this.fieldValidationType = fieldValidationType;
    }

    public String getFieldMinValue() {
        return fieldMinValue;
    }

    public void setFieldMinValue(String fieldMinValue) {
        this.fieldMinValue = fieldMinValue;
    }

    public String getFieldMaxValue() {
        return fieldMaxValue;
    }

    public void setFieldMaxValue(String fieldMaxValue) {
        this.fieldMaxValue = fieldMaxValue;
    }

    public String getFieldRegExp() {
        return fieldRegExp;
    }

    public void setFieldRegExp(String fieldRegExp) {
        this.fieldRegExp = fieldRegExp;
    }

    public ArrayList<FormFieldOptionResponse> getFieldOptionList() {
        return fieldOptionList;
    }

    public void setFieldOptionList(ArrayList<FormFieldOptionResponse> fieldOptionList) {
        this.fieldOptionList = fieldOptionList;
    }
}
