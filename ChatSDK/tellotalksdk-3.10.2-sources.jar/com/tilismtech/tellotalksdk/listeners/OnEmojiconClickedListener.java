package com.tilismtech.tellotalksdk.listeners;

public interface OnEmojiconClickedListener {
        void onEmojiIconClicked(String emojicon);
        boolean onBackSpace();
    }