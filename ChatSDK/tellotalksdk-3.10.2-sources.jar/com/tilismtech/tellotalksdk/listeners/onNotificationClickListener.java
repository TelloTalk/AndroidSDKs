package com.tilismtech.tellotalksdk.listeners;

public interface onNotificationClickListener {
    public void onNotificationClicked(String message_id, String broadcastFrom, String message_type, String campaignId);
}
