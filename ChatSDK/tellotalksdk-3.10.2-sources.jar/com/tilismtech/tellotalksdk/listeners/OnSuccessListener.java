package com.tilismtech.tellotalksdk.listeners;

public interface OnSuccessListener<T> {
    public void onSuccess(T object);
}
