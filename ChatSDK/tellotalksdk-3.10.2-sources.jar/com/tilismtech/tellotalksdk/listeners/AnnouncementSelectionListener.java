package com.tilismtech.tellotalksdk.listeners;

public interface AnnouncementSelectionListener {
    void onAnnouncementClicked(String message_id, String broadcastFrom, String message_type, String campaignId);
}
