package com.tilismtech.tellotalksdk.listeners;

public interface CallBack<T,K> {
    default void clicked(T item){

    }
    default void action(K item){

    }
    default void action(T item, K item2){

    }
}
