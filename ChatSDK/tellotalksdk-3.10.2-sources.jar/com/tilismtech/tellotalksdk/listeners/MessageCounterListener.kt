package com.tilismtech.tellotalksdk.listeners


interface MessageCounterListener {
    fun onMessageCountUpdate(count:Int)
    fun onAnnouncementCountUpdate(count:Int)
}
