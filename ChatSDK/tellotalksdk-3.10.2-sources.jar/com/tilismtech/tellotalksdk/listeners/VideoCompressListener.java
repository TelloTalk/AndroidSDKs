package com.tilismtech.tellotalksdk.listeners;

public interface VideoCompressListener {

    public void onVideoCompressionSuccess(String filepath);
    public void onVideoCompressionFailed();
    public void onProgress(int progress);
}