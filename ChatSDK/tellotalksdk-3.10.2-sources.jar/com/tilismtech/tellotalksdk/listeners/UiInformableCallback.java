package com.tilismtech.tellotalksdk.listeners;

public interface UiInformableCallback<T> extends UiCallback<T> {
    void inform(String text);
}
